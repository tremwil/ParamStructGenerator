/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MapGdRegionInfo_H
#define _PARAM_MapGdRegionInfo_H
#include <stdint.h>

// MAP_GD_REGION_ID_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MapGdRegionInfo {

	// NAME: Do you remove it from the NT version output? - NT版出力から外すか
	// DESC: Parameters marked with ○ are excluded in the NT version package. - ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// NAME: Reserve for package output 1 - パッケージ出力用リザーブ1
	// DESC: Reserve for package output 1 - パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// NAME: Reserve for package output 2 - パッケージ出力用リザーブ2
	// DESC: Reserve for package output 2 - パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// NAME: Map region ID - マップ地方ID 
	// DESC: Map for GD use Local identification ID [00-99: Open, 1000-9999: Legacy] - GD用途のマップ地方識別ID[00-99：オープン、1000-9999：レガシー]
	uint32_t mapRegionId_004;

	// NAME: Reserve - リザーブ
	// DESC: Reserve - リザーブ
	uint8_t Reserve_008[24];

} MapGdRegionInfo;

#endif
