/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SoundCommonIngameParam_H
#define _PARAM_SoundCommonIngameParam_H
#include <stdint.h>

// SOUND_COMMON_INGAME_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SoundCommonIngameParam {

	// NAME: Parameter Key string - パラメータのKey文字列
	// DESC: Key string of the parameter - パラメータのKey文字列です
	char ParamKeyStr_000[32];

	// NAME: Parameter Value string - パラメータのValue文字列
	// DESC: Value string of the parameter - パラメータのValue文字列です
	char ParamValueStr_020[32];

} SoundCommonIngameParam;

#endif
