/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SoundCutsceneParam_H
#define _PARAM_SoundCutsceneParam_H
#include <stdint.h>

// SOUND_CUTSCENE_PARAM_ST
// Data Version: 5
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SoundCutsceneParam {

	// NAME: Do you remove it from the NT version output? - NT版出力から外すか
	// DESC: Parameters marked with ○ are excluded in the NT version package. - ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// NAME: Reserve for package output 1 - パッケージ出力用リザーブ1
	// DESC: Reserve for package output 1 - パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// NAME: Reserve for package output 2 - パッケージ出力用リザーブ2
	// DESC: Reserve for package output 2 - パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// NAME: Reverb type in cutscenes - カットシーン中のリバーブタイプ
	// DESC: Specifies the reverb type to apply during the cutscene - カットシーン中に適応するリバーブタイプを指定します
	uint8_t ReverbType_004;

	// NAME: pad0 - pad0
	uint8_t pad0_005[3];

	// NAME: Normal BGM behavior at the start of cutscenes - カットシーン開始時通常BGM挙動
	// DESC: Specifies normal BGM behavior at the start of cutscenes - カットシーン開始時通常BGM挙動を指定します
	int16_t BgmBehaviorTypeOnStart_008;

	// NAME: One-shot BGM behavior at the start of the cutscene - カットシーン開始時ワンショットBGM挙動
	// DESC: Specifies the one-shot BGM behavior at the start of the cutscene - カットシーン開始時ワンショットBGM挙動を指定します
	int16_t OneShotBgmBehaviorOnStart_00A;

	// NAME: SEID (category: p) specification to post at the end of the cutscene (-1: do not post) - カットシーン終了時にポストするSEID（カテゴリ：p)指定(-1:ポストしない)
	// DESC: SEID (category: p) specification to post at the end of the cutscene (-1: do not post) - カットシーン終了時にポストするSEID（カテゴリ：p)指定(-1:ポストしない)
	int32_t PostPlaySeId_00C;

	// NAME: Post at the end of the cutscene SEID_Skip (category: p) specified (-1: do not post) - カットシーン終了時にポストするSEID_スキップ時（カテゴリ：p)指定(-1:ポストしない)
	// DESC: SEID_ for skipping to post at the end of the cutscene (category: p) specified (-1: not posted) - カットシーン終了時にポストするSEID_スキップ時用（カテゴリ：p)指定(-1:ポストしない)
	int32_t PostPlaySeIdForSkip_010;

	// NAME: Cutscene drawing time to unmute immediately after entering [seconds] (less than 0: not canceled in drawing time) - 入場直後ミュート解除するカットシーン描画時間[秒](0より小さい：描画時間で解除しない)
	// DESC: Cutscene drawing time to unmute immediately after entering [seconds] (less than 0: not canceled in drawing time) - 入場直後のミュート解除するカットシーン描画時間[秒](0より小さい：描画時間で解除しない)
	float EnterMapMuteStopTimeOnDrawCutscene_014;

	// NAME: Reserve - リザーブ
	// DESC: Reserve - リザーブ
	uint8_t reserved_018[8];

} SoundCutsceneParam;

#endif
