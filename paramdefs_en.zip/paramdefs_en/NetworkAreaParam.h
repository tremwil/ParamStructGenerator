/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_NetworkAreaParam_H
#define _PARAM_NetworkAreaParam_H
#include <stdint.h>

// NETWORK_AREA_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _NetworkAreaParam {

	// NAME: Cell size X - セルサイズX
	// DESC: Cell size X - セルサイズX
	float cellSizeX_000;

	// NAME: Cell size Y - セルサイズY
	// DESC: Cell size Y - セルサイズY
	float cellSizeY_004;

	// NAME: Cell size Z - セルサイズZ
	// DESC: Cell size Z - セルサイズZ
	float cellSizeZ_008;

	// NAME: Cell offset X - セルオフセットX
	// DESC: Cell offset X - セルオフセットX
	float cellOffsetX_00C;

	// NAME: Cell offset Y - セルオフセットY
	// DESC: Cell offset Y - セルオフセットY
	float cellOffsetY_010;

	// NAME: Cell offset Z - セルオフセットZ
	// DESC: Cell offset Z - セルオフセットZ
	float cellOffsetZ_014;

	// NAME: Effective bloodstain / death illusion - 血痕・死亡幻影有効
	// DESC: Effective bloodstain / death illusion - 血痕・死亡幻影有効
	uint8_t enableBloodstain_018: 1;

	// NAME: Blood character valid - 血文字有効
	// DESC: Blood character valid - 血文字有効
	uint8_t enableBloodMessage_018: 1;

	// NAME: Phantom effective - 幻影有効
	// DESC: Phantom effective - 幻影有効
	uint8_t enableGhost_018: 1;

	// NAME: Multiplayer enabled - マルチプレイ有効
	// DESC: Multiplayer enabled - マルチプレイ有効
	uint8_t enableMultiPlay_018: 1;

	// NAME: Ring search enabled - 指輪検索有効
	// DESC: Is it a search target for ring search? (Area called Kanemori Ash Spirit / Relief Blue Spirit) - 指輪検索の検索対象か？（鐘守灰霊・救援青霊として呼ばれるエリア）
	uint8_t enableRingSearch_018: 1;

	// NAME: Intrusion search enabled - 乱入検索有効
	// DESC: Is it the target of intrusion search? - 乱入検索の対象か？
	uint8_t enableBreakInSearch_018: 1;

	// NAME: dummy - ダミー
	uint8_t dummy_018[3];

} NetworkAreaParam;

#endif
