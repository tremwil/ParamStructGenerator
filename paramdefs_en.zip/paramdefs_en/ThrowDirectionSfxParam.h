/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ThrowDirectionSfxParam_H
#define _PARAM_ThrowDirectionSfxParam_H
#include <stdint.h>

// THROW_DIRECTION_SFX_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 106
typedef struct _ThrowDirectionSfxParam {

	// NAME: 0 - 0
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_00_000;

	// NAME: 1 - 1
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_01_004;

	// NAME: 2 - 2
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_02_008;

	// NAME: 3 - 3
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_03_00C;

	// NAME: Four - 4
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_04_010;

	// NAME: Five - 5
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_05_014;

	// NAME: 6 - 6
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_06_018;

	// NAME: 7 - 7
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_07_01C;

	// NAME: 8 - 8
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_08_020;

	// NAME: 9 - 9
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_09_024;

	// NAME: Ten - 10
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_10_028;

	// NAME: 11 11 - 11
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_11_02C;

	// NAME: 12 - 12
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_12_030;

	// NAME: 13 - 13
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_13_034;

	// NAME: 14 - 14
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_14_038;

	// NAME: 15 - 15
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_15_03C;

	// NAME: 16 16 - 16
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_16_040;

	// NAME: 17 17 - 17
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_17_044;

	// NAME: 18 18 - 18
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_18_048;

	// NAME: 19 19 - 19
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_19_04C;

	// NAME: 20 - 20
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_20_050;

	// NAME: twenty one - 21
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_21_054;

	// NAME: twenty two - 22
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_22_058;

	// NAME: twenty three - 23
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_23_05C;

	// NAME: twenty four - 24
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_24_060;

	// NAME: twenty five - 25
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_25_064;

	// NAME: 26 - 26
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_26_068;

	// NAME: 27 - 27
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_27_06C;

	// NAME: 28 28 - 28
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_28_070;

	// NAME: 29 - 29
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_29_074;

	// NAME: 30 - 30
	// DESC: ID of SFX to use - 使用するSFXのID
	int32_t sfxId_30_078;

	// NAME: pad - パッド
	// DESC: pad - pad
	uint8_t pad1_07C[20];

} ThrowDirectionSfxParam;

#endif
