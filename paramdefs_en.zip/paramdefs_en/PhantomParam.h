/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PhantomParam_H
#define _PARAM_PhantomParam_H
#include <stdint.h>

// PHANTOM_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _PhantomParam {

	// NAME: A - A
	// DESC: Edge color A. - エッジ色Aです。
	float edgeColorA_000;

	// NAME: A - A
	// DESC: The front color is A. - 正面色Aです。
	float frontColorA_004;

	// NAME: A - A
	// DESC: Diffuse multiplication color A. - ディフューズ乗算色Aです。
	float diffMulColorA_008;

	// NAME: A - A
	// DESC: Specular multiplication color A. - スペキュラ乗算色Aです。
	float specMulColorA_00C;

	// NAME: A - A
	// DESC: Light color A. - ライト色Aです。
	float lightColorA_010;

	// NAME: R - R
	// DESC: Edge color R. - エッジ色Rです。
	uint8_t edgeColorR_014;

	// NAME: G - G
	// DESC: Edge color G. - エッジ色Gです。
	uint8_t edgeColorG_015;

	// NAME: B - B
	// DESC: Edge color B. - エッジ色Bです。
	uint8_t edgeColorB_016;

	// NAME: R - R
	// DESC: The front color is R. - 正面色Rです。
	uint8_t frontColorR_017;

	// NAME: G - G
	// DESC: The front color is G. - 正面色Gです。
	uint8_t frontColorG_018;

	// NAME: B - B
	// DESC: Front color B. - 正面色Bです。
	uint8_t frontColorB_019;

	// NAME: R - R
	// DESC: Diffuse multiplication color R. - ディフューズ乗算色Rです。
	uint8_t diffMulColorR_01A;

	// NAME: G - G
	// DESC: Diffuse multiplication color G. - ディフューズ乗算色Gです。
	uint8_t diffMulColorG_01B;

	// NAME: B - B
	// DESC: Diffuse multiplication color B. - ディフューズ乗算色Bです。
	uint8_t diffMulColorB_01C;

	// NAME: R - R
	// DESC: Specular multiplication color R. - スペキュラ乗算色Rです。
	uint8_t specMulColorR_01D;

	// NAME: G - G
	// DESC: Specular multiplication color G. - スペキュラ乗算色Gです。
	uint8_t specMulColorG_01E;

	// NAME: B - B
	// DESC: Specular multiplication color B. - スペキュラ乗算色Bです。
	uint8_t specMulColorB_01F;

	// NAME: R - R
	// DESC: Light color R. - ライト色Rです。
	uint8_t lightColorR_020;

	// NAME: G - G
	// DESC: Light color G. - ライト色Gです。
	uint8_t lightColorG_021;

	// NAME: B - B
	// DESC: Light color B. - ライト色Bです。
	uint8_t lightColorB_022;

	// NAME: Reserve - 予備
	uint8_t reserve_023[1];

	// NAME: α - α
	// DESC: The overall transparency. - 全体の透過度です。
	float alpha_024;

	// NAME: Blend rate - ブレンド率
	// DESC: The blend ratio. - ブレンド率です。
	float blendRate_028;

	// NAME: α type - α種類
	// DESC: The type of alpha blend. - αブレンドの種類です。
	uint8_t blendType_02C;

	// NAME: Whether to perform edge color subtraction - エッジ色減算を行うか
	// DESC: Whether to perform edge color subtraction. - エッジ色減算を行うかです。
	uint8_t isEdgeSubtract_02D;

	// NAME: Whether to perform front color subtraction - 正面色減算を行うか
	// DESC: Is it front color subtraction? - 正面色減算を行うかです。
	uint8_t isFrontSubtract_02E;

	// NAME: Do not do 2pass - 2passを行わない
	// DESC: Do you not do 2pass? - 2passを行わないかです。
	uint8_t isNo2Pass_02F;

	// NAME: Edge width - エッジの幅
	// DESC: Edge width - エッジの幅
	float edgePower_030;

	// NAME: Glow strength - Glowの強さ
	// DESC: Glow strength - Glowの強さ
	float glowScale_034;

} PhantomParam;

#endif
