/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WetAspectParam_H
#define _PARAM_WetAspectParam_H
#include <stdint.h>

// WET_ASPECT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WetAspectParam {

	// NAME: Base color value R - ベースカラー 値R
	// DESC: Base color color R. - ベースカラー色Rです。
	uint8_t baseColorR_000;

	// NAME: Base color value G - ベースカラー 値G
	// DESC: Base color color G. - ベースカラー色Gです。
	uint8_t baseColorG_001;

	// NAME: Base color value B - ベースカラー 値B
	// DESC: Base color color B. - ベースカラー色Bです。
	uint8_t baseColorB_002;

	// NAME: Spare 1 - 予備1
	uint8_t reserve_0_003[1];

	// NAME: Base color% - ベースカラー ％
	// DESC: Base color override rate. - ベースカラーのオーバーライド率です。 
	float baseColorA_004;

	// NAME: Metallic value - メタリック 値
	// DESC: It's metallic. - メタリックです。
	uint8_t metallic_008;

	// NAME: Spare 2 - 予備2
	uint8_t reserve_1_009[1];

	// NAME: Spare 3 - 予備3
	uint8_t reserve_2_00A[1];

	// NAME: Spare 4 - 予備4
	uint8_t reserve_3_00B[1];

	// NAME: Metallic% - メタリック ％
	// DESC: Metallic override rate. - メタリックのオーバーライド率です。
	float metallicRate_00C;

	// NAME: Shininess% - シャイニネス ％
	// DESC: Shininess override rate. - シャイニネスのオーバーライド率です。
	float shininessRate_010;

	// NAME: Shininess value - シャイニネス 値
	// DESC: Shininess. - シャイニネスです。 
	uint8_t shininess_014;

	// NAME: Spare 5 - 予備5
	uint8_t reserve_4_015[11];

} WetAspectParam;

#endif
