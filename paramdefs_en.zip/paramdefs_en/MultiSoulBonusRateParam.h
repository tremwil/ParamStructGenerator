/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MultiSoulBonusRateParam_H
#define _PARAM_MultiSoulBonusRateParam_H
#include <stdint.h>

// MULTI_SOUL_BONUS_RATE_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MultiSoulBonusRateParam {

	// NAME: host - ホスト
	// DESC: Host reward soul multiplier - ホストの報酬ソウル倍率
	float host_000;

	// NAME: White sign - 白サイン
	// DESC: Cooperation sign white spirit reward soul multiplier - 協力サインの白霊の報酬ソウル倍率
	float WhiteGhost_None_004;

	// NAME: Gold spirit (sun) - 金霊（太陽）
	// DESC: Cooperative sign gold spirit reward soul multiplier - 協力サインの金霊の報酬ソウル倍率
	float WhiteGhost_Umbasa_008;

	// NAME: White berserker - 白バーサーカー
	// DESC: Cooperation sign white Berserker reward soul multiplier - 協力サインの白バーサーカーの報酬ソウル倍率
	float WhiteGhost_Berserker_00C;

	// NAME: Red sign - 赤サイン
	// DESC: Hostile sign red spirit reward soul multiplier - 敵対サインの赤霊の報酬ソウル倍率
	float BlackGhost_None_Sign_010;

	// NAME: Red gold spirit (signature) - 赤金霊（サイン）
	// DESC: Hostile sign red gold spirit reward soul multiplier - 敵対サインの赤金霊の報酬ソウル倍率
	float BlackGhost_Umbasa_Sign_014;

	// NAME: Red berserker (sign) - 赤バーサーカー（サイン）
	// DESC: Hostile sign red berserker reward soul multiplier - 敵対サインの赤バーサーカーの報酬ソウル倍率
	float BlackGhost_Berserker_Sign_018;

	// NAME: Invasion - 侵入
	// DESC: Invasion reward Soul multiplier - 侵入の報酬ソウル倍率
	float BlackGhost_None_Invade_01C;

	// NAME: Red Gold Spirit (Invasion) - 赤金霊（侵入）
	// DESC: Invasion Orb's Red Gold Spirit Reward Soul Multiplier - 侵入オーブの赤金霊の報酬ソウル倍率
	float BlackGhost_Umbasa_Invade_020;

	// NAME: Red berserker (invasion) - 赤バーサーカー（侵入）
	// DESC: Invasion Orb Red Berserker Reward Soul Multiplier - 侵入オーブの赤バーサーカーの報酬ソウル倍率
	float BlackGhost_Berserker_Invade_024;

	// NAME: Relief guest - 救援ゲスト
	// DESC: Relief guest reward soul multiplier - 救援ゲストの報酬ソウル倍率
	float RedHunter1_028;

	// NAME: Red Scare Spirit 2 - 赤狩り霊２
	// DESC: Red Scare Spirit 2 Reward Soul Multiplier - 赤狩り霊２の報酬ソウル倍率
	float RedHunter2_02C;

	// NAME: Map Guardian Spirit (Forest) - マップ守護霊(森)
	// DESC: Map Guardian Spirit (Forest) Reward Soul Magnification - マップ守護霊（森）の報酬ソウル倍率
	float GuardianOfForest_030;

	// NAME: Map Guardian (Anor) - マップ守護霊(アノール)
	// DESC: Map Guardian Spirit (Anor) Reward Soul Multiplier - マップ守護霊(アノール)の報酬ソウル倍率
	float GuardianOfAnor_034;

	// NAME: Arena - 闘技場
	// DESC: Arena reward soul multiplier - 闘技場の報酬ソウル倍率
	float BattleRoyal_038;

	// NAME: Yellow robe's old man - 黄衣の翁
	// DESC: Yellow robe's old man's reward soul multiplier - 黄衣の翁の報酬ソウル倍率
	float YellowMonk_03C;

	// NAME: pad - pad
	uint8_t pad1_040[64];

} MultiSoulBonusRateParam;

#endif
