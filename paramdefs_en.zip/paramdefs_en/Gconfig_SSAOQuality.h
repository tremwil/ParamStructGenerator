/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_SSAOQuality_H
#define _PARAM_Gconfig_SSAOQuality_H
#include <stdint.h>

// CS_SSAO_QUALITY_DETAIL
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_SSAOQuality {

	// NAME: SSAO enabled - SSAO有効
	// DESC: SSAO enabled - SSAO有効
	uint8_t enabled_000;

	// NAME: Reprojection enabled - リプロジェクション有効
	// DESC: When reprojection is forcibly enabled, Prevent Ghost is also enabled. - リプロジェクション強制有効の時は、PreventGhostも有効になる
	uint8_t cs_reprojEnabledType_001;

	// NAME: Bilateral upscale effective - バイラテラルアップスケール有効
	// DESC: Bilateral upscale effective - バイラテラルアップスケール有効
	uint8_t cs_upScaleEnabledType_002;

	// NAME: Valid to use normals - 法線使用有効
	// DESC: Valid to use normals - 法線使用有効
	uint8_t cs_useNormalEnabledType_003;

	// NAME: dmy - dmy
	uint8_t dmy_004[1];

} Gconfig_SSAOQuality;

#endif
