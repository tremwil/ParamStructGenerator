/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SoundCommonSystemParam_H
#define _PARAM_SoundCommonSystemParam_H
#include <stdint.h>

// SOUND_COMMON_SYSTEM_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 202
typedef struct _SoundCommonSystemParam {

	// NAME: Parameter Key string - パラメータのKey文字列
	// DESC: Key string of the parameter - パラメータのKey文字列です
	char ParamKeyStr_000[32];

	// NAME: Parameter Value string - パラメータのValue文字列
	// DESC: Value string of the parameter - パラメータのValue文字列です
	char ParamValueStr_020[32];

} SoundCommonSystemParam;

#endif
