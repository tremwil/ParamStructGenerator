/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MapGridCreateHeightLimitInfo_H
#define _PARAM_MapGridCreateHeightLimitInfo_H
#include <stdint.h>

// MAP_GRID_CREATE_HEIGHT_LIMIT_INFO_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MapGridCreateHeightLimitInfo {

	// NAME: Grid can be constructed Height Min [m] - グリッド構築可能高さMin[m]
	// DESC: Minimum height that can be built in the grid [m]. (LOD 2 units) - グリッド構築可能高さ最小値[m]。(LOD2単位)
	float GridEnableCreateHeightMin_000;

	// NAME: Grid can be constructed Height Max [m] - グリッド構築可能高さMax[m]
	// DESC: Maximum height that can be constructed in the grid [m]. (LOD 2 units) - グリッド構築可能高さ最大値[m]。(LOD2単位)
	float GridEnableCreateHeightMax_004;

	// NAME: Reserve - リザーブ
	// DESC: Reserve - リザーブ
	uint8_t Reserve_008[24];

} MapGridCreateHeightLimitInfo;

#endif
