/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_FootSfxParam_H
#define _PARAM_FootSfxParam_H
#include <stdint.h>

// FOOT_SFX_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _FootSfxParam {

	// NAME: SFX identifier: 00 - SFX識別子：00
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_00_000;

	// NAME: SFX identifier: 01 - SFX識別子：01
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_01_004;

	// NAME: SFX identifier: 02 - SFX識別子：02
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_02_008;

	// NAME: SFX identifier: 03 - SFX識別子：03
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_03_00C;

	// NAME: SFX identifier: 04 - SFX識別子：04
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_04_010;

	// NAME: SFX identifier: 05 - SFX識別子：05
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_05_014;

	// NAME: SFX identifier: 06 - SFX識別子：06
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_06_018;

	// NAME: SFX identifier: 07 - SFX識別子：07
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_07_01C;

	// NAME: SFX identifier: 08 - SFX識別子：08
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_08_020;

	// NAME: SFX identifier: 09 - SFX識別子：09
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_09_024;

	// NAME: SFX identifier: 10 - SFX識別子：10
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_10_028;

	// NAME: SFX identifier: 11 - SFX識別子：11
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_11_02C;

	// NAME: SFX identifier: 12 - SFX識別子：12
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_12_030;

	// NAME: SFX identifier: 13 - SFX識別子：13
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_13_034;

	// NAME: SFX identifier: 14 - SFX識別子：14
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_14_038;

	// NAME: SFX identifier: 15 - SFX識別子：15
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_15_03C;

	// NAME: SFX identifier: 16 - SFX識別子：16
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_16_040;

	// NAME: SFX identifier: 17 - SFX識別子：17
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_17_044;

	// NAME: SFX identifier: 18 - SFX識別子：18
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_18_048;

	// NAME: SFX identifier: 19 - SFX識別子：19
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_19_04C;

	// NAME: SFX identifier: 20 - SFX識別子：20
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_20_050;

	// NAME: SFX identifier: 21 - SFX識別子：21
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_21_054;

	// NAME: SFX identifier: 22 - SFX識別子：22
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_22_058;

	// NAME: SFX identifier: 23 - SFX識別子：23
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_23_05C;

	// NAME: SFX identifier: 24 - SFX識別子：24
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_24_060;

	// NAME: SFX identifier: 25 - SFX識別子：25
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_25_064;

	// NAME: SFX identifier: 26 - SFX識別子：26
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_26_068;

	// NAME: SFX identifier: 27 - SFX識別子：27
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_27_06C;

	// NAME: SFX identifier: 28 - SFX識別子：28
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_28_070;

	// NAME: SFX identifier: 29 - SFX識別子：29
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_29_074;

	// NAME: SFX identifier: 30 - SFX識別子：30
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_30_078;

	// NAME: SFX identifier: 31 - SFX識別子：31
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_31_07C;

	// NAME: SFX identifier: 32 - SFX識別子：32
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_32_080;

	// NAME: SFX identifier: 33 - SFX識別子：33
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_33_084;

	// NAME: SFX identifier: 34 - SFX識別子：34
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_34_088;

	// NAME: SFX identifier: 35 - SFX識別子：35
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_35_08C;

	// NAME: SFX identifier: 36 - SFX識別子：36
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_36_090;

	// NAME: SFX identifier: 37 - SFX識別子：37
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_37_094;

	// NAME: SFX identifier: 38 - SFX識別子：38
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_38_098;

	// NAME: SFX identifier: 39 - SFX識別子：39
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_39_09C;

	// NAME: SFX identifier: 40 - SFX識別子：40
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_40_0A0;

	// NAME: SFX identifier: 41 - SFX識別子：41
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_41_0A4;

	// NAME: SFX identifier: 42 - SFX識別子：42
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_42_0A8;

	// NAME: SFX identifier: 43 - SFX識別子：43
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_43_0AC;

	// NAME: SFX identifier: 44 - SFX識別子：44
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_44_0B0;

	// NAME: SFX identifier: 45 - SFX識別子：45
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_45_0B4;

	// NAME: SFX identifier: 46 - SFX識別子：46
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_46_0B8;

	// NAME: SFX identifier: 47 - SFX識別子：47
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_47_0BC;

	// NAME: SFX identifier: 48 - SFX識別子：48
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_48_0C0;

	// NAME: SFX identifier: 49 - SFX識別子：49
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_49_0C4;

	// NAME: SFX identifier: 50 - SFX識別子：50
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_50_0C8;

	// NAME: SFX identifier: 51 - SFX識別子：51
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_51_0CC;

	// NAME: SFX identifier: 52 - SFX識別子：52
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_52_0D0;

	// NAME: SFX identifier: 53 - SFX識別子：53
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_53_0D4;

	// NAME: SFX identifier: 54 - SFX識別子：54
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_54_0D8;

	// NAME: SFX identifier: 55 - SFX識別子：55
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_55_0DC;

	// NAME: SFX identifier: 56 - SFX識別子：56
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_56_0E0;

	// NAME: SFX identifier: 57 - SFX識別子：57
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_57_0E4;

	// NAME: SFX identifier: 58 - SFX識別子：58
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_58_0E8;

	// NAME: SFX identifier: 59 - SFX識別子：59
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_59_0EC;

	// NAME: SFX identifier: 60 - SFX識別子：60
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_60_0F0;

	// NAME: SFX identifier: 61 - SFX識別子：61
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_61_0F4;

	// NAME: SFX identifier: 62 - SFX識別子：62
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_62_0F8;

	// NAME: SFX identifier: 63 - SFX識別子：63
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_63_0FC;

	// NAME: SFX identifier: 64 - SFX識別子：64
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_64_100;

	// NAME: SFX identifier: 65 - SFX識別子：65
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_65_104;

	// NAME: SFX identifier: 66 - SFX識別子：66
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_66_108;

	// NAME: SFX identifier: 67 - SFX識別子：67
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_67_10C;

	// NAME: SFX identifier: 68 - SFX識別子：68
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_68_110;

	// NAME: SFX identifier: 69 - SFX識別子：69
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_69_114;

	// NAME: SFX identifier: 70 - SFX識別子：70
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_70_118;

	// NAME: SFX identifier: 71 - SFX識別子：71
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_71_11C;

	// NAME: SFX identifier: 72 - SFX識別子：72
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_72_120;

	// NAME: SFX identifier: 73 - SFX識別子：73
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_73_124;

	// NAME: SFX identifier: 74 - SFX識別子：74
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_74_128;

	// NAME: SFX identifier: 75 - SFX識別子：75
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_75_12C;

	// NAME: SFX identifier: 76 - SFX識別子：76
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_76_130;

	// NAME: SFX identifier: 77 - SFX識別子：77
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_77_134;

	// NAME: SFX identifier: 78 - SFX識別子：78
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_78_138;

	// NAME: SFX identifier: 79 - SFX識別子：79
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_79_13C;

	// NAME: SFX identifier: 80 - SFX識別子：80
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_80_140;

	// NAME: SFX identifier: 81 - SFX識別子：81
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_81_144;

	// NAME: SFX identifier: 82 - SFX識別子：82
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_82_148;

	// NAME: SFX identifier: 83 - SFX識別子：83
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_83_14C;

	// NAME: SFX identifier: 84 - SFX識別子：84
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_84_150;

	// NAME: SFX identifier: 85 - SFX識別子：85
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_85_154;

	// NAME: SFX identifier: 86 - SFX識別子：86
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_86_158;

	// NAME: SFX identifier: 87 - SFX識別子：87
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_87_15C;

	// NAME: SFX identifier: 88 - SFX識別子：88
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_88_160;

	// NAME: SFX identifier: 89 - SFX識別子：89
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_89_164;

	// NAME: SFX identifier: 90 - SFX識別子：90
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_90_168;

	// NAME: SFX identifier: 91 - SFX識別子：91
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_91_16C;

	// NAME: SFX identifier: 92 - SFX識別子：92
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_92_170;

	// NAME: SFX identifier: 93 - SFX識別子：93
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_93_174;

	// NAME: SFX identifier: 94 - SFX識別子：94
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_94_178;

	// NAME: SFX identifier: 95 - SFX識別子：95
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_95_17C;

	// NAME: SFX identifier: 96 - SFX識別子：96
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_96_180;

	// NAME: SFX identifier: 97 - SFX識別子：97
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_97_184;

	// NAME: SFX identifier: 98 - SFX識別子：98
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_98_188;

	// NAME: SFX identifier: 99 - SFX識別子：99
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_99_18C;

	// NAME: SFX identifier: 100 - SFX識別子：100
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_100_190;

	// NAME: SFX identifier: 101 - SFX識別子：101
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_101_194;

	// NAME: SFX identifier: 102 - SFX識別子：102
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_102_198;

	// NAME: SFX identifier: 103 - SFX識別子：103
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_103_19C;

	// NAME: SFX identifier: 104 - SFX識別子：104
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_104_1A0;

	// NAME: SFX identifier: 105 - SFX識別子：105
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_105_1A4;

	// NAME: SFX identifier: 106 - SFX識別子：106
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_106_1A8;

	// NAME: SFX identifier: 107 - SFX識別子：107
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_107_1AC;

	// NAME: SFX identifier: 108 - SFX識別子：108
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_108_1B0;

	// NAME: SFX identifier: 109 - SFX識別子：109
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_109_1B4;

	// NAME: SFX identifier: 110 - SFX識別子：110
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_110_1B8;

	// NAME: SFX identifier: 111 - SFX識別子：111
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_111_1BC;

	// NAME: SFX identifier: 112 - SFX識別子：112
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_112_1C0;

	// NAME: SFX identifier: 113 - SFX識別子：113
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_113_1C4;

	// NAME: SFX identifier: 114 - SFX識別子：114
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_114_1C8;

	// NAME: SFX identifier: 115 - SFX識別子：115
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_115_1CC;

	// NAME: SFX identifier: 116 - SFX識別子：116
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_116_1D0;

	// NAME: SFX identifier: 117 - SFX識別子：117
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_117_1D4;

	// NAME: SFX identifier: 118 - SFX識別子：118
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_118_1D8;

	// NAME: SFX identifier: 119 - SFX識別子：119
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_119_1DC;

	// NAME: SFX identifier: 120 - SFX識別子：120
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_120_1E0;

	// NAME: SFX identifier: 121 - SFX識別子：121
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_121_1E4;

	// NAME: SFX identifier: 122 - SFX識別子：122
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_122_1E8;

	// NAME: SFX identifier: 123 - SFX識別子：123
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_123_1EC;

	// NAME: SFX identifier: 124 - SFX識別子：124
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_124_1F0;

	// NAME: SFX identifier: 125 - SFX識別子：125
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_125_1F4;

	// NAME: SFX identifier: 126 - SFX識別子：126
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_126_1F8;

	// NAME: SFX identifier: 127 - SFX識別子：127
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_127_1FC;

	// NAME: SFX identifier: 128 - SFX識別子：128
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_128_200;

	// NAME: SFX identifier: 129 - SFX識別子：129
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_129_204;

	// NAME: SFX identifier: 130 - SFX識別子：130
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_130_208;

	// NAME: SFX identifier: 131 - SFX識別子：131
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_131_20C;

	// NAME: SFX identifier: 132 - SFX識別子：132
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_132_210;

	// NAME: SFX identifier: 133 - SFX識別子：133
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_133_214;

	// NAME: SFX identifier: 134 - SFX識別子：134
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_134_218;

	// NAME: SFX identifier: 135 - SFX識別子：135
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_135_21C;

	// NAME: SFX identifier: 136 - SFX識別子：136
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_136_220;

	// NAME: SFX identifier: 137 - SFX識別子：137
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_137_224;

	// NAME: SFX identifier: 138 - SFX識別子：138
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_138_228;

	// NAME: SFX identifier: 139 - SFX識別子：139
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_139_22C;

	// NAME: SFX identifier: 140 - SFX識別子：140
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_140_230;

	// NAME: SFX identifier: 141 - SFX識別子：141
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_141_234;

	// NAME: SFX identifier: 142 - SFX識別子：142
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_142_238;

	// NAME: SFX identifier: 143 - SFX識別子：143
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_143_23C;

	// NAME: SFX identifier: 144 - SFX識別子：144
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_144_240;

	// NAME: SFX identifier: 145 - SFX識別子：145
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_145_244;

	// NAME: SFX identifier: 146 - SFX識別子：146
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_146_248;

	// NAME: SFX identifier: 147 - SFX識別子：147
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_147_24C;

	// NAME: SFX identifier: 148 - SFX識別子：148
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_148_250;

	// NAME: SFX identifier: 149 - SFX識別子：149
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_149_254;

	// NAME: SFX identifier: 150 - SFX識別子：150
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_150_258;

	// NAME: SFX identifier: 151 - SFX識別子：151
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_151_25C;

	// NAME: SFX identifier: 152 - SFX識別子：152
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_152_260;

	// NAME: SFX identifier: 153 - SFX識別子：153
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_153_264;

	// NAME: SFX identifier: 154 - SFX識別子：154
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_154_268;

	// NAME: SFX identifier: 155 - SFX識別子：155
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_155_26C;

	// NAME: SFX identifier: 156 - SFX識別子：156
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_156_270;

	// NAME: SFX identifier: 157 - SFX識別子：157
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_157_274;

	// NAME: SFX identifier: 158 - SFX識別子：158
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_158_278;

	// NAME: SFX identifier: 159 - SFX識別子：159
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_159_27C;

	// NAME: SFX identifier: 160 - SFX識別子：160
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_160_280;

	// NAME: SFX identifier: 161 - SFX識別子：161
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_161_284;

	// NAME: SFX identifier: 162 - SFX識別子：162
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_162_288;

	// NAME: SFX identifier: 163 - SFX識別子：163
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_163_28C;

	// NAME: SFX identifier: 164 - SFX識別子：164
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_164_290;

	// NAME: SFX identifier: 165 - SFX識別子：165
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_165_294;

	// NAME: SFX identifier: 166 - SFX識別子：166
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_166_298;

	// NAME: SFX identifier: 167 - SFX識別子：167
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_167_29C;

	// NAME: SFX identifier: 168 - SFX識別子：168
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_168_2A0;

	// NAME: SFX identifier: 169 - SFX識別子：169
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_169_2A4;

	// NAME: SFX identifier: 170 - SFX識別子：170
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_170_2A8;

	// NAME: SFX identifier: 171 - SFX識別子：171
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_171_2AC;

	// NAME: SFX identifier: 172 - SFX識別子：172
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_172_2B0;

	// NAME: SFX identifier: 173 - SFX識別子：173
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_173_2B4;

	// NAME: SFX identifier: 174 - SFX識別子：174
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_174_2B8;

	// NAME: SFX identifier: 175 - SFX識別子：175
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_175_2BC;

	// NAME: SFX identifier: 176 - SFX識別子：176
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_176_2C0;

	// NAME: SFX identifier: 177 - SFX識別子：177
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_177_2C4;

	// NAME: SFX identifier: 178 - SFX識別子：178
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_178_2C8;

	// NAME: SFX identifier: 179 - SFX識別子：179
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_179_2CC;

	// NAME: SFX identifier: 180 - SFX識別子：180
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_180_2D0;

	// NAME: SFX identifier: 181 - SFX識別子：181
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_181_2D4;

	// NAME: SFX identifier: 182 - SFX識別子：182
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_182_2D8;

	// NAME: SFX identifier: 183 - SFX識別子：183
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_183_2DC;

	// NAME: SFX identifier: 184 - SFX識別子：184
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_184_2E0;

	// NAME: SFX identifier: 185 - SFX識別子：185
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_185_2E4;

	// NAME: SFX identifier: 186 - SFX識別子：186
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_186_2E8;

	// NAME: SFX identifier: 187 - SFX識別子：187
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_187_2EC;

	// NAME: SFX identifier: 188 - SFX識別子：188
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_188_2F0;

	// NAME: SFX identifier: 189 - SFX識別子：189
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_189_2F4;

	// NAME: SFX identifier: 190 - SFX識別子：190
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_190_2F8;

	// NAME: SFX identifier: 191 - SFX識別子：191
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_191_2FC;

	// NAME: SFX identifier: 192 - SFX識別子：192
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_192_300;

	// NAME: SFX identifier: 193 - SFX識別子：193
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_193_304;

	// NAME: SFX identifier: 194 - SFX識別子：194
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_194_308;

	// NAME: SFX identifier: 195 - SFX識別子：195
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_195_30C;

	// NAME: SFX identifier: 196 - SFX識別子：196
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_196_310;

	// NAME: SFX identifier: 197 - SFX識別子：197
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_197_314;

	// NAME: SFX identifier: 198 - SFX識別子：198
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_198_318;

	// NAME: SFX identifier: 199 - SFX識別子：199
	// DESC: Numerical value entered in the "Foot effect identifier" item of the NPC parameter, numerical value entered in the "Additional foot effect identifier" item of the special effect parameter, SFX identifier set in the TAE action "Foot effect" - NPCパラメータの「フットエフェクト識別子」項目に入力された数値、特殊効果パラメータの「追加フットエフェクト識別子」項目に入力された数値、TAEアクション「フットエフェクト」に設定する、SFX識別子
	uint32_t sfxId_199_31C;

} FootSfxParam;

#endif
