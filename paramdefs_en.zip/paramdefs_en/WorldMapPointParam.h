/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WorldMapPointParam_H
#define _PARAM_WorldMapPointParam_H
#include <stdint.h>

// WORLD_MAP_POINT_PARAM_ST
// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WorldMapPointParam {

	// NAME: Do you remove it from the NT version output? - NT版出力から外すか
	// DESC: Parameters marked with ○ are excluded in the NT version package. - ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// NAME: Reserve for package output 1 - パッケージ出力用リザーブ1
	// DESC: Reserve for package output 1 - パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// NAME: Reserve for package output 2 - パッケージ出力用リザーブ2
	// DESC: Reserve for package output 2 - パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// NAME: Release event flag ID - 開放イベントフラグID
	// DESC: Event flag ID of open condition - 開放条件のイベントフラグID
	uint32_t eventFlagId_004;

	// NAME: Far-viewing platform discovery event flag ID - 遠見台発見イベントフラグID
	// DESC: Event flag ID to be set when found on the distant view - 遠見台で発見した際に立てるイベントフラグID
	uint32_t distViewEventFlagId_008;

	// NAME: Icon ID - アイコンID
	// DESC: Icon ID - アイコンID
	uint16_t iconId_00C;

	// NAME: BGM location information (inside the entrance area) - BGM用場所情報（入場領域内）
	// DESC: Bgm location type - Bgm場所タイプ
	int16_t bgmPlaceType_00E;

	// NAME: Is it a range icon? - 範囲アイコンか
	// DESC: Is it an icon that represents a range? Same size as the map - 範囲を表すアイコンか。地図に対して等倍になる
	uint8_t isAreaIcon_010: 1;

	// NAME: Tomidai mark_Coordinates overwrite - 遠見台目印_座標上書きするか
	// DESC: Whether to overwrite the coordinates when using it as a distant view marker - 遠見台目印として使うときに座標を上書きするか
	uint8_t isOverrideDistViewMarkPos_010: 1;

	// NAME: Whether to display when there is no text - テキストが無いときに表示するか
	// DESC: Do you want to display it even when there is no text? Basically, points are not displayed without text. Display without text when this flag is enabled - テキストが無いときにも表示するか。基本的にはテキストがなければポイントは表示しない。このフラグが有効なときにはテキストがなくても表示する
	uint8_t isEnableNoText_010: 1;

	// NAME: Pad 3 - パッド3
	uint8_t pad3_010: 5;

	// NAME: Overwrite distant view mark_area number - 遠見台目印上書き_エリア番号
	// DESC: AA part of mAA_BB_CC_DD - mAA_BB_CC_DD の AA 部分
	uint8_t areaNo_forDistViewMark_011;

	// NAME: Overwrite distant view mark_Grid X number - 遠見台目印上書き_グリッドX番号
	// DESC: BB part of mAA_BB_CC_DD - mAA_BB_CC_DD の BB 部分
	uint8_t gridXNo_forDistViewMark_012;

	// NAME: Overwrite distant view mark_Grid Z number - 遠見台目印上書き_グリッドZ番号
	// DESC: CC part of mAA_BB_CC_DD - mAA_BB_CC_DD の CC 部分
	uint8_t gridZNo_forDistViewMark_013;

	// NAME: Cleared event flag ID - クリア済イベントフラグID
	// DESC: Cleared event flag ID (0: always treated as cleared) - クリア済みイベントフラグID(0:常にクリア済み扱い)
	uint32_t clearedEventFlagId_014;

	// NAME: Display setting M00 - 表示設定M00
	// DESC: Whether to display with M00 - M00で表示するか
	uint8_t dispMask00_018: 1;

	// NAME: Display setting M01 - 表示設定M01
	// DESC: Whether to display with M01 - M01で表示するか
	uint8_t dispMask01_018: 1;

	// NAME: pad - パッド
	// DESC: pad2_0 - pad2_0
	uint8_t pad2_0_018: 6;

	// NAME: pad - パッド
	// DESC: pad2 - pad2
	uint8_t pad2_019[1];

	// NAME: Icon ID when distant view is found - 遠見台発見時アイコンID
	// DESC: Icon ID when distant view is found - 遠見台発見時アイコンID
	uint16_t distViewIconId_01A;

	// NAME: Icon angle [deg] - アイコン角度[deg]
	// DESC: Display icon rotation angle [deg] - 表示アイコンの回転角度[deg]
	float angle_01C;

	// NAME: Area number - エリア番号
	// DESC: AA part of mAA_BB_CC_DD - mAA_BB_CC_DD の AA 部分
	uint8_t areaNo_020;

	// NAME: Grid X number - グリッドX番号
	// DESC: BB part of mAA_BB_CC_DD - mAA_BB_CC_DD の BB 部分
	uint8_t gridXNo_021;

	// NAME: Grid Z number - グリッドZ番号
	// DESC: CC part of mAA_BB_CC_DD - mAA_BB_CC_DD の CC 部分
	uint8_t gridZNo_022;

	// NAME: Padding - パディング
	// DESC: Padding - パディング
	uint8_t pad_023[1];

	// NAME: X coordinate - X座標
	// DESC: X coordinate - X座標
	float posX_024;

	// NAME: Y coordinate - Y座標
	// DESC: Y coordinate (not used) - Y座標（使っていない）
	float posY_028;

	// NAME: Z coordinate - Z座標
	// DESC: Z coordinate - Z座標
	float posZ_02C;

	// NAME: Text ID - テキストID
	// DESC: The text ID to display. If the value is invalid (-1), nothing is displayed. - 表示するテキストID。無効値(-1)なら、何も表示しない
	int32_t textId1_030;

	// NAME: Occurrence event flag ID - 出現イベントフラグID
	// DESC: Display text Event flag ID. Display if the event flag is On. If the event flag ID (0) is invalid, it will be treated as On. - テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(0)なら、On扱いされる
	uint32_t textEnableFlagId1_034;

	// NAME: Hidden event flag ID - 非表示イベントフラグID
	// DESC: Hidden event flag ID of the text. If the event flag is On, it will not be displayed. It takes precedence over the display event flag ID. If the event flag ID (0) is invalid, it will be treated as Off. - テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(0)なら、Off扱いされる
	uint32_t textDisableFlagId1_038;

	// NAME: Text ID - テキストID
	// DESC: The text ID to display. If it is an invalid value (-2), nothing is displayed. - 表示するテキストID。無効値(-2)なら、何も表示しない
	int32_t textId2_03C;

	// NAME: Occurrence event flag ID - 出現イベントフラグID
	// DESC: Display text Event flag ID. Display if the event flag is On. If the event flag ID (1) is invalid, it will be treated as On. - テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(1)なら、On扱いされる
	uint32_t textEnableFlagId2_040;

	// NAME: Hidden event flag ID - 非表示イベントフラグID
	// DESC: Hidden event flag ID of the text. If the event flag is On, it will not be displayed. It takes precedence over the display event flag ID. If the event flag ID (1) is invalid, it will be treated as Off. - テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(1)なら、Off扱いされる
	uint32_t textDisableFlagId2_044;

	// NAME: Text ID - テキストID
	// DESC: The text ID to display. If it is an invalid value (-3), nothing is displayed. - 表示するテキストID。無効値(-3)なら、何も表示しない
	int32_t textId3_048;

	// NAME: Occurrence event flag ID - 出現イベントフラグID
	// DESC: Display text Event flag ID. Display if the event flag is On. If the event flag ID (2) is invalid, it will be treated as On. - テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(2)なら、On扱いされる
	uint32_t textEnableFlagId3_04C;

	// NAME: Hidden event flag ID - 非表示イベントフラグID
	// DESC: Hidden event flag ID of the text. If the event flag is On, it will not be displayed. It takes precedence over the display event flag ID. If the event flag ID (2) is invalid, it will be treated as Off. - テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(2)なら、Off扱いされる
	uint32_t textDisableFlagId3_050;

	// NAME: Text ID - テキストID
	// DESC: The text ID to display. If it is an invalid value (-4), nothing is displayed. - 表示するテキストID。無効値(-4)なら、何も表示しない
	int32_t textId4_054;

	// NAME: Occurrence event flag ID - 出現イベントフラグID
	// DESC: Display text Event flag ID. Display if the event flag is On. If the event flag ID (3) is invalid, it will be treated as On. - テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(3)なら、On扱いされる
	uint32_t textEnableFlagId4_058;

	// NAME: Hidden event flag ID - 非表示イベントフラグID
	// DESC: Hidden event flag ID of the text. If the event flag is On, it will not be displayed. It takes precedence over the display event flag ID. If the event flag ID (3) is invalid, it will be treated as Off. - テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(3)なら、Off扱いされる
	uint32_t textDisableFlagId4_05C;

	// NAME: Text ID - テキストID
	// DESC: The text ID to display. If it is an invalid value (-5), nothing is displayed. - 表示するテキストID。無効値(-5)なら、何も表示しない
	int32_t textId5_060;

	// NAME: Occurrence event flag ID - 出現イベントフラグID
	// DESC: Display text Event flag ID. Display if the event flag is On. If the event flag ID (4) is invalid, it will be treated as On. - テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(4)なら、On扱いされる
	uint32_t textEnableFlagId5_064;

	// NAME: Hidden event flag ID - 非表示イベントフラグID
	// DESC: Hidden event flag ID of the text. If the event flag is On, it will not be displayed. It takes precedence over the display event flag ID. If the event flag ID (4) is invalid, it will be treated as Off. - テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(4)なら、Off扱いされる
	uint32_t textDisableFlagId5_068;

	// NAME: Text ID - テキストID
	// DESC: The text ID to display. If it is an invalid value (-6), nothing is displayed. - 表示するテキストID。無効値(-6)なら、何も表示しない
	int32_t textId6_06C;

	// NAME: Occurrence event flag ID - 出現イベントフラグID
	// DESC: Display text Event flag ID. Display if the event flag is On. If the event flag ID (5) is invalid, it will be treated as On. - テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(5)なら、On扱いされる
	uint32_t textEnableFlagId6_070;

	// NAME: Hidden event flag ID - 非表示イベントフラグID
	// DESC: Hidden event flag ID of the text. If the event flag is On, it will not be displayed. It takes precedence over the display event flag ID. If the event flag ID (5) is invalid, it will be treated as Off. - テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(5)なら、Off扱いされる
	uint32_t textDisableFlagId6_074;

	// NAME: Text ID - テキストID
	// DESC: The text ID to display. If it is an invalid value (-7), nothing is displayed. - 表示するテキストID。無効値(-7)なら、何も表示しない
	int32_t textId7_078;

	// NAME: Occurrence event flag ID - 出現イベントフラグID
	// DESC: Display text Event flag ID. Display if the event flag is On. If the event flag ID (6) is invalid, it will be treated as On. - テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(6)なら、On扱いされる
	uint32_t textEnableFlagId7_07C;

	// NAME: Hidden event flag ID - 非表示イベントフラグID
	// DESC: Hidden event flag ID of the text. If the event flag is On, it will not be displayed. It takes precedence over the display event flag ID. If the event flag ID (6) is invalid, it will be treated as Off. - テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(6)なら、Off扱いされる
	uint32_t textDisableFlagId7_080;

	// NAME: Text ID - テキストID
	// DESC: The text ID to display. If it is an invalid value (-8), nothing is displayed. - 表示するテキストID。無効値(-8)なら、何も表示しない
	int32_t textId8_084;

	// NAME: Occurrence event flag ID - 出現イベントフラグID
	// DESC: Display text Event flag ID. Display if the event flag is On. If the event flag ID (7) is invalid, it will be treated as On. - テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(7)なら、On扱いされる
	uint32_t textEnableFlagId8_088;

	// NAME: Hidden event flag ID - 非表示イベントフラグID
	// DESC: Hidden event flag ID of the text. If the event flag is On, it will not be displayed. It takes precedence over the display event flag ID. If the event flag ID (7) is invalid, it will be treated as Off. - テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(7)なら、Off扱いされる
	uint32_t textDisableFlagId8_08C;

	// NAME: Text type - テキスト種別
	// DESC: Text type (place name, NPC name, ...) - テキストの種別(地名,NPC名,...)
	uint8_t textType1_090;

	// NAME: Text type - テキスト種別
	// DESC: Text type (place name, NPC name, ...) - テキストの種別(地名,NPC名,...)
	uint8_t textType2_091;

	// NAME: Text type - テキスト種別
	// DESC: Text type (place name, NPC name, ...) - テキストの種別(地名,NPC名,...)
	uint8_t textType3_092;

	// NAME: Text type - テキスト種別
	// DESC: Text type (place name, NPC name, ...) - テキストの種別(地名,NPC名,...)
	uint8_t textType4_093;

	// NAME: Text type - テキスト種別
	// DESC: Text type (place name, NPC name, ...) - テキストの種別(地名,NPC名,...)
	uint8_t textType5_094;

	// NAME: Text type - テキスト種別
	// DESC: Text type (place name, NPC name, ...) - テキストの種別(地名,NPC名,...)
	uint8_t textType6_095;

	// NAME: Text type - テキスト種別
	// DESC: Text type (place name, NPC name, ...) - テキストの種別(地名,NPC名,...)
	uint8_t textType7_096;

	// NAME: Text type - テキスト種別
	// DESC: Text type (place name, NPC name, ...) - テキストの種別(地名,NPC名,...)
	uint8_t textType8_097;

	// NAME: Distance stand ID0 - 遠見台ID0
	// DESC: Distance stand ID - 遠見台ID
	int32_t distViewId_098;

	// NAME: Distance viewing marker overwrite _X coordinates - 遠見台目印上書き_X座標
	// DESC: X coordinate - X座標
	float posX_forDistViewMark_09C;

	// NAME: Distance viewing mark overwrite Y coordinate - 遠見台目印上書きY座標
	// DESC: Y coordinate - Y座標
	float posY_forDistViewMark_0A0;

	// NAME: Distant mark overwrite Z coordinate - 遠見台目印上書きZ座標
	// DESC: Z coordinate - Z座標
	float posZ_forDistViewMark_0A4;

	// NAME: Distance stand ID1 - 遠見台ID1
	// DESC: Distance stand ID - 遠見台ID
	int32_t distViewId1_0A8;

	// NAME: Distance stand ID2 - 遠見台ID2
	// DESC: Distance stand ID - 遠見台ID
	int32_t distViewId2_0AC;

	// NAME: Distance stand ID3 - 遠見台ID3
	// DESC: Distance stand ID - 遠見台ID
	int32_t distViewId3_0B0;

	// NAME: Display zoom step - 表示ズームステップ
	// DESC: Zoom step to display map points (0 when zoomed out most, +1 for each zoom). Displayed when "<< Display zoom step >> ≤ Current zoom step". Default is 0 (always displayed) - 地図ポイントを表示するズームステップ（一番ズームアウトした状態が0、ズームするごとに+1）。「《表示ズームステップ》≦ 現在のズームステップ 」のときに表示される。デフォルトは 0（常に表示）
	uint8_t dispMinZoomStep_0B4;

	// NAME: Selectable zoom steps - 選択可能ズームステップ
	// DESC: Zoom step where map points can be selected (0 when zoomed out most, +1 for each zoom). Selectable when "<< Selectable zoom step >> ≤ Current enlargement stage". Default is 0 (always selectable) - 地図ポイントを選択可能なズームステップ（一番ズームアウトした状態が0、ズームするごとに+1）。「《選択可能ズームステップ》≦ 現在の拡大段階 」のときに選択可能。デフォルトは 0（常に選択可能）
	uint8_t selectMinZoomStep_0B5;

	// NAME: Admission display format - 入場表示形式
	// DESC: Admission display format. Map points to be displayed at the time of admission Types of admission FE - 入場表示形式。入場時に表示する地図ポイント入場FEの種類
	uint8_t entryFEType_0B6;

	// NAME: pad - パッド
	// DESC: pad3 - pad3
	uint8_t pad4_0B7[9];

	// NAME: unkC0 - unkC0
	int32_t unkC0_0C0;

	// NAME: unkC4 - unkC4
	int32_t unkC4_0C4;

	// NAME: unkC8 - unkC8
	int32_t unkC8_0C8;

	// NAME: unkCC - unkCC
	int32_t unkCC_0CC;

	// NAME: unkD0 - unkD0
	int32_t unkD0_0D0;

	// NAME: unkD4 - unkD4
	int32_t unkD4_0D4;

	// NAME: unkD8 - unkD8
	int32_t unkD8_0D8;

	// NAME: unkDC - unkDC
	int32_t unkDC_0DC;

	// NAME: unkE0 - unkE0
	int32_t unkE0_0E0;

	// NAME: unkE4 - unkE4
	int32_t unkE4_0E4;

	// NAME: unkE8 - unkE8
	int32_t unkE8_0E8;

	// NAME: unkEC - unkEC
	int32_t unkEC_0EC;

	// NAME: unkF0 - unkF0
	int32_t unkF0_0F0;

	// NAME: unkF4 - unkF4
	int32_t unkF4_0F4;

	// NAME: unkF8 - unkF8
	int32_t unkF8_0F8;

	// NAME: unkFC - unkFC
	int32_t unkFC_0FC;

} WorldMapPointParam;

#endif
