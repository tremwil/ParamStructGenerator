/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CharMakeMenuTopParam_H
#define _PARAM_CharMakeMenuTopParam_H
#include <stdint.h>

// CHARMAKEMENUTOP_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CharMakeMenuTopParam {

	// NAME: Command type - コマンドタイプ
	// DESC: Command type - コマンドの種別
	int32_t commandType_000;

	// NAME: Item text ID - 項目テキストID
	// DESC: ID of the text to be displayed - 表示するテキストのID
	int32_t captionId_004;

	// NAME: Face Param ID - 顔パラムID
	// DESC: Face Param ID - 顔パラムID
	int32_t faceParamId_008;

	// NAME: Table ID (male) - テーブルID（男性）
	// DESC: First ID (male) in the list of items to select. The command type is [Slider: Text ID of minimum label (n) and maximum label (n + 1), Color: ID of color table, Grid or text: First ID of character make list item, Other: Ignore] - 選択するアイテム一覧の先頭ID（男）。コマンドタイプが[スライダー：最小値ラベル(n)と最大値ラベル(n+1)のテキストID、カラー：カラーテーブルのID、グリッド or テキスト：キャラメイクリストアイテムの先頭ID、それ以外：無視]
	int32_t tableId_00C;

	// NAME: Display conditions - 表示条件
	// DESC: Conditions for displaying this command - このコマンドを表示する条件
	int32_t viewCondition_010;

	// NAME: Preview mode - プレビューモード
	// DESC: Display mode of the character model displayed in preview - プレビュー表示しているキャラクターモデルの表示モード
	int8_t previewMode_014;

	// NAME: reserve - 予約
	uint8_t reserved2_015[3];

	// NAME: Table ID (female) - テーブルID（女性）
	// DESC: For women with table ID. If -1, refer to for men - テーブルIDの女用。-1なら男用を参照する
	int32_t tableId2_018;

	// NAME: Referenced face Param ID - 参照先の顔パラムID
	// DESC: Face param ID of the matching destination for "matching to XX" - 「○○に合わせる」用の合わせ先の顔パラムID
	int32_t refFaceParamId_01C;

	// NAME: Referenced text ID - 参照先テキストID
	// DESC: Display text ID for "fit to XX" - 「○○に合わせる」用の表示テキストID
	int32_t refTextId_020;

	// NAME: 1 line help text ID (overwrite) - 1行ヘルプテキストID（上書き）
	// DESC: 1-line help text ID (-1: Get 1-line help with item text ID). Basically, item text ID = 1 line help text ID, but if you want to overwrite part of it, specify it with this parameter. - 1行ヘルプのテキストID(-1: 項目テキストIDで1行ヘルプを取得する)。基本的に項目テキストID＝1行ヘルプテキストIDになっているが、一部上書きしたいときにこのパラメータで指定する
	int32_t helpTextId_024;

	// NAME: Event flag ID - イベントフラグID
	// DESC: Event flag to unlock this item (0: invalid value). Invalid value will always be unlocked - この項目をアンロックするイベントフラグ(0:無効値)。無効値なら常にアンロックされる
	uint32_t unlockEventFlagId_028;

	// NAME: reserve - 予約
	uint8_t reserved_02C[4];

} CharMakeMenuTopParam;

#endif
