/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_FaceRangeParam_H
#define _PARAM_FaceRangeParam_H
#include <stdint.h>

// FACE_RANGE_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _FaceRangeParam {

	// NAME: Face part ID - 顔パーツID
	// DESC: Face part ID - 顔パーツID
	float face_partsId_000;

	// NAME: Skin color (R) - 肌の色(Ｒ)
	// DESC: Skin color (R) - 肌の色(Ｒ)
	float skin_color_R_004;

	// NAME: Skin color (G) - 肌の色(Ｇ)
	// DESC: Skin color (G) - 肌の色(Ｇ)
	float skin_color_G_008;

	// NAME: Skin color (B) - 肌の色(Ｂ)
	// DESC: Skin color (B) - 肌の色(Ｂ)
	float skin_color_B_00C;

	// NAME: Shiny skin - 肌のつや
	// DESC: Shiny skin - 肌のつや
	float skin_gloss_010;

	// NAME: pores - 毛穴
	// DESC: pores - 毛穴
	float skin_pores_014;

	// NAME: Blue beard - 青ひげ
	// DESC: Blue beard - 青ひげ
	float face_beard_018;

	// NAME: Bear - くま
	// DESC: Bear - くま
	float face_aroundEye_01C;

	// NAME: Bear color (R) - くまの色(R)
	// DESC: Bear color (R) - くまの色(R)
	float face_aroundEyeColor_R_020;

	// NAME: Bear color (G) - くまの色(G)
	// DESC: Bear color (G) - くまの色(G)
	float face_aroundEyeColor_G_024;

	// NAME: Bear color (B) - くまの色(B)
	// DESC: Bear color (B) - くまの色(B)
	float face_aroundEyeColor_B_028;

	// NAME: cheek - チーク
	// DESC: cheek - チーク
	float face_cheek_02C;

	// NAME: Teak color (R) - チークの色(R)
	// DESC: Teak color (R) - チークの色(R)
	float face_cheekColor_R_030;

	// NAME: Teak color (G) - チークの色(G)
	// DESC: Teak color (G) - チークの色(G)
	float face_cheekColor_G_034;

	// NAME: Teak color (B) - チークの色(B)
	// DESC: Teak color (B) - チークの色(B)
	float face_cheekColor_B_038;

	// NAME: Eyeline - アイライン
	// DESC: Eyeline - アイライン
	float face_eyeLine_03C;

	// NAME: Eyeliner color (R) - アイラインの色(R)
	// DESC: Eyeliner color (R) - アイラインの色(R)
	float face_eyeLineColor_R_040;

	// NAME: Eyeliner color (G) - アイラインの色(G)
	// DESC: Eyeliner color (G) - アイラインの色(G)
	float face_eyeLineColor_G_044;

	// NAME: Eyeliner color (B) - アイラインの色(B)
	// DESC: Eyeliner color (B) - アイラインの色(B)
	float face_eyeLineColor_B_048;

	// NAME: Eye shadow (bottom) - アイシャドウ(下)
	// DESC: Eye shadow (bottom) - アイシャドウ(下)
	float face_eyeShadowDown_04C;

	// NAME: Eyeshadow (bottom) color (R) - アイシャドウ(下)の色(R)
	// DESC: Eyeshadow (bottom) color (R) - アイシャドウ(下)の色(R)
	float face_eyeShadowDownColor_R_050;

	// NAME: Eyeshadow (bottom) color (G) - アイシャドウ(下)の色(G)
	// DESC: Eyeshadow (bottom) color (G) - アイシャドウ(下)の色(G)
	float face_eyeShadowDownColor_G_054;

	// NAME: Eyeshadow (bottom) color (B) - アイシャドウ(下)の色(B)
	// DESC: Eyeshadow (bottom) color (B) - アイシャドウ(下)の色(B)
	float face_eyeShadowDownColor_B_058;

	// NAME: Eye shadow (top) - アイシャドウ(上)
	// DESC: Eye shadow (top) - アイシャドウ(上)
	float face_eyeShadowUp_05C;

	// NAME: Eyeshadow (top) color (R) - アイシャドウ(上)の色(R)
	// DESC: Eyeshadow (top) color (R) - アイシャドウ(上)の色(R)
	float face_eyeShadowUpColor_R_060;

	// NAME: Eyeshadow (top) color (G) - アイシャドウ(上)の色(G)
	// DESC: Eyeshadow (top) color (G) - アイシャドウ(上)の色(G)
	float face_eyeShadowUpColor_G_064;

	// NAME: Eyeshadow (top) color (B) - アイシャドウ(上)の色(B)
	// DESC: Eyeshadow (top) color (B) - アイシャドウ(上)の色(B)
	float face_eyeShadowUpColor_B_068;

	// NAME: lipstick - 口紅
	// DESC: lipstick - 口紅
	float face_lip_06C;

	// NAME: Lipstick color (R) - 口紅の色(R)
	// DESC: Lipstick color (R) - 口紅の色(R)
	float face_lipColor_R_070;

	// NAME: Lipstick color (G) - 口紅の色(G)
	// DESC: Lipstick color (G) - 口紅の色(G)
	float face_lipColor_G_074;

	// NAME: Lipstick color (B) - 口紅の色(B)
	// DESC: Lipstick color (B) - 口紅の色(B)
	float face_lipColor_B_078;

	// NAME: Hair thickness - 体毛の濃さ
	// DESC: Hair thickness - 体毛の濃さ
	float body_hair_07C;

	// NAME: Hair color (R) - 体毛の色(R)
	// DESC: Hair color (R) - 体毛の色(R)
	float body_hairColor_R_080;

	// NAME: Hair color (G) - 体毛の色(G)
	// DESC: Hair color (G) - 体毛の色(G)
	float body_hairColor_G_084;

	// NAME: Hair color (B) - 体毛の色(B)
	// DESC: Hair color (B) - 体毛の色(B)
	float body_hairColor_B_088;

	// NAME: Eyeball part ID - 眼球パーツID
	// DESC: Eyeball part ID - 眼球パーツID
	float eye_partsId_08C;

	// NAME: Iris color (R) - 虹彩の色(Ｒ)
	// DESC: Right eye iris color (R) - 右目の虹彩の色(Ｒ)
	float eyeR_irisColor_R_090;

	// NAME: Iris color (G) - 虹彩の色(Ｇ)
	// DESC: Right eye iris color (G) - 右目の虹彩の色(Ｇ)
	float eyeR_irisColor_G_094;

	// NAME: Iris color (B) - 虹彩の色(Ｂ)
	// DESC: Right eye iris color (B) - 右目の虹彩の色(Ｂ)
	float eyeR_irisColor_B_098;

	// NAME: The size of the iris - 虹彩の大きさ
	// DESC: The size of the iris of the right eye - 右目の虹彩の大きさ
	float eyeR_irisScale_09C;

	// NAME: Cloudiness of the crystalline lens - 水晶体の濁り
	// DESC: Cloudiness of the crystalline lens of the right eye - 右目の水晶体の濁り
	float eyeR_cataract_0A0;

	// NAME: The turbid color of the crystalline lens (R) - 水晶体の濁りの色(Ｒ)
	// DESC: The turbid color of the crystalline lens of the right eye (R) - 右目の水晶体の濁りの色(Ｒ)
	float eyeR_cataractColor_R_0A4;

	// NAME: The turbid color of the crystalline lens (G) - 水晶体の濁りの色(Ｇ)
	// DESC: The turbid color of the crystalline lens of the right eye (G) - 右目の水晶体の濁りの色(Ｇ)
	float eyeR_cataractColor_G_0A8;

	// NAME: The turbid color of the crystalline lens (B) - 水晶体の濁りの色(Ｂ)
	// DESC: The turbid color of the crystalline lens of the right eye (B) - 右目の水晶体の濁りの色(Ｂ)
	float eyeR_cataractColor_B_0AC;

	// NAME: White eye color (R) - 白目の色(Ｒ)
	// DESC: White eye color of the right eye (R) - 右目の白目の色(Ｒ)
	float eyeR_scleraColor_R_0B0;

	// NAME: White eye color (G) - 白目の色(G)
	// DESC: White eye color of the right eye (G) - 右目の白目の色(G)
	float eyeR_scleraColor_G_0B4;

	// NAME: White eye color (B) - 白目の色(B)
	// DESC: White eye color of the right eye (B) - 右目の白目の色(B)
	float eyeR_scleraColor_B_0B8;

	// NAME: Position of the iris - 虹彩の位置
	// DESC: Position of the iris of the right eye - 右目の虹彩の位置
	float eyeR_irisDistance_0BC;

	// NAME: Iris color (R) - 虹彩の色(Ｒ)
	// DESC: Left eye iris color (R) - 左目の虹彩の色(Ｒ)
	float eyeL_irisColor_R_0C0;

	// NAME: Iris color (G) - 虹彩の色(Ｇ)
	// DESC: Left eye iris color (G) - 左目の虹彩の色(Ｇ)
	float eyeL_irisColor_G_0C4;

	// NAME: Iris color (B) - 虹彩の色(Ｂ)
	// DESC: Left eye iris color (B) - 左目の虹彩の色(Ｂ)
	float eyeL_irisColor_B_0C8;

	// NAME: The size of the iris - 虹彩の大きさ
	// DESC: The size of the iris of the left eye - 左目の虹彩の大きさ
	float eyeL_irisScale_0CC;

	// NAME: Cloudiness of the crystalline lens - 水晶体の濁り
	// DESC: Cloudiness of the crystalline lens of the left eye - 左目の水晶体の濁り
	float eyeL_cataract_0D0;

	// NAME: The turbid color of the crystalline lens (R) - 水晶体の濁りの色(Ｒ)
	// DESC: The turbid color of the crystalline lens of the left eye (R) - 左目の水晶体の濁りの色(Ｒ)
	float eyeL_cataractColor_R_0D4;

	// NAME: The turbid color of the crystalline lens (G) - 水晶体の濁りの色(Ｇ)
	// DESC: The turbid color of the crystalline lens of the left eye (G) - 左目の水晶体の濁りの色(Ｇ)
	float eyeL_cataractColor_G_0D8;

	// NAME: The turbid color of the crystalline lens (B) - 水晶体の濁りの色(Ｂ)
	// DESC: The turbid color of the crystalline lens of the left eye (B) - 左目の水晶体の濁りの色(Ｂ)
	float eyeL_cataractColor_B_0DC;

	// NAME: White eye color (R) - 白目の色(Ｒ)
	// DESC: White eye color of the left eye (R) - 左目の白目の色(Ｒ)
	float eyeL_scleraColor_R_0E0;

	// NAME: White eye color (G) - 白目の色(G)
	// DESC: White eye color of the left eye (G) - 左目の白目の色(G)
	float eyeL_scleraColor_G_0E4;

	// NAME: White eye color (B) - 白目の色(B)
	// DESC: White eye color of the left eye (B) - 左目の白目の色(B)
	float eyeL_scleraColor_B_0E8;

	// NAME: Position of the iris - 虹彩の位置
	// DESC: Position of the iris of the left eye - 左目の虹彩の位置
	float eyeL_irisDistance_0EC;

	// NAME: Hair part ID - 髪パーツID
	// DESC: Hair part ID - 髪パーツID
	float hair_partsId_0F0;

	// NAME: Hair color (R) - 髪の色(Ｒ)
	// DESC: Hair color (R) - 髪の色(Ｒ)
	float hair_color_R_0F4;

	// NAME: Hair color (G) - 髪の色(Ｇ)
	// DESC: Hair color (G) - 髪の色(Ｇ)
	float hair_color_G_0F8;

	// NAME: Hair color (B) - 髪の色(Ｂ)
	// DESC: Hair color (B) - 髪の色(Ｂ)
	float hair_color_B_0FC;

	// NAME: Gloss - 光沢
	// DESC: Hair gloss - 髪の光沢
	float hair_shininess_100;

	// NAME: Blackness at the base - 根元の黒さ
	// DESC: Blackness at the base of hair - 髪の根元の黒さ
	float hair_rootBlack_104;

	// NAME: Amount of gray hair - 白髪の量
	// DESC: Amount of white hair - 髪の白髪の量
	float hair_whiteDensity_108;

	// NAME: Beard part ID - 髭パーツID
	// DESC: Beard part ID - 髭パーツID
	float beard_partsId_10C;

	// NAME: Beard color (R) - 髭の色(Ｒ)
	// DESC: Beard color (R) - 髭の色(Ｒ)
	float beard_color_R_110;

	// NAME: Beard color (G) - 髭の色(Ｇ)
	// DESC: Beard color (G) - 髭の色(Ｇ)
	float beard_color_G_114;

	// NAME: Beard color (B) - 髭の色(Ｂ)
	// DESC: Beard color (B) - 髭の色(Ｂ)
	float beard_color_B_118;

	// NAME: Gloss - 光沢
	// DESC: Beard luster - 髭の光沢
	float beard_shininess_11C;

	// NAME: Blackness at the base - 根元の黒さ
	// DESC: Blackness at the base of the beard - 髭の根元の黒さ
	float beard_rootBlack_120;

	// NAME: Amount of gray hair - 白髪の量
	// DESC: Amount of white hair with a beard - 髭の白髪の量
	float beard_whiteDensity_124;

	// NAME: Eyebrow part ID - 眉パーツID
	// DESC: Eyebrow part ID - 眉パーツID
	float eyebrow_partsId_128;

	// NAME: Eyebrow color (R) - 眉の色(Ｒ)
	// DESC: Eyebrow color (R) - 眉の色(Ｒ)
	float eyebrow_color_R_12C;

	// NAME: Eyebrow color (G) - 眉の色(Ｇ)
	// DESC: Eyebrow color (G) - 眉の色(Ｇ)
	float eyebrow_color_G_130;

	// NAME: Eyebrow color (B) - 眉の色(Ｂ)
	// DESC: Eyebrow color (B) - 眉の色(Ｂ)
	float eyebrow_color_B_134;

	// NAME: Gloss - 光沢
	// DESC: Glossy eyebrows - 眉の光沢
	float eyebrow_shininess_138;

	// NAME: Blackness at the base - 根元の黒さ
	// DESC: Blackness at the base of the eyebrows - 眉の根元の黒さ
	float eyebrow_rootBlack_13C;

	// NAME: Amount of gray hair - 白髪の量
	// DESC: Amount of white hair on the eyebrows - 眉の白髪の量
	float eyebrow_whiteDensity_140;

	// NAME: Eyelash parts ID - まつげパーツID
	// DESC: Eyelash parts ID - まつげパーツID
	float eyelash_partsId_144;

	// NAME: Eyelash color (R) - まつげの色(Ｒ)
	// DESC: Eyelash color (R) - まつげの色(Ｒ)
	float eyelash_color_R_148;

	// NAME: Eyelash color (G) - まつげの色(Ｇ)
	// DESC: Eyelash color (G) - まつげの色(Ｇ)
	float eyelash_color_G_14C;

	// NAME: Eyelash color (B) - まつげの色(Ｂ)
	// DESC: Eyelash color (B) - まつげの色(Ｂ)
	float eyelash_color_B_150;

	// NAME: Decorative part ID - 装飾パーツID
	// DESC: Decorative part ID - 装飾パーツID
	float accessories_partsId_154;

	// NAME: Decoration color (R) - 装飾の色(Ｒ)
	// DESC: Decoration color (R) - 装飾の色(Ｒ)
	float accessories_color_R_158;

	// NAME: Decoration color (G) - 装飾の色(Ｇ)
	// DESC: Decoration color (G) - 装飾の色(Ｇ)
	float accessories_color_G_15C;

	// NAME: Decorative color (B) - 装飾の色(Ｂ)
	// DESC: Decorative color (B) - 装飾の色(Ｂ)
	float accessories_color_B_160;

	// NAME: Decal part ID - デカールパーツID
	// DESC: Decal part ID - デカールパーツID
	float decal_partsId_164;

	// NAME: Decal position (x) - デカール位置(x)
	// DESC: Decal position (x) - デカール位置(x)
	float decal_posX_168;

	// NAME: Decal position (y) - デカール位置(y)
	// DESC: Decal position (y) - デカール位置(y)
	float decal_posY_16C;

	// NAME: Decal angle - デカール角度
	// DESC: Decal angle - デカール角度
	float decal_angle_170;

	// NAME: Decal scale - デカールスケール
	// DESC: Decal scale - デカールスケール
	float decal_scale_174;

	// NAME: Decal color (R) - デカールの色(Ｒ)
	// DESC: Decal color (R) - デカールの色(Ｒ)
	float decal_color_R_178;

	// NAME: Decal color (G) - デカールの色(Ｇ)
	// DESC: Decal color (G) - デカールの色(Ｇ)
	float decal_color_G_17C;

	// NAME: Decal color (B) - デカールの色(Ｂ)
	// DESC: Decal color (B) - デカールの色(Ｂ)
	float decal_color_B_180;

	// NAME: Decal gloss - デカールのつや
	// DESC: Decal gloss - デカールのつや
	float decal_gloss_184;

	// NAME: Decal reversal - デカールの反転
	// DESC: Decal reversal - デカールの反転
	float decal_mirror_188;

	// NAME: Character body head scale - キャラ体型頭部スケール
	// DESC: Character body head scale - キャラ体型頭部スケール
	float chrBodyScaleHead_18C;

	// NAME: Character body chest scale - キャラ体型胸部スケール
	// DESC: Character body chest scale - キャラ体型胸部スケール
	float chrBodyScaleBreast_190;

	// NAME: Character body type abdominal scale - キャラ体型腹部スケール
	// DESC: Character body type abdominal scale - キャラ体型腹部スケール
	float chrBodyScaleAbdomen_194;

	// NAME: Character body type arm scale - キャラ体型腕部スケール
	// DESC: Character body type arm scale - キャラ体型腕部スケール
	float chrBodyScaleArm_198;

	// NAME: Character body type leg scale - キャラ体型脚部スケール
	// DESC: Character body type leg scale - キャラ体型脚部スケール
	float chrBodyScaleLeg_19C;

	// NAME: age - 年齢
	// DESC: age - 年齢
	float age_1A0;

	// NAME: sex - 性別
	// DESC: sex - 性別
	float gender_1A4;

	// NAME: Exaggeration (model) - 誇張（モデル）
	// DESC: Exaggeration (model) - 誇張（モデル）
	float caricatureGeometry_1A8;

	// NAME: Exaggeration (texture) - 誇張（テクスチャ）
	// DESC: Exaggeration (texture) - 誇張（テクスチャ）
	float caricatureTexture_1AC;

	// NAME: Face creation geometry data 00 - 顔作成ジオメトリデータ00
	// DESC: Face creation geometry data 00 - 顔作成ジオメトリデータ00
	float faceGeoData00_1B0;

	// NAME: Face creation geometry data 01 - 顔作成ジオメトリデータ01
	// DESC: Face creation geometry data 01 - 顔作成ジオメトリデータ01
	float faceGeoData01_1B4;

	// NAME: Face creation geometry data 02 - 顔作成ジオメトリデータ02
	// DESC: Face creation geometry data 02 - 顔作成ジオメトリデータ02
	float faceGeoData02_1B8;

	// NAME: Face creation geometry data 03 - 顔作成ジオメトリデータ03
	// DESC: Face creation geometry data 03 - 顔作成ジオメトリデータ03
	float faceGeoData03_1BC;

	// NAME: Face creation geometry data 04 - 顔作成ジオメトリデータ04
	// DESC: Face creation geometry data 04 - 顔作成ジオメトリデータ04
	float faceGeoData04_1C0;

	// NAME: Face creation geometry data 05 - 顔作成ジオメトリデータ05
	// DESC: Face creation geometry data 05 - 顔作成ジオメトリデータ05
	float faceGeoData05_1C4;

	// NAME: Face creation geometry data 06 - 顔作成ジオメトリデータ06
	// DESC: Face creation geometry data 06 - 顔作成ジオメトリデータ06
	float faceGeoData06_1C8;

	// NAME: Face creation geometry data 07 - 顔作成ジオメトリデータ07
	// DESC: Face creation geometry data 07 - 顔作成ジオメトリデータ07
	float faceGeoData07_1CC;

	// NAME: Face creation geometry data 08 - 顔作成ジオメトリデータ08
	// DESC: Face creation geometry data 08 - 顔作成ジオメトリデータ08
	float faceGeoData08_1D0;

	// NAME: Face creation geometry data 09 - 顔作成ジオメトリデータ09
	// DESC: Face creation geometry data 09 - 顔作成ジオメトリデータ09
	float faceGeoData09_1D4;

	// NAME: Face creation geometry data 10 - 顔作成ジオメトリデータ10
	// DESC: Face creation geometry data 10 - 顔作成ジオメトリデータ10
	float faceGeoData10_1D8;

	// NAME: Face creation geometry data 11 - 顔作成ジオメトリデータ11
	// DESC: Face creation geometry data 11 - 顔作成ジオメトリデータ11
	float faceGeoData11_1DC;

	// NAME: Face creation geometry data 12 - 顔作成ジオメトリデータ12
	// DESC: Face creation geometry data 12 - 顔作成ジオメトリデータ12
	float faceGeoData12_1E0;

	// NAME: Face creation geometry data 13 - 顔作成ジオメトリデータ13
	// DESC: Face creation geometry data 13 - 顔作成ジオメトリデータ13
	float faceGeoData13_1E4;

	// NAME: Face creation geometry data 14 - 顔作成ジオメトリデータ14
	// DESC: Face creation geometry data 14 - 顔作成ジオメトリデータ14
	float faceGeoData14_1E8;

	// NAME: Face creation geometry data 15 - 顔作成ジオメトリデータ15
	// DESC: Face creation geometry data 15 - 顔作成ジオメトリデータ15
	float faceGeoData15_1EC;

	// NAME: Face creation geometry data 16 - 顔作成ジオメトリデータ16
	// DESC: Face creation geometry data 16 - 顔作成ジオメトリデータ16
	float faceGeoData16_1F0;

	// NAME: Face creation geometry data 17 - 顔作成ジオメトリデータ17
	// DESC: Face creation geometry data 17 - 顔作成ジオメトリデータ17
	float faceGeoData17_1F4;

	// NAME: Face creation geometry data 18 - 顔作成ジオメトリデータ18
	// DESC: Face creation geometry data 18 - 顔作成ジオメトリデータ18
	float faceGeoData18_1F8;

	// NAME: Face creation geometry data 19 - 顔作成ジオメトリデータ19
	// DESC: Face creation geometry data 19 - 顔作成ジオメトリデータ19
	float faceGeoData19_1FC;

	// NAME: Face creation geometry data 20 - 顔作成ジオメトリデータ20
	// DESC: Face creation geometry data 20 - 顔作成ジオメトリデータ20
	float faceGeoData20_200;

	// NAME: Face creation geometry data 21 - 顔作成ジオメトリデータ21
	// DESC: Face creation geometry data 21 - 顔作成ジオメトリデータ21
	float faceGeoData21_204;

	// NAME: Face creation geometry data 22 - 顔作成ジオメトリデータ22
	// DESC: Face creation geometry data 22 - 顔作成ジオメトリデータ22
	float faceGeoData22_208;

	// NAME: Face creation geometry data 23 - 顔作成ジオメトリデータ23
	// DESC: Face creation geometry data 23 - 顔作成ジオメトリデータ23
	float faceGeoData23_20C;

	// NAME: Face creation geometry data 24 - 顔作成ジオメトリデータ24
	// DESC: Face creation geometry data 24 - 顔作成ジオメトリデータ24
	float faceGeoData24_210;

	// NAME: Face creation geometry data 25 - 顔作成ジオメトリデータ25
	// DESC: Face creation geometry data 25 - 顔作成ジオメトリデータ25
	float faceGeoData25_214;

	// NAME: Face creation geometry data 26 - 顔作成ジオメトリデータ26
	// DESC: Face creation geometry data 26 - 顔作成ジオメトリデータ26
	float faceGeoData26_218;

	// NAME: Face creation geometry data 27 - 顔作成ジオメトリデータ27
	// DESC: Face creation geometry data 27 - 顔作成ジオメトリデータ27
	float faceGeoData27_21C;

	// NAME: Face creation geometry data 28 - 顔作成ジオメトリデータ28
	// DESC: Face creation geometry data 28 - 顔作成ジオメトリデータ28
	float faceGeoData28_220;

	// NAME: Face creation geometry data 29 - 顔作成ジオメトリデータ29
	// DESC: Face creation geometry data 29 - 顔作成ジオメトリデータ29
	float faceGeoData29_224;

	// NAME: Face creation geometry data 30 - 顔作成ジオメトリデータ30
	// DESC: Face creation geometry data 30 - 顔作成ジオメトリデータ30
	float faceGeoData30_228;

	// NAME: Face creation geometry data 31 - 顔作成ジオメトリデータ31
	// DESC: Face creation geometry data 31 - 顔作成ジオメトリデータ31
	float faceGeoData31_22C;

	// NAME: Face creation geometry data 32 - 顔作成ジオメトリデータ32
	// DESC: Face creation geometry data 32 - 顔作成ジオメトリデータ32
	float faceGeoData32_230;

	// NAME: Face creation geometry data 33 - 顔作成ジオメトリデータ33
	// DESC: Face creation geometry data 33 - 顔作成ジオメトリデータ33
	float faceGeoData33_234;

	// NAME: Face creation geometry data 34 - 顔作成ジオメトリデータ34
	// DESC: Face creation geometry data 34 - 顔作成ジオメトリデータ34
	float faceGeoData34_238;

	// NAME: Face creation geometry data 35 - 顔作成ジオメトリデータ35
	// DESC: Face creation geometry data 35 - 顔作成ジオメトリデータ35
	float faceGeoData35_23C;

	// NAME: Face creation geometry data 36 - 顔作成ジオメトリデータ36
	// DESC: Face creation geometry data 36 - 顔作成ジオメトリデータ36
	float faceGeoData36_240;

	// NAME: Face creation geometry data 37 - 顔作成ジオメトリデータ37
	// DESC: Face creation geometry data 37 - 顔作成ジオメトリデータ37
	float faceGeoData37_244;

	// NAME: Face creation geometry data 38 - 顔作成ジオメトリデータ38
	// DESC: Face creation geometry data 38 - 顔作成ジオメトリデータ38
	float faceGeoData38_248;

	// NAME: Face creation geometry data 39 - 顔作成ジオメトリデータ39
	// DESC: Face creation geometry data 39 - 顔作成ジオメトリデータ39
	float faceGeoData39_24C;

	// NAME: Face creation geometry data 40 - 顔作成ジオメトリデータ40
	// DESC: Face creation geometry data 40 - 顔作成ジオメトリデータ40
	float faceGeoData40_250;

	// NAME: Face creation geometry data 41 - 顔作成ジオメトリデータ41
	// DESC: Face creation geometry data 41 - 顔作成ジオメトリデータ41
	float faceGeoData41_254;

	// NAME: Face creation geometry data 42 - 顔作成ジオメトリデータ42
	// DESC: Face creation geometry data 42 - 顔作成ジオメトリデータ42
	float faceGeoData42_258;

	// NAME: Face creation geometry data 43 - 顔作成ジオメトリデータ43
	// DESC: Face creation geometry data 43 - 顔作成ジオメトリデータ43
	float faceGeoData43_25C;

	// NAME: Face creation geometry data 44 - 顔作成ジオメトリデータ44
	// DESC: Face creation geometry data 44 - 顔作成ジオメトリデータ44
	float faceGeoData44_260;

	// NAME: Face creation geometry data 45 - 顔作成ジオメトリデータ45
	// DESC: Face creation geometry data 45 - 顔作成ジオメトリデータ45
	float faceGeoData45_264;

	// NAME: Face creation geometry data 46 - 顔作成ジオメトリデータ46
	// DESC: Face creation geometry data 46 - 顔作成ジオメトリデータ46
	float faceGeoData46_268;

	// NAME: Face creation geometry data 47 - 顔作成ジオメトリデータ47
	// DESC: Face creation geometry data 47 - 顔作成ジオメトリデータ47
	float faceGeoData47_26C;

	// NAME: Face creation geometry data 48 - 顔作成ジオメトリデータ48
	// DESC: Face creation geometry data 48 - 顔作成ジオメトリデータ48
	float faceGeoData48_270;

	// NAME: Face creation geometry data 49 - 顔作成ジオメトリデータ49
	// DESC: Face creation geometry data 49 - 顔作成ジオメトリデータ49
	float faceGeoData49_274;

	// NAME: Face creation geometry data 50 - 顔作成ジオメトリデータ50
	// DESC: Face creation geometry data 50 - 顔作成ジオメトリデータ50
	float faceGeoData50_278;

	// NAME: Face creation geometry data 51 - 顔作成ジオメトリデータ51
	// DESC: Face creation geometry data 51 - 顔作成ジオメトリデータ51
	float faceGeoData51_27C;

	// NAME: Face creation geometry data 52 - 顔作成ジオメトリデータ52
	// DESC: Face creation geometry data 52 - 顔作成ジオメトリデータ52
	float faceGeoData52_280;

	// NAME: Face creation geometry data 53 - 顔作成ジオメトリデータ53
	// DESC: Face creation geometry data 53 - 顔作成ジオメトリデータ53
	float faceGeoData53_284;

	// NAME: Face creation geometry data 54 - 顔作成ジオメトリデータ54
	// DESC: Face creation geometry data 54 - 顔作成ジオメトリデータ54
	float faceGeoData54_288;

	// NAME: Face creation geometry data 55 - 顔作成ジオメトリデータ55
	// DESC: Face creation geometry data 55 - 顔作成ジオメトリデータ55
	float faceGeoData55_28C;

	// NAME: Face creation geometry data 56 - 顔作成ジオメトリデータ56
	// DESC: Face creation geometry data 56 - 顔作成ジオメトリデータ56
	float faceGeoData56_290;

	// NAME: Face creation geometry data 57 - 顔作成ジオメトリデータ57
	// DESC: Face creation geometry data 57 - 顔作成ジオメトリデータ57
	float faceGeoData57_294;

	// NAME: Face creation geometry data 58 - 顔作成ジオメトリデータ58
	// DESC: Face creation geometry data 58 - 顔作成ジオメトリデータ58
	float faceGeoData58_298;

	// NAME: Face creation geometry data 59 - 顔作成ジオメトリデータ59
	// DESC: Face creation geometry data 59 - 顔作成ジオメトリデータ59
	float faceGeoData59_29C;

	// NAME: Face creation geometry data 60 - 顔作成ジオメトリデータ60
	// DESC: Face creation geometry data 60 - 顔作成ジオメトリデータ60
	float faceGeoData60_2A0;

	// NAME: Face creation texture data 00 - 顔作成テクスチャデータ00
	// DESC: Face creation texture data 00 - 顔作成テクスチャデータ00
	float faceTexData00_2A4;

	// NAME: Face creation texture data 01 - 顔作成テクスチャデータ01
	// DESC: Face creation texture data 01 - 顔作成テクスチャデータ01
	float faceTexData01_2A8;

	// NAME: Face creation texture data 02 - 顔作成テクスチャデータ02
	// DESC: Face creation texture data 02 - 顔作成テクスチャデータ02
	float faceTexData02_2AC;

	// NAME: Face creation texture data 03 - 顔作成テクスチャデータ03
	// DESC: Face creation texture data 03 - 顔作成テクスチャデータ03
	float faceTexData03_2B0;

	// NAME: Face creation texture data 04 - 顔作成テクスチャデータ04
	// DESC: Face creation texture data 04 - 顔作成テクスチャデータ04
	float faceTexData04_2B4;

	// NAME: Face creation texture data 05 - 顔作成テクスチャデータ05
	// DESC: Face creation texture data 05 - 顔作成テクスチャデータ05
	float faceTexData05_2B8;

	// NAME: Face creation texture data 06 - 顔作成テクスチャデータ06
	// DESC: Face creation texture data 06 - 顔作成テクスチャデータ06
	float faceTexData06_2BC;

	// NAME: Face creation texture data 07 - 顔作成テクスチャデータ07
	// DESC: Face creation texture data 07 - 顔作成テクスチャデータ07
	float faceTexData07_2C0;

	// NAME: Face creation texture data 08 - 顔作成テクスチャデータ08
	// DESC: Face creation texture data 08 - 顔作成テクスチャデータ08
	float faceTexData08_2C4;

	// NAME: Face creation texture data 09 - 顔作成テクスチャデータ09
	// DESC: Face creation texture data 09 - 顔作成テクスチャデータ09
	float faceTexData09_2C8;

	// NAME: Face creation texture data 10 - 顔作成テクスチャデータ10
	// DESC: Face creation texture data 10 - 顔作成テクスチャデータ10
	float faceTexData10_2CC;

	// NAME: Face creation texture data 11 - 顔作成テクスチャデータ11
	// DESC: Face creation texture data 11 - 顔作成テクスチャデータ11
	float faceTexData11_2D0;

	// NAME: Face creation texture data 12 - 顔作成テクスチャデータ12
	// DESC: Face creation texture data 12 - 顔作成テクスチャデータ12
	float faceTexData12_2D4;

	// NAME: Face creation texture data 13 - 顔作成テクスチャデータ13
	// DESC: Face creation texture data 13 - 顔作成テクスチャデータ13
	float faceTexData13_2D8;

	// NAME: Face creation texture data 14 - 顔作成テクスチャデータ14
	// DESC: Face creation texture data 14 - 顔作成テクスチャデータ14
	float faceTexData14_2DC;

	// NAME: Face creation texture data 15 - 顔作成テクスチャデータ15
	// DESC: Face creation texture data 15 - 顔作成テクスチャデータ15
	float faceTexData15_2E0;

	// NAME: Face creation texture data 16 - 顔作成テクスチャデータ16
	// DESC: Face creation texture data 16 - 顔作成テクスチャデータ16
	float faceTexData16_2E4;

	// NAME: Face creation texture data 17 - 顔作成テクスチャデータ17
	// DESC: Face creation texture data 17 - 顔作成テクスチャデータ17
	float faceTexData17_2E8;

	// NAME: Face creation texture data 18 - 顔作成テクスチャデータ18
	// DESC: Face creation texture data 18 - 顔作成テクスチャデータ18
	float faceTexData18_2EC;

	// NAME: Face creation texture data 19 - 顔作成テクスチャデータ19
	// DESC: Face creation texture data 19 - 顔作成テクスチャデータ19
	float faceTexData19_2F0;

	// NAME: Face creation texture data 20 - 顔作成テクスチャデータ20
	// DESC: Face creation texture data 20 - 顔作成テクスチャデータ20
	float faceTexData20_2F4;

	// NAME: Face creation texture data 21 - 顔作成テクスチャデータ21
	// DESC: Face creation texture data 21 - 顔作成テクスチャデータ21
	float faceTexData21_2F8;

	// NAME: Face creation texture data 22 - 顔作成テクスチャデータ22
	// DESC: Face creation texture data 22 - 顔作成テクスチャデータ22
	float faceTexData22_2FC;

	// NAME: Face creation texture data 23 - 顔作成テクスチャデータ23
	// DESC: Face creation texture data 23 - 顔作成テクスチャデータ23
	float faceTexData23_300;

	// NAME: Face creation texture data 24 - 顔作成テクスチャデータ24
	// DESC: Face creation texture data 24 - 顔作成テクスチャデータ24
	float faceTexData24_304;

	// NAME: Face creation texture data 25 - 顔作成テクスチャデータ25
	// DESC: Face creation texture data 25 - 顔作成テクスチャデータ25
	float faceTexData25_308;

	// NAME: Face creation texture data 26 - 顔作成テクスチャデータ26
	// DESC: Face creation texture data 26 - 顔作成テクスチャデータ26
	float faceTexData26_30C;

	// NAME: Face creation texture data 27 - 顔作成テクスチャデータ27
	// DESC: Face creation texture data 27 - 顔作成テクスチャデータ27
	float faceTexData27_310;

	// NAME: Face creation texture data 28 - 顔作成テクスチャデータ28
	// DESC: Face creation texture data 28 - 顔作成テクスチャデータ28
	float faceTexData28_314;

	// NAME: Face creation texture data 29 - 顔作成テクスチャデータ29
	// DESC: Face creation texture data 29 - 顔作成テクスチャデータ29
	float faceTexData29_318;

	// NAME: Face creation texture data 30 - 顔作成テクスチャデータ30
	// DESC: Face creation texture data 30 - 顔作成テクスチャデータ30
	float faceTexData30_31C;

	// NAME: Face creation texture data 31 - 顔作成テクスチャデータ31
	// DESC: Face creation texture data 31 - 顔作成テクスチャデータ31
	float faceTexData31_320;

	// NAME: Face creation texture data 32 - 顔作成テクスチャデータ32
	// DESC: Face creation texture data 32 - 顔作成テクスチャデータ32
	float faceTexData32_324;

	// NAME: Face creation texture data 33 - 顔作成テクスチャデータ33
	// DESC: Face creation texture data 33 - 顔作成テクスチャデータ33
	float faceTexData33_328;

	// NAME: Face creation texture data 34 - 顔作成テクスチャデータ34
	// DESC: Face creation texture data 34 - 顔作成テクスチャデータ34
	float faceTexData34_32C;

	// NAME: Face creation texture data 35 - 顔作成テクスチャデータ35
	// DESC: Face creation texture data 35 - 顔作成テクスチャデータ35
	float faceTexData35_330;

	// NAME: Burn scars - 火傷跡
	// DESC: Burn scars - 火傷跡
	float burn_scar_334;

} FaceRangeParam;

#endif
