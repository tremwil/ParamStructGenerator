/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MaterialEx_H
#define _PARAM_MaterialEx_H
#include <stdint.h>

// MATERIAL_EX_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MaterialEx {

	// NAME: Material parameter name - マテリアルパラメータ名
	// DESC: Set the parameter name of the material. Up to 31 characters - マテリアルのパラメータ名を設定する。最大31文字まで
	wchar_t paramName_000[32];

	// NAME: Target material ID - 対象マテリアルID
	// DESC: NPC Para: Resident Material Expansion Para ID setting -1 for all materials - NPCパラ：常駐マテリアル拡張パラID用設定　-1なら全マテリアル対象
	int32_t materialId_040;

	// NAME: Overwrite value 1 (R) - 上書き値1(R)
	// DESC: NPC Para: Resident Material Extended Para ID Settings - NPCパラ：常駐マテリアル拡張パラID用設定
	float materialParamValue0_044;

	// NAME: Overwrite value 2 (G) - 上書き値2(G)
	// DESC: NPC Para: Resident Material Expansion Para ID Settings - NPCパラ：常駐マテリアル拡張パラID用設定
	float materialParamValue1_048;

	// NAME: Overwrite value 3 (B) - 上書き値3(B)
	// DESC: NPC Para: Resident Material Expansion Para ID Settings - NPCパラ：常駐マテリアル拡張パラID用設定
	float materialParamValue2_04C;

	// NAME: Overwrite value 4 (A) - 上書き値4(A)
	// DESC: NPC Para: Resident Material Extended Para ID Settings - NPCパラ：常駐マテリアル拡張パラID用設定
	float materialParamValue3_050;

	// NAME: Overwrite value 5 (I) - 上書き値5(I)
	// DESC: NPC Para: Resident Material Expansion Para ID Settings - NPCパラ：常駐マテリアル拡張パラID用設定
	float materialParamValue4_054;

	// NAME: Padding - パディング
	// DESC: Padding - パディング
	uint8_t pad_058[8];

} MaterialEx;

#endif
