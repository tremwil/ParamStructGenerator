/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MenuPropertyLayoutParam_H
#define _PARAM_MenuPropertyLayoutParam_H
#include <stdint.h>

// MENUPROPERTY_LAYOUT
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MenuPropertyLayoutParam {

	// NAME: Layout path - レイアウトパス
	char LayoutPath_000[16];

	// NAME: Property ID - プロパティID
	int32_t PropertyID_010;

	// NAME: Item name Text ID - 項目名テキストID
	// DESC: If a valid text ID is set, this will be displayed in preference to the property name. - 有効なテキストIDが設定されている場合、プロパティ名よりもこちらを優先して表示します。
	int32_t CaptionTextID_014;

	// NAME: Help text ID - ヘルプテキストID
	// DESC: Only if this is a valid text ID will it be selectable in the field help. - ここが有効なテキストIDの場合のみ、項目ヘルプで選択できるようになります。
	int32_t HelpTextID_018;

	// NAME: reserve - 予約
	uint8_t reserved_01C[4];

} MenuPropertyLayoutParam;

#endif
