/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EstusFlaskRecoveryParam_H
#define _PARAM_EstusFlaskRecoveryParam_H
#include <stdint.h>

// ESTUS_FLASK_RECOVERY_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EstusFlaskRecoveryParam {

	// NAME: host - ホスト
	// DESC: Number of host est recovery - ホストのエスト回復数
	uint8_t host_000;

	// NAME: No intrusion route_orb_ - 侵入経路_オーブ_なし
	// DESC: The number of est recovery of the power of the orb whose invasion route is - 侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_None_001;

	// NAME: Invasion route_Orb_Sun - 侵入経路_オーブ_太陽
	// DESC: The number of est recovery of the power of the orb whose invasion route is - 侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_Umbasa_002;

	// NAME: Intrusion route_Orb_Berserker - 侵入経路_オーブ_バーサーカー
	// DESC: The number of est recovery of the power of the orb whose invasion route is - 侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_Berserker_003;

	// NAME: Invasion route_Orb_Sinner - 侵入経路_オーブ_罪人
	// DESC: The number of est recovery of the power of the orb whose invasion route is - 侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_Sinners_004;

	// NAME: No intrusion route_sign_ - 侵入経路_サイン_なし
	// DESC: The number of est recovery of the power whose invasion route is a sign - 侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_None_005;

	// NAME: Invasion route_sign_sun - 侵入経路_サイン_太陽
	// DESC: The number of est recovery of the power whose invasion route is a sign - 侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_Umbasa_006;

	// NAME: Intrusion route_sign_berserker - 侵入経路_サイン_バーサーカー
	// DESC: The number of est recovery of the power whose invasion route is a sign - 侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_Berserker_007;

	// NAME: Intrusion route_sign_sinner - 侵入経路_サイン_罪人
	// DESC: The number of est recovery of the power whose invasion route is a sign - 侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_Sinners_008;

	// NAME: Invasion route_ring_sinner - 侵入経路_指輪_罪人
	// DESC: The number of est recovery of the power of the ring whose invasion route is - 侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Sinners_009;

	// NAME: Invasion route_Ring_Boss guard (Rosalia) - 侵入経路_指輪_ボス守(ロザリア)
	// DESC: The number of est recovery of the power of the ring whose invasion route is - 侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Rosalia_00A;

	// NAME: Invasion route_Ring_Map Mamoru (Forest) - 侵入経路_指輪_マップ守(森)
	// DESC: The number of est recovery of the power of the ring whose invasion route is - 侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Forest_00B;

	// NAME: Cooperation route_sign_ None - 協力経路_サイン_なし
	// DESC: The number of est recovery of the power whose cooperation route is a sign - 協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_None_00C;

	// NAME: Cooperation route_sign_sun - 協力経路_サイン_太陽
	// DESC: The number of est recovery of the power whose cooperation route is a sign - 協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_Umbasa_00D;

	// NAME: Cooperation route_sign_berserker - 協力経路_サイン_バーサーカー
	// DESC: The number of est recovery of the power whose cooperation route is a sign - 協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_Berserker_00E;

	// NAME: Cooperation route_sign_sinner - 協力経路_サイン_罪人
	// DESC: The number of est recovery of the power whose cooperation route is a sign - 協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_Sinners_00F;

	// NAME: Cooperation route _ ring _ red hunting - 協力経路_指輪 _赤狩り
	// DESC: Cooperation route is the number of est recovery of the power of the ring - 協力経路が指輪の勢力のエスト回復数
	uint8_t coopRing_RedHunter_010;

	// NAME: Intrusion route_Ring_Map guard (Anor) - 侵入経路_指輪_マップ守(アノール)
	// DESC: The number of est recovery of the power of the ring whose invasion route is - 侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Anor_011;

	// NAME: Recovery number Parameter replacement rate - 回復数パラメータ差し替え率
	// DESC: Recovery number Parameter replacement rate - 回復数パラメータ差し替え率
	uint16_t paramReplaceRate_012;

	// NAME: Recovery number Parameter replacement destination ID - 回復数パラメータ差し替え先ID
	// DESC: Recovery number Parameter replacement destination ID - 回復数パラメータ差し替え先ID
	int32_t paramReplaceId_014;

	// NAME: pad - pad
	uint8_t pad_018[8];

} EstusFlaskRecoveryParam;

#endif
