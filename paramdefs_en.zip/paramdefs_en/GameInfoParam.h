/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_GameInfoParam_H
#define _PARAM_GameInfoParam_H
#include <stdint.h>

// GAME_INFO_PARAM
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GameInfoParam {

	// NAME: Title MsgID - タイトルのMsgID
	// DESC: Title name - タイトル名
	int32_t titleMsgId_000;

	// NAME: Content MsgID - 内容のMsgID
	// DESC: Contents - 内容
	int32_t contentMsgId_004;

	// NAME: price - 価格
	// DESC: price - 価格
	int32_t value_008;

	// NAME: Sort ID - ソートID
	// DESC: Sort ID - ソートID
	int32_t sortId_00C;

	// NAME: Action ID - アクションID
	// DESC: This is the action ID that determines the sales status. - 販売状況を判断するアクションIDです。
	int32_t eventId_010;

	// NAME: Padding - パディング
	// DESC: Padding - パディング
	uint8_t Pad_014[12];

} GameInfoParam;

#endif
