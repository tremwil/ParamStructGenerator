/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CharMakeMenuListItemParam_H
#define _PARAM_CharMakeMenuListItemParam_H
#include <stdint.h>

// CHARMAKEMENU_LISTITEM_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CharMakeMenuListItemParam {

	// NAME: value - 値
	// DESC: The value handled by the program. Make serial numbers within one group - プログラム側に扱う値。1つのグループ内で通し番号にする
	int32_t value_000;

	// NAME: Item text ID - 項目テキストID
	// DESC: ID of the text to be displayed - 表示するテキストのID
	int32_t captionId_004;

	// NAME: Icon ID - アイコンID
	// DESC: ID of the icon to be displayed - 表示するアイコンのID
	uint8_t iconId_008;

	// NAME: reserve - 予約
	uint8_t reserved_009[7];

} CharMakeMenuListItemParam;

#endif
