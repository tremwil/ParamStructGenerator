/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_AAQuality_H
#define _PARAM_Gconfig_AAQuality_H
#include <stdint.h>

// CS_AA_QUALITY_DETAIL
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_AAQuality {

	// NAME: AA valid - AA有効
	// DESC: AA valid - AA有効
	uint8_t enabled_000;

	// NAME: Force FXAA2 - 強制的にFXAA2
	// DESC: Force FXAA2 - 強制的にFXAA2
	uint8_t forceFXAA2_001;

	// NAME: dmy - dmy
	uint8_t dmy_002[2];

} Gconfig_AAQuality;

#endif
