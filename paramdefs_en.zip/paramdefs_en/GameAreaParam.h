/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_GameAreaParam_H
#define _PARAM_GameAreaParam_H
#include <stdint.h>

// GAME_AREA_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GameAreaParam {

	// NAME: Do you remove it from the NT version output? - NT版出力から外すか
	// DESC: Parameters marked with ○ are excluded in the NT version package. - ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// NAME: Reserve for package output 1 - パッケージ出力用リザーブ1
	// DESC: Reserve for package output 1 - パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// NAME: Reserve for package output 2 - パッケージ出力用リザーブ2
	// DESC: Reserve for package output 2 - パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// NAME: Single time clear bonus soul amount - シングル時クリアボーナスソウル量
	// DESC: Amount of soul that can be obtained when defeating an area boss (in single play) - エリアボスを倒したときに取得できるソウル量(シングルプレイ時)
	uint32_t bonusSoul_single_004;

	// NAME: Clear bonus soul amount during multiplayer - マルチプレイ時クリアボーナスソウル量
	// DESC: Amount of soul that can be obtained when defeating an area boss (during multiplayer) - エリアボスを倒したときに取得できるソウル量(マルチプレイ時)
	uint32_t bonusSoul_multi_008;

	// NAME: Human nature drop point count head flag ID - 人間性ドロップポイントカウント先頭フラグID
	// DESC: First flag ID for managing humanity drop points (using 20 Bit) - 人間性ドロップポイントを管理する為の先頭フラグID(20Bit使用)
	uint32_t humanityPointCountFlagIdTop_00C;

	// NAME: Human nature drop required point 1 - 人間性ドロップ必要ポイント1
	// DESC: Threshold for acquiring humanity 1 - 人間性を取得する為の閾値1
	uint16_t humanityDropPoint1_010;

	// NAME: Human nature drop required point 2 - 人間性ドロップ必要ポイント2
	// DESC: Threshold 2 for acquiring humanity - 人間性を取得する為の閾値2
	uint16_t humanityDropPoint2_012;

	// NAME: Human nature drop required point 3 - 人間性ドロップ必要ポイント3
	// DESC: Threshold 3 for acquiring humanity - 人間性を取得する為の閾値3
	uint16_t humanityDropPoint3_014;

	// NAME: Human nature drop required point 4 - 人間性ドロップ必要ポイント4
	// DESC: Threshold 4 for acquiring humanity - 人間性を取得する為の閾値4
	uint16_t humanityDropPoint4_016;

	// NAME: Human nature drop required point 5 - 人間性ドロップ必要ポイント5
	// DESC: Threshold 5 for acquiring humanity - 人間性を取得する為の閾値5
	uint16_t humanityDropPoint5_018;

	// NAME: Human nature drop required point 6 - 人間性ドロップ必要ポイント6
	// DESC: Threshold 6 for acquiring humanity - 人間性を取得する為の閾値6
	uint16_t humanityDropPoint6_01A;

	// NAME: Human nature drop required point 7 - 人間性ドロップ必要ポイント7
	// DESC: Threshold for acquiring humanity 7 - 人間性を取得する為の閾値7
	uint16_t humanityDropPoint7_01C;

	// NAME: Human nature drop required point 8 - 人間性ドロップ必要ポイント8
	// DESC: Threshold for acquiring humanity 8 - 人間性を取得する為の閾値8
	uint16_t humanityDropPoint8_01E;

	// NAME: Human nature drop required point 9 - 人間性ドロップ必要ポイント9
	// DESC: Threshold for acquiring humanity 9 - 人間性を取得する為の閾値9
	uint16_t humanityDropPoint9_020;

	// NAME: Humanity drop required points 10 - 人間性ドロップ必要ポイント10
	// DESC: Threshold 10 for acquiring humanity - 人間性を取得する為の閾値10
	uint16_t humanityDropPoint10_022;

	// NAME: Solo intrusion point addition lower limit - ソロ侵入ポイント加算値下限
	// DESC: The minimum value of solo intrusion points to be added when defeating an area boss. - エリアボスを倒したときに加算するソロ侵入ポイントの最小値。
	uint32_t soloBreakInPoint_Min_024;

	// NAME: Solo intrusion point addition value upper limit - ソロ侵入ポイント加算値上限
	// DESC: The maximum value of solo intrusion points to be added when defeating an area boss. - エリアボスを倒したときに加算するソロ侵入ポイントの最大値。
	uint32_t soloBreakInPoint_Max_028;

	// NAME: Boss defeated flag ID (for displaying purpose when hosting) - ボス撃破済みフラグID(ホスト化時の目的表示用)
	// DESC: If this flag is ON, it will not be displayed in the list of purpose settings at the time of hosting. If it is 0, it is always displayed. - このフラグがONの場合はホスト化時の目的設定のリストに表示しない。0の場合は常時表示。
	uint32_t defeatBossFlagId_forSignAimList_02C;

	// NAME: Purpose display flag ID - 目的表示フラグID
	uint32_t displayAimFlagId_030;

	// NAME: Boss discovery flag ID - ボス発見フラグID
	uint32_t foundBossFlagId_034;

	// NAME: Text ID at the time of discovery - 発見時テキストID
	int32_t foundBossTextId_038;

	// NAME: Undiscovered text ID - 未発見時テキストID
	int32_t notFindBossTextId_03C;

	// NAME: Boss challengeable flag ID - ボス挑戦可能フラグID
	// DESC: Boss challengeable flag ID. When selecting the target boss in the intrusion position search when "Is the intrusion point automatically generated?" In the multiplayer area para is ○, the boss with this flag ON is targeted. If it is 0, it is always the target. - ボス挑戦可能フラグID。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索で目的のボスを選ぶ時にこのフラグがONのボスが対象になる。0の場合は常に対象になる。
	uint32_t bossChallengeFlagId_040;

	// NAME: Boss defeat flag ID - ボス撃破フラグID
	// DESC: Boss defeat flag ID. When selecting the target boss in the intrusion position search when "Is the intrusion point automatically generated?" In the multiplayer area para is ○, the boss with this flag OFF is targeted. - ボス撃破フラグID。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索で目的のボスを選ぶ時にこのフラグがOFFのボスが対象になる。
	uint32_t defeatBossFlagId_044;

	// NAME: Boss position_X coordinates - ボス位置_X座標
	// DESC: Boss position_X coordinates (relative coordinates from the specified map). It is used to check the distance between the host and the boss in the intrusion position search when "Is the intrusion point automatically generated?" In the multiplayer area para. - ボス位置_X座標（指定したマップからの相対座標）。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	float bossPosX_048;

	// NAME: Boss position_Y coordinates - ボス位置_Y座標
	// DESC: Boss position_Y coordinates (relative coordinates from the specified map). It is used to check the distance between the host and the boss in the intrusion position search when "Is the intrusion point automatically generated?" In the multiplayer area para. - ボス位置_Y座標（指定したマップからの相対座標）。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	float bossPosY_04C;

	// NAME: Boss position_Z coordinates - ボス位置_Z座標
	// DESC: Boss position_Z coordinates (relative coordinates from the specified map). It is used to check the distance between the host and the boss in the intrusion position search when "Is the intrusion point automatically generated?" In the multiplayer area para. - ボス位置_Z座標（指定したマップからの相対座標）。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	float bossPosZ_050;

	// NAME: Boss position_Area number (mXX_00_00_00) - ボス位置_エリア番号(mXX_00_00_00)
	// DESC: Boss position_area number (mXX_00_00_00). It is used to check the distance between the host and the boss in the intrusion position search when "Is the intrusion point automatically generated?" In the multiplayer area para. - ボス位置_エリア番号(mXX_00_00_00)。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	uint8_t bossMapAreaNo_054;

	// NAME: Boss position_grid X number (m00_XX_00_00) - ボス位置_グリッドX番号(m00_XX_00_00)
	// DESC: Boss position_grid X number (m00_XX_00_00). It is used to check the distance between the host and the boss in the intrusion position search when "Is the intrusion point automatically generated?" In the multiplayer area para. - ボス位置_グリッドX番号(m00_XX_00_00)。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	uint8_t bossMapBlockNo_055;

	// NAME: Boss position_grid Z number (m00_00_XX_00) - ボス位置_グリッドZ番号(m00_00_XX_00)
	// DESC: Boss position_grid Z number (m00_00_XX_00). It is used to check the distance between the host and the boss in the intrusion position search when "Is the intrusion point automatically generated?" In the multiplayer area para. - ボス位置_グリッドZ番号(m00_00_XX_00)。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	uint8_t bossMapMapNo_056;

	// NAME: Reserved area - 予約領域
	// DESC: Reserved area - 予約領域
	uint8_t reserve_057[9];

} GameAreaParam;

#endif
