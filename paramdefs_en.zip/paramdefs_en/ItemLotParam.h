/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ItemLotParam_H
#define _PARAM_ItemLotParam_H
#include <stdint.h>

// ITEMLOT_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ItemLotParam {

	// NAME: 1: Item ID - １：アイテムID
	// DESC: Item ID that can be obtained - 取得できるアイテムのID
	int32_t lotItemId01_000;

	// NAME: 2: Item ID - ２：アイテムID
	// DESC: Item ID that can be obtained - 取得できるアイテムのID
	int32_t lotItemId02_004;

	// NAME: 3: Item ID - ３：アイテムID
	// DESC: Item ID that can be obtained - 取得できるアイテムのID
	int32_t lotItemId03_008;

	// NAME: 4: Item ID - ４：アイテムID
	// DESC: Item ID that can be obtained - 取得できるアイテムのID
	int32_t lotItemId04_00C;

	// NAME: 5: Item ID - ５：アイテムID
	// DESC: Item ID that can be obtained - 取得できるアイテムのID
	int32_t lotItemId05_010;

	// NAME: 6: Item ID - ６：アイテムID
	// DESC: Item ID that can be obtained - 取得できるアイテムのID
	int32_t lotItemId06_014;

	// NAME: 7: Item ID - ７：アイテムID
	// DESC: Item ID that can be obtained - 取得できるアイテムのID
	int32_t lotItemId07_018;

	// NAME: 8: Item ID - ８：アイテムID
	// DESC: Item ID that can be obtained - 取得できるアイテムのID
	int32_t lotItemId08_01C;

	// NAME: 1: Item category - １：アイテムカテゴリ
	// DESC: Category of items that can be obtained - 取得できるアイテムのカテゴリ
	int32_t lotItemCategory01_020;

	// NAME: 2: Item category - ２：アイテムカテゴリ
	// DESC: Category of items that can be obtained - 取得できるアイテムのカテゴリ
	int32_t lotItemCategory02_024;

	// NAME: 3: Item category - ３：アイテムカテゴリ
	// DESC: Category of items that can be obtained - 取得できるアイテムのカテゴリ
	int32_t lotItemCategory03_028;

	// NAME: 4: Item category - ４：アイテムカテゴリ
	// DESC: Category of items that can be obtained - 取得できるアイテムのカテゴリ
	int32_t lotItemCategory04_02C;

	// NAME: 5: Item category - ５：アイテムカテゴリ
	// DESC: Category of items that can be obtained - 取得できるアイテムのカテゴリ
	int32_t lotItemCategory05_030;

	// NAME: 6: Item category - ６：アイテムカテゴリ
	// DESC: Category of items that can be obtained - 取得できるアイテムのカテゴリ
	int32_t lotItemCategory06_034;

	// NAME: 7: Item category - ７：アイテムカテゴリ
	// DESC: Category of items that can be obtained - 取得できるアイテムのカテゴリ
	int32_t lotItemCategory07_038;

	// NAME: 8: Item category - ８：アイテムカテゴリ
	// DESC: Category of items that can be obtained - 取得できるアイテムのカテゴリ
	int32_t lotItemCategory08_03C;

	// NAME: Basic appearance point - 基本出現ポイント
	// DESC: Appearance point at normal time - 通常時の出現ポイント
	uint16_t lotItemBasePoint01_040;

	// NAME: Basic appearance point - 基本出現ポイント
	// DESC: Appearance point at normal time - 通常時の出現ポイント
	uint16_t lotItemBasePoint02_042;

	// NAME: Basic appearance point - 基本出現ポイント
	// DESC: Appearance point at normal time - 通常時の出現ポイント
	uint16_t lotItemBasePoint03_044;

	// NAME: Basic appearance point - 基本出現ポイント
	// DESC: Appearance point at normal time - 通常時の出現ポイント
	uint16_t lotItemBasePoint04_046;

	// NAME: Basic appearance point - 基本出現ポイント
	// DESC: Appearance point at normal time - 通常時の出現ポイント
	uint16_t lotItemBasePoint05_048;

	// NAME: Basic appearance point - 基本出現ポイント
	// DESC: Appearance point at normal time - 通常時の出現ポイント
	uint16_t lotItemBasePoint06_04A;

	// NAME: Basic appearance point - 基本出現ポイント
	// DESC: Appearance point at normal time - 通常時の出現ポイント
	uint16_t lotItemBasePoint07_04C;

	// NAME: Basic appearance point - 基本出現ポイント
	// DESC: Appearance point at normal time - 通常時の出現ポイント
	uint16_t lotItemBasePoint08_04E;

	// NAME: Appearance points after accumulation - 累積後出現ポイント
	// DESC: Appearance point at maximum cumulative - 最大累積時の出現ポイント
	uint16_t cumulateLotPoint01_050;

	// NAME: Appearance points after accumulation - 累積後出現ポイント
	// DESC: Appearance point at maximum cumulative - 最大累積時の出現ポイント
	uint16_t cumulateLotPoint02_052;

	// NAME: Cumulative post-appearance points - 累積後出現ポイント
	// DESC: Appearance point at maximum cumulative - 最大累積時の出現ポイント
	uint16_t cumulateLotPoint03_054;

	// NAME: Appearance points after accumulation - 累積後出現ポイント
	// DESC: Appearance point at maximum cumulative - 最大累積時の出現ポイント
	uint16_t cumulateLotPoint04_056;

	// NAME: Appearance points after accumulation - 累積後出現ポイント
	// DESC: Appearance point at maximum cumulative - 最大累積時の出現ポイント
	uint16_t cumulateLotPoint05_058;

	// NAME: Appearance points after accumulation - 累積後出現ポイント
	// DESC: Appearance point at maximum cumulative - 最大累積時の出現ポイント
	uint16_t cumulateLotPoint06_05A;

	// NAME: Cumulative post-appearance points - 累積後出現ポイント
	// DESC: Appearance point at maximum cumulative - 最大累積時の出現ポイント
	uint16_t cumulateLotPoint07_05C;

	// NAME: Cumulative post-appearance points - 累積後出現ポイント
	// DESC: Appearance point at maximum cumulative - 最大累積時の出現ポイント
	uint16_t cumulateLotPoint08_05E;

	// NAME: Another crunchy flag ID - 別ザクザクフラグID
	// DESC: Combined use of acquired flag and crunchy frame (0: common use) - 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId01_060;

	// NAME: Another crunchy flag ID - 別ザクザクフラグID
	// DESC: Combined use of acquired flag and crunchy frame (0: common use) - 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId02_064;

	// NAME: Another crunchy flag ID - 別ザクザクフラグID
	// DESC: Combined use of acquired flag and crunchy frame (0: common use) - 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId03_068;

	// NAME: Another crunchy flag ID - 別ザクザクフラグID
	// DESC: Combined use of acquired flag and crunchy frame (0: common use) - 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId04_06C;

	// NAME: Another crunchy flag ID - 別ザクザクフラグID
	// DESC: Combined use of acquired flag and crunchy frame (0: common use) - 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId05_070;

	// NAME: Another crunchy flag ID - 別ザクザクフラグID
	// DESC: Combined use of acquired flag and crunchy frame (0: common use) - 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId06_074;

	// NAME: Another crunchy flag ID - 別ザクザクフラグID
	// DESC: Combined use of acquired flag and crunchy frame (0: common use) - 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId07_078;

	// NAME: Another crunchy flag ID - 別ザクザクフラグID
	// DESC: Combined use of acquired flag and crunchy frame (0: common use) - 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId08_07C;

	// NAME: Crunchy flag ID - ザクザクフラグID
	// DESC: Combined use of acquired flag and crunchy frame (0: flag invalid) - 取得済みフラグとザクザク枠兼用(0:フラグ無効)
	uint32_t getItemFlagId_080;

	// NAME: Lottery cumulative save flag ID - 抽選累積保存フラグID
	// DESC: For saving the number of lottery (* 8 flag serial number used) - 抽選回数保存用(※8フラグ連番使用)
	uint32_t cumulateNumFlagId_084;

	// NAME: Maximum number of lottery cumulative - 抽選累積最大数
	// DESC: Maximum number of lottery cumulative (0: no cumulative) - 抽選累積最大数(0:累積なし)
	uint8_t cumulateNumMax_088;

	// NAME: Rarity overwrite - レア度上書き
	// DESC: Specify how valuable items are in the treasure chest. When -1, use the rarity of the equipment para without overwriting - 宝箱などに、どれくらい貴重なアイテムが入っているかを指定する。-1の時は上書きせず装備品パラのレア度を使用する
	int8_t lotItem_Rarity_089;

	// NAME: Quantity - 個数
	// DESC: Number of items that can be acquired - 取得できるアイテムの個数
	uint8_t lotItemNum01_08A;

	// NAME: Quantity - 個数
	// DESC: Number of items that can be acquired - 取得できるアイテムの個数
	uint8_t lotItemNum02_08B;

	// NAME: Quantity - 個数
	// DESC: Number of items that can be acquired - 取得できるアイテムの個数
	uint8_t lotItemNum03_08C;

	// NAME: Quantity - 個数
	// DESC: Number of items that can be acquired - 取得できるアイテムの個数
	uint8_t lotItemNum04_08D;

	// NAME: Quantity - 個数
	// DESC: Number of items that can be acquired - 取得できるアイテムの個数
	uint8_t lotItemNum05_08E;

	// NAME: Quantity - 個数
	// DESC: Number of items that can be acquired - 取得できるアイテムの個数
	uint8_t lotItemNum06_08F;

	// NAME: Quantity - 個数
	// DESC: Number of items that can be acquired - 取得できるアイテムの個数
	uint8_t lotItemNum07_090;

	// NAME: Quantity - 個数
	// DESC: Number of items that can be acquired - 取得できるアイテムの個数
	uint8_t lotItemNum08_091;

	// NAME: Luck parameter valid - 運パラメータ有効
	// DESC: Whether the probability of lottery reflects the player's luck - 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck01_092: 1;

	// NAME: Luck parameter valid - 運パラメータ有効
	// DESC: Whether the probability of lottery reflects the player's luck - 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck02_092: 1;

	// NAME: Luck parameter valid - 運パラメータ有効
	// DESC: Whether the probability of lottery reflects the player's luck - 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck03_092: 1;

	// NAME: Luck parameter valid - 運パラメータ有効
	// DESC: Whether the probability of lottery reflects the player's luck - 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck04_092: 1;

	// NAME: Luck parameter valid - 運パラメータ有効
	// DESC: Whether the probability of lottery reflects the player's luck - 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck05_092: 1;

	// NAME: Luck parameter valid - 運パラメータ有効
	// DESC: Whether the probability of lottery reflects the player's luck - 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck06_092: 1;

	// NAME: Luck parameter valid - 運パラメータ有効
	// DESC: Whether the probability of lottery reflects the player's luck - 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck07_092: 1;

	// NAME: Luck parameter valid - 運パラメータ有効
	// DESC: Whether the probability of lottery reflects the player's luck - 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck08_092: 1;

	// NAME: Cumulative reset - 累積リセット
	// DESC: Whether to reset cumulatively - 累積リセットするか
	uint16_t cumulateReset01_093: 1;

	// NAME: Cumulative reset - 累積リセット
	// DESC: Whether to reset cumulatively - 累積リセットするか
	uint16_t cumulateReset02_093: 1;

	// NAME: Cumulative reset - 累積リセット
	// DESC: Whether to reset cumulatively - 累積リセットするか
	uint16_t cumulateReset03_093: 1;

	// NAME: Cumulative reset - 累積リセット
	// DESC: Whether to reset cumulatively - 累積リセットするか
	uint16_t cumulateReset04_093: 1;

	// NAME: Cumulative reset - 累積リセット
	// DESC: Whether to reset cumulatively - 累積リセットするか
	uint16_t cumulateReset05_093: 1;

	// NAME: Cumulative reset - 累積リセット
	// DESC: Whether to reset cumulatively - 累積リセットするか
	uint16_t cumulateReset06_093: 1;

	// NAME: Cumulative reset - 累積リセット
	// DESC: Whether to reset cumulatively - 累積リセットするか
	uint16_t cumulateReset07_093: 1;

	// NAME: Cumulative reset - 累積リセット
	// DESC: Whether to reset cumulatively - 累積リセットするか
	uint16_t cumulateReset08_093: 1;

	// NAME: Offset after X week - X週目以降オフセット
	// DESC: Offset during lap play - 周回プレイ時のオフセット
	int8_t GameClearOffset_094;

	// NAME: Do you draw lots even with cooperating spirits? - 協力霊でも抽選するか
	// DESC: Do you draw lots even when you are a cooperating spirit? - 自身が協力霊の時でも抽選するか
	uint8_t canExecByFriendlyGhost_095: 1;

	// NAME: Do you draw even hostile spirits? - 敵対霊でも抽選するか
	// DESC: Do you draw lots even when you are a hostile spirit? - 自身が敵対霊の時でも抽選するか
	uint8_t canExecByHostileGhost_095: 1;

	// NAME: PAD1 - PAD1
	// DESC: PAD1 - PAD1
	uint8_t PAD1_095: 6;

	// NAME: PAD2 - PAD2
	// DESC: PAD2 - PAD2
	uint16_t PAD2_096;

} ItemLotParam;

#endif
