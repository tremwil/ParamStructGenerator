/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PerformanceCheckParam_H
#define _PARAM_PerformanceCheckParam_H
#include <stdint.h>

// PERFORMANCE_CHECK_PARAM
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 202
typedef struct _PerformanceCheckParam {

	// NAME: Report destination_Job type tag - 報告先_職種タグ
	// DESC: Report destination_Job type tag - 報告先_職種タグ
	uint8_t workTag_000;

	// NAME: Report destination_category tag - 報告先_カテゴリタグ
	// DESC: Report destination_category tag - 報告先_カテゴリタグ
	uint8_t categoryTag_001;

	// NAME: Comparison symbol - 比較記号
	// DESC: Comparison symbol - 比較記号
	uint8_t compareType_002;

	// NAME: Reservation 1 - 予約1
	// DESC: Reservation 1 - 予約1
	uint8_t dummy1_003[1];

	// NAME: Comparison value - 比較数値
	// DESC: Comparison value - 比較数値
	float compareValue_004;

	// NAME: Reservation 2 - 予約2
	// DESC: Reservation 2 - 予約2
	uint8_t dummy2_008[8];

	// NAME: Report destination_user tag - 報告先_userタグ
	// DESC: Report to_Performance person tag - 報告先_パフォーマンス人物タグ
	wchar_t userTag_010[16];

} PerformanceCheckParam;

#endif
