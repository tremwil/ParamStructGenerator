/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CommonSystemParam_H
#define _PARAM_CommonSystemParam_H
#include <stdint.h>

// COMMON_SYSTEM_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CommonSystemParam {

	// NAME: At the start of the game Map name ID_for save data - ゲーム開始時マップ名ID_セーブデータ用
	// DESC: At the start of the game Map name ID_for save data (SEQ15052) - ゲーム開始時マップ名ID_セーブデータ用(SEQ15052)
	uint32_t mapSaveMapNameIdOnGameStart_000;

	// NAME: Reserve - リザーブ
	// DESC: Reserve - リザーブ
	uint8_t reserve0_004[60];

} CommonSystemParam;

#endif
