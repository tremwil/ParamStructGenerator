/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SeMaterialConvertParam_H
#define _PARAM_SeMaterialConvertParam_H
#include <stdint.h>

// SE_MATERIAL_CONVERT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SeMaterialConvertParam {

	// NAME: SE material ID - SE材質ID
	// DESC: Conversion from SFX material ID (3 digits) to SE material ID (2 digits) - SFX材質ID（３桁）からSE材質ID（２桁）への変換
	uint8_t seMaterialId_000;

	// NAME: Padding - パディング
	// DESC: Padding - パディング
	uint8_t pad_001[3];

} SeMaterialConvertParam;

#endif
