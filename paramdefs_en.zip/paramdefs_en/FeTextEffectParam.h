/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_FeTextEffectParam_H
#define _PARAM_FeTextEffectParam_H
#include <stdint.h>

// FE_TEXT_EFFECT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _FeTextEffectParam {

	// NAME: Resource ID - リソースID
	// DESC: Instance name of the menu resource. ID of TextEffect_X - メニューリソースのインスタンス名。TextEffect_X のID
	int16_t resId_000;

	// NAME: Padding - パディング
	uint8_t pad1_002[2];

	// NAME: Text ID - テキストID
	// DESC: Text ID to display (-1: No text). MenuText - 表示するテキストID(-1: テキストなし)。MenuText
	int32_t textId_004;

	// NAME: SE ID - SEのID
	// DESC: Voice ID to play (-1: No SE) - 再生するVoiceのID(-1: SEなし)
	int32_t seId_008;

	// NAME: Whether to display at the same time as the map name - マップ名と同時に表示するか
	// DESC: Whether to display at the same time as the map name - マップ名と同時に表示するか
	uint8_t canMixMapName_00C: 1;

	// NAME: Padding - パディング
	uint8_t pad3_00C: 7;

	// NAME: Padding - パディング
	uint8_t pad2_00D[19];

} FeTextEffectParam;

#endif
