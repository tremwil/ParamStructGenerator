/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_NpcAiBehaviorProbabilityParam_H
#define _PARAM_NpcAiBehaviorProbabilityParam_H
#include <stdint.h>

// NPC_AI_BEHAVIOR_PROBABILITY_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _NpcAiBehaviorProbabilityParam {

	// NAME: Right hand proximity_R1 combo - 右手近接_R1コンボ
	// DESC: Right-handed proximity behavior - 右手近接行動
	int16_t param000_000;

	// NAME: Right hand proximity_R2 combo - 右手近接_R2コンボ
	// DESC: Right-handed proximity behavior - 右手近接行動
	int16_t param001_002;

	// NAME: Right-handed melee_dash attack - 右手近接_ダッシュ攻撃
	// DESC: Right-handed proximity behavior - 右手近接行動
	int16_t param002_004;

	// NAME: Right-handed melee_front rolling attack - 右手近接_前ローリング攻撃
	// DESC: Right-handed proximity behavior - 右手近接行動
	int16_t param003_006;

	// NAME: Right hand proximity_left and right rolling attack - 右手近接_左右ローリング攻撃
	// DESC: Right-handed proximity behavior - 右手近接行動
	int16_t param004_008;

	// NAME: Right-handed melee_rear rolling attack - 右手近接_後ローリング攻撃
	// DESC: Right-handed proximity behavior - 右手近接行動
	int16_t param005_00A;

	// NAME: Right-handed melee_backstep attack - 右手近接_バックステップ攻撃
	// DESC: Right-handed proximity behavior - 右手近接行動
	int16_t param006_00C;

	// NAME: Right-handed melee_jump attack - 右手近接_ジャンプ攻撃
	// DESC: Right-handed proximity behavior - 右手近接行動
	int16_t param007_00E;

	// NAME: Right-handed melee_dash jump attack - 右手近接_ダッシュジャンプ攻撃
	// DESC: Right-handed proximity behavior - 右手近接行動
	int16_t param008_010;

	// NAME: unused - 未使用
	int16_t param009_012;

	// NAME: Right hand long range _R1 shooting - 右手遠距離_R1射撃
	// DESC: Right-handed long-range weapon action - 右手遠距離武器行動
	int16_t param010_014;

	// NAME: Right hand long range _R2 shooting - 右手遠距離_R2射撃
	// DESC: Right-handed long-range weapon action - 右手遠距離武器行動
	int16_t param011_016;

	// NAME: unused - 未使用
	int16_t param012_018;

	// NAME: Right hand magic _ long distance magic _ move forward - 右手魔法_遠距離魔法_前移動
	// DESC: Right hand magic action - 右手魔法行動
	int16_t param013_01A;

	// NAME: Right-handed magic_long-distance magic_moving backwards - 右手魔法_遠距離魔法_後ろ移動
	// DESC: Right hand magic action - 右手魔法行動
	int16_t param014_01C;

	// NAME: Move left / right [Close Draw Bow] - 左右移動[CloseDrawBow]
	// DESC: Interrupt approached while holding a bow - 弓構え中に近づかれたインタラプト
	int16_t param015_01E;

	// NAME: Left and right rolling [Close Draw Bow] - 左右ローリング[CloseDrawBow]
	// DESC: Interrupt approached while holding a bow - 弓構え中に近づかれたインタラプト
	int16_t param016_020;

	// NAME: Do not interrupt [Close Draw Bow] - 割り込まない[CloseDrawBow]
	// DESC: Interrupt approached while holding a bow - 弓構え中に近づかれたインタラプト
	int16_t param017_022;

	// NAME: unused - 未使用
	int16_t param018_024;

	// NAME: unused - 未使用
	int16_t param019_026;

	// NAME: Right hand magic_Melee magic_Left and right - 右手魔法_近接魔法_左右
	// DESC: Right hand magic action - 右手魔法行動
	int16_t param020_028;

	// NAME: Right hand magic_medium range magic_left and right - 右手魔法_中距離魔法_左右
	// DESC: Right hand magic action - 右手魔法行動
	int16_t param021_02A;

	// NAME: Right hand magic _ long distance magic _ left and right - 右手魔法_遠距離魔法_左右
	// DESC: Right hand magic action - 右手魔法行動
	int16_t param022_02C;

	// NAME: Right hand magic _HP recovery magic - 右手魔法_HP回復魔法
	// DESC: Right hand magic action - 右手魔法行動
	int16_t param023_02E;

	// NAME: Right hand magic_buff magic - 右手魔法_バフ魔法
	// DESC: Right hand magic action - 右手魔法行動
	int16_t param024_030;

	// NAME: Right hand magic_Melee magic_Move forward - 右手魔法_近接魔法_前移動
	// DESC: Right hand magic action - 右手魔法行動
	int16_t param025_032;

	// NAME: Right hand magic_Melee magic_Move backwards - 右手魔法_近接魔法_後ろ移動
	// DESC: Right hand magic action - 右手魔法行動
	int16_t param026_034;

	// NAME: Right-handed magic_Medium-range magic_Move forward - 右手魔法_中距離魔法_前移動
	// DESC: Right hand magic action - 右手魔法行動
	int16_t param027_036;

	// NAME: Right-handed magic_Medium-range magic_Move backwards - 右手魔法_中距離魔法_後ろ移動
	// DESC: Right hand magic action - 右手魔法行動
	int16_t param028_038;

	// NAME: unused - 未使用
	int16_t param029_03A;

	// NAME: Right hand shield_R1 attack - 右手盾_R1攻撃
	// DESC: Right hand shield action - 右手盾行動
	int16_t param030_03C;

	// NAME: Right hand shield_R2 attack - 右手盾_R2攻撃
	// DESC: Right hand shield action - 右手盾行動
	int16_t param031_03E;

	// NAME: unused - 未使用
	int16_t param032_040;

	// NAME: unused - 未使用
	int16_t param033_042;

	// NAME: unused - 未使用
	int16_t param034_044;

	// NAME: Backstep [SuccessGuard] - バックステップ[SuccessGuard]
	// DESC: Guard success interrupt - ガード成功インタラプト
	int16_t param035_046;

	// NAME: Do not interrupt [SuccessGuard] - 割り込まない[SuccessGuard]
	// DESC: Guard success interrupt - ガード成功インタラプト
	int16_t param036_048;

	// NAME: Guard Counter Attack [SuccessGuard] - ガードカウンター攻撃[SuccessGuard]
	// DESC: Guard success interrupt - ガード成功インタラプト
	int16_t param037_04A;

	// NAME: unused - 未使用
	int16_t param038_04C;

	// NAME: unused - 未使用
	int16_t param039_04E;

	// NAME: Left hand proximity_R1 combo (both hands only) - 左手近接_R1コンボ(両手持ちのみ)
	// DESC: Left hand proximity behavior - 左手近接行動
	int16_t param040_050;

	// NAME: Left hand proximity_R2 combo (both hands only) - 左手近接_R2コンボ(両手持ちのみ)
	// DESC: Left hand proximity behavior - 左手近接行動
	int16_t param041_052;

	// NAME: Left-handed proximity_L1 combo (one-handed only) - 左手近接_L1コンボ(片手持ちのみ)
	// DESC: Left hand proximity behavior - 左手近接行動
	int16_t param042_054;

	// NAME: Left-handed melee_dash attack (both hands only) - 左手近接_ダッシュ攻撃(両手持ちのみ)
	// DESC: Left hand proximity behavior - 左手近接行動
	int16_t param043_056;

	// NAME: Left hand proximity_front rolling attack (both hands only) - 左手近接_前ローリング攻撃(両手持ちのみ)
	// DESC: Left hand proximity behavior - 左手近接行動
	int16_t param044_058;

	// NAME: Left hand proximity_left and right rolling attack (only with both hands) - 左手近接_左右ローリング攻撃(両手持ちのみ)
	// DESC: Left hand proximity behavior - 左手近接行動
	int16_t param045_05A;

	// NAME: Left hand proximity_rear rolling attack (only with both hands) - 左手近接_後ローリング攻撃(両手持ちのみ)
	// DESC: Left hand proximity behavior - 左手近接行動
	int16_t param046_05C;

	// NAME: Left-handed melee_backstep attack (only with both hands) - 左手近接_バックステップ攻撃(両手持ちのみ)
	// DESC: Left hand proximity behavior - 左手近接行動
	int16_t param047_05E;

	// NAME: Left-handed melee_jump attack (only with both hands) - 左手近接_ジャンプ攻撃(両手持ちのみ)
	// DESC: Left hand proximity behavior - 左手近接行動
	int16_t param048_060;

	// NAME: Left-handed melee_dash jump attack (only with both hands) - 左手近接_ダッシュジャンプ攻撃(両手持ちのみ)
	// DESC: Left hand proximity behavior - 左手近接行動
	int16_t param049_062;

	// NAME: Left hand long range _R1 shooting - 左手遠距離_R1射撃
	// DESC: Left-handed long-range weapon action - 左手遠距離武器行動
	int16_t param050_064;

	// NAME: Left hand long range _R2 shooting - 左手遠距離_R2射撃
	// DESC: Left-handed long-range weapon action - 左手遠距離武器行動
	int16_t param051_066;

	// NAME: unused - 未使用
	int16_t param052_068;

	// NAME: Left hand magic _ long distance magic _ move forward - 左手魔法_遠距離魔法_前移動
	// DESC: Left hand magic action - 左手魔法行動
	int16_t param053_06A;

	// NAME: Left hand magic _ long distance magic _ move backward - 左手魔法_遠距離魔法_後ろ移動
	// DESC: Left hand magic action - 左手魔法行動
	int16_t param054_06C;

	// NAME: Fatal Attack [Success Parry] - 致命攻撃[SuccessParry]
	// DESC: Parry Success Interrupt - パリィ成功インタラプト
	int16_t param055_06E;

	// NAME: Do not interrupt [Success Parry] - 割り込まない[SuccessParry]
	// DESC: Parry Success Interrupt - パリィ成功インタラプト
	int16_t param056_070;

	// NAME: unused - 未使用
	int16_t param057_072;

	// NAME: unused - 未使用
	int16_t param058_074;

	// NAME: unused - 未使用
	int16_t param059_076;

	// NAME: Left hand magic_Melee magic_Left and right - 左手魔法_近接魔法_左右
	// DESC: Left hand magic action - 左手魔法行動
	int16_t param060_078;

	// NAME: Left hand magic_medium range magic_left and right - 左手魔法_中距離魔法_左右
	// DESC: Left hand magic action - 左手魔法行動
	int16_t param061_07A;

	// NAME: Left hand magic _ long distance magic _ left and right - 左手魔法_遠距離魔法_左右
	// DESC: Left hand magic action - 左手魔法行動
	int16_t param062_07C;

	// NAME: Left hand magic _HP recovery magic - 左手魔法_HP回復魔法
	// DESC: Left hand magic action - 左手魔法行動
	int16_t param063_07E;

	// NAME: Left hand magic_buff magic - 左手魔法_バフ魔法
	// DESC: Left hand magic action - 左手魔法行動
	int16_t param064_080;

	// NAME: Left hand magic_Melee magic_Move forward - 左手魔法_近接魔法_前移動
	// DESC: Left hand magic action - 左手魔法行動
	int16_t param065_082;

	// NAME: Left hand magic_Melee magic_Move backward - 左手魔法_近接魔法_後ろ移動
	// DESC: Left hand magic action - 左手魔法行動
	int16_t param066_084;

	// NAME: Left hand magic_medium range magic_move forward - 左手魔法_中距離魔法_前移動
	// DESC: Left hand magic action - 左手魔法行動
	int16_t param067_086;

	// NAME: Left hand magic_medium range magic_moving backwards - 左手魔法_中距離魔法_後ろ移動
	// DESC: Left hand magic action - 左手魔法行動
	int16_t param068_088;

	// NAME: unused - 未使用
	int16_t param069_08A;

	// NAME: backstep - バックステップ
	// DESC: Common behavior - 共通行動
	int16_t param070_08C;

	// NAME: Front rolling - 前ローリング
	// DESC: Common behavior - 共通行動
	int16_t param071_08E;

	// NAME: Left and right rolling - 左右ローリング
	// DESC: Common behavior - 共通行動
	int16_t param072_090;

	// NAME: Rolling behind - 後ろローリング
	// DESC: Common behavior - 共通行動
	int16_t param073_092;

	// NAME: Move left and right - 左右移動
	// DESC: Common behavior - 共通行動
	int16_t param074_094;

	// NAME: Recession - 後退
	// DESC: Common behavior - 共通行動
	int16_t param075_096;

	// NAME: Dash approach - ダッシュ接近
	// DESC: Common behavior - 共通行動
	int16_t param076_098;

	// NAME: stand-by - 待機
	// DESC: Common behavior - 共通行動
	int16_t param077_09A;

	// NAME: Switch to two-handed right hand - 右手両手持ちに持ち替え
	// DESC: Common behavior - 共通行動
	int16_t param078_09C;

	// NAME: Switch to two-handed left hand - 左手両手持ちに持ち替え
	// DESC: Common behavior - 共通行動
	int16_t param079_09E;

	// NAME: Switch to one-handed - 片手持ちに持ち替え
	// DESC: Common behavior - 共通行動
	int16_t param080_0A0;

	// NAME: Approach to combat distance - 戦闘距離までアプローチ
	// DESC: Common behavior - 共通行動
	int16_t param081_0A2;

	// NAME: unused - 未使用
	int16_t param082_0A4;

	// NAME: unused - 未使用
	int16_t param083_0A6;

	// NAME: unused - 未使用
	int16_t param084_0A8;

	// NAME: Deadly Attack [Guard Break] - 致命攻撃[GuardBreak]
	// DESC: Guard break interrupt - ガードブレイクインタラプト
	int16_t param085_0AA;

	// NAME: Dash Attack [Guard Break] - ダッシュ攻撃[GuardBreak]
	// DESC: Guard break interrupt - ガードブレイクインタラプト
	int16_t param086_0AC;

	// NAME: Magic_Melee Magic [GuardBreak] - 魔法_近接魔法[GuardBreak]
	// DESC: Guard break interrupt - ガードブレイクインタラプト
	int16_t param087_0AE;

	// NAME: Do not interrupt [Guard Break] - 割り込まない[GuardBreak]
	// DESC: Guard break interrupt - ガードブレイクインタラプト
	int16_t param088_0B0;

	// NAME: unused - 未使用
	int16_t param089_0B2;

	// NAME: Shield Chiku - 盾チク
	// DESC: Special behavior - 特殊行動
	int16_t param090_0B4;

	// NAME: unused - 未使用
	int16_t param091_0B6;

	// NAME: unused - 未使用
	int16_t param092_0B8;

	// NAME: unused - 未使用
	int16_t param093_0BA;

	// NAME: unused - 未使用
	int16_t param094_0BC;

	// NAME: Dash Attack [Estus] - ダッシュ攻撃[Estus]
	// DESC: Interrupt who drank Est - エストを飲んだインタラプト
	int16_t param095_0BE;

	// NAME: Throwing item [Estus] - 投擲アイテム[Estus]
	// DESC: Interrupt who drank Est - エストを飲んだインタラプト
	int16_t param096_0C0;

	// NAME: Do not interrupt [Estus] - 割り込まない[Estus]
	// DESC: Interrupt who drank Est - エストを飲んだインタラプト
	int16_t param097_0C2;

	// NAME: unused - 未使用
	int16_t param098_0C4;

	// NAME: unused - 未使用
	int16_t param099_0C6;

	// NAME: Parry time - パリィ[Parrytime]
	// DESC: Parry Timing Interrupt - パリィタイミングインタラプト
	int16_t param100_0C8;

	// NAME: Front rolling [Parrytime] - 前ローリング[Parrytime]
	// DESC: Parry Timing Interrupt - パリィタイミングインタラプト
	int16_t param101_0CA;

	// NAME: Left and right rolling [Parrytime] - 左右ローリング[Parrytime]
	// DESC: Parry Timing Interrupt - パリィタイミングインタラプト
	int16_t param102_0CC;

	// NAME: Rolling behind [Parrytime] - 後ろローリング[Parrytime]
	// DESC: Parry Timing Interrupt - パリィタイミングインタラプト
	int16_t param103_0CE;

	// NAME: Backstep attack [Parrytime] - バックステップ攻撃[Parrytime]
	// DESC: Parry Timing Interrupt - パリィタイミングインタラプト
	int16_t param104_0D0;

	// NAME: On-the-spot guard [Parrytime] - その場ガード[Parrytime]
	// DESC: Parry Timing Interrupt - パリィタイミングインタラプト
	int16_t param105_0D2;

	// NAME: Do not interrupt [Parrytime] - 割り込まない[Parrytime]
	// DESC: Parry Timing Interrupt - パリィタイミングインタラプト
	int16_t param106_0D4;

	// NAME: unused - 未使用
	int16_t param107_0D6;

	// NAME: unused - 未使用
	int16_t param108_0D8;

	// NAME: unused - 未使用
	int16_t param109_0DA;

	// NAME: Rolling behind [Damaged] - 後ろローリング[Damaged]
	// DESC: Damaged interrupt - 被ダメージインタラプト
	int16_t param110_0DC;

	// NAME: Left and right rolling [Damaged] - 左右ローリング[Damaged]
	// DESC: Damaged interrupt - 被ダメージインタラプト
	int16_t param111_0DE;

	// NAME: Back guard move [Damaged] - 後ろガード移動[Damaged]
	// DESC: Damaged interrupt - 被ダメージインタラプト
	int16_t param112_0E0;

	// NAME: Left and right guard movement [Damaged] - 左右ガード移動[Damaged]
	// DESC: Damaged interrupt - 被ダメージインタラプト
	int16_t param113_0E2;

	// NAME: Do not interrupt [Damaged] - 割り込まない[Damaged]
	// DESC: Damaged interrupt - 被ダメージインタラプト
	int16_t param114_0E4;

	// NAME: R1 Combo [Damaged] - R1コンボ[Damaged]
	// DESC: Damaged interrupt - 被ダメージインタラプト
	int16_t param115_0E6;

	// NAME: Front rolling [Damaged] - 前ローリング[Damaged]
	// DESC: Damaged interrupt - 被ダメージインタラプト
	int16_t param116_0E8;

	// NAME: Backstep [Damaged] - バックステップ[Damaged]
	// DESC: Damaged interrupt - 被ダメージインタラプト
	int16_t param117_0EA;

	// NAME: Front guard move [Damaged] - 前ガード移動[Damaged]
	// DESC: Damaged interrupt - 被ダメージインタラプト
	int16_t param118_0EC;

	// NAME: unused - 未使用
	int16_t param119_0EE;

	// NAME: Front rolling [Shoot] - 前ローリング[Shoot]
	// DESC: Projectile discovery interrupt - 飛び道具発見インタラプト
	int16_t param120_0F0;

	// NAME: Left and right rolling [Shoot] - 左右ローリング[Shoot]
	// DESC: Projectile discovery interrupt - 飛び道具発見インタラプト
	int16_t param121_0F2;

	// NAME: Front guard move [Shoot] - 前ガード移動[Shoot]
	// DESC: Projectile discovery interrupt - 飛び道具発見インタラプト
	int16_t param122_0F4;

	// NAME: Left and right guard movement [Shoot] - 左右ガード移動[Shoot]
	// DESC: Projectile discovery interrupt - 飛び道具発見インタラプト
	int16_t param123_0F6;

	// NAME: Do not interrupt [Shoot] - 割り込まない[Shoot]
	// DESC: Projectile discovery interrupt - 飛び道具発見インタラプト
	int16_t param124_0F8;

	// NAME: After rolling [Shoot] - 後ローリング[Shoot]
	// DESC: Projectile discovery interrupt - 飛び道具発見インタラプト
	int16_t param125_0FA;

	// NAME: Dash approach [Shoot] - ダッシュ接近[Shoot]
	// DESC: Projectile discovery interrupt - 飛び道具発見インタラプト
	int16_t param126_0FC;

	// NAME: unused - 未使用
	int16_t param127_0FE;

	// NAME: unused - 未使用
	int16_t param128_100;

	// NAME: unused - 未使用
	int16_t param129_102;

	// NAME: Backstep [Find Attack] - バックステップ[FindAttack]
	// DESC: Attack detection interrupt - 攻撃発見インタラプト
	int16_t param130_104;

	// NAME: Front rolling [Find Attack] - 前ローリング[FindAttack]
	// DESC: Attack detection interrupt - 攻撃発見インタラプト
	int16_t param131_106;

	// NAME: Left and right rolling [Find Attack] - 左右ローリング[FindAttack]
	// DESC: Attack detection interrupt - 攻撃発見インタラプト
	int16_t param132_108;

	// NAME: After rolling [Find Attack] - 後ローリング[FindAttack]
	// DESC: Attack detection interrupt - 攻撃発見インタラプト
	int16_t param133_10A;

	// NAME: Front guard move [Find Attack] - 前ガード移動[FindAttack]
	// DESC: Attack detection interrupt - 攻撃発見インタラプト
	int16_t param134_10C;

	// NAME: Left and right guard movement [Find Attack] - 左右ガード移動[FindAttack]
	// DESC: Attack detection interrupt - 攻撃発見インタラプト
	int16_t param135_10E;

	// NAME: On-the-spot guard [Find Attack] - その場ガード[FindAttack]
	// DESC: Attack detection interrupt - 攻撃発見インタラプト
	int16_t param136_110;

	// NAME: Shield Chiku [Find Attack] - 盾チク[FindAttack]
	// DESC: Attack detection interrupt - 攻撃発見インタラプト
	int16_t param137_112;

	// NAME: Do not interrupt [Find Attack] - 割り込まない[FindAttack]
	// DESC: Attack detection interrupt - 攻撃発見インタラプト
	int16_t param138_114;

	// NAME: On-the-spot avoidance arts [Find Attack] - その場回避アーツ[FindAttack]
	// DESC: Attack detection interrupt - 攻撃発見インタラプト
	int16_t param139_116;

	// NAME: Probability of holding both hands at R1 combo - R1コンボ時両手持ち確率
	// DESC: Other probability corrections - その他の確率補正
	int16_t param140_118;

	// NAME: Probability of holding both hands at R2 combo - R2コンボ時両手持ち確率
	// DESC: Other probability corrections - その他の確率補正
	int16_t param141_11A;

	// NAME: Guard probability when moving during planning action - プランニング行動時の移動時ガード確率
	// DESC: Other probability corrections - その他の確率補正
	int16_t param142_11C;

	// NAME: Probability of replacing R1 attack with dual wield attack - R1攻撃を二刀攻撃に置き換える確率
	// DESC: Other probability corrections - その他の確率補正
	int16_t param143_11E;

	// NAME: Probability of replacing evasion with special rolling arts - 回避を特殊ローリングアーツに置き換える確率
	// DESC: Other probability corrections - その他の確率補正
	int16_t param144_120;

	// NAME: Use of throwing items - 投擲系アイテムの使用
	// DESC: Item usage system - アイテム使用系
	int16_t param145_122;

	// NAME: Use of HP recovery items - HP回復アイテムの使用
	// DESC: Item usage system - アイテム使用系
	int16_t param146_124;

	// NAME: Use of buff items - バフアイテムの使用
	// DESC: Item usage system - アイテム使用系
	int16_t param147_126;

	// NAME: Drug package combo attack - 薬包コンボ攻撃
	// DESC: Item usage system - アイテム使用系
	int16_t param148_128;

	// NAME: unused - 未使用
	int16_t param149_12A;

	// NAME: Arts_Short Range Attack - アーツ_近距離攻撃
	// DESC: Arts behavior system - アーツ行動系
	int16_t param150_12C;

	// NAME: Arts_Medium Range Attack - アーツ_中距離攻撃
	// DESC: Arts behavior system - アーツ行動系
	int16_t param151_12E;

	// NAME: Arts_range attack - アーツ_遠距離攻撃
	// DESC: Arts behavior system - アーツ行動系
	int16_t param152_130;

	// NAME: Arts_Recovery - アーツ_回復
	// DESC: Arts behavior system - アーツ行動系
	int16_t param153_132;

	// NAME: Arts_buff - アーツ_バフ
	// DESC: Arts behavior system - アーツ行動系
	int16_t param154_134;

	// NAME: unused - 未使用
	// DESC: Arts behavior system - アーツ行動系
	int16_t param155_136;

	// NAME: unused - 未使用
	int16_t param156_138;

	// NAME: unused - 未使用
	int16_t param157_13A;

	// NAME: unused - 未使用
	int16_t param158_13C;

	// NAME: unused - 未使用
	int16_t param159_13E;

	// NAME: unused - 未使用
	int16_t param160_140;

	// NAME: unused - 未使用
	int16_t param161_142;

	// NAME: unused - 未使用
	int16_t param162_144;

	// NAME: unused - 未使用
	int16_t param163_146;

	// NAME: unused - 未使用
	int16_t param164_148;

	// NAME: unused - 未使用
	int16_t param165_14A;

	// NAME: unused - 未使用
	int16_t param166_14C;

	// NAME: unused - 未使用
	int16_t param167_14E;

	// NAME: unused - 未使用
	int16_t param168_150;

	// NAME: unused - 未使用
	int16_t param169_152;

	// NAME: unused - 未使用
	int16_t param170_154;

	// NAME: unused - 未使用
	int16_t param171_156;

	// NAME: unused - 未使用
	int16_t param172_158;

	// NAME: unused - 未使用
	int16_t param173_15A;

	// NAME: unused - 未使用
	int16_t param174_15C;

	// NAME: unused - 未使用
	int16_t param175_15E;

	// NAME: unused - 未使用
	int16_t param176_160;

	// NAME: unused - 未使用
	int16_t param177_162;

	// NAME: unused - 未使用
	int16_t param178_164;

	// NAME: unused - 未使用
	int16_t param179_166;

	// NAME: unused - 未使用
	int16_t param180_168;

	// NAME: unused - 未使用
	int16_t param181_16A;

	// NAME: unused - 未使用
	int16_t param182_16C;

	// NAME: unused - 未使用
	int16_t param183_16E;

	// NAME: unused - 未使用
	int16_t param184_170;

	// NAME: unused - 未使用
	int16_t param185_172;

	// NAME: unused - 未使用
	int16_t param186_174;

	// NAME: unused - 未使用
	int16_t param187_176;

	// NAME: unused - 未使用
	int16_t param188_178;

	// NAME: unused - 未使用
	int16_t param189_17A;

	// NAME: unused - 未使用
	int16_t param190_17C;

	// NAME: unused - 未使用
	int16_t param191_17E;

	// NAME: unused - 未使用
	int16_t param192_180;

	// NAME: unused - 未使用
	int16_t param193_182;

	// NAME: unused - 未使用
	int16_t param194_184;

	// NAME: unused - 未使用
	int16_t param195_186;

	// NAME: unused - 未使用
	int16_t param196_188;

	// NAME: unused - 未使用
	int16_t param197_18A;

	// NAME: unused - 未使用
	int16_t param198_18C;

	// NAME: unused - 未使用
	int16_t param199_18E;

} NpcAiBehaviorProbabilityParam;

#endif
