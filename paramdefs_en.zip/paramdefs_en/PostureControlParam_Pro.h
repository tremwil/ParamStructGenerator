/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PostureControlParam_Pro_H
#define _PARAM_PostureControlParam_Pro_H
#include <stdint.h>

// POSTURE_CONTROL_PARAM_PRO_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _PostureControlParam_Pro {

	// NAME: Right arm_inside and outside - 右腕_内外
	// DESC: Right arm_inside and outside - 右腕_内外
	int16_t a000_rightArmIO_000;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a000_rightArmFB_002;

	// NAME: Left arm_inside and outside - 左腕_内外
	// DESC: Left arm_inside and outside - 左腕_内外
	int16_t a000_leftArmIO_004;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a000_leftArmFB_006;

	// NAME: Right arm_inside and outside - 右腕_内外
	// DESC: Right arm_inside and outside - 右腕_内外
	int16_t a002_rightArmIO_008;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a002_rightArmFB_00A;

	// NAME: Left arm_inside and outside - 左腕_内外
	// DESC: Left arm_inside and outside - 左腕_内外
	int16_t a002_leftArmIO_00C;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a002_leftArmFB_00E;

	// NAME: Right arm_inside and outside - 右腕_内外
	// DESC: Right arm_inside and outside - 右腕_内外
	int16_t a003_rightArmIO_010;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a003_rightArmFB_012;

	// NAME: Left arm_inside and outside - 左腕_内外
	// DESC: Left arm_inside and outside - 左腕_内外
	int16_t a003_leftArmIO_014;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a003_leftArmFB_016;

	// NAME: Right arm_inside and outside - 右腕_内外
	// DESC: Right arm_inside and outside - 右腕_内外
	int16_t a010_rightArmIO_018;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a010_rightArmFB_01A;

	// NAME: Left arm_inside and outside - 左腕_内外
	// DESC: Left arm_inside and outside - 左腕_内外
	int16_t a010_leftArmIO_01C;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a010_leftArmFB_01E;

	// NAME: Right arm_inside and outside - 右腕_内外
	// DESC: Right arm_inside and outside - 右腕_内外
	int16_t a012_rightArmIO_020;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a012_rightArmFB_022;

	// NAME: Left arm_inside and outside - 左腕_内外
	// DESC: Left arm_inside and outside - 左腕_内外
	int16_t a012_leftArmIO_024;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a012_leftArmFB_026;

	// NAME: Right arm_inside and outside - 右腕_内外
	// DESC: Right arm_inside and outside - 右腕_内外
	int16_t a013_rightArmIO_028;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a013_rightArmFB_02A;

	// NAME: Left arm_inside and outside - 左腕_内外
	// DESC: Left arm_inside and outside - 左腕_内外
	int16_t a013_leftArmIO_02C;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a013_leftArmFB_02E;

	// NAME: Right arm_inside and outside - 右腕_内外
	// DESC: Right arm_inside and outside - 右腕_内外
	int16_t a014_rightArmIO_030;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a014_rightArmFB_032;

	// NAME: Left arm_inside and outside - 左腕_内外
	// DESC: Left arm_inside and outside - 左腕_内外
	int16_t a014_leftArmIO_034;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a014_leftArmFB_036;

	// NAME: Right arm_inside and outside - 右腕_内外
	// DESC: Right arm_inside and outside - 右腕_内外
	int16_t a015_rightArmIO_038;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a015_rightArmFB_03A;

	// NAME: Left arm_inside and outside - 左腕_内外
	// DESC: Left arm_inside and outside - 左腕_内外
	int16_t a015_leftArmIO_03C;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a015_leftArmFB_03E;

	// NAME: Right arm_inside and outside - 右腕_内外
	// DESC: Right arm_inside and outside - 右腕_内外
	int16_t a016_rightArmIO_040;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a016_rightArmFB_042;

	// NAME: Left arm_inside and outside - 左腕_内外
	// DESC: Left arm_inside and outside - 左腕_内外
	int16_t a016_leftArmIO_044;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a016_leftArmFB_046;

	// NAME: pad - pad
	uint8_t pad_048[8];

} PostureControlParam_Pro;

#endif
