/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AttackElementCorrectParam_H
#define _PARAM_AttackElementCorrectParam_H
#include <stdint.h>

// ATTACK_ELEMENT_CORRECT_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AttackElementCorrectParam {

	// NAME: Whether to correct muscle strength (physical) - 筋力補正するか（物理）
	uint8_t isStrengthCorrect_byPhysics_000: 1;

	// NAME: Whether to correct the skill (physical) - 技量補正するか（物理）
	uint8_t isDexterityCorrect_byPhysics_000: 1;

	// NAME: Whether to correct the force (physics) - 理力補正するか（物理）
	uint8_t isMagicCorrect_byPhysics_000: 1;

	// NAME: Do you correct your faith (physics)? - 信仰補正するか（物理）
	uint8_t isFaithCorrect_byPhysics_000: 1;

	// NAME: Whether to correct luck (physical) - 運補正するか（物理）
	uint8_t isLuckCorrect_byPhysics_000: 1;

	// NAME: Whether to correct muscle strength (magic) - 筋力補正するか（魔法）
	uint8_t isStrengthCorrect_byMagic_000: 1;

	// NAME: Do you correct your workmanship (magic)? - 技量補正するか（魔法）
	uint8_t isDexterityCorrect_byMagic_000: 1;

	// NAME: Do you correct the force (magic)? - 理力補正するか（魔法）
	uint8_t isMagicCorrect_byMagic_000: 1;

	// NAME: Do you correct your faith (magic)? - 信仰補正するか（魔法）
	uint8_t isFaithCorrect_byMagic_001: 1;

	// NAME: Do you correct your luck (magic) - 運補正するか（魔法）
	uint8_t isLuckCorrect_byMagic_001: 1;

	// NAME: Do you correct muscle strength (flame)? - 筋力補正するか（炎）
	uint8_t isStrengthCorrect_byFire_001: 1;

	// NAME: Do you correct your workmanship (flame)? - 技量補正するか（炎）
	uint8_t isDexterityCorrect_byFire_001: 1;

	// NAME: Do you correct the force (flame)? - 理力補正するか（炎）
	uint8_t isMagicCorrect_byFire_001: 1;

	// NAME: Do you correct your faith (flame)? - 信仰補正するか（炎）
	uint8_t isFaithCorrect_byFire_001: 1;

	// NAME: Do you correct your luck (flame)? - 運補正するか（炎）
	uint8_t isLuckCorrect_byFire_001: 1;

	// NAME: Whether to correct muscle strength (lightning) - 筋力補正するか（雷）
	uint8_t isStrengthCorrect_byThunder_001: 1;

	// NAME: Do you correct your workmanship (lightning)? - 技量補正するか（雷）
	uint8_t isDexterityCorrect_byThunder_002: 1;

	// NAME: Do you correct the force (lightning)? - 理力補正するか（雷）
	uint8_t isMagicCorrect_byThunder_002: 1;

	// NAME: Do you correct your faith (thunder)? - 信仰補正するか（雷）
	uint8_t isFaithCorrect_byThunder_002: 1;

	// NAME: Do you correct your luck (lightning)? - 運補正するか（雷）
	uint8_t isLuckCorrect_byThunder_002: 1;

	// NAME: Do you correct your strength (darkness)? - 筋力補正するか（闇）
	uint8_t isStrengthCorrect_byDark_002: 1;

	// NAME: Do you correct your workmanship (darkness)? - 技量補正するか（闇）
	uint8_t isDexterityCorrect_byDark_002: 1;

	// NAME: Do you correct the force (darkness)? - 理力補正するか（闇）
	uint8_t isMagicCorrect_byDark_002: 1;

	// NAME: Do you correct your faith (darkness)? - 信仰補正するか（闇）
	uint8_t isFaithCorrect_byDark_002: 1;

	// NAME: Do you correct your luck (darkness)? - 運補正するか（闇）
	uint8_t isLuckCorrect_byDark_003: 1;

	// NAME: Padding - パディング
	uint8_t pad1_003: 7;

	// NAME: Overwrite muscle strength correction value (physical) - 筋力補正値上書き（物理）
	int16_t overwriteStrengthCorrectRate_byPhysics_004;

	// NAME: Skill correction value overwrite (physical) - 技量補正値上書き（物理）
	int16_t overwriteDexterityCorrectRate_byPhysics_006;

	// NAME: Overwrite the force correction value (physical) - 理力補正値上書き（物理）
	int16_t overwriteMagicCorrectRate_byPhysics_008;

	// NAME: Faith correction value overwrite (physical) - 信仰補正値上書き（物理）
	int16_t overwriteFaithCorrectRate_byPhysics_00A;

	// NAME: Overwrite luck correction value (physical) - 運補正値上書き（物理）
	int16_t overwriteLuckCorrectRate_byPhysics_00C;

	// NAME: Overwrite muscle strength correction value (magic) - 筋力補正値上書き（魔法）
	int16_t overwriteStrengthCorrectRate_byMagic_00E;

	// NAME: Skill correction value overwrite (magic) - 技量補正値上書き（魔法）
	int16_t overwriteDexterityCorrectRate_byMagic_010;

	// NAME: Overwrite the force correction value (magic) - 理力補正値上書き（魔法）
	int16_t overwriteMagicCorrectRate_byMagic_012;

	// NAME: Faith correction value overwrite (magic) - 信仰補正値上書き（魔法）
	int16_t overwriteFaithCorrectRate_byMagic_014;

	// NAME: Overwrite luck correction value (magic) - 運補正値上書き（魔法）
	int16_t overwriteLuckCorrectRate_byMagic_016;

	// NAME: Overwrite muscle strength correction value (flame) - 筋力補正値上書き（炎）
	int16_t overwriteStrengthCorrectRate_byFire_018;

	// NAME: Skill correction value overwrite (flame) - 技量補正値上書き（炎）
	int16_t overwriteDexterityCorrectRate_byFire_01A;

	// NAME: Overwrite the force correction value (flame) - 理力補正値上書き（炎）
	int16_t overwriteMagicCorrectRate_byFire_01C;

	// NAME: Faith correction value overwrite (flame) - 信仰補正値上書き（炎）
	int16_t overwriteFaithCorrectRate_byFire_01E;

	// NAME: Overwrite luck correction value (flame) - 運補正値上書き（炎）
	int16_t overwriteLuckCorrectRate_byFire_020;

	// NAME: Overwrite muscle strength correction value (lightning) - 筋力補正値上書き（雷）
	int16_t overwriteStrengthCorrectRate_byThunder_022;

	// NAME: Skill correction value overwrite (lightning) - 技量補正値上書き（雷）
	int16_t overwriteDexterityCorrectRate_byThunder_024;

	// NAME: Overwrite the force correction value (lightning) - 理力補正値上書き（雷）
	int16_t overwriteMagicCorrectRate_byThunder_026;

	// NAME: Faith correction value overwrite (thunder) - 信仰補正値上書き（雷）
	int16_t overwriteFaithCorrectRate_byThunder_028;

	// NAME: Overwrite luck correction value (lightning) - 運補正値上書き（雷）
	int16_t overwriteLuckCorrectRate_byThunder_02A;

	// NAME: Overwrite muscle strength correction value (darkness) - 筋力補正値上書き（闇）
	int16_t overwriteStrengthCorrectRate_byDark_02C;

	// NAME: Skill correction value overwrite (darkness) - 技量補正値上書き（闇）
	int16_t overwriteDexterityCorrectRate_byDark_02E;

	// NAME: Overwrite the force correction value (darkness) - 理力補正値上書き（闇）
	int16_t overwriteMagicCorrectRate_byDark_030;

	// NAME: Faith correction value overwrite (darkness) - 信仰補正値上書き（闇）
	int16_t overwriteFaithCorrectRate_byDark_032;

	// NAME: Overwrite luck correction value (darkness) - 運補正値上書き（闇）
	int16_t overwriteLuckCorrectRate_byDark_034;

	// NAME: Strength correction value Impact rate (physical) - 筋力補正値影響率（物理）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byPhysics_036;

	// NAME: Skill correction value Impact rate (physical) - 技量補正値影響率（物理）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byPhysics_038;

	// NAME: Force correction value Impact rate (physical) - 理力補正値影響率（物理）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byPhysics_03A;

	// NAME: Faith correction value Impact rate (physical) - 信仰補正値影響率（物理）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byPhysics_03C;

	// NAME: Luck correction value influence rate (physical) - 運補正値影響率（物理）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byPhysics_03E;

	// NAME: Strength correction value Impact rate (magic) - 筋力補正値影響率（魔法）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byMagic_040;

	// NAME: Skill correction value Impact rate (magic) - 技量補正値影響率（魔法）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byMagic_042;

	// NAME: Force correction value Impact rate (magic) - 理力補正値影響率（魔法）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byMagic_044;

	// NAME: Faith correction value Impact rate (magic) - 信仰補正値影響率（魔法）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byMagic_046;

	// NAME: Luck correction value influence rate (magic) - 運補正値影響率（魔法）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byMagic_048;

	// NAME: Strength correction value Impact rate (flame) - 筋力補正値影響率（炎）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byFire_04A;

	// NAME: Skill correction value Impact rate (flame) - 技量補正値影響率（炎）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byFire_04C;

	// NAME: Force correction value Impact rate (flame) - 理力補正値影響率（炎）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byFire_04E;

	// NAME: Faith correction value Impact rate (flame) - 信仰補正値影響率（炎）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byFire_050;

	// NAME: Luck correction value influence rate (flame) - 運補正値影響率（炎）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byFire_052;

	// NAME: Strength correction value Impact rate (lightning) - 筋力補正値影響率（雷）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byThunder_054;

	// NAME: Skill correction value Impact rate (lightning) - 技量補正値影響率（雷）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byThunder_056;

	// NAME: Force correction value Impact rate (lightning) - 理力補正値影響率（雷）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byThunder_058;

	// NAME: Faith correction value Impact rate (lightning) - 信仰補正値影響率（雷）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byThunder_05A;

	// NAME: Luck correction value influence rate (lightning) - 運補正値影響率（雷）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byThunder_05C;

	// NAME: Strength correction value influence rate (darkness) - 筋力補正値影響率（闇）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byDark_05E;

	// NAME: Skill correction value Impact rate (darkness) - 技量補正値影響率（闇）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byDark_060;

	// NAME: Force correction value Impact rate (darkness) - 理力補正値影響率（闇）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byDark_062;

	// NAME: Faith correction value Impact rate (darkness) - 信仰補正値影響率（闇）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byDark_064;

	// NAME: Luck correction value influence rate (darkness) - 運補正値影響率（闇）
	// DESC: The rate of influence of the correction factor. - 補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byDark_066;

	// NAME: Padding - パディング
	uint8_t pad2_068[24];

} AttackElementCorrectParam;

#endif
