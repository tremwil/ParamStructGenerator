/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_EffectQuality_H
#define _PARAM_Gconfig_EffectQuality_H
#include <stdint.h>

// CS_EFFECT_QUALITY_DETAIL
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_EffectQuality {

	// NAME: Soft particles enabled - ソフトパーティクル有効
	// DESC: Soft particles enabled - ソフトパーティクル有効
	uint8_t softParticleEnabled_000;

	// NAME: Glow effective - グロー有効
	// DESC: Glow effective - グロー有効
	uint8_t glowEnabled_001;

	// NAME: Distortion effective - 歪み有効
	// DESC: Distortion effective - 歪み有効
	uint8_t distortionEnable_002;

	// NAME: Enable bilateral upscale - バイラテラルアップスケールを有効
	// DESC: Bilateral upscale effective - バイラテラルアップスケール有効
	uint8_t cs_upScaleEnabledType_003;

	// NAME: Number of Emits at one time - 一回のエミット数
	// DESC: Number of Emits at one time - 一回のエミット数
	float fNumOnceEmitsScale_004;

	// NAME: Emit interval - エミット間隔
	// DESC: Emit interval - エミット間隔
	float fEmitSpanScale_008;

	// NAME: 1st stage LOD distance scale - 1段階目のLOD距離スケール
	// DESC: 1st stage LOD distance scale - 1段階目のLOD距離スケール
	float fLodDistance1Scale_00C;

	// NAME: Second stage LOD distance scale - 2段階目のLOD距離スケール
	// DESC: Second stage LOD distance scale - 2段階目のLOD距離スケール
	float fLodDistance2Scale_010;

	// NAME: 3rd stage LOD distance scale - 3段階目のLOD距離スケール
	// DESC: 3rd stage LOD distance scale - 3段階目のLOD距離スケール
	float fLodDistance3Scale_014;

	// NAME: 4th stage LOD distance scale - 4段階目のLOD距離スケール
	// DESC: 4th stage LOD distance scale - 4段階目のLOD距離スケール
	float fLodDistance4Scale_018;

	// NAME: Magnification to the distance registered in the reduction buffer - 縮小バッファへ登録される距離への倍率
	// DESC: Magnification to the distance registered in the reduction buffer - 縮小バッファへ登録される距離への倍率
	float fScaleRenderDistanceScale_01C;

	// NAME: dummy - ダミー
	uint8_t dmy_020[4];

} Gconfig_EffectQuality;

#endif
