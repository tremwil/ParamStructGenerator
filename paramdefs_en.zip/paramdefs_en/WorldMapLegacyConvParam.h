/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WorldMapLegacyConvParam_H
#define _PARAM_WorldMapLegacyConvParam_H
#include <stdint.h>

// WORLD_MAP_LEGACY_CONV_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WorldMapLegacyConvParam {

	// NAME: Do you remove it from the NT version output? - NT版出力から外すか
	// DESC: Parameters marked with ○ are excluded in the NT version package. - ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// NAME: Reserve for package output 1 - パッケージ出力用リザーブ1
	// DESC: Reserve for package output 1 - パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// NAME: Reserve for package output 2 - パッケージ出力用リザーブ2
	// DESC: Reserve for package output 2 - パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// NAME: Conversion source map ID: Area number - 変換元マップID：エリア番号
	// DESC: Conversion source map ID: Area number - 変換元マップID：エリア番号
	uint8_t srcAreaNo_004;

	// NAME: Source map ID: Grid X - 変換元マップID：グリッドX
	// DESC: Source map ID: Grid X - 変換元マップID：グリッドX
	uint8_t srcGridXNo_005;

	// NAME: Source map ID: Grid Z - 変換元マップID：グリッドZ
	// DESC: Source map ID: Grid Z - 変換元マップID：グリッドZ
	uint8_t srcGridZNo_006;

	// NAME: Padding 1 - パディング１
	// DESC: Padding 1 - パディング１
	uint8_t pad1_007[1];

	// NAME: Source map reference coordinates X - 変換元マップ基準座標X
	// DESC: Source map reference coordinates X - 変換元マップ基準座標X
	float srcPosX_008;

	// NAME: Source map reference coordinates Y - 変換元マップ基準座標Y
	// DESC: Source map reference coordinates Y - 変換元マップ基準座標Y
	float srcPosY_00C;

	// NAME: Source map reference coordinates Z - 変換元マップ基準座標Z
	// DESC: Source map reference coordinates Z - 変換元マップ基準座標Z
	float srcPosZ_010;

	// NAME: Conversion destination map ID: Area number - 変換先マップID：エリア番号
	// DESC: Conversion destination map ID: Area number - 変換先マップID：エリア番号
	uint8_t dstAreaNo_014;

	// NAME: Destination map ID: Grid X - 変換先マップID：グリッドX
	// DESC: Destination map ID: Grid X - 変換先マップID：グリッドX
	uint8_t dstGridXNo_015;

	// NAME: Destination map ID: Grid Z - 変換先マップID：グリッドZ
	// DESC: Destination map ID: Grid Z - 変換先マップID：グリッドZ
	uint8_t dstGridZNo_016;

	// NAME: Padding 2 - パディング２
	// DESC: Padding 2 - パディング２
	uint8_t pad2_017[1];

	// NAME: Destination map reference coordinates X - 変換先マップ基準座標X
	// DESC: Destination map reference coordinates X - 変換先マップ基準座標X
	float dstPosX_018;

	// NAME: Destination map reference coordinates Y - 変換先マップ基準座標Y
	// DESC: Destination map reference coordinates Y - 変換先マップ基準座標Y
	float dstPosY_01C;

	// NAME: Destination map reference coordinates Z - 変換先マップ基準座標Z
	// DESC: Destination map reference coordinates Z - 変換先マップ基準座標Z
	float dstPosZ_020;

	// NAME: Is it a reference connection point? - 基準となる接続点か
	// DESC: Is it a reference connection point? One reference connection point is always set for one conversion source map ID. - 基準となる接続点か。１つの変換元マップIDには必ず一つは基準となる接続点が設定される
	uint8_t isBasePoint_024: 1;

	// NAME: Padding 3 - パディング３
	// DESC: Padding 3 - パディング３
	uint8_t pad3_024: 7;

	// NAME: Padding 4 - パディング４
	// DESC: Padding 4 - パディング４
	uint8_t pad4_025[11];

} WorldMapLegacyConvParam;

#endif
