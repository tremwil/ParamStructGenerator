/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AssetMaterialSfxParam_H
#define _PARAM_AssetMaterialSfxParam_H
#include <stdint.h>

// ASSET_MATERIAL_SFX_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AssetMaterialSfxParam {

	// NAME: SFX identifier: 00 - SFX識別子：00
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_00_000;

	// NAME: SFX identifier: 01 - SFX識別子：01
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_01_004;

	// NAME: SFX identifier: 02 - SFX識別子：02
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_02_008;

	// NAME: SFX identifier: 03 - SFX識別子：03
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_03_00C;

	// NAME: SFX identifier: 04 - SFX識別子：04
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_04_010;

	// NAME: SFX identifier: 05 - SFX識別子：05
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_05_014;

	// NAME: SFX identifier: 06 - SFX識別子：06
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_06_018;

	// NAME: SFX identifier: 07 - SFX識別子：07
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_07_01C;

	// NAME: SFX identifier: 08 - SFX識別子：08
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_08_020;

	// NAME: SFX identifier: 09 - SFX識別子：09
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_09_024;

	// NAME: SFX identifier: 10 - SFX識別子：10
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_10_028;

	// NAME: SFX identifier: 11 - SFX識別子：11
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_11_02C;

	// NAME: SFX identifier: 12 - SFX識別子：12
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_12_030;

	// NAME: SFX identifier: 13 - SFX識別子：13
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_13_034;

	// NAME: SFX identifier: 14 - SFX識別子：14
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_14_038;

	// NAME: SFX identifier: 15 - SFX識別子：15
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_15_03C;

	// NAME: SFX identifier: 16 - SFX識別子：16
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_16_040;

	// NAME: SFX identifier: 17 - SFX識別子：17
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_17_044;

	// NAME: SFX identifier: 18 - SFX識別子：18
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_18_048;

	// NAME: SFX identifier: 19 - SFX識別子：19
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_19_04C;

	// NAME: SFX identifier: 20 - SFX識別子：20
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_20_050;

	// NAME: SFX identifier: 21 - SFX識別子：21
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_21_054;

	// NAME: SFX identifier: 22 - SFX識別子：22
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_22_058;

	// NAME: SFX identifier: 23 - SFX識別子：23
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_23_05C;

	// NAME: SFX identifier: 24 - SFX識別子：24
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_24_060;

	// NAME: SFX identifier: 25 - SFX識別子：25
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_25_064;

	// NAME: SFX identifier: 26 - SFX識別子：26
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_26_068;

	// NAME: SFX identifier: 27 - SFX識別子：27
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_27_06C;

	// NAME: SFX identifier: 28 - SFX識別子：28
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_28_070;

	// NAME: SFX identifier: 29 - SFX識別子：29
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_29_074;

	// NAME: SFX identifier: 30 - SFX識別子：30
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_30_078;

	// NAME: SFX identifier: 31 - SFX識別子：31
	// DESC: SFX identifier corresponding to the asset parameter "SFX identifier after destruction" - アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_31_07C;

} AssetMaterialSfxParam;

#endif
