/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MenuValueTableSpecParam_H
#define _PARAM_MenuValueTableSpecParam_H
#include <stdint.h>

// MENU_VALUE_TABLE_SPEC
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MenuValueTableSpecParam {

	// NAME: Value to compare - 比較する値
	// DESC: Value to compare - 比較する値
	int32_t value_000;

	// NAME: Converted text ID - 変換後のテキストID
	// DESC: Converted text ID - 変換後のテキストID
	int32_t textId_004;

	// NAME: Comparison type - 比較タイプ
	// DESC: Comparison type - 比較タイプ
	int8_t compareType_008;

	// NAME: Padding - パディング
	// DESC: Padding - パディング
	uint8_t padding_009[3];

} MenuValueTableSpecParam;

#endif
