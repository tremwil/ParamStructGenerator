/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_DecalQuality_H
#define _PARAM_Gconfig_DecalQuality_H
#include <stdint.h>

// CS_DECAL_QUALITY_DETAIL
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_DecalQuality {

	// NAME: Decal valid - デカール有効
	// DESC: Decal valid - デカール有効
	uint8_t enabled_000;

	// NAME: dmy - dmy
	uint8_t dmy_001[3];

} Gconfig_DecalQuality;

#endif
