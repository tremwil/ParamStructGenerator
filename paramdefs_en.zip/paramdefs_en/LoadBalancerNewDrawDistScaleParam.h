/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_LoadBalancerNewDrawDistScaleParam_H
#define _PARAM_LoadBalancerNewDrawDistScaleParam_H
#include <stdint.h>

// LOAD_BALANCER_NEW_DRAW_DIST_SCALE_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _LoadBalancerNewDrawDistScaleParam {

	// NAME: Activation level (start) - 発動レベル(開始)
	// DESC: Drawing distance scale activation level (start) - 描画距離スケール発動レベル(開始)
	uint8_t DrawDist_LvBegin_000;

	// NAME: Activation level (end) - 発動レベル(終了)
	// DESC: Drawing distance scale activation level (completed) - 描画距離スケール発動レベル(修了)
	uint8_t DrawDist_LvEnd_001;

	// NAME: Reserve - 予備
	// DESC: Reserve - 予備
	uint8_t reserve0_002[2];

	// NAME: Scale (start) - スケール（開始）
	// DESC: Drawing distance scale (start) - 描画距離スケール（開始）
	float DrawDist_ScaleBegin_004;

	// NAME: Scale (end) - スケール（終了）
	// DESC: Drawing distance scale (completed) - 描画距離スケール（修了）
	float DrawDist_ScaleEnd_008;

	// NAME: Activation level (start) - 発動レベル(開始)
	// DESC: Shadow drawing distance scale activation level (start) - 影描画距離スケール発動レベル(開始)
	uint8_t ShadwDrawDist_LvBegin_00C;

	// NAME: Activation level (end) - 発動レベル(終了)
	// DESC: Shadow drawing distance scale activation level (completed) - 影描画距離スケール発動レベル(修了)
	uint8_t ShadwDrawDist_LvEnd_00D;

	// NAME: Reserve - 予備
	// DESC: Reserve - 予備
	uint8_t reserve1_00E[2];

	// NAME: Scale (start) - スケール（開始）
	// DESC: Shadow drawing distance scale (start) - 影描画距離スケール（開始）
	float ShadwDrawDist_ScaleBegin_010;

	// NAME: Scale (end) - スケール（終了）
	// DESC: Shadow drawing distance scale (completed) - 影描画距離スケール（修了）
	float ShadwDrawDist_ScaleEnd_014;

	// NAME: Reserve - 予備
	// DESC: Reserve - 予備
	uint8_t reserve2_018[24];

} LoadBalancerNewDrawDistScaleParam;

#endif
