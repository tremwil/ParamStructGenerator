/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_LoadBalancerParam_H
#define _PARAM_LoadBalancerParam_H
#include <stdint.h>

// LOAD_BALANCER_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _LoadBalancerParam {

	// NAME: lowerFpsThreshold - lowerFpsThreshold
	// DESC: If it falls below this FPS, increase the load balance level by 1. - このFPSを下回ったら、ロードバランスレベルを1上げる
	float lowerFpsThreshold_000;

	// NAME: upperFpsThreshold - upperFpsThreshold
	// DESC: If you exceed this FPS, lower the load balance level by 1. - このFPSを上回ったら、ロードバランスレベルを1下げる
	float upperFpsThreshold_004;

	// NAME: lowerFpsContinousCount - lowerFpsContinousCount
	// DESC: If this frame continues below the threshold, level up - このフレーム連続してしきい値を下回ったら、レベルアップ
	uint32_t lowerFpsContinousCount_008;

	// NAME: upperFpsContinousCount - upperFpsContinousCount
	// DESC: If the threshold is exceeded continuously for this frame, level down - このフレーム連続してしきい値を上回ったら、レベルダウン
	uint32_t upperFpsContinousCount_00C;

	// NAME: downAfterChangeSleep - downAfterChangeSleep
	// DESC: Sleep frame count after level down - レベルダウン後のスリープフレームカウント
	uint32_t downAfterChangeSleep_010;

	// NAME: upAfterChangeSleep - upAfterChangeSleep
	// DESC: Sleep frame count after leveling up - レベルアップ後のスリープフレームカウント
	uint32_t upAfterChangeSleep_014;

	// NAME: Light shaft - ライトシャフト
	// DESC: Light shaft of filter - フィルタのライトシャフト
	uint8_t postProcessLightShaft_018;

	// NAME: Bloom - Bloom
	// DESC: Bloom - ブルーム
	uint8_t postProcessBloom_019;

	// NAME: Glow - Glow
	// DESC: Glow - グロー
	uint8_t postProcessGlow_01A;

	// NAME: AA - AA
	// DESC: Antialiasing - アンチエイリアス
	uint8_t postProcessAA_01B;

	// NAME: SSAO - SSAO
	// DESC: SSAO - SSAO
	uint8_t postProcessSSAO_01C;

	// NAME: DOF - DOF
	// DESC: DOF - DOF
	uint8_t postProcessDOF_01D;

	// NAME: Motion Blur - MotionBlur
	// DESC: Motion Blur - MotionBlur
	uint8_t postProcessMotionBlur_01E;

	// NAME: MotionBlurIteration - MotionBlurIteration
	// DESC: Reduce the number of Motion Blur iterations - MotionBlurのイテレーション回数を下げる
	uint8_t postProcessMotionBlurIteration_01F;

	// NAME: Reserve - 予備
	// DESC: Reserve - 予備
	uint8_t reserve0_020[1];

	// NAME: Shadow Blur - Shadow Blur
	// DESC: Cut the shadow blur - 影のブラーを切る
	uint8_t shadowBlur_021;

	// NAME: Around the SFX Emit - SFXのエミット回り
	// DESC: Emit interval, number of emits, LOD distance halved in graphics config - エミット間隔、エミット数、LOD距離をグラフィックスコンフィグの半分に
	uint8_t sfxParticleHalf_022;

	// NAME: SFX reflection - SFXの反射
	// DESC: Omit the reflection scene SFX - 反射シーンSFXをオミット
	uint8_t sfxReflection_023;

	// NAME: Water interaction - 水面インタラクション
	// DESC: Omit water surface interact SFX - 水面インタラクトSFXをオミット
	uint8_t sfxWaterInteraction_024;

	// NAME: SFX glow - SFXのグロー
	// DESC: Omit Glow playing with SFX - SFXでかけてるGlowをオミット
	uint8_t sfxGlow_025;

	// NAME: SFX distortion - SFXの歪み
	// DESC: Omit of distortion applied by SFX - SFXでかけてる歪みのオミット
	uint8_t sfxDistortion_026;

	// NAME: Soft sprite - ソフトスプライト
	// DESC: Soft sprite omit with SFX - SFXでかけてるソフトスプライトのオミット
	uint8_t sftSoftSprite_027;

	// NAME: Light shaft - ライトシャフト
	// DESC: SFX Light Shaft Omit - SFXのライトシャフトのオミット
	uint8_t sfxLightShaft_028;

	// NAME: Scale to the distance judgment of the effect dynamically registered in the reduction buffer - 動的に縮小バッファに登録されるエフェクトの距離判定にスケール
	// DESC: Scale to the distance judgment of the effect dynamically registered in the reduction buffer by the distance of SFX - SFXの距離で動的に縮小バッファに登録されるエフェクトの距離判定にスケール
	uint8_t sfxScaleRenderDistanceScale_029;

	// NAME: Dynamic resolution - 動的解像度
	// DESC: Dynamic resolution - 動的解像度
	uint8_t dynamicResolution_02A;

	// NAME: Shadow Cascade0 Resolution Half - Shadow Cascade0 ResolutionHalf
	// DESC: Cut the shadow (cascade 0) resolution in half - 影（カスケード0）の解像度を半分に下げる
	uint8_t shadowCascade0ResolutionHalf_02B;

	// NAME: Shadow Cascade1 Resolution Half - Shadow Cascade1 ResolutionHalf
	// DESC: Cut the shadow (cascade 1) resolution in half - 影（カスケード1）の解像度を半分に下げる
	uint8_t shadowCascade1ResolutionHalf_02C;

	// NAME: Local player - ローカルプレイヤー
	// DESC: Turn off the water wetting process for local players - ローカルプレイヤーの水濡れ処理を切る
	uint8_t chrWetDisablePlayer_02D;

	// NAME: Remote player - リモートプレイヤー
	// DESC: Turn off the water wetting process of the remote player - リモートプレイヤーの水濡れ処理を切る
	uint8_t chrWetDisableRemotePlayer_02E;

	// NAME: Enemy character - 敵キャラ
	// DESC: Turn off the water wetting process of enemy characters - 敵キャラの水濡れ処理を切る
	uint8_t chrWetDisableEnemy_02F;

	// NAME: Resolution reduction lower limit (%) - 解像度引き下げ 下限(%)
	// DESC: Resolution reduction lower limit (%) - 解像度引き下げ 下限(%)
	uint8_t dynamicResolutionPercentageMin_030;

	// NAME: Resolution reduction upper limit (%) - 解像度引き下げ 上限(%)
	// DESC: Resolution reduction upper limit (%) - 解像度引き下げ 上限(%)
	uint8_t dynamicResolutionPercentageMax_031;

	// NAME: Reserve - 予備
	// DESC: Reserve - 予備
	uint8_t reserve1_032[30];

} LoadBalancerParam;

#endif
