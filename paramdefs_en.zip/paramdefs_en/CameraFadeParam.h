/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CameraFadeParam_H
#define _PARAM_CameraFadeParam_H
#include <stdint.h>

// CAMERA_FADE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CameraFadeParam {

	// NAME: Distance to be transparent (m) - 透明になりきる距離(m)
	// DESC: Near Fade minimum distance (m): Distance where α = 0 - Nearフェード最小距離(m) : α = 0になる距離
	float NearMinDist_000;

	// NAME: Distance that begins to become transparent (m) - 透明になり始める距離(m)
	// DESC: Near fade maximum distance (m): Starting distance between α = Middel Alpha - Nearフェード最大距離(m) : α = MiddelAlphaとなる間の開始距離
	float NearMaxDist_004;

	// NAME: Distance to become translucent (m) - 半透明状態になりきる距離(m)
	// DESC: Minimum distance of Far fade (m): End distance between α = Middle Alpha - Farフェードの最小距離(m) : α = MiddleAlphaとなる間の終了距離
	float FarMinDist_008;

	// NAME: Distance (m) at which it begins to become translucent - 半透明状態になり始める距離(m)
	// DESC: Maximum Far Fade Distance (m): Distance where α = 1 - Farフェードの最大距離(m) : α = 1になる距離
	float FarMaxDist_00C;

	// NAME: Translucent darkness (α value) - 半透明状態の濃さ(α値)
	// DESC: Intermediate α value - 中間のα値
	float MiddleAlpha_010;

	// NAME: dummy - ダミー
	uint8_t dummy_014[12];

} CameraFadeParam;

#endif
