/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_NetworkMsgParam_H
#define _PARAM_NetworkMsgParam_H
#include <stdint.h>

// NETWORK_MSG_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _NetworkMsgParam {

	// NAME: priority - 優先度
	// DESC: priority - 優先度
	uint16_t priority_000;

	// NAME: Forced interrupt - 強制割り込み
	// DESC: Forced interrupt - 強制割り込み
	uint8_t forcePlay_002;

	// NAME: reserve - 予約
	// DESC: reserve - 予約
	uint8_t pad1_003[1];

	// NAME: White spirit (white sign) - 白霊（白サイン）
	// DESC: White spirit (white sign) - 白霊（白サイン）
	int32_t normalWhite_004;

	// NAME: Sun spirit (white sign) - 太陽霊（白サイン）
	// DESC: Sun spirit (white sign) - 太陽霊（白サイン）
	int32_t umbasaWhite_008;

	// NAME: Berserker spirit (white sign) - バーサーカー霊（白サイン）
	// DESC: Berserker spirit (white sign) - バーサーカー霊（白サイン）
	int32_t berserkerWhite_00C;

	// NAME: Sinner Hero Spirit (white sign) - 罪人英雄霊（白サイン ）
	// DESC: Sinner Hero Spirit (white sign) - 罪人英雄霊（白サイン ）
	int32_t sinnerHeroWhite_010;

	// NAME: Dark spirit (red sign) - 闇霊（赤サイン）
	// DESC: Dark spirit (red sign) - 闇霊（赤サイン）
	int32_t normalBlack_014;

	// NAME: Sun spirit (red sign) - 太陽霊（赤サイン）
	// DESC: Sun spirit (red sign) - 太陽霊（赤サイン）
	int32_t umbasaBlack_018;

	// NAME: Berserker spirit (red sign) - バーサーカー霊（赤サイン）
	// DESC: Berserker spirit (red sign) - バーサーカー霊（赤サイン）
	int32_t berserkerBlack_01C;

	// NAME: Intrusion_A - 侵入_A
	// DESC: Intrusion_A - 侵入_A
	int32_t forceJoinBlack_020;

	// NAME: Sun spirit (intrusion) - 太陽霊（乱入）
	// DESC: Sun spirit (intrusion) - 太陽霊（乱入）
	int32_t forceJoinUmbasaBlack_024;

	// NAME: Berserker spirit (intrusion) - バーサーカー霊（乱入）
	// DESC: Berserker spirit (intrusion) - バーサーカー霊（乱入）
	int32_t forceJoinBerserkerBlack_028;

	// NAME: Sinner hunting spirit (visit) - 罪人狩り霊（訪問）
	// DESC: Sinner hunting spirit (visit) - 罪人狩り霊（訪問）
	int32_t sinnerHunterVisitor_02C;

	// NAME: Red Scare Spirit (Visit) - 赤狩り霊（訪問）
	// DESC: Red Scare Spirit (Visit) - 赤狩り霊（訪問）
	int32_t redHunterVisitor_030;

	// NAME: Boss guardian spirit (visit) - ボス守護霊（訪問）
	// DESC: Boss guardian spirit (visit) - ボス守護霊（訪問）
	int32_t guardianOfBossVisitor_034;

	// NAME: Map Guardian Spirit_Forest (Visit) - マップ守護霊_森（訪問）
	// DESC: Map Guardian Spirit_Forest (Visit) - マップ守護霊_森（訪問）
	int32_t guardianOfForestMapVisitor_038;

	// NAME: Map Guardian_Anor (Visit) - マップ守護霊_アノール（訪問）
	// DESC: Map Guardian_Anor (Visit) - マップ守護霊_アノール（訪問）
	int32_t guardianOfAnolisVisitor_03C;

	// NAME: Rosalia spirit (red sign) - ロザリア霊（赤サイン）
	// DESC: Rosalia spirit (red sign) - ロザリア霊（赤サイン）
	int32_t rosaliaBlack_040;

	// NAME: Rosalia spirit (intrusion) - ロザリア霊（乱入）
	// DESC: Rosalia spirit (intrusion) - ロザリア霊（乱入）
	int32_t forceJoinRosaliaBlack_044;

	// NAME: Red Scare Spirit 2 (Visit) - 赤狩り霊2（訪問）
	// DESC: Red Scare Spirit 2 (Visit) - 赤狩り霊2（訪問）
	int32_t redHunterVisitor2_048;

	// NAME: NPC Pseudo Multi 1 - NPC擬似マルチ1
	// DESC: NPC Pseudo Multi 1 - NPC擬似マルチ1
	int32_t npc1_04C;

	// NAME: NPC Pseudo Multi 2 - NPC擬似マルチ2
	// DESC: NPC Pseudo Multi 2 - NPC擬似マルチ2
	int32_t npc2_050;

	// NAME: NPC Pseudo Multi 3 - NPC擬似マルチ3
	// DESC: NPC Pseudo Multi 3 - NPC擬似マルチ3
	int32_t npc3_054;

	// NAME: NPC Pseudo Multi 4 - NPC擬似マルチ4
	// DESC: NPC Pseudo Multi 4 - NPC擬似マルチ4
	int32_t npc4_058;

	// NAME: Battle royale - バトルロイヤル
	// DESC: Battle royale - バトルロイヤル
	int32_t battleRoyal_05C;

	// NAME: NPC Pseudo Multi 5 - NPC擬似マルチ5
	// DESC: NPC Pseudo Multi 5 - NPC擬似マルチ5
	int32_t npc5_060;

	// NAME: NPC Pseudo Multi 6 - NPC擬似マルチ6
	// DESC: NPC Pseudo Multi 6 - NPC擬似マルチ6
	int32_t npc6_064;

	// NAME: NPC Pseudo Multi 7 - NPC擬似マルチ7
	// DESC: NPC Pseudo Multi 7 - NPC擬似マルチ7
	int32_t npc7_068;

	// NAME: NPC Pseudo Multi 8 - NPC擬似マルチ8
	// DESC: NPC Pseudo Multi 8 - NPC擬似マルチ8
	int32_t npc8_06C;

	// NAME: NPC Pseudo Multi 9 - NPC擬似マルチ9
	// DESC: NPC Pseudo Multi 9 - NPC擬似マルチ9
	int32_t npc9_070;

	// NAME: NPC Pseudo Multi 10 - NPC擬似マルチ10
	// DESC: NPC Pseudo Multi 10 - NPC擬似マルチ10
	int32_t npc10_074;

	// NAME: NPC Pseudo Multi 11 - NPC擬似マルチ11
	// DESC: NPC Pseudo Multi 11 - NPC擬似マルチ11
	int32_t npc11_078;

	// NAME: NPC Pseudo Multi 12 - NPC擬似マルチ12
	// DESC: NPC Pseudo Multi 12 - NPC擬似マルチ12
	int32_t npc12_07C;

	// NAME: NPC Pseudo Multi 13 - NPC擬似マルチ13
	// DESC: NPC Pseudo Multi 13 - NPC擬似マルチ13
	int32_t npc13_080;

	// NAME: NPC Pseudo Multi 14 - NPC擬似マルチ14
	// DESC: NPC Pseudo Multi 14 - NPC擬似マルチ14
	int32_t npc14_084;

	// NAME: NPC Pseudo Multi 15 - NPC擬似マルチ15
	// DESC: NPC Pseudo Multi 15 - NPC擬似マルチ15
	int32_t npc15_088;

	// NAME: NPC Pseudo Multi 16 - NPC擬似マルチ16
	// DESC: NPC Pseudo Multi 16 - NPC擬似マルチ16
	int32_t npc16_08C;

	// NAME: Intrusion_B - 侵入_B
	// DESC: Intrusion_B - 侵入_B
	int32_t forceJoinBlack_B_090;

	// NAME: White spirit (white sign) for NPCs - 白霊（白サイン）_NPC用
	// DESC: White spirit (white sign) for NPCs - 白霊（白サイン）_NPC用
	int32_t normalWhite_Npc_094;

	// NAME: For intrusion_A_NPCs - 侵入_A_NPC用
	// DESC: For intrusion_A_NPCs - 侵入_A_NPC用
	int32_t forceJoinBlack_Npc_098;

	// NAME: For intrusion_B_NPCs - 侵入_B_NPC用
	// DESC: For intrusion_B_NPCs - 侵入_B_NPC用
	int32_t forceJoinBlack_B_Npc_09C;

	// NAME: For intrusion_C_NPCs - 侵入_C_NPC用
	// DESC: For intrusion_C_NPCs - 侵入_C_NPC用
	int32_t forceJoinBlack_C_Npc_0A0;

	// NAME: reserve - 予約
	// DESC: reserve - 予約
	uint8_t pad2_0A4[28];

} NetworkMsgParam;

#endif
