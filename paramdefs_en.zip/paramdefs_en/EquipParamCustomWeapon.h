/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EquipParamCustomWeapon_H
#define _PARAM_EquipParamCustomWeapon_H
#include <stdint.h>

// EQUIP_PARAM_CUSTOM_WEAPON_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EquipParamCustomWeapon {

	// NAME: Weapon base ID - 武器ベースID
	// DESC: Weapon base ID - 武器ベースID
	int32_t baseWepId_000;

	// NAME: Magic stone ID - 魔石ID
	// DESC: Magic stone ID - 魔石ID
	int32_t gemId_004;

	// NAME: Enhancement value - 強化値
	// DESC: Enhancement value - 強化値
	uint8_t reinforceLv_008;

	// NAME: pad - pad
	// DESC: pad - pad
	uint8_t pad_009[7];

} EquipParamCustomWeapon;

#endif
