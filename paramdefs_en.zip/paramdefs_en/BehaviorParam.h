/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_BehaviorParam_H
#define _PARAM_BehaviorParam_H
#include <stdint.h>

// BEHAVIOR_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BehaviorParam {

	// NAME: Behavior variation ID - 行動バリエーションID
	// DESC: Used when calculating the ID for attack parameters. It is not used directly on the actual machine. - 攻撃パラメータ用のIDを算出する際に使用します。実機上では直接使用しません。
	int32_t variationId_000;

	// NAME: Action judgment ID - 行動判定ID
	// DESC: Used when calculating the ID for attack parameters. This ID matches the action judgment ID entered in TimeActEditor. It is not used directly on the actual machine. - 攻撃パラメータ用のIDを算出する際に使用します。このIDはTimeActEditorで入力される行動判定IDと一致させます。実機上では直接使用しません。
	int32_t behaviorJudgeId_004;

	// NAME: For ID rules - IDルール用
	// DESC: For ID calculation rules - ID算出ルール用
	uint8_t ezStateBehaviorType_old_008;

	// NAME: Reference ID type - 参照IDタイプ
	// DESC: Specify the reference ID so that it is correct. - 参照IDを間違わないように指定.
	uint8_t refType_009;

	// NAME: pad - pad
	uint8_t pad2_00A[2];

	// NAME: Reference ID - 参照ID
	// DESC: It can be used properly according to the attack power, missile, ID of special effect parameter, and refType. - 攻撃力、飛び道具、特殊効果パラメータのID、refTypeによって使い分けられる。
	int32_t refId_00C;

	// NAME: Consumption SA - 消費SA
	// DESC: Set the amount of SA consumed during action. - 行動時の消費SA量を設定.
	float consumeSA_010;

	// NAME: Consumption stamina - 消費スタミナ
	// DESC: Set the amount of stamina consumed during action. - 行動時の消費スタミナ量を設定.
	int32_t stamina_014;

	// NAME: Weapon durability consumption (only when using missiles) - 武器耐久度消費（飛び道具時のみ）
	// DESC: Set the durability of weapons consumed during action. - 行動時の消費武器耐久度を設定.
	int32_t consumeDurability_018;

	// NAME: category - カテゴリ
	// DESC: Since there are effects (enchantment weapons, etc.) whose parameters fluctuate depending on skills, magic, items, etc., set each action so that the determined effect can correspond to the effect such as "power up only weapon attack". Set "None" for items that do not need to be set, such as varistor. - スキルや、魔法、アイテムなどで、パラメータが変動する効果（エンチャントウェポンなど）があるので、│定した効果が、「武器攻撃のみをパワーアップする」といった効果に対応できるように行動ごとに設定するバリスタなど、設定の必要のないものは「なし」を設定する
	uint8_t category_01C;

	// NAME: Consumer nature - 消費人間性
	// DESC: Set the amount of humanity consumed during action - 行動時の消費人間性量を設定
	uint8_t heroPoint_01D;

	// NAME: pad - pad
	uint8_t pad1_01E[2];

} BehaviorParam;

#endif
