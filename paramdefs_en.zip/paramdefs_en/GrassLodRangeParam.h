/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_GrassLodRangeParam_H
#define _PARAM_GrassLodRangeParam_H
#include <stdint.h>

// GRASS_LOD_RANGE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GrassLodRangeParam {

	// NAME: LOD0-distance - LOD0 - 距離
	float LOD0_range_000;

	// NAME: LOD0-play - LOD0 - 遊び
	float LOD0_play_004;

	// NAME: LOD1-distance - LOD１ - 距離
	float LOD1_range_008;

	// NAME: LOD1-Play - LOD１ - 遊び
	float LOD1_play_00C;

	// NAME: LOD2-distance - LOD２ - 距離
	float LOD2_range_010;

	// NAME: LOD2-Play - LOD２ - 遊び
	float LOD2_play_014;

} GrassLodRangeParam;

#endif
