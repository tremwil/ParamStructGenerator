/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_RuntimeBoneControlParam_H
#define _PARAM_RuntimeBoneControlParam_H
#include <stdint.h>

// RUNTIME_BONE_CONTROL_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _RuntimeBoneControlParam {

	// NAME: Character ID - キャラID
	// DESC: Character ID - キャラID
	uint32_t chrId_000;

	// NAME: Control type - 制御タイプ
	// DESC: Control type - 制御タイプ
	uint8_t ctrlType_004;

	// NAME: pad - pad
	uint8_t pad_005[11];

	// NAME: Applicable joint - 適用関節
	// DESC: Applicable joint - 適用関節
	char applyBone_010[32];

	// NAME: Target joint 1 - ターゲット関節１
	// DESC: Target joint 1 - ターゲット関節１
	char targetBone1_030[32];

	// NAME: Target joint 2 - ターゲット関節２
	// DESC: Target joint 2 - ターゲット関節２
	char targetBone2_050[32];

} RuntimeBoneControlParam;

#endif
