/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_HitEffectSeParam_H
#define _PARAM_HitEffectSeParam_H
#include <stdint.h>

// HIT_EFFECT_SE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _HitEffectSeParam {

	// NAME: Iron: Slash: Small - 鉄製：斬撃：小
	// DESC: Iron: Slash: Small - 鉄製：斬撃：小
	int32_t Iron_Slash_S_000;

	// NAME: Iron: Slash: Large - 鉄製：斬撃：大
	// DESC: Iron: Slash: Large - 鉄製：斬撃：大
	int32_t Iron_Slash_L_004;

	// NAME: Iron: Slash: Oversized - 鉄製：斬撃：特大
	// DESC: Iron: Slash: Oversized - 鉄製：斬撃：特大
	int32_t Iron_Slash_LL_008;

	// NAME: Iron: piercing: small - 鉄製：刺突：小
	// DESC: Iron: piercing: small - 鉄製：刺突：小
	int32_t Iron_Thrust_S_00C;

	// NAME: Made of iron: piercing: large - 鉄製：刺突：大
	// DESC: Made of iron: piercing: large - 鉄製：刺突：大
	int32_t Iron_Thrust_L_010;

	// NAME: Iron: piercing: oversized - 鉄製：刺突：特大
	// DESC: Iron: piercing: oversized - 鉄製：刺突：特大
	int32_t Iron_Thrust_LL_014;

	// NAME: Iron: Batter: Small - 鉄製：打撃：小
	// DESC: Iron: Batter: Small - 鉄製：打撃：小
	int32_t Iron_Blow_S_018;

	// NAME: Iron: Batter: Large - 鉄製：打撃：大
	// DESC: Iron: Batter: Large - 鉄製：打撃：大
	int32_t Iron_Blow_L_01C;

	// NAME: Iron: Batter: Oversized - 鉄製：打撃：特大
	// DESC: Iron: Batter: Oversized - 鉄製：打撃：特大
	int32_t Iron_Blow_LL_020;

	// NAME: Flame: Slash: Small - 炎：斬撃：小
	// DESC: Flame: Slash: Small - 炎：斬撃：小
	int32_t Fire_Slash_S_024;

	// NAME: Flame: Slash: Large - 炎：斬撃：大
	// DESC: Flame: Slash: Large - 炎：斬撃：大
	int32_t Fire_Slash_L_028;

	// NAME: Flame: Slash: Oversized - 炎：斬撃：特大
	// DESC: Flame: Slash: Oversized - 炎：斬撃：特大
	int32_t Fire_Slash_LL_02C;

	// NAME: Flame: Piercing: Small - 炎：刺突：小
	// DESC: Flame: Piercing: Small - 炎：刺突：小
	int32_t Fire_Thrust_S_030;

	// NAME: Flame: Piercing: Large - 炎：刺突：大
	// DESC: Flame: Piercing: Large - 炎：刺突：大
	int32_t Fire_Thrust_L_034;

	// NAME: Flame: Piercing: Oversized - 炎：刺突：特大
	// DESC: Flame: Piercing: Oversized - 炎：刺突：特大
	int32_t Fire_Thrust_LL_038;

	// NAME: Flame: Batter: Small - 炎：打撃：小
	// DESC: Flame: Batter: Small - 炎：打撃：小
	int32_t Fire_Blow_S_03C;

	// NAME: Flame: Batter: Large - 炎：打撃：大
	// DESC: Flame: Batter: Large - 炎：打撃：大
	int32_t Fire_Blow_L_040;

	// NAME: Flame: Batter: Oversized - 炎：打撃：特大
	// DESC: Flame: Batter: Oversized - 炎：打撃：特大
	int32_t Fire_Blow_LL_044;

	// NAME: Wooden: Slash: Small - 木製：斬撃：小
	// DESC: Wooden: Slash: Small - 木製：斬撃：小
	int32_t Wood_Slash_S_048;

	// NAME: Wooden: Slash: Large - 木製：斬撃：大
	// DESC: Wooden: Slash: Large - 木製：斬撃：大
	int32_t Wood_Slash_L_04C;

	// NAME: Wooden: Slash: Oversized - 木製：斬撃：特大
	// DESC: Wooden: Slash: Oversized - 木製：斬撃：特大
	int32_t Wood_Slash_LL_050;

	// NAME: Wooden: piercing: small - 木製：刺突：小
	// DESC: Wooden: piercing: small - 木製：刺突：小
	int32_t Wood_Thrust_S_054;

	// NAME: Wooden: piercing: large - 木製：刺突：大
	// DESC: Wooden: piercing: large - 木製：刺突：大
	int32_t Wood_Thrust_L_058;

	// NAME: Wooden: piercing: oversized - 木製：刺突：特大
	// DESC: Wooden: piercing: oversized - 木製：刺突：特大
	int32_t Wood_Thrust_LL_05C;

	// NAME: Wooden: Batter: Small - 木製：打撃：小
	// DESC: Wooden: Batter: Small - 木製：打撃：小
	int32_t Wood_Blow_S_060;

	// NAME: Wooden: Batter: Large - 木製：打撃：大
	// DESC: Wooden: Batter: Large - 木製：打撃：大
	int32_t Wood_Blow_L_064;

	// NAME: Wooden: Batter: Oversized - 木製：打撃：特大
	// DESC: Wooden: Batter: Oversized - 木製：打撃：特大
	int32_t Wood_Blow_LL_068;

	// NAME: Meat: Slash: Small - 肉：斬撃：小
	// DESC: Meat: Slash: Small - 肉：斬撃：小
	int32_t Body_Slash_S_06C;

	// NAME: Meat: Slash: Large - 肉：斬撃：大
	// DESC: Meat: Slash: Large - 肉：斬撃：大
	int32_t Body_Slash_L_070;

	// NAME: Meat: Slash: Oversized - 肉：斬撃：特大
	// DESC: Meat: Slash: Oversized - 肉：斬撃：特大
	int32_t Body_Slash_LL_074;

	// NAME: Meat: Stab: Small - 肉：刺突：小
	// DESC: Meat: Stab: Small - 肉：刺突：小
	int32_t Body_Thrust_S_078;

	// NAME: Meat: Stab: Large - 肉：刺突：大
	// DESC: Meat: Stab: Large - 肉：刺突：大
	int32_t Body_Thrust_L_07C;

	// NAME: Meat: Stab: Oversized - 肉：刺突：特大
	// DESC: Meat: Stab: Oversized - 肉：刺突：特大
	int32_t Body_Thrust_LL_080;

	// NAME: Meat: Batter: Small - 肉：打撃：小
	// DESC: Meat: Batter: Small - 肉：打撃：小
	int32_t Body_Blow_S_084;

	// NAME: Meat: Batter: Large - 肉：打撃：大
	// DESC: Meat: Batter: Large - 肉：打撃：大
	int32_t Body_Blow_L_088;

	// NAME: Meat: Batter: Oversized - 肉：打撃：特大
	// DESC: Meat: Batter: Oversized - 肉：打撃：特大
	int32_t Body_Blow_LL_08C;

	// NAME: Corrosion: Slash: Small - 蝕：斬撃：小
	// DESC: Corrosion: Slash: Small - 蝕：斬撃：小
	int32_t Eclipse_Slash_S_090;

	// NAME: Eating: Slashing: Large - 蝕：斬撃：大
	// DESC: Eating: Slashing: Large - 蝕：斬撃：大
	int32_t Eclipse_Slash_L_094;

	// NAME: Eating: Slashing: Oversized - 蝕：斬撃：特大
	// DESC: Eating: Slashing: Oversized - 蝕：斬撃：特大
	int32_t Eclipse_Slash_LL_098;

	// NAME: Corrosion: piercing: small - 蝕：刺突：小
	// DESC: Corrosion: piercing: small - 蝕：刺突：小
	int32_t Eclipse_Thrust_S_09C;

	// NAME: Corrosion: Piercing: Large - 蝕：刺突：大
	// DESC: Corrosion: Piercing: Large - 蝕：刺突：大
	int32_t Eclipse_Thrust_L_0A0;

	// NAME: Corrosion: piercing: oversized - 蝕：刺突：特大
	// DESC: Corrosion: piercing: oversized - 蝕：刺突：特大
	int32_t Eclipse_Thrust_LL_0A4;

	// NAME: Corrosion: Batter: Small - 蝕：打撃：小
	// DESC: Corrosion: Batter: Small - 蝕：打撃：小
	int32_t Eclipse_Blow_S_0A8;

	// NAME: Corrosion: Batter: Large - 蝕：打撃：大
	// DESC: Corrosion: Batter: Large - 蝕：打撃：大
	int32_t Eclipse_Blow_L_0AC;

	// NAME: Corrosion: Batter: Oversized - 蝕：打撃：特大
	// DESC: Corrosion: Batter: Oversized - 蝕：打撃：特大
	int32_t Eclipse_Blow_LL_0B0;

	// NAME: Energy: Slash: Small - エネルギー：斬撃：小
	// DESC: Energy: Slash: Small - エネルギー：斬撃：小
	int32_t Energy_Slash_S_0B4;

	// NAME: Energy: Slash: Large - エネルギー：斬撃：大
	// DESC: Energy: Slash: Large - エネルギー：斬撃：大
	int32_t Energy_Slash_L_0B8;

	// NAME: Energy: Slash: Oversized - エネルギー：斬撃：特大
	// DESC: Energy: Slash: Oversized - エネルギー：斬撃：特大
	int32_t Energy_Slash_LL_0BC;

	// NAME: Energy: Puncture: Small - エネルギー：刺突：小
	// DESC: Energy: Puncture: Small - エネルギー：刺突：小
	int32_t Energy_Thrust_S_0C0;

	// NAME: Energy: Puncture: Large - エネルギー：刺突：大
	// DESC: Energy: Puncture: Large - エネルギー：刺突：大
	int32_t Energy_Thrust_L_0C4;

	// NAME: Energy: Puncture: Oversized - エネルギー：刺突：特大
	// DESC: Energy: Puncture: Oversized - エネルギー：刺突：特大
	int32_t Energy_Thrust_LL_0C8;

	// NAME: Energy: Batter: Small - エネルギー：打撃：小
	// DESC: Energy: Batter: Small - エネルギー：打撃：小
	int32_t Energy_Blow_S_0CC;

	// NAME: Energy: Batter: Large - エネルギー：打撃：大
	// DESC: Energy: Batter: Large - エネルギー：打撃：大
	int32_t Energy_Blow_L_0D0;

	// NAME: Energy: Batter: Oversized - エネルギー：打撃：特大
	// DESC: Energy: Batter: Oversized - エネルギー：打撃：特大
	int32_t Energy_Blow_LL_0D4;

	// NAME: None: Slash: Small - なし：斬撃：小
	// DESC: None: Slash: Small - なし：斬撃：小
	int32_t None_Slash_S_0D8;

	// NAME: None: Slash: Large - なし：斬撃：大
	// DESC: None: Slash: Large - なし：斬撃：大
	int32_t None_Slash_L_0DC;

	// NAME: None: Slash: Oversized - なし：斬撃：特大
	// DESC: None: Slash: Oversized - なし：斬撃：特大
	int32_t None_Slash_LL_0E0;

	// NAME: None: Piercing: Small - なし：刺突：小
	// DESC: None: Piercing: Small - なし：刺突：小
	int32_t None_Thrust_S_0E4;

	// NAME: None: Piercing: Large - なし：刺突：大
	// DESC: None: Piercing: Large - なし：刺突：大
	int32_t None_Thrust_L_0E8;

	// NAME: None: Piercing: Oversized - なし：刺突：特大
	// DESC: None: Piercing: Oversized - なし：刺突：特大
	int32_t None_Thrust_LL_0EC;

	// NAME: None: Batter: Small - なし：打撃：小
	// DESC: None: Batter: Small - なし：打撃：小
	int32_t None_Blow_S_0F0;

	// NAME: None: Batter: Large - なし：打撃：大
	// DESC: None: Batter: Large - なし：打撃：大
	int32_t None_Blow_L_0F4;

	// NAME: None: Batter: Oversized - なし：打撃：特大
	// DESC: None: Batter: Oversized - なし：打撃：特大
	int32_t None_Blow_LL_0F8;

	// NAME: Dmy1: Slash: Small - Dmy1：斬撃：小
	// DESC: Dmy1: Slash: Small - Dmy1：斬撃：小
	int32_t Dmy1_Slash_S_0FC;

	// NAME: Dmy1: Slash: Large - Dmy1：斬撃：大
	// DESC: Dmy1: Slash: Large - Dmy1：斬撃：大
	int32_t Dmy1_Slash_L_100;

	// NAME: Dmy1: Slash: Oversized - Dmy1：斬撃：特大
	// DESC: Dmy1: Slash: Oversized - Dmy1：斬撃：特大
	int32_t Dmy1_Slash_LL_104;

	// NAME: Dmy1: Stab: Small - Dmy1：刺突：小
	// DESC: Dmy1: Stab: Small - Dmy1：刺突：小
	int32_t Dmy1_Thrust_S_108;

	// NAME: Dmy1: Stab: Large - Dmy1：刺突：大
	// DESC: Dmy1: Stab: Large - Dmy1：刺突：大
	int32_t Dmy1_Thrust_L_10C;

	// NAME: Dmy1: Stab: Oversized - Dmy1：刺突：特大
	// DESC: Dmy1: Stab: Oversized - Dmy1：刺突：特大
	int32_t Dmy1_Thrust_LL_110;

	// NAME: Dmy1: Batter: Small - Dmy1：打撃：小
	// DESC: Dmy1: Batter: Small - Dmy1：打撃：小
	int32_t Dmy1_Blow_S_114;

	// NAME: Dmy1: Batter: Large - Dmy1：打撃：大
	// DESC: Dmy1: Batter: Large - Dmy1：打撃：大
	int32_t Dmy1_Blow_L_118;

	// NAME: Dmy1: Batter: Oversized - Dmy1：打撃：特大
	// DESC: Dmy1: Batter: Oversized - Dmy1：打撃：特大
	int32_t Dmy1_Blow_LL_11C;

	// NAME: Dmy2: Slash: Small - Dmy2：斬撃：小
	// DESC: Dmy2: Slash: Small - Dmy2：斬撃：小
	int32_t Dmy2_Slash_S_120;

	// NAME: Dmy2: Slash: Large - Dmy2：斬撃：大
	// DESC: Dmy2: Slash: Large - Dmy2：斬撃：大
	int32_t Dmy2_Slash_L_124;

	// NAME: Dmy2: Slash: Oversized - Dmy2：斬撃：特大
	// DESC: Dmy2: Slash: Oversized - Dmy2：斬撃：特大
	int32_t Dmy2_Slash_LL_128;

	// NAME: Dmy2: Piercing: Small - Dmy2：刺突：小
	// DESC: Dmy2: Piercing: Small - Dmy2：刺突：小
	int32_t Dmy2_Thrust_S_12C;

	// NAME: Dmy2: Piercing: Large - Dmy2：刺突：大
	// DESC: Dmy2: Piercing: Large - Dmy2：刺突：大
	int32_t Dmy2_Thrust_L_130;

	// NAME: Dmy2: Piercing: Oversized - Dmy2：刺突：特大
	// DESC: Dmy2: Piercing: Oversized - Dmy2：刺突：特大
	int32_t Dmy2_Thrust_LL_134;

	// NAME: Dmy2: Batter: Small - Dmy2：打撃：小
	// DESC: Dmy2: Batter: Small - Dmy2：打撃：小
	int32_t Dmy2_Blow_S_138;

	// NAME: Dmy2: Batter: Large - Dmy2：打撃：大
	// DESC: Dmy2: Batter: Large - Dmy2：打撃：大
	int32_t Dmy2_Blow_L_13C;

	// NAME: Dmy2: Batter: Oversized - Dmy2：打撃：特大
	// DESC: Dmy2: Batter: Oversized - Dmy2：打撃：特大
	int32_t Dmy2_Blow_LL_140;

	// NAME: Dmy3: Slash: Small - Dmy3：斬撃：小
	// DESC: Dmy3: Slash: Small - Dmy3：斬撃：小
	int32_t Dmy3_Slash_S_144;

	// NAME: Dmy3: Slash: Large - Dmy3：斬撃：大
	// DESC: Dmy3: Slash: Large - Dmy3：斬撃：大
	int32_t Dmy3_Slash_L_148;

	// NAME: Dmy3: Slash: Oversized - Dmy3：斬撃：特大
	// DESC: Dmy3: Slash: Oversized - Dmy3：斬撃：特大
	int32_t Dmy3_Slash_LL_14C;

	// NAME: Dmy3: Piercing: Small - Dmy3：刺突：小
	// DESC: Dmy3: Piercing: Small - Dmy3：刺突：小
	int32_t Dmy3_Thrust_S_150;

	// NAME: Dmy3: Piercing: Large - Dmy3：刺突：大
	// DESC: Dmy3: Piercing: Large - Dmy3：刺突：大
	int32_t Dmy3_Thrust_L_154;

	// NAME: Dmy3: Piercing: Oversized - Dmy3：刺突：特大
	// DESC: Dmy3: Piercing: Oversized - Dmy3：刺突：特大
	int32_t Dmy3_Thrust_LL_158;

	// NAME: Dmy3: Batter: Small - Dmy3：打撃：小
	// DESC: Dmy3: Batter: Small - Dmy3：打撃：小
	int32_t Dmy3_Blow_S_15C;

	// NAME: Dmy3: Batter: Large - Dmy3：打撃：大
	// DESC: Dmy3: Batter: Large - Dmy3：打撃：大
	int32_t Dmy3_Blow_L_160;

	// NAME: Dmy3: Batter: Oversized - Dmy3：打撃：特大
	// DESC: Dmy3: Batter: Oversized - Dmy3：打撃：特大
	int32_t Dmy3_Blow_LL_164;

	// NAME: Uji: Slash: Small - うじ：斬撃：小
	// DESC: Uji: Slash: Small - うじ：斬撃：小
	int32_t Maggot_Slash_S_168;

	// NAME: Uji: Slash: Large - うじ：斬撃：大
	// DESC: Uji: Slash: Large - うじ：斬撃：大
	int32_t Maggot_Slash_L_16C;

	// NAME: Uji: Slash: Oversized - うじ：斬撃：特大
	// DESC: Uji: Slash: Oversized - うじ：斬撃：特大
	int32_t Maggot_Slash_LL_170;

	// NAME: Uji: Stab: Small - うじ：刺突：小
	// DESC: Uji: Stab: Small - うじ：刺突：小
	int32_t Maggot_Thrust_S_174;

	// NAME: Uji: Stab: Large - うじ：刺突：大
	// DESC: Uji: Stab: Large - うじ：刺突：大
	int32_t Maggot_Thrust_L_178;

	// NAME: Uji: Stab: Oversized - うじ：刺突：特大
	// DESC: Uji: Stab: Oversized - うじ：刺突：特大
	int32_t Maggot_Thrust_LL_17C;

	// NAME: Uji: Batter: Small - うじ：打撃：小
	// DESC: Uji: Batter: Small - うじ：打撃：小
	int32_t Maggot_Blow_S_180;

	// NAME: Uji: Batter: Large - うじ：打撃：大
	// DESC: Uji: Batter: Large - うじ：打撃：大
	int32_t Maggot_Blow_L_184;

	// NAME: Uji: Batter: Oversized - うじ：打撃：特大
	// DESC: Uji: Batter: Oversized - うじ：打撃：特大
	int32_t Maggot_Blow_LL_188;

	// NAME: Wax: Slash: Small - 蝋：斬撃：小
	// DESC: Wax: Slash: Small - 蝋：斬撃：小
	int32_t Wax_Slash_S_18C;

	// NAME: Wax: Slash: Large - 蝋：斬撃：大
	// DESC: Wax: Slash: Large - 蝋：斬撃：大
	int32_t Wax_Slash_L_190;

	// NAME: Wax: Slash: Oversized - 蝋：斬撃：特大
	// DESC: Wax: Slash: Oversized - 蝋：斬撃：特大
	int32_t Wax_Slash_LL_194;

	// NAME: Wax: piercing: small - 蝋：刺突：小
	// DESC: Wax: piercing: small - 蝋：刺突：小
	int32_t Wax_Thrust_S_198;

	// NAME: Wax: piercing: large - 蝋：刺突：大
	// DESC: Wax: piercing: large - 蝋：刺突：大
	int32_t Wax_Thrust_L_19C;

	// NAME: Wax: piercing: oversized - 蝋：刺突：特大
	// DESC: Wax: piercing: oversized - 蝋：刺突：特大
	int32_t Wax_Thrust_LL_1A0;

	// NAME: Wax: Batter: Small - 蝋：打撃：小
	// DESC: Wax: Batter: Small - 蝋：打撃：小
	int32_t Wax_Blow_S_1A4;

	// NAME: Wax: Batter: Large - 蝋：打撃：大
	// DESC: Wax: Batter: Large - 蝋：打撃：大
	int32_t Wax_Blow_L_1A8;

	// NAME: Wax: Batter: Oversized - 蝋：打撃：特大
	// DESC: Wax: Batter: Oversized - 蝋：打撃：特大
	int32_t Wax_Blow_LL_1AC;

	// NAME: Burning: Slashing: Small - 炎上：斬撃：小
	// DESC: Burning: Slashing: Small - 炎上：斬撃：小
	int32_t FireFlame_Slash_S_1B0;

	// NAME: Burning: Slashing: Large - 炎上：斬撃：大
	// DESC: Burning: Slashing: Large - 炎上：斬撃：大
	int32_t FireFlame_Slash_L_1B4;

	// NAME: Burning: Slashing: Oversized - 炎上：斬撃：特大
	// DESC: Burning: Slashing: Oversized - 炎上：斬撃：特大
	int32_t FireFlame_Slash_LL_1B8;

	// NAME: Burning: Piercing: Small - 炎上：刺突：小
	// DESC: Burning: Piercing: Small - 炎上：刺突：小
	int32_t FireFlame_Thrust_S_1BC;

	// NAME: Burning: Piercing: Large - 炎上：刺突：大
	// DESC: Burning: Piercing: Large - 炎上：刺突：大
	int32_t FireFlame_Thrust_L_1C0;

	// NAME: Burning: Piercing: Oversized - 炎上：刺突：特大
	// DESC: Burning: Piercing: Oversized - 炎上：刺突：特大
	int32_t FireFlame_Thrust_LL_1C4;

	// NAME: On fire: Batter: Small - 炎上：打撃：小
	// DESC: On fire: Batter: Small - 炎上：打撃：小
	int32_t FireFlame_Blow_S_1C8;

	// NAME: On fire: Batter: Large - 炎上：打撃：大
	// DESC: On fire: Batter: Large - 炎上：打撃：大
	int32_t FireFlame_Blow_L_1CC;

	// NAME: On fire: Batter: Oversized - 炎上：打撃：特大
	// DESC: On fire: Batter: Oversized - 炎上：打撃：特大
	int32_t FireFlame_Blow_LL_1D0;

	// NAME: Corrosion: Gas: Slash: Small - 蝕：気体：斬撃：小
	// DESC: Corrosion: Gas: Slash: Small - 蝕：気体：斬撃：小
	int32_t EclipseGas_Slash_S_1D4;

	// NAME: Corrosion: Gas: Slash: Large - 蝕：気体：斬撃：大
	// DESC: Corrosion: Gas: Slash: Large - 蝕：気体：斬撃：大
	int32_t EclipseGas_Slash_L_1D8;

	// NAME: Corrosion: Gas: Slash: Oversized - 蝕：気体：斬撃：特大
	// DESC: Corrosion: Gas: Slash: Oversized - 蝕：気体：斬撃：特大
	int32_t EclipseGas_Slash_LL_1DC;

	// NAME: Corrosion: Gas: Piercing: Small - 蝕：気体：刺突：小
	// DESC: Corrosion: Gas: Piercing: Small - 蝕：気体：刺突：小
	int32_t EclipseGas_Thrust_S_1E0;

	// NAME: Corrosion: Gas: Piercing: Large - 蝕：気体：刺突：大
	// DESC: Corrosion: Gas: Piercing: Large - 蝕：気体：刺突：大
	int32_t EclipseGas_Thrust_L_1E4;

	// NAME: Corrosion: Gas: Piercing: Oversized - 蝕：気体：刺突：特大
	// DESC: Corrosion: Gas: Piercing: Oversized - 蝕：気体：刺突：特大
	int32_t EclipseGas_Thrust_LL_1E8;

	// NAME: Corrosion: Gas: Batter: Small - 蝕：気体：打撃：小
	// DESC: Corrosion: Gas: Batter: Small - 蝕：気体：打撃：小
	int32_t EclipseGas_Blow_S_1EC;

	// NAME: Corrosion: Gas: Batter: Large - 蝕：気体：打撃：大
	// DESC: Corrosion: Gas: Batter: Large - 蝕：気体：打撃：大
	int32_t EclipseGas_Blow_L_1F0;

	// NAME: Corrosion: Gas: Batter: Oversized - 蝕：気体：打撃：特大
	// DESC: Corrosion: Gas: Batter: Oversized - 蝕：気体：打撃：特大
	int32_t EclipseGas_Blow_LL_1F4;

	// NAME: Energy (strong): Slash: Small - エネルギー（強）：斬撃：小
	// DESC: Energy (strong): Slash: Small - エネルギー（強）：斬撃：小
	int32_t EnergyStrong_Slash_S_1F8;

	// NAME: Energy (strong): Slash: Large - エネルギー（強）：斬撃：大
	// DESC: Energy (strong): Slash: Large - エネルギー（強）：斬撃：大
	int32_t EnergyStrong_Slash_L_1FC;

	// NAME: Energy (strong): Slash: Oversized - エネルギー（強）：斬撃：特大
	// DESC: Energy (strong): Slash: Oversized - エネルギー（強）：斬撃：特大
	int32_t EnergyStrong_Slash_LL_200;

	// NAME: Energy (strong): piercing: small - エネルギー（強）：刺突：小
	// DESC: Energy (strong): piercing: small - エネルギー（強）：刺突：小
	int32_t EnergyStrong_Thrust_S_204;

	// NAME: Energy (strong): piercing: large - エネルギー（強）：刺突：大
	// DESC: Energy (strong): piercing: large - エネルギー（強）：刺突：大
	int32_t EnergyStrong_Thrust_L_208;

	// NAME: Energy (strong): piercing: oversized - エネルギー（強）：刺突：特大
	// DESC: Energy (strong): piercing: oversized - エネルギー（強）：刺突：特大
	int32_t EnergyStrong_Thrust_LL_20C;

	// NAME: Energy (strong): Batter: Small - エネルギー（強）：打撃：小
	// DESC: Energy (strong): Batter: Small - エネルギー（強）：打撃：小
	int32_t EnergyStrong_Blow_S_210;

	// NAME: Energy (strong): Batter: Large - エネルギー（強）：打撃：大
	// DESC: Energy (strong): Batter: Large - エネルギー（強）：打撃：大
	int32_t EnergyStrong_Blow_L_214;

	// NAME: Energy (strong): Batter: Oversized - エネルギー（強）：打撃：特大
	// DESC: Energy (strong): Batter: Oversized - エネルギー（強）：打撃：特大
	int32_t EnergyStrong_Blow_LL_218;

	// NAME: Reserved area - 予約領域
	// DESC: Reserved area - 予約領域
	uint8_t reserve_21C[100];

} HitEffectSeParam;

#endif
