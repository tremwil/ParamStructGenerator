/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MenuPropertySpecParam_H
#define _PARAM_MenuPropertySpecParam_H
#include <stdint.h>

// MENUPROPERTY_SPEC
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MenuPropertySpecParam {

	// NAME: Item name Text ID - 項目名テキストID
	int32_t CaptionTextID_000;

	// NAME: Item icon ID - 項目アイコンID
	int32_t IconID_004;

	// NAME: Required skills - 必要スキル
	uint32_t RequiredPropertyID_008;

	// NAME: Superiority or inferiority judgment - 優劣判定
	int8_t CompareType_00C;

	// NAME: Padding - パディング
	uint8_t pad2_00D[1];

	// NAME: Format - 書式
	uint16_t FormatType_00E;

	// NAME: Padding - パディング
	uint8_t pad_010[16];

} MenuPropertySpecParam;

#endif
