/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MapPieceTexParam_H
#define _PARAM_MapPieceTexParam_H
#include <stdint.h>

// MAP_PIECE_TEX_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MapPieceTexParam {

	// NAME: Do you remove it from the NT version output? - NT版出力から外すか
	// DESC: Parameters marked with ○ are excluded in the NT version package. - ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// NAME: Reserve for package output 1 - パッケージ出力用リザーブ1
	// DESC: Reserve for package output 1 - パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// NAME: Reserve for package output 2 - パッケージ出力用リザーブ2
	// DESC: Reserve for package output 2 - パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// NAME: R - R
	// DESC: Color information (R) of the map image before conversion. Pixels with matching RGB values are associated with this parameter - 変換前の地図画像のカラー情報（R）。RGB値が一致したピクセルとこのパラメータが紐づく
	uint8_t srcR_004;

	// NAME: G - G
	// DESC: Color information (G) of the map image before conversion. Pixels with matching RGB values are associated with this parameter - 変換前の地図画像のカラー情報（G）。RGB値が一致したピクセルとこのパラメータが紐づく
	uint8_t srcG_005;

	// NAME: B - B
	// DESC: Color information (B) of the map image before conversion. Pixels with matching RGB values are associated with this parameter - 変換前の地図画像のカラー情報（B）。RGB値が一致したピクセルとこのパラメータが紐づく
	uint8_t srcB_006;

	// NAME: pad - パッド
	// DESC: pad. For the time being, leave it open for "image color information (A)" - パッド。一応「画像色情報（A）」用で空けておく
	uint8_t pad1_007[1];

	// NAME: Map name ID_for saving data display - マップ名ID_セーブデータ表示用
	// DESC: Map name ID for displaying save data [PlaceName] (0: invalid value) - セーブデータ表示用のマップ名ID[PlaceName](0:無効値)
	int32_t saveMapNameId_008;

	// NAME: Multiplayer area ID - マルチプレイエリアID
	// DESC: Multiplayer area ID (-1: invalid value) - マルチプレイエリアID(-1:無効値)
	int32_t multiPlayAreaId_00C;

} MapPieceTexParam;

#endif
