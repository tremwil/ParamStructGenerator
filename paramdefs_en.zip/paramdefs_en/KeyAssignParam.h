/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_KeyAssignParam_H
#define _PARAM_KeyAssignParam_H
#include <stdint.h>

// KEY_ASSIGN_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _KeyAssignParam {

	// NAME: pad - パッド
	// DESC: Pad (physical key) - パッド（物理キー）
	int32_t padKeyId_000;

	// NAME: Keyboard modifier - キーボード修飾
	// DESC: Keyboard modifier keys - キーボード修飾キー
	int32_t keyboardModifyKey_004;

	// NAME: keyboard - キーボード
	// DESC: Keyboard (physical keys) - キーボード（物理キー）
	int32_t keyboardKeyId_008;

	// NAME: Mouse modification - マウス修飾
	// DESC: Mouse modifier key - マウス修飾キー
	int32_t mouseModifyKey_00C;

	// NAME: mouse - マウス
	// DESC: Mouse (physical key) - マウス（物理キー）
	int32_t mouseKeyId_010;

	// NAME: ---- - ----
	uint8_t reserved_014[12];

} KeyAssignParam;

#endif
