/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EquipParamProtector_H
#define _PARAM_EquipParamProtector_H
#include <stdint.h>

// EQUIP_PARAM_PROTECTOR_ST
// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EquipParamProtector {

	// NAME: Do you remove it from the NT version output? - NT版出力から外すか
	// DESC: Parameters marked with ○ are excluded in the NT version package. - ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// NAME: Reserve for package output 1 - パッケージ出力用リザーブ1
	// DESC: Reserve for package output 1 - パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// NAME: Reserve for package output 2 - パッケージ出力用リザーブ2
	// DESC: Reserve for package output 2 - パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// NAME: Sort ID - ソートID
	// DESC: Sort ID (7 digits is the limit for s32 because the enhancement level is added in the program) - ソートID(プログラム内で強化レベルを加味しているので s32 では７桁が限界)
	int32_t sortId_004;

	// NAME: Wandering equipment ID - 徘徊装備ID
	// DESC: Replacement equipment ID for wandering ghosts. - 徘徊ゴースト用の差し替え装備ID.
	uint32_t wanderingEquipId_008;

	// NAME: Sleep tolerance - 睡眠耐性
	// DESC: Difficulty in getting sleep abnormalities - 睡眠状態異常へのかかりにくさ
	uint16_t resistSleep_00C;

	// NAME: Madness resistance - 発狂耐性
	// DESC: Difficulty in getting mad - 発狂状態異常へのかかりにくさ
	uint16_t resistMadness_00E;

	// NAME: SA durability value - SA耐久値
	// DESC: Super armor endurance - スーパーアーマー耐久力
	float saDurability_010;

	// NAME: Toughness correction factor - 強靭度 補正倍率
	// DESC: It is a magnification that corrects the basic value of toughness. - 強靭度の基本値を補正する倍率です
	float toughnessCorrectRate_014;

	// NAME: Repair price - 修理価格
	// DESC: Basic repair price - 修理基本価格
	int32_t fixPrice_018;

	// NAME: Basic price - 基本価格
	// DESC: Basic price - 基本価格
	int32_t basicPrice_01C;

	// NAME: Sale price - 売却価格
	// DESC: Selling price - 販売価格
	int32_t sellValue_020;

	// NAME: Weight [kg] - 重量[kg]
	// DESC: Weight [kg]. - 重量[kg].
	float weight_024;

	// NAME: Resident special effect ID1 - 常駐特殊効果ID1
	// DESC: Resident special effect ID1 - 常駐特殊効果ID1
	int32_t residentSpEffectId_028;

	// NAME: Resident special effect ID2 - 常駐特殊効果ID2
	// DESC: Resident special effect ID2 - 常駐特殊効果ID2
	int32_t residentSpEffectId2_02C;

	// NAME: Resident special effect ID3 - 常駐特殊効果ID3
	// DESC: Resident special effect ID3 - 常駐特殊効果ID3
	int32_t residentSpEffectId3_030;

	// NAME: Material ID - 素材ID
	// DESC: Material parameter ID required for weapon enhancement - 武器強化に必要な素材パラメータID
	int32_t materialSetId_034;

	// NAME: Part damage rate - 部位ダメージ率
	// DESC: Part damage rate - 部位ダメージ率
	float partsDamageRate_038;

	// NAME: SA recovery time correction value - SA回復時間補正値
	// DESC: Super Armor Recovery Time Correction Value - スーパーアーマー回復時間の補正値
	float corectSARecover_03C;

	// NAME: Derivation source - 派生元
	// DESC: Strengthening of this armor Original armor ID - この防具の強化元防具ID
	int32_t originEquipPro_040;

	// NAME: Derivative source enhancement +1 - 派生元 強化+1
	// DESC: Strengthening this armor Original armor ID1 - この防具の強化元防具ID1
	int32_t originEquipPro1_044;

	// NAME: Derivative source enhancement +2 - 派生元 強化+2
	// DESC: Strengthening this armor Original armor ID2 - この防具の強化元防具ID2
	int32_t originEquipPro2_048;

	// NAME: Derivative source enhancement +3 - 派生元 強化+3
	// DESC: Strengthening this armor Original armor ID3 - この防具の強化元防具ID3
	int32_t originEquipPro3_04C;

	// NAME: Derivative source enhancement +4 - 派生元 強化+4
	// DESC: Strengthening this armor Original armor ID4 - この防具の強化元防具ID4
	int32_t originEquipPro4_050;

	// NAME: Derivative source enhancement +5 - 派生元 強化+5
	// DESC: Strengthening this armor Original armor ID5 - この防具の強化元防具ID5
	int32_t originEquipPro5_054;

	// NAME: Derivative source enhancement +6 - 派生元 強化+6
	// DESC: Strengthening this armor Original armor ID6 - この防具の強化元防具ID6
	int32_t originEquipPro6_058;

	// NAME: Derivative source enhancement +7 - 派生元 強化+7
	// DESC: Strengthening this armor Original armor ID7 - この防具の強化元防具ID7
	int32_t originEquipPro7_05C;

	// NAME: Derivative source enhancement +8 - 派生元 強化+8
	// DESC: Strengthening this armor Original armor ID8 - この防具の強化元防具ID8
	int32_t originEquipPro8_060;

	// NAME: Derivative source enhancement +9 - 派生元 強化+9
	// DESC: Strengthening this armor Original armor ID9 - この防具の強化元防具ID9
	int32_t originEquipPro9_064;

	// NAME: Derivative source enhancement +10 - 派生元 強化+10
	// DESC: Strengthening this armor Original armor ID10 - この防具の強化元防具ID10
	int32_t originEquipPro10_068;

	// NAME: Derivative source enhancement +11 - 派生元 強化+11
	// DESC: Strengthening this armor Original armor ID11 - この防具の強化元防具ID11
	int32_t originEquipPro11_06C;

	// NAME: Derivative source enhancement +12 - 派生元 強化+12
	// DESC: Strengthening this armor Original armor ID12 - この防具の強化元防具ID12
	int32_t originEquipPro12_070;

	// NAME: Derivative source enhancement +13 - 派生元 強化+13
	// DESC: Strengthening this armor Original armor ID13 - この防具の強化元防具ID13
	int32_t originEquipPro13_074;

	// NAME: Derivative source enhancement +14 - 派生元 強化+14
	// DESC: Strengthening this armor Original armor ID14 - この防具の強化元防具ID14
	int32_t originEquipPro14_078;

	// NAME: Derivative source enhancement +15 - 派生元 強化+15
	// DESC: Strengthening this armor Original armor ID15 - この防具の強化元防具ID15
	int32_t originEquipPro15_07C;

	// NAME: Man profile enlargement scale - 男横顔拡大スケール
	float faceScaleM_ScaleX_080;

	// NAME: Male face enlargement scale - 男前顔拡大スケール
	float faceScaleM_ScaleZ_084;

	// NAME: Maximum magnification for male profile enlargement - 男横顔拡大最大倍率
	float faceScaleM_MaxX_088;

	// NAME: Maximum magnification for man's face enlargement - 男前顔拡大最大倍率
	float faceScaleM_MaxZ_08C;

	// NAME: Female profile enlargement scale - 女横顔拡大スケール
	float faceScaleF_ScaleX_090;

	// NAME: Female face enlargement scale - 女前顔拡大スケール
	float faceScaleF_ScaleZ_094;

	// NAME: Female profile enlargement maximum magnification - 女横顔拡大最大倍率
	float faceScaleF_MaxX_098;

	// NAME: Maximum magnification for female face enlargement - 女前顔拡大最大倍率
	float faceScaleF_MaxZ_09C;

	// NAME: QWCID - QWCID
	// DESC: QWC parameter ID - QWCのパラメタID
	int32_t qwcId_0A0;

	// NAME: Equipment model number - 装備モデル番号
	// DESC: Equipment model number. - 装備モデルの番号.
	uint16_t equipModelId_0A4;

	// NAME: Icon ID for men - 男用アイコンID
	// DESC: Men's menu icon ID. - 男用メニューアイコンID.
	uint16_t iconIdM_0A6;

	// NAME: Female icon ID - 女用アイコンID
	// DESC: Women's menu icon ID. - 女用メニューアイコンID.
	uint16_t iconIdF_0A8;

	// NAME: Knockback cut rate - ノックバックカット率
	// DESC: Knockback reduction value. - ノックバックの減少値.
	uint16_t knockBack_0AA;

	// NAME: Knockback repulsion rate - ノックバック反発率
	// DESC: Knockback repulsion rate. - ノックバックの反発率.
	uint16_t knockbackBounceRate_0AC;

	// NAME: Durability - 耐久度
	// DESC: Initial durability. - 初期耐久度.
	uint16_t durability_0AE;

	// NAME: Maximum durability - 耐久度最大値
	// DESC: New durability. - 新品耐久度.
	uint16_t durabilityMax_0B0;

	// NAME: pad - pad
	uint8_t pad03_0B2[2];

	// NAME: Repellent defense - はじき防御力
	// DESC: Used to determine the repulsion of enemy attacks. - 敵の攻撃のはじき返し判定に利用.
	uint16_t defFlickPower_0B4;

	// NAME: Physical defense - 物理防御力
	// DESC: Physical attack damage protection. - 物理攻撃のダメージ防御.
	uint16_t defensePhysics_0B6;

	// NAME: Magic defense - 魔法防御力
	// DESC: Magic attack damage protection. - 魔法攻撃のダメージ防御.
	uint16_t defenseMagic_0B8;

	// NAME: Fire defense - 炎防御力
	// DESC: Fire attack damage protection. - 炎攻撃のダメージ防御.
	uint16_t defenseFire_0BA;

	// NAME: Electric shock defense - 電撃防御力
	// DESC: Damage protection for electric shock attacks. - 電撃攻撃のダメージ防御.
	uint16_t defenseThunder_0BC;

	// NAME: Slash defense - 斬撃防御力
	// DESC: Look at the attack type, and if it is a slashing attribute, reduce the defense power - 攻撃タイプを見て、斬撃属性のときは、防御力を減少させる
	int16_t defenseSlash_0BE;

	// NAME: Strike defense - 打撃防御力
	// DESC: Look at the attack attribute, and if it is a hit attribute, reduce the defense power. - 攻撃属性を見て、打撃属性のときは、防御力を減少させる.
	int16_t defenseBlow_0C0;

	// NAME: Puncture defense - 刺突防御力
	// DESC: Look at the attack attribute, and if it is a hit attribute, reduce the defense power. - 攻撃属性を見て、打撃属性のときは、防御力を減少させる.
	int16_t defenseThrust_0C2;

	// NAME: Poison resistance - 毒耐性
	// DESC: Difficulty in getting poisonous - 毒状態異常へのかかりにくさ
	uint16_t resistPoison_0C4;

	// NAME: Epidemic resistance - 疫病耐性
	// DESC: Difficulty in getting sick - 疫病状態異常へのかかりにくさ
	uint16_t resistDisease_0C6;

	// NAME: Bleeding resistance - 出血耐性
	// DESC: Difficulty in getting bleeding abnormalities - 出血状態異常へのかかりにくさ
	uint16_t resistBlood_0C8;

	// NAME: Curse resistance - 呪耐性
	// DESC: Difficulty in getting a curse condition - 呪い状態異常へのかかりにくさ
	uint16_t resistCurse_0CA;

	// NAME: Enhanced type ID - 強化タイプID
	// DESC: Enhanced type ID - 強化タイプID
	int16_t reinforceTypeId_0CC;

	// NAME: Trophy - トロフィー
	// DESC: Is it related to the trophy system? - トロフィーシステムに関係あるか？
	int16_t trophySGradeId_0CE;

	// NAME: Shop level - ショップレベル
	// DESC: Level that can be sold at the store - お店で販売できるレベル
	int16_t shopLv_0D0;

	// NAME: Knockback parameter ID - ノックバックパラメータID
	// DESC: ID of the parameter used for knockback - ノックバックで使用するパラメータのID
	uint8_t knockbackParamId_0D2;

	// NAME: Damage attenuation rate when repelling [%] - はじき時ダメージ減衰率[%]
	// DESC: Used for damage attenuation rate when repelling - はじき時のダメージ減衰率に使用
	uint8_t flickDamageCutRate_0D3;

	// NAME: Equipment model type - 装備モデル種別
	// DESC: Equipment model type. - 装備モデルの種別.
	uint8_t equipModelCategory_0D4;

	// NAME: Equipment model gender - 装備モデル性別
	// DESC: Gender of equipment model. - 装備モデルの性別.
	uint8_t equipModelGender_0D5;

	// NAME: Armor category - 防具カテゴリ
	// DESC: Armor category. - 防具のカテゴリ.
	uint8_t protectorCategory_0D6;

	// NAME: Rarity - レア度
	// DESC: Rarity used in item acquisition logs - アイテム取得ログで使うレア度
	uint8_t rarity_0D7;

	// NAME: Sort item type ID - ソートアイテム種別ID
	// DESC: Sort item type ID. In the sort "Item type order", the same ID is displayed together as the same group. - ソートアイテム種別ID。ソート「アイテム種別順」にて、同じIDは同じグループとしてまとめて表示されます
	uint8_t sortGroupId_0D8;

	// NAME: Part damage application attack - 部位ダメージ適用攻撃
	// DESC: Set the attack type to judge the part damage - 部位ダメージ判定を行う攻撃タイプを設定
	uint8_t partsDmgType_0D9;

	// NAME: Padding - パディング
	uint8_t pad04_0DA[2];

	// NAME: Can i deposit - 預けれるか
	// DESC: Can you leave it in the warehouse? - 倉庫に預けれるか
	uint8_t isDeposit_0DC: 1;

	// NAME: Head equipment - 頭装備
	// DESC: Is it head equipment? - 頭装備か.
	uint8_t headEquip_0DC: 1;

	// NAME: Torso equipment - 胴装備
	// DESC: Is it torso equipment? - 胴装備か.
	uint8_t bodyEquip_0DC: 1;

	// NAME: Arm equipment - 腕装備
	// DESC: Is it arm equipment? - 腕装備か.
	uint8_t armEquip_0DC: 1;

	// NAME: Leg equipment - 脚装備
	// DESC: Is it leg equipment? - 脚装備か.
	uint8_t legEquip_0DC: 1;

	// NAME: Whether to use a face scale - 顔スケールを使用するか
	// DESC: Whether to use a face scale - 顔スケールを使用するか
	uint8_t useFaceScale_0DC: 1;

	// NAME: Do you want to skip the weakness animation? - 弱点アニメをスキップするか
	// DESC: Weakness damage Whether to skip animation playback. "Part damage rate" and "defense material" are treated as weak points just by not playing the animation. - 弱点ダメージアニメ再生をスキップするかどうか。アニメを再生しないだけで「部位ダメージ率」「防御材質」は弱点として扱われます。
	uint8_t isSkipWeakDamageAnim_0DC: 1;

	// NAME: Padding - パディング
	uint8_t pad06_0DC: 1;

	// NAME: Weakness defense material variation value - 弱点防御材質バリエーション値
	// DESC: It is a value used for variation of abnormal condition, damage SFX, SE in combination with weak point defense material. SEQ16473 - 弱点防御材質と組み合わせて状態異常、ダメージSFX,SEのバリエーション分けに使用する値です。SEQ16473
	uint8_t defenseMaterialVariationValue_Weak_0DD;

	// NAME: Foot decal identifier 2 - フットデカール識別子2
	// DESC: Decal ID for automatic foot effects. Floor material is also considered. Only used when the "armor category" is "legs". - 自動フットエフェクトのデカールID。床材質も考慮される。防具カテゴリ」が「脚」のときのみ利用される。
	int16_t autoFootEffectDecalBaseId2_0DE;

	// NAME: Foot decal identifier 3 - フットデカール識別子3
	// DESC: Decal ID for automatic foot effects. Floor material is also considered. Only used when the "armor category" is "legs". - 自動フットエフェクトのデカールID。床材質も考慮される。防具カテゴリ」が「脚」のときのみ利用される。
	int16_t autoFootEffectDecalBaseId3_0E0;

	// NAME: Defensive material variation value - 防御材質バリエーション値
	// DESC: It is a value used in combination with the defense material to classify abnormal conditions, damage SFX, and SE. SEQ16473 - 防御材質と組み合わせて状態異常、ダメージSFX,SEのバリエーション分けに使用する値です。SEQ16473
	uint8_t defenseMaterialVariationValue_0E2;

	// NAME: Can you throw it away - 捨てれるか
	// DESC: Can you throw away the item? TRUE = thrown away - アイテムを捨てれるか？TRUE=捨てれる
	uint8_t isDiscard_0E3: 1;

	// NAME: Can you put it on the spot - その場に置けるか
	// DESC: Can I put the item on the spot? TRUE = can be placed - アイテムをその場に置けるか？TRUE=置ける
	uint8_t isDrop_0E3: 1;

	// NAME: Is multi-drop sharing prohibited? - マルチドロップ共有禁止か
	// DESC: Is multi-drop sharing prohibited? - マルチドロップ共有禁止か
	uint8_t disableMultiDropShare_0E3: 1;

	// NAME: Is there a simple model for DLC? - DLC用シンプルモデルありか
	// DESC: Is there a simple model for DLC? - ＤＬＣ用シンプルモデルが存在しているか
	uint8_t simpleModelForDlc_0E3: 1;

	// NAME: Acquisition log display condition - 取得ログ表示条件
	// DESC: Whether to display in the item acquisition log when acquiring the item (not entered: ○) - アイテム取得時にアイテム取得ログに表示するか（未入力: ○）
	uint8_t showLogCondType_0E3: 1;

	// NAME: Acquisition dialog display condition - 取得ダイアログ表示条件
	// DESC: Whether to display it in the item acquisition dialog when acquiring an item (not entered: new only) - アイテム取得時にアイテム取得ダイアログに表示するか（未入力: newのみ）
	uint8_t showDialogCondType_0E3: 2;

	// NAME: Padding - パディング
	uint8_t pad_0E3: 1;

	// NAME: Non-attribute damage multiplier - 無属性ダメージ倍率
	// DESC: Non-attribute damage multiplier - 無属性ダメージ倍率
	float neutralDamageCutRate_0E4;

	// NAME: Slash damage multiplier - 斬撃ダメージ倍率
	// DESC: Slash damage multiplier - 斬撃ダメージ倍率
	float slashDamageCutRate_0E8;

	// NAME: Batter damage multiplier - 打撃ダメージ倍率
	// DESC: Batter damage multiplier - 打撃ダメージ倍率
	float blowDamageCutRate_0EC;

	// NAME: Puncture damage ratio - 刺突ダメージ倍率
	// DESC: Puncture damage ratio - 刺突ダメージ倍率
	float thrustDamageCutRate_0F0;

	// NAME: Magic damage multiplier - 魔法ダメージ倍率
	// DESC: Magic damage multiplier - 魔法ダメージ倍率
	float magicDamageCutRate_0F4;

	// NAME: Flame damage multiplier - 火炎ダメージ倍率
	// DESC: Flame damage multiplier - 火炎ダメージ倍率
	float fireDamageCutRate_0F8;

	// NAME: Electric shock damage ratio - 電撃ダメージ倍率
	// DESC: Electric shock damage ratio - 電撃ダメージ倍率
	float thunderDamageCutRate_0FC;

	// NAME: Defensive material 1 [SFX] - 防御材質1【SFX】
	// DESC: For SFX when moving / defending. 1 - 移動/防御時のSFX用.1
	uint16_t defenseMaterialSfx1_100;

	// NAME: Weakness protection material 1 [SFX] - 弱点防御材質1【SFX】
	// DESC: For SFX when weak points are damaged 1 - 弱点部位ダメージ時のSFX用1
	uint16_t defenseMaterialSfx_Weak1_102;

	// NAME: Defensive material 1 [SE] - 防御材質1【SE】
	// DESC: For SE when moving / defending. 1 - 移動/防御時のSE用.1
	uint16_t defenseMaterial1_104;

	// NAME: Weakness defense material 1 [SE] - 弱点防御材質1【SE】
	// DESC: For SE when weak points are damaged 1 - 弱点部位ダメージ時のSE用1
	uint16_t defenseMaterial_Weak1_106;

	// NAME: Defensive material 2 [SFX] - 防御材質2【SFX】
	// DESC: For SFX when moving / defending. 2 - 移動/防御時のSFX用.2
	uint16_t defenseMaterialSfx2_108;

	// NAME: Weakness protection material 2 [SFX] - 弱点防御材質2【SFX】
	// DESC: 2 for SFX when weak points are damaged - 弱点部位ダメージ時のSFX用2
	uint16_t defenseMaterialSfx_Weak2_10A;

	// NAME: Foot equipment material [SE] - 足装備材質【SE】
	// DESC: Material for foot equipment SE. Only foot equipment is referenced. ([GR] SEQ10061) In the case of "139: None", the defense material 1 [SE] is referred to. - 足装備SE用材質。足装備のみ参照される。(【GR】SEQ10061) 「139:なし」の場合は防御材質1【SE】が参照される
	uint16_t footMaterialSe_10C;

	// NAME: Weakness defense material 2 [SE] - 弱点防御材質2【SE】
	// DESC: 2 for SE when weak points are damaged - 弱点部位ダメージ時のSE用2
	uint16_t defenseMaterial_Weak2_10E;

	// NAME: Foot decal identifier 1 - フットデカール識別子1
	// DESC: Decal ID for automatic foot effects. Floor material is also considered. Only used when the "armor category" is "legs". - 自動フットエフェクトのデカールID。床材質も考慮される。防具カテゴリ」が「脚」のときのみ利用される。
	int32_t autoFootEffectDecalBaseId1_110;

	// NAME: Toughness Damage multiplier - 強靭度 被ダメージ倍率
	// DESC: Toughness version cut rate - 強靭度版カット率
	float toughnessDamageCutRate_114;

	// NAME: Toughness recovery time correction value - 強靭度 回復時間補正値
	// DESC: Correction value for toughness recovery time - 強靭度の回復時間用の補正値
	float toughnessRecoverCorrection_118;

	// NAME: Dark damage multiplier - 闇ダメージ倍率
	// DESC: Dark damage multiplier - 闇ダメージ倍率
	float darkDamageCutRate_11C;

	// NAME: Dark defense - 闇防御力
	// DESC: Dark attack damage protection. - 闇攻撃のダメージ防御.
	uint16_t defenseDark_120;

	// NAME: PAD_original_ # 48 # hidden - PAD_元_#48#非表示
	// DESC: Original _ # 48 # hidden - 元_#48#非表示
	uint8_t invisibleFlag48_122: 1;

	// NAME: PAD_original_ # 49 # hidden - PAD_元_#49#非表示
	// DESC: Original _ # 49 # hidden - 元_#49#非表示
	uint8_t invisibleFlag49_122: 1;

	// NAME: PAD_original_ # 50 # hidden - PAD_元_#50#非表示
	// DESC: Original _ # 50 # hidden - 元_#50#非表示
	uint8_t invisibleFlag50_122: 1;

	// NAME: PAD_original_ # 51 # hidden - PAD_元_#51#非表示
	// DESC: Original _ # 51 # hidden - 元_#51#非表示
	uint8_t invisibleFlag51_122: 1;

	// NAME: PAD_original_ # 52 # hidden - PAD_元_#52#非表示
	// DESC: Original _ # 52 # hidden - 元_#52#非表示
	uint8_t invisibleFlag52_122: 1;

	// NAME: PAD_original_ # 53 # hidden - PAD_元_#53#非表示
	// DESC: Original _ # 53 # hidden - 元_#53#非表示
	uint8_t invisibleFlag53_122: 1;

	// NAME: PAD_original_ # 54 # hidden - PAD_元_#54#非表示
	// DESC: Original _ # 54 # hidden - 元_#54#非表示
	uint8_t invisibleFlag54_122: 1;

	// NAME: PAD_original_ # 55 # hidden - PAD_元_#55#非表示
	// DESC: Original _ # 55 # hidden - 元_#55#非表示
	uint8_t invisibleFlag55_122: 1;

	// NAME: PAD_original_ # 56 # hidden - PAD_元_#56#非表示
	// DESC: Original _ # 56 # hidden - 元_#56#非表示
	uint8_t invisibleFlag56_123: 1;

	// NAME: PAD_original_ # 57 # hidden - PAD_元_#57#非表示
	// DESC: Original _ # 57 # hidden - 元_#57#非表示
	uint8_t invisibleFlag57_123: 1;

	// NAME: PAD_original_ # 58 # hidden - PAD_元_#58#非表示
	// DESC: Original _ # 58 # hidden - 元_#58#非表示
	uint8_t invisibleFlag58_123: 1;

	// NAME: PAD_original_ # 59 # hidden - PAD_元_#59#非表示
	// DESC: Original _ # 59 # hidden - 元_#59#非表示
	uint8_t invisibleFlag59_123: 1;

	// NAME: PAD_original_ # 60 # hidden - PAD_元_#60#非表示
	// DESC: Original _ # 60 # hidden - 元_#60#非表示
	uint8_t invisibleFlag60_123: 1;

	// NAME: PAD_original_ # 61 # hidden - PAD_元_#61#非表示
	// DESC: Original _ # 61 # Hidden - 元_#61#非表示
	uint8_t invisibleFlag61_123: 1;

	// NAME: PAD_original_ # 62 # hidden - PAD_元_#62#非表示
	// DESC: Original _ # 62 # hidden - 元_#62#非表示
	uint8_t invisibleFlag62_123: 1;

	// NAME: PAD_original_ # 63 # hidden - PAD_元_#63#非表示
	// DESC: Original _ # 63 # hidden - 元_#63#非表示
	uint8_t invisibleFlag63_123: 1;

	// NAME: PAD_original_ # 64 # hidden - PAD_元_#64#非表示
	// DESC: Original _ # 64 # hidden - 元_#64#非表示
	uint8_t invisibleFlag64_124: 1;

	// NAME: PAD_original_ # 65 # hidden - PAD_元_#65#非表示
	// DESC: Original _ # 65 # hidden - 元_#65#非表示
	uint8_t invisibleFlag65_124: 1;

	// NAME: PAD_original_ # 66 # hidden - PAD_元_#66#非表示
	// DESC: Original _ # 66 # hidden - 元_#66#非表示
	uint8_t invisibleFlag66_124: 1;

	// NAME: PAD_original_ # 67 # hidden - PAD_元_#67#非表示
	// DESC: Original _ # 67 # hidden - 元_#67#非表示
	uint8_t invisibleFlag67_124: 1;

	// NAME: PAD_original_ # 68 # hidden - PAD_元_#68#非表示
	// DESC: Original _ # 68 # hidden - 元_#68#非表示
	uint8_t invisibleFlag68_124: 1;

	// NAME: PAD_original_ # 69 # hidden - PAD_元_#69#非表示
	// DESC: Original _ # 69 # hidden - 元_#69#非表示
	uint8_t invisibleFlag69_124: 1;

	// NAME: PAD_original_ # 70 # hidden - PAD_元_#70#非表示
	// DESC: Original _ # 70 # hidden - 元_#70#非表示
	uint8_t invisibleFlag70_124: 1;

	// NAME: PAD_original_ # 71 # hidden - PAD_元_#71#非表示
	// DESC: Original _ # 71 # hidden - 元_#71#非表示
	uint8_t invisibleFlag71_124: 1;

	// NAME: PAD_original_ # 72 # hidden - PAD_元_#72#非表示
	// DESC: Original _ # 72 # hidden - 元_#72#非表示
	uint8_t invisibleFlag72_125: 1;

	// NAME: PAD_original_ # 73 # hidden - PAD_元_#73#非表示
	// DESC: Original _ # 73 # hidden - 元_#73#非表示
	uint8_t invisibleFlag73_125: 1;

	// NAME: PAD_original_ # 74 # hidden - PAD_元_#74#非表示
	// DESC: Original _ # 74 # hidden - 元_#74#非表示
	uint8_t invisibleFlag74_125: 1;

	// NAME: PAD_original_ # 75 # hidden - PAD_元_#75#非表示
	// DESC: Original _ # 75 # hidden - 元_#75#非表示
	uint8_t invisibleFlag75_125: 1;

	// NAME: PAD_original_ # 76 # hidden - PAD_元_#76#非表示
	// DESC: Original _ # 76 # hidden - 元_#76#非表示
	uint8_t invisibleFlag76_125: 1;

	// NAME: PAD_original_ # 77 # hidden - PAD_元_#77#非表示
	// DESC: Original _ # 77 # hidden - 元_#77#非表示
	uint8_t invisibleFlag77_125: 1;

	// NAME: PAD_original_ # 78 # hidden - PAD_元_#78#非表示
	// DESC: Original _ # 78 # hidden - 元_#78#非表示
	uint8_t invisibleFlag78_125: 1;

	// NAME: PAD_original_ # 79 # hidden - PAD_元_#79#非表示
	// DESC: Original _ # 79 # hidden - 元_#79#非表示
	uint8_t invisibleFlag79_125: 1;

	// NAME: PAD_original_ # 80 # hidden - PAD_元_#80#非表示
	// DESC: Original _ # 80 # hidden - 元_#80#非表示
	uint8_t invisibleFlag80_126: 1;

	// NAME: Padding - パディング
	uint8_t padbit_126: 7;

	// NAME: Attitude control ID (torso) - 姿勢制御ID(胴)
	// DESC: Attitude control ID (torso) - 姿勢制御ID(胴)
	uint8_t postureControlId_127;

	// NAME: pad - pad
	uint8_t pad2_128[4];

	// NAME: Selling price - 販売価格
	// DESC: Selling price - 販売価格
	int32_t saleValue_12C;

	// NAME: Cold resistance - 冷気耐性
	// DESC: Difficulty in getting cold air condition abnormal - 冷気状態異常へのかかりにくさ
	uint16_t resistFreeze_130;

	// NAME: # 00 #Hidden (Gender designation) - #00#非表示(男女指定)
	// DESC: Bangs tip - 前髪の先
	uint8_t invisibleFlag_SexVer00_132;

	// NAME: # 01 #Hidden (Gender designation) - #01#非表示(男女指定)
	// DESC: Bangs root - 前髪の根元
	uint8_t invisibleFlag_SexVer01_133;

	// NAME: # 02 #Hidden (Gender designation) - #02#非表示(男女指定)
	// DESC: Sideburns - もみあげ
	uint8_t invisibleFlag_SexVer02_134;

	// NAME: # 03 #Hidden (Gender designation) - #03#非表示(男女指定)
	// DESC: Top of the head - 頭頂部
	uint8_t invisibleFlag_SexVer03_135;

	// NAME: # 04 #Hidden (Gender designation) - #04#非表示(男女指定)
	// DESC: Top of the head - 頭頂部
	uint8_t invisibleFlag_SexVer04_136;

	// NAME: # 05 #Hidden (Gender designation) - #05#非表示(男女指定)
	// DESC: Back hair - 後ろ髪
	uint8_t invisibleFlag_SexVer05_137;

	// NAME: # 06 #Hidden (Gender designation) - #06#非表示(男女指定)
	// DESC: The tip of the back hair - 後ろ髪の先
	uint8_t invisibleFlag_SexVer06_138;

	// NAME: # 07 #Hidden (Gender designation) - #07#非表示(男女指定)
	uint8_t invisibleFlag_SexVer07_139;

	// NAME: # 08 #Hidden (Gender designation) - #08#非表示(男女指定)
	uint8_t invisibleFlag_SexVer08_13A;

	// NAME: # 09 #Hidden (Gender designation) - #09#非表示(男女指定)
	uint8_t invisibleFlag_SexVer09_13B;

	// NAME: # 10 #Hidden (Gender designation) - #10#非表示(男女指定)
	// DESC: collar - 襟
	uint8_t invisibleFlag_SexVer10_13C;

	// NAME: # 11 #Hidden (Gender designation) - #11#非表示(男女指定)
	// DESC: Around the collar - 襟回り
	uint8_t invisibleFlag_SexVer11_13D;

	// NAME: # 12 #Hidden (Gender designation) - #12#非表示(男女指定)
	uint8_t invisibleFlag_SexVer12_13E;

	// NAME: # 13 #Hidden (Gender designation) - #13#非表示(男女指定)
	uint8_t invisibleFlag_SexVer13_13F;

	// NAME: # 14 #Hidden (Gender designation) - #14#非表示(男女指定)
	uint8_t invisibleFlag_SexVer14_140;

	// NAME: # 15 #Hidden (Gender designation) - #15#非表示(男女指定)
	// DESC: Hood hem - 頭巾の裾
	uint8_t invisibleFlag_SexVer15_141;

	// NAME: # 16 #Hidden (Gender designation) - #16#非表示(男女指定)
	uint8_t invisibleFlag_SexVer16_142;

	// NAME: # 17 #Hidden (Gender designation) - #17#非表示(男女指定)
	uint8_t invisibleFlag_SexVer17_143;

	// NAME: # 18 #Hidden (Gender designation) - #18#非表示(男女指定)
	uint8_t invisibleFlag_SexVer18_144;

	// NAME: # 19 #Hidden (Gender designation) - #19#非表示(男女指定)
	uint8_t invisibleFlag_SexVer19_145;

	// NAME: # 20 #Hidden (Gender designation) - #20#非表示(男女指定)
	// DESC: Sleeve A - 袖A
	uint8_t invisibleFlag_SexVer20_146;

	// NAME: # 21 #Hidden (Gender designation) - #21#非表示(男女指定)
	// DESC: Sleeve B - 袖B
	uint8_t invisibleFlag_SexVer21_147;

	// NAME: # 22 #Hidden (Gender designation) - #22#非表示(男女指定)
	uint8_t invisibleFlag_SexVer22_148;

	// NAME: # 23 #Hidden (Gender designation) - #23#非表示(男女指定)
	uint8_t invisibleFlag_SexVer23_149;

	// NAME: # 24 #Hidden (Gender designation) - #24#非表示(男女指定)
	uint8_t invisibleFlag_SexVer24_14A;

	// NAME: # 25 #Hidden (Gender designation) - #25#非表示(男女指定)
	// DESC: arm - 腕
	uint8_t invisibleFlag_SexVer25_14B;

	// NAME: # 26 #Hidden (Gender designation) - #26#非表示(男女指定)
	uint8_t invisibleFlag_SexVer26_14C;

	// NAME: # 27 #Hidden (Gender designation) - #27#非表示(男女指定)
	uint8_t invisibleFlag_SexVer27_14D;

	// NAME: # 28 #Hidden (Gender designation) - #28#非表示(男女指定)
	uint8_t invisibleFlag_SexVer28_14E;

	// NAME: # 29 #Hidden (Gender designation) - #29#非表示(男女指定)
	uint8_t invisibleFlag_SexVer29_14F;

	// NAME: # 30 #Hidden (Gender designation) - #30#非表示(男女指定)
	// DESC: belt - ベルト
	uint8_t invisibleFlag_SexVer30_150;

	// NAME: # 31 #Hidden (Gender designation) - #31#非表示(男女指定)
	uint8_t invisibleFlag_SexVer31_151;

	// NAME: # 32 #Hidden (Men and women specified) - #32#非表示(男女指定)
	uint8_t invisibleFlag_SexVer32_152;

	// NAME: # 33 #Hidden (Gender designation) - #33#非表示(男女指定)
	uint8_t invisibleFlag_SexVer33_153;

	// NAME: # 34 #Hidden (Gender designation) - #34#非表示(男女指定)
	uint8_t invisibleFlag_SexVer34_154;

	// NAME: # 35 #Hidden (Gender designation) - #35#非表示(男女指定)
	uint8_t invisibleFlag_SexVer35_155;

	// NAME: # 36 #Hidden (Gender designation) - #36#非表示(男女指定)
	uint8_t invisibleFlag_SexVer36_156;

	// NAME: # 37 #Hidden (Gender designation) - #37#非表示(男女指定)
	uint8_t invisibleFlag_SexVer37_157;

	// NAME: # 38 #Hidden (Gender designation) - #38#非表示(男女指定)
	uint8_t invisibleFlag_SexVer38_158;

	// NAME: # 39 #Hidden (Gender designation) - #39#非表示(男女指定)
	uint8_t invisibleFlag_SexVer39_159;

	// NAME: # 40 #Hidden (Gender designation) - #40#非表示(男女指定)
	uint8_t invisibleFlag_SexVer40_15A;

	// NAME: # 41 #Hidden (Gender designation) - #41#非表示(男女指定)
	uint8_t invisibleFlag_SexVer41_15B;

	// NAME: # 42 #Hidden (Gender designation) - #42#非表示(男女指定)
	uint8_t invisibleFlag_SexVer42_15C;

	// NAME: # 43 #Hidden (Gender designation) - #43#非表示(男女指定)
	uint8_t invisibleFlag_SexVer43_15D;

	// NAME: # 44 #Hidden (Gender designation) - #44#非表示(男女指定)
	uint8_t invisibleFlag_SexVer44_15E;

	// NAME: # 45 #Hidden (Gender designation) - #45#非表示(男女指定)
	uint8_t invisibleFlag_SexVer45_15F;

	// NAME: # 46 #Hidden (Gender designation) - #46#非表示(男女指定)
	uint8_t invisibleFlag_SexVer46_160;

	// NAME: # 47 #Hidden (Gender designation) - #47#非表示(男女指定)
	uint8_t invisibleFlag_SexVer47_161;

	// NAME: # 48 #Hidden (Gender designation) - #48#非表示(男女指定)
	uint8_t invisibleFlag_SexVer48_162;

	// NAME: # 49 #Hidden (Gender designation) - #49#非表示(男女指定)
	uint8_t invisibleFlag_SexVer49_163;

	// NAME: # 50 #Hidden (Gender designation) - #50#非表示(男女指定)
	uint8_t invisibleFlag_SexVer50_164;

	// NAME: # 51 #Hidden (Gender designation) - #51#非表示(男女指定)
	uint8_t invisibleFlag_SexVer51_165;

	// NAME: # 52 #Hidden (Gender designation) - #52#非表示(男女指定)
	uint8_t invisibleFlag_SexVer52_166;

	// NAME: # 53 #Hidden (Gender designation) - #53#非表示(男女指定)
	uint8_t invisibleFlag_SexVer53_167;

	// NAME: # 54 #Hidden (Gender designation) - #54#非表示(男女指定)
	uint8_t invisibleFlag_SexVer54_168;

	// NAME: # 55 #Hidden (Gender designation) - #55#非表示(男女指定)
	uint8_t invisibleFlag_SexVer55_169;

	// NAME: # 56 #Hidden (Gender designation) - #56#非表示(男女指定)
	uint8_t invisibleFlag_SexVer56_16A;

	// NAME: # 57 #Hidden (Gender designation) - #57#非表示(男女指定)
	uint8_t invisibleFlag_SexVer57_16B;

	// NAME: # 58 #Hidden (Gender designation) - #58#非表示(男女指定)
	uint8_t invisibleFlag_SexVer58_16C;

	// NAME: # 59 #Hidden (Gender designation) - #59#非表示(男女指定)
	uint8_t invisibleFlag_SexVer59_16D;

	// NAME: # 60 #Hidden (Men and women specified) - #60#非表示(男女指定)
	uint8_t invisibleFlag_SexVer60_16E;

	// NAME: # 61 #Hidden (Gender designation) - #61#非表示(男女指定)
	uint8_t invisibleFlag_SexVer61_16F;

	// NAME: # 62 #Hidden (Gender designation) - #62#非表示(男女指定)
	uint8_t invisibleFlag_SexVer62_170;

	// NAME: # 63 #Hidden (Gender designation) - #63#非表示(男女指定)
	uint8_t invisibleFlag_SexVer63_171;

	// NAME: # 64 #Hidden (Gender designation) - #64#非表示(男女指定)
	uint8_t invisibleFlag_SexVer64_172;

	// NAME: # 65 #Hidden (Gender designation) - #65#非表示(男女指定)
	uint8_t invisibleFlag_SexVer65_173;

	// NAME: # 66 #Hidden (Gender designation) - #66#非表示(男女指定)
	uint8_t invisibleFlag_SexVer66_174;

	// NAME: # 67 #Hidden (Gender designation) - #67#非表示(男女指定)
	uint8_t invisibleFlag_SexVer67_175;

	// NAME: # 68 #Hidden (Gender designation) - #68#非表示(男女指定)
	uint8_t invisibleFlag_SexVer68_176;

	// NAME: # 69 #Hidden (Gender designation) - #69#非表示(男女指定)
	uint8_t invisibleFlag_SexVer69_177;

	// NAME: # 70 #Hidden (Gender designation) - #70#非表示(男女指定)
	uint8_t invisibleFlag_SexVer70_178;

	// NAME: # 71 #Hidden (Gender designation) - #71#非表示(男女指定)
	uint8_t invisibleFlag_SexVer71_179;

	// NAME: # 72 #Hidden (Gender designation) - #72#非表示(男女指定)
	uint8_t invisibleFlag_SexVer72_17A;

	// NAME: # 73 #Hidden (Gender designation) - #73#非表示(男女指定)
	uint8_t invisibleFlag_SexVer73_17B;

	// NAME: # 74 #Hidden (Gender designation) - #74#非表示(男女指定)
	uint8_t invisibleFlag_SexVer74_17C;

	// NAME: # 75 #Hidden (Gender designation) - #75#非表示(男女指定)
	uint8_t invisibleFlag_SexVer75_17D;

	// NAME: # 76 #Hidden (Gender designation) - #76#非表示(男女指定)
	uint8_t invisibleFlag_SexVer76_17E;

	// NAME: # 77 #Hidden (Gender designation) - #77#非表示(男女指定)
	uint8_t invisibleFlag_SexVer77_17F;

	// NAME: # 78 #Hidden (Gender designation) - #78#非表示(男女指定)
	uint8_t invisibleFlag_SexVer78_180;

	// NAME: # 79 #Hidden (Gender designation) - #79#非表示(男女指定)
	uint8_t invisibleFlag_SexVer79_181;

	// NAME: # 80 #Hidden (Gender designation) - #80#非表示(男女指定)
	uint8_t invisibleFlag_SexVer80_182;

	// NAME: # 81 #Hidden (Gender designation) - #81#非表示(男女指定)
	uint8_t invisibleFlag_SexVer81_183;

	// NAME: # 82 #Hidden (Gender designation) - #82#非表示(男女指定)
	uint8_t invisibleFlag_SexVer82_184;

	// NAME: # 83 #Hidden (Gender designation) - #83#非表示(男女指定)
	uint8_t invisibleFlag_SexVer83_185;

	// NAME: # 84 #Hidden (Gender designation) - #84#非表示(男女指定)
	uint8_t invisibleFlag_SexVer84_186;

	// NAME: # 85 #Hidden (Gender designation) - #85#非表示(男女指定)
	uint8_t invisibleFlag_SexVer85_187;

	// NAME: # 86 #Hidden (Gender designation) - #86#非表示(男女指定)
	uint8_t invisibleFlag_SexVer86_188;

	// NAME: # 87 #Hidden (Gender designation) - #87#非表示(男女指定)
	uint8_t invisibleFlag_SexVer87_189;

	// NAME: # 88 #Hidden (Gender designation) - #88#非表示(男女指定)
	uint8_t invisibleFlag_SexVer88_18A;

	// NAME: # 89 #Hidden (Gender designation) - #89#非表示(男女指定)
	uint8_t invisibleFlag_SexVer89_18B;

	// NAME: # 90 #Hidden (Gender designation) - #90#非表示(男女指定)
	uint8_t invisibleFlag_SexVer90_18C;

	// NAME: # 91 #Hidden (Gender designation) - #91#非表示(男女指定)
	uint8_t invisibleFlag_SexVer91_18D;

	// NAME: # 92 #Hidden (Gender designation) - #92#非表示(男女指定)
	uint8_t invisibleFlag_SexVer92_18E;

	// NAME: # 93 #Hidden (Gender designation) - #93#非表示(男女指定)
	uint8_t invisibleFlag_SexVer93_18F;

	// NAME: # 94 #Hidden (Gender designation) - #94#非表示(男女指定)
	uint8_t invisibleFlag_SexVer94_190;

	// NAME: # 95 #Hidden (Gender designation) - #95#非表示(男女指定)
	uint8_t invisibleFlag_SexVer95_191;

	// NAME: Padding - パディング
	// DESC: Padding - パディング
	uint8_t pad404_192[14];

} EquipParamProtector;

#endif
