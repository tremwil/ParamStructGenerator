/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PostureControlParam_WepLeft_H
#define _PARAM_PostureControlParam_WepLeft_H
#include <stdint.h>

// POSTURE_CONTROL_PARAM_WEP_LEFT_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _PostureControlParam_WepLeft {

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a000_leftArmFB_000;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a000_leftWristFB_002;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a000_leftWristIO_004;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a002_leftArmFB_006;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a002_leftWristFB_008;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a002_leftWristIO_00A;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a003_leftArmFB_00C;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a003_leftWristFB_00E;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a003_leftWristIO_010;

	// NAME: pad - pad
	uint8_t pad_012[14];

} PostureControlParam_WepLeft;

#endif
