/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CalcCorrectGraph_H
#define _PARAM_CalcCorrectGraph_H
#include <stdint.h>

// CACL_CORRECT_GRAPH_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CalcCorrectGraph {

	// NAME: Threshold point 0 - 閾値ポイント0
	// DESC: Those with "nth threshold [point]" written in the specifications - 仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal0_000;

	// NAME: Threshold point 1 - 閾値ポイント1
	// DESC: Those with "nth threshold [point]" written in the specifications - 仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal1_004;

	// NAME: Threshold point 2 - 閾値ポイント2
	// DESC: Those with "nth threshold [point]" written in the specifications - 仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal2_008;

	// NAME: Threshold point 3 - 閾値ポイント3
	// DESC: Those with "nth threshold [point]" written in the specifications - 仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal3_00C;

	// NAME: Threshold point 4 - 閾値ポイント4
	// DESC: Those with "nth threshold [point]" written in the specifications - 仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal4_010;

	// NAME: Threshold coefficient 0 - 閾値係数0
	// DESC: Those with "nth threshold [coefficient]" written in the specifications - 仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal0_014;

	// NAME: Threshold coefficient 1 - 閾値係数1
	// DESC: Those with "nth threshold [coefficient]" written in the specifications - 仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal1_018;

	// NAME: Threshold coefficient 2 - 閾値係数2
	// DESC: Those with "nth threshold [coefficient]" written in the specifications - 仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal2_01C;

	// NAME: Threshold coefficient 3 - 閾値係数3
	// DESC: Those with "nth threshold [coefficient]" written in the specifications - 仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal3_020;

	// NAME: Threshold coefficient 4 - 閾値係数4
	// DESC: Those with "nth threshold [coefficient]" written in the specifications - 仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal4_024;

	// NAME: Adjustment factor 0 - 調整係数0
	// DESC: Adjustment factor - 調整係数
	float adjPt_maxGrowVal0_028;

	// NAME: Adjustment factor 1 - 調整係数1
	// DESC: Adjustment factor - 調整係数
	float adjPt_maxGrowVal1_02C;

	// NAME: Adjustment factor 2 - 調整係数2
	// DESC: Adjustment factor - 調整係数
	float adjPt_maxGrowVal2_030;

	// NAME: Adjustment factor 3 - 調整係数3
	// DESC: Adjustment factor - 調整係数
	float adjPt_maxGrowVal3_034;

	// NAME: Adjustment factor 4 - 調整係数4
	// DESC: Adjustment factor - 調整係数
	float adjPt_maxGrowVal4_038;

	// NAME: Growth Soul Slope of the early graph α1 - 成長ソウル 初期のグラフの傾きα1
	// DESC: Growth Soul Slope of the early graph α1 - 成長ソウル 初期のグラフの傾きα1
	float init_inclination_soul_03C;

	// NAME: Growth soul Early soul adjustment α2 - 成長ソウル 初期のsoul調整α2
	// DESC: Growth soul Early soul adjustment α2 - 成長ソウル 初期のsoul調整α2
	float adjustment_value_040;

	// NAME: Affects the slope of the graph after the growth soul threshold α3 - 成長ソウル 閾値後のグラフの傾きに影響α3
	// DESC: Affects the slope of the graph after the growth soul threshold α3 - 成長ソウル 閾値後のグラフの傾きに影響α3
	float boundry_inclination_soul_044;

	// NAME: Growth soul threshold t - 成長ソウル 閾値 t
	// DESC: Growth soul threshold t - 成長ソウル 閾値 t
	float boundry_value_048;

	// NAME: Padding - パディング
	uint8_t pad_04C[4];

} CalcCorrectGraph;

#endif
