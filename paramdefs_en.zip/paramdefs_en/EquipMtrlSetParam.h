/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EquipMtrlSetParam_H
#define _PARAM_EquipMtrlSetParam_H
#include <stdint.h>

// EQUIP_MTRL_SET_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EquipMtrlSetParam {

	// NAME: Required Material Item ID 01 - 必要素材アイテムID01
	// DESC: Material item ID required to strengthen armor. - 武具強化に必要な素材アイテムIDです。
	int32_t materialId01_000;

	// NAME: Required Material Item ID 02 - 必要素材アイテムID02
	// DESC: Material item ID required to strengthen armor. - 武具強化に必要な素材アイテムIDです。
	int32_t materialId02_004;

	// NAME: Required Material Item ID 03 - 必要素材アイテムID03
	// DESC: Material item ID required to strengthen armor. - 武具強化に必要な素材アイテムIDです。
	int32_t materialId03_008;

	// NAME: Required Material Item ID 04 - 必要素材アイテムID04
	// DESC: Material item ID required to strengthen armor. - 武具強化に必要な素材アイテムIDです。
	int32_t materialId04_00C;

	// NAME: Required Material Item ID 05 - 必要素材アイテムID05
	// DESC: Material item ID required to strengthen armor. - 武具強化に必要な素材アイテムIDです。
	int32_t materialId05_010;

	// NAME: Required Material Item ID 06 - 必要素材アイテムID06
	// DESC: Material item ID required to strengthen armor. - 武具強化に必要な素材アイテムIDです。
	int32_t materialId06_014;

	// NAME: Padding - パディング
	// DESC: Padding. For when the material item ID increases - パディング。素材アイテムIDが増えたとき用
	uint8_t pad_id_018[8];

	// NAME: Required number 01 - 必要個数01
	// DESC: The number of material items required to strengthen armor. - 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum01_020;

	// NAME: Required number 02 - 必要個数02
	// DESC: The number of material items required to strengthen armor. - 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum02_021;

	// NAME: Required number 03 - 必要個数03
	// DESC: The number of material items required to strengthen armor. - 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum03_022;

	// NAME: Required number 04 - 必要個数04
	// DESC: The number of material items required to strengthen armor. - 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum04_023;

	// NAME: Required number 05 - 必要個数05
	// DESC: The number of material items required to strengthen armor. - 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum05_024;

	// NAME: Required number 06 - 必要個数06
	// DESC: The number of material items required to strengthen armor. - 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum06_025;

	// NAME: Padding - パディング
	// DESC: Padding. For when the number of items increases - パディング。アイテムの個数が増えたとき用
	uint8_t pad_num_026[2];

	// NAME: Required Material Item Category 01 - 必要素材アイテムカテゴリ01
	// DESC: This is a category of material items required for strengthening armor. - 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate01_028;

	// NAME: Required Material Item Category 02 - 必要素材アイテムカテゴリ02
	// DESC: This is a category of material items required for strengthening armor. - 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate02_029;

	// NAME: Required Material Item Category 03 - 必要素材アイテムカテゴリ03
	// DESC: This is a category of material items required for strengthening armor. - 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate03_02A;

	// NAME: Required Material Item Category 04 - 必要素材アイテムカテゴリ04
	// DESC: This is a category of material items required for strengthening armor. - 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate04_02B;

	// NAME: Required Material Item Category 05 - 必要素材アイテムカテゴリ05
	// DESC: This is a category of material items required for strengthening armor. - 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate05_02C;

	// NAME: Required Material Item Category 06 - 必要素材アイテムカテゴリ06
	// DESC: This is a category of material items required for strengthening armor. - 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate06_02D;

	// NAME: Padding - パディング
	// DESC: Padding. For when the number of categories increases - パディング。カテゴリが増えたとき用
	uint8_t pad_cate_02E[2];

	// NAME: Disable number display 01 - 個数表示を無効化01
	// DESC: Disable the number display (for enhanced shops) - 個数表示を無効化するか(強化ショップ用)
	uint8_t isDisableDispNum01_030: 1;

	// NAME: Disable number display 02 - 個数表示を無効化02
	// DESC: Whether to disable the number display - 個数表示を無効化するか
	uint8_t isDisableDispNum02_030: 1;

	// NAME: Disable number display 03 - 個数表示を無効化03
	// DESC: Whether to disable the number display - 個数表示を無効化するか
	uint8_t isDisableDispNum03_030: 1;

	// NAME: Disable number display 04 - 個数表示を無効化04
	// DESC: Whether to disable the number display - 個数表示を無効化するか
	uint8_t isDisableDispNum04_030: 1;

	// NAME: Disable number display 05 - 個数表示を無効化05
	// DESC: Whether to disable the number display - 個数表示を無効化するか
	uint8_t isDisableDispNum05_030: 1;

	// NAME: Disable number display 06 - 個数表示を無効化06
	// DESC: Whether to disable the number display - 個数表示を無効化するか
	uint8_t isDisableDispNum06_030: 1;

	// NAME: Padding - パディング
	// DESC: It's padding. - パディングです。
	uint8_t pad_030[3];

} EquipMtrlSetParam;

#endif
