/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_TextureFilterQuality_H
#define _PARAM_Gconfig_TextureFilterQuality_H
#include <stdint.h>

// CS_TEXTURE_FILTER_QUALITY_DETAIL
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_TextureFilterQuality {

	// NAME: filter - フィルター
	// DESC: filter - フィルター
	uint8_t filter_000;

	// NAME: dmy - dmy
	uint8_t dmy_001[3];

	// NAME: Aniso level - アニソレベル
	// DESC: Aniso level - アニソレベル
	uint32_t maxAnisoLevel_004;

} Gconfig_TextureFilterQuality;

#endif
