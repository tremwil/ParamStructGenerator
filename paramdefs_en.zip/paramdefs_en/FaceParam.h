/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_FaceParam_H
#define _PARAM_FaceParam_H
#include <stdint.h>

// FACE_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _FaceParam {

	// NAME: Face part ID - 顔パーツID
	// DESC: Face part ID - 顔パーツID
	uint8_t face_partsId_000;

	// NAME: Skin color (R) - 肌の色(Ｒ)
	// DESC: Skin color (R) - 肌の色(Ｒ)
	uint8_t skin_color_R_001;

	// NAME: Skin color (G) - 肌の色(Ｇ)
	// DESC: Skin color (G) - 肌の色(Ｇ)
	uint8_t skin_color_G_002;

	// NAME: Skin color (B) - 肌の色(Ｂ)
	// DESC: Skin color (B) - 肌の色(Ｂ)
	uint8_t skin_color_B_003;

	// NAME: Shiny skin - 肌のつや
	// DESC: Shiny skin - 肌のつや
	uint8_t skin_gloss_004;

	// NAME: pores - 毛穴
	// DESC: pores - 毛穴
	uint8_t skin_pores_005;

	// NAME: Blue beard - 青ひげ
	// DESC: Blue beard - 青ひげ
	uint8_t face_beard_006;

	// NAME: Bear - くま
	// DESC: Bear - くま
	uint8_t face_aroundEye_007;

	// NAME: Bear color (R) - くまの色(R)
	// DESC: Bear color (R) - くまの色(R)
	uint8_t face_aroundEyeColor_R_008;

	// NAME: Bear color (G) - くまの色(G)
	// DESC: Bear color (G) - くまの色(G)
	uint8_t face_aroundEyeColor_G_009;

	// NAME: Bear color (B) - くまの色(B)
	// DESC: Bear color (B) - くまの色(B)
	uint8_t face_aroundEyeColor_B_00A;

	// NAME: cheek - チーク
	// DESC: cheek - チーク
	uint8_t face_cheek_00B;

	// NAME: Teak color (R) - チークの色(R)
	// DESC: Teak color (R) - チークの色(R)
	uint8_t face_cheekColor_R_00C;

	// NAME: Teak color (G) - チークの色(G)
	// DESC: Teak color (G) - チークの色(G)
	uint8_t face_cheekColor_G_00D;

	// NAME: Teak color (B) - チークの色(B)
	// DESC: Teak color (B) - チークの色(B)
	uint8_t face_cheekColor_B_00E;

	// NAME: Eyeline - アイライン
	// DESC: Eyeline - アイライン
	uint8_t face_eyeLine_00F;

	// NAME: Eyeliner color (R) - アイラインの色(R)
	// DESC: Eyeliner color (R) - アイラインの色(R)
	uint8_t face_eyeLineColor_R_010;

	// NAME: Eyeliner color (G) - アイラインの色(G)
	// DESC: Eyeliner color (G) - アイラインの色(G)
	uint8_t face_eyeLineColor_G_011;

	// NAME: Eyeliner color (B) - アイラインの色(B)
	// DESC: Eyeliner color (B) - アイラインの色(B)
	uint8_t face_eyeLineColor_B_012;

	// NAME: Eye shadow (bottom) - アイシャドウ(下)
	// DESC: Eye shadow (bottom) - アイシャドウ(下)
	uint8_t face_eyeShadowDown_013;

	// NAME: Eyeshadow (bottom) color (R) - アイシャドウ(下)の色(R)
	// DESC: Eyeshadow (bottom) color (R) - アイシャドウ(下)の色(R)
	uint8_t face_eyeShadowDownColor_R_014;

	// NAME: Eyeshadow (bottom) color (G) - アイシャドウ(下)の色(G)
	// DESC: Eyeshadow (bottom) color (G) - アイシャドウ(下)の色(G)
	uint8_t face_eyeShadowDownColor_G_015;

	// NAME: Eyeshadow (bottom) color (B) - アイシャドウ(下)の色(B)
	// DESC: Eyeshadow (bottom) color (B) - アイシャドウ(下)の色(B)
	uint8_t face_eyeShadowDownColor_B_016;

	// NAME: Eye shadow (top) - アイシャドウ(上)
	// DESC: Eye shadow (top) - アイシャドウ(上)
	uint8_t face_eyeShadowUp_017;

	// NAME: Eyeshadow (top) color (R) - アイシャドウ(上)の色(R)
	// DESC: Eyeshadow (top) color (R) - アイシャドウ(上)の色(R)
	uint8_t face_eyeShadowUpColor_R_018;

	// NAME: Eyeshadow (top) color (G) - アイシャドウ(上)の色(G)
	// DESC: Eyeshadow (top) color (G) - アイシャドウ(上)の色(G)
	uint8_t face_eyeShadowUpColor_G_019;

	// NAME: Eyeshadow (top) color (B) - アイシャドウ(上)の色(B)
	// DESC: Eyeshadow (top) color (B) - アイシャドウ(上)の色(B)
	uint8_t face_eyeShadowUpColor_B_01A;

	// NAME: lipstick - 口紅
	// DESC: lipstick - 口紅
	uint8_t face_lip_01B;

	// NAME: Lipstick color (R) - 口紅の色(R)
	// DESC: Lipstick color (R) - 口紅の色(R)
	uint8_t face_lipColor_R_01C;

	// NAME: Lipstick color (G) - 口紅の色(G)
	// DESC: Lipstick color (G) - 口紅の色(G)
	uint8_t face_lipColor_G_01D;

	// NAME: Lipstick color (B) - 口紅の色(B)
	// DESC: Lipstick color (B) - 口紅の色(B)
	uint8_t face_lipColor_B_01E;

	// NAME: Hair thickness - 体毛の濃さ
	// DESC: Hair thickness - 体毛の濃さ
	uint8_t body_hair_01F;

	// NAME: Hair color (R) - 体毛の色(R)
	// DESC: Hair color (R) - 体毛の色(R)
	uint8_t body_hairColor_R_020;

	// NAME: Hair color (G) - 体毛の色(G)
	// DESC: Hair color (G) - 体毛の色(G)
	uint8_t body_hairColor_G_021;

	// NAME: Hair color (B) - 体毛の色(B)
	// DESC: Hair color (B) - 体毛の色(B)
	uint8_t body_hairColor_B_022;

	// NAME: Eyeball part ID - 眼球パーツID
	// DESC: Eyeball part ID - 眼球パーツID
	uint8_t eye_partsId_023;

	// NAME: Iris color (R) - 虹彩の色(Ｒ)
	// DESC: Right eye iris color (R) - 右目の虹彩の色(Ｒ)
	uint8_t eyeR_irisColor_R_024;

	// NAME: Iris color (G) - 虹彩の色(Ｇ)
	// DESC: Right eye iris color (G) - 右目の虹彩の色(Ｇ)
	uint8_t eyeR_irisColor_G_025;

	// NAME: Iris color (B) - 虹彩の色(Ｂ)
	// DESC: Right eye iris color (B) - 右目の虹彩の色(Ｂ)
	uint8_t eyeR_irisColor_B_026;

	// NAME: The size of the iris - 虹彩の大きさ
	// DESC: The size of the iris of the right eye - 右目の虹彩の大きさ
	uint8_t eyeR_irisScale_027;

	// NAME: Cloudiness of the crystalline lens - 水晶体の濁り
	// DESC: Cloudiness of the crystalline lens of the right eye - 右目の水晶体の濁り
	uint8_t eyeR_cataract_028;

	// NAME: The turbid color of the crystalline lens (R) - 水晶体の濁りの色(Ｒ)
	// DESC: The turbid color of the crystalline lens of the right eye (R) - 右目の水晶体の濁りの色(Ｒ)
	uint8_t eyeR_cataractColor_R_029;

	// NAME: The turbid color of the crystalline lens (G) - 水晶体の濁りの色(Ｇ)
	// DESC: The turbid color of the crystalline lens of the right eye (G) - 右目の水晶体の濁りの色(Ｇ)
	uint8_t eyeR_cataractColor_G_02A;

	// NAME: The turbid color of the crystalline lens (B) - 水晶体の濁りの色(Ｂ)
	// DESC: The turbid color of the crystalline lens of the right eye (B) - 右目の水晶体の濁りの色(Ｂ)
	uint8_t eyeR_cataractColor_B_02B;

	// NAME: White eye color (R) - 白目の色(Ｒ)
	// DESC: White eye color of the right eye (R) - 右目の白目の色(Ｒ)
	uint8_t eyeR_scleraColor_R_02C;

	// NAME: White eye color (G) - 白目の色(G)
	// DESC: White eye color of the right eye (G) - 右目の白目の色(G)
	uint8_t eyeR_scleraColor_G_02D;

	// NAME: White eye color (B) - 白目の色(B)
	// DESC: White eye color of the right eye (B) - 右目の白目の色(B)
	uint8_t eyeR_scleraColor_B_02E;

	// NAME: Position of the iris - 虹彩の位置
	// DESC: Position of the iris of the right eye - 右目の虹彩の位置
	uint8_t eyeR_irisDistance_02F;

	// NAME: Iris color (R) - 虹彩の色(Ｒ)
	// DESC: Left eye iris color (R) - 左目の虹彩の色(Ｒ)
	uint8_t eyeL_irisColor_R_030;

	// NAME: Iris color (G) - 虹彩の色(Ｇ)
	// DESC: Left eye iris color (G) - 左目の虹彩の色(Ｇ)
	uint8_t eyeL_irisColor_G_031;

	// NAME: Iris color (B) - 虹彩の色(Ｂ)
	// DESC: Left eye iris color (B) - 左目の虹彩の色(Ｂ)
	uint8_t eyeL_irisColor_B_032;

	// NAME: The size of the iris - 虹彩の大きさ
	// DESC: The size of the iris of the left eye - 左目の虹彩の大きさ
	uint8_t eyeL_irisScale_033;

	// NAME: Cloudiness of the crystalline lens - 水晶体の濁り
	// DESC: Cloudiness of the crystalline lens of the left eye - 左目の水晶体の濁り
	uint8_t eyeL_cataract_034;

	// NAME: The turbid color of the crystalline lens (R) - 水晶体の濁りの色(Ｒ)
	// DESC: The turbid color of the crystalline lens of the left eye (R) - 左目の水晶体の濁りの色(Ｒ)
	uint8_t eyeL_cataractColor_R_035;

	// NAME: The turbid color of the crystalline lens (G) - 水晶体の濁りの色(Ｇ)
	// DESC: The turbid color of the crystalline lens of the left eye (G) - 左目の水晶体の濁りの色(Ｇ)
	uint8_t eyeL_cataractColor_G_036;

	// NAME: The turbid color of the crystalline lens (B) - 水晶体の濁りの色(Ｂ)
	// DESC: The turbid color of the crystalline lens of the left eye (B) - 左目の水晶体の濁りの色(Ｂ)
	uint8_t eyeL_cataractColor_B_037;

	// NAME: White eye color (R) - 白目の色(Ｒ)
	// DESC: White eye color of the left eye (R) - 左目の白目の色(Ｒ)
	uint8_t eyeL_scleraColor_R_038;

	// NAME: White eye color (G) - 白目の色(G)
	// DESC: White eye color of the left eye (G) - 左目の白目の色(G)
	uint8_t eyeL_scleraColor_G_039;

	// NAME: White eye color (B) - 白目の色(B)
	// DESC: White eye color of the left eye (B) - 左目の白目の色(B)
	uint8_t eyeL_scleraColor_B_03A;

	// NAME: Position of the iris - 虹彩の位置
	// DESC: Position of the iris of the left eye - 左目の虹彩の位置
	uint8_t eyeL_irisDistance_03B;

	// NAME: Hair part ID - 髪パーツID
	// DESC: Hair part ID - 髪パーツID
	uint8_t hair_partsId_03C;

	// NAME: Hair color (R) - 髪の色(Ｒ)
	// DESC: Hair color (R) - 髪の色(Ｒ)
	uint8_t hair_color_R_03D;

	// NAME: Hair color (G) - 髪の色(Ｇ)
	// DESC: Hair color (G) - 髪の色(Ｇ)
	uint8_t hair_color_G_03E;

	// NAME: Hair color (B) - 髪の色(Ｂ)
	// DESC: Hair color (B) - 髪の色(Ｂ)
	uint8_t hair_color_B_03F;

	// NAME: Gloss - 光沢
	// DESC: Hair gloss - 髪の光沢
	uint8_t hair_shininess_040;

	// NAME: Blackness at the base - 根元の黒さ
	// DESC: Blackness at the base of hair - 髪の根元の黒さ
	uint8_t hair_rootBlack_041;

	// NAME: Amount of gray hair - 白髪の量
	// DESC: Amount of white hair - 髪の白髪の量
	uint8_t hair_whiteDensity_042;

	// NAME: Beard part ID - 髭パーツID
	// DESC: Beard part ID - 髭パーツID
	uint8_t beard_partsId_043;

	// NAME: Beard color (R) - 髭の色(Ｒ)
	// DESC: Beard color (R) - 髭の色(Ｒ)
	uint8_t beard_color_R_044;

	// NAME: Beard color (G) - 髭の色(Ｇ)
	// DESC: Beard color (G) - 髭の色(Ｇ)
	uint8_t beard_color_G_045;

	// NAME: Beard color (B) - 髭の色(Ｂ)
	// DESC: Beard color (B) - 髭の色(Ｂ)
	uint8_t beard_color_B_046;

	// NAME: Gloss - 光沢
	// DESC: Beard luster - 髭の光沢
	uint8_t beard_shininess_047;

	// NAME: Blackness at the base - 根元の黒さ
	// DESC: Blackness at the base of the beard - 髭の根元の黒さ
	uint8_t beard_rootBlack_048;

	// NAME: Amount of gray hair - 白髪の量
	// DESC: Amount of white hair with a beard - 髭の白髪の量
	uint8_t beard_whiteDensity_049;

	// NAME: Eyebrow part ID - 眉パーツID
	// DESC: Eyebrow part ID - 眉パーツID
	uint8_t eyebrow_partsId_04A;

	// NAME: Eyebrow color (R) - 眉の色(Ｒ)
	// DESC: Eyebrow color (R) - 眉の色(Ｒ)
	uint8_t eyebrow_color_R_04B;

	// NAME: Eyebrow color (G) - 眉の色(Ｇ)
	// DESC: Eyebrow color (G) - 眉の色(Ｇ)
	uint8_t eyebrow_color_G_04C;

	// NAME: Eyebrow color (B) - 眉の色(Ｂ)
	// DESC: Eyebrow color (B) - 眉の色(Ｂ)
	uint8_t eyebrow_color_B_04D;

	// NAME: Gloss - 光沢
	// DESC: Glossy eyebrows - 眉の光沢
	uint8_t eyebrow_shininess_04E;

	// NAME: Blackness at the base - 根元の黒さ
	// DESC: Blackness at the base of the eyebrows - 眉の根元の黒さ
	uint8_t eyebrow_rootBlack_04F;

	// NAME: Amount of gray hair - 白髪の量
	// DESC: Amount of white hair on the eyebrows - 眉の白髪の量
	uint8_t eyebrow_whiteDensity_050;

	// NAME: Eyelash parts ID - まつげパーツID
	// DESC: Eyelash parts ID - まつげパーツID
	uint8_t eyelash_partsId_051;

	// NAME: Eyelash color (R) - まつげの色(Ｒ)
	// DESC: Eyelash color (R) - まつげの色(Ｒ)
	uint8_t eyelash_color_R_052;

	// NAME: Eyelash color (G) - まつげの色(Ｇ)
	// DESC: Eyelash color (G) - まつげの色(Ｇ)
	uint8_t eyelash_color_G_053;

	// NAME: Eyelash color (B) - まつげの色(Ｂ)
	// DESC: Eyelash color (B) - まつげの色(Ｂ)
	uint8_t eyelash_color_B_054;

	// NAME: Decorative part ID - 装飾パーツID
	// DESC: Decorative part ID - 装飾パーツID
	uint8_t accessories_partsId_055;

	// NAME: Decoration color (R) - 装飾の色(Ｒ)
	// DESC: Decoration color (R) - 装飾の色(Ｒ)
	uint8_t accessories_color_R_056;

	// NAME: Decoration color (G) - 装飾の色(Ｇ)
	// DESC: Decoration color (G) - 装飾の色(Ｇ)
	uint8_t accessories_color_G_057;

	// NAME: Decorative color (B) - 装飾の色(Ｂ)
	// DESC: Decorative color (B) - 装飾の色(Ｂ)
	uint8_t accessories_color_B_058;

	// NAME: Decal part ID - デカールパーツID
	// DESC: Decal part ID - デカールパーツID
	uint8_t decal_partsId_059;

	// NAME: Decal position (x) - デカール位置(x)
	// DESC: Decal position (x) - デカール位置(x)
	uint8_t decal_posX_05A;

	// NAME: Decal position (y) - デカール位置(y)
	// DESC: Decal position (y) - デカール位置(y)
	uint8_t decal_posY_05B;

	// NAME: Decal angle - デカール角度
	// DESC: Decal angle - デカール角度
	uint8_t decal_angle_05C;

	// NAME: Decal scale - デカールスケール
	// DESC: Decal scale - デカールスケール
	uint8_t decal_scale_05D;

	// NAME: Decal color (R) - デカールの色(Ｒ)
	// DESC: Decal color (R) - デカールの色(Ｒ)
	uint8_t decal_color_R_05E;

	// NAME: Decal color (G) - デカールの色(Ｇ)
	// DESC: Decal color (G) - デカールの色(Ｇ)
	uint8_t decal_color_G_05F;

	// NAME: Decal color (B) - デカールの色(Ｂ)
	// DESC: Decal color (B) - デカールの色(Ｂ)
	uint8_t decal_color_B_060;

	// NAME: Decal gloss - デカールのつや
	// DESC: Decal gloss - デカールのつや
	uint8_t decal_gloss_061;

	// NAME: Decal reversal - デカールの反転
	// DESC: Decal reversal - デカールの反転
	uint8_t decal_mirror_062;

	// NAME: Character body head scale - キャラ体型頭部スケール
	// DESC: Character body head scale - キャラ体型頭部スケール
	uint8_t chrBodyScaleHead_063;

	// NAME: Character body chest scale - キャラ体型胸部スケール
	// DESC: Character body chest scale - キャラ体型胸部スケール
	uint8_t chrBodyScaleBreast_064;

	// NAME: Character body type abdominal scale - キャラ体型腹部スケール
	// DESC: Character body type abdominal scale - キャラ体型腹部スケール
	uint8_t chrBodyScaleAbdomen_065;

	// NAME: Character body right arm scale - キャラ体型右腕部スケール
	// DESC: Character body right arm scale - キャラ体型右腕部スケール
	uint8_t chrBodyScaleRArm_066;

	// NAME: Character body right leg scale - キャラ体型右脚部スケール
	// DESC: Character body right leg scale - キャラ体型右脚部スケール
	uint8_t chrBodyScaleRLeg_067;

	// NAME: Character body shape left arm scale - キャラ体型左腕部スケール
	// DESC: Character body shape left arm scale - キャラ体型左腕部スケール
	uint8_t chrBodyScaleLArm_068;

	// NAME: Character body type left leg scale - キャラ体型左脚部スケール
	// DESC: Character body type left leg scale - キャラ体型左脚部スケール
	uint8_t chrBodyScaleLLeg_069;

	// NAME: Burn scars - 火傷跡
	// DESC: Burn scars - 火傷跡
	uint8_t burn_scar_06A;

	// NAME: Eyeball part ID - 眼球パーツID
	// DESC: Whether to overwrite the eyeball part ID - 眼球パーツIDを上書きするか
	uint8_t override_eye_partsId_06B: 1;

	// NAME: Iris color - 虹彩の色
	// DESC: Do you want to overwrite the color of the iris? - 虹彩の色を上書きするか
	uint8_t override_eye_irisColor_06B: 1;

	// NAME: Cloudiness of the crystalline lens - 水晶体の濁り
	// DESC: Do you want to overwrite the turbidity of the crystalline lens? - 水晶体の濁りを上書きするか
	uint8_t override_eye_cataract_06B: 1;

	// NAME: The turbid color of the crystalline lens - 水晶体の濁り色
	// DESC: Do you want to overwrite the muddy color of the crystalline lens? - 水晶体の濁り色を上書きするか
	uint8_t override_eye_cataractColor_06B: 1;

	// NAME: White eye color - 白目の色
	// DESC: Do you want to overwrite the white eye color? - 白目の色を上書きするか
	uint8_t override_eye_scleraColor_06B: 1;

	// NAME: Burn scars - 火傷跡
	// DESC: Do you want to overwrite the burn scars? - 火傷跡を上書きするか
	uint8_t override_burn_scar_06B: 1;

	// NAME: pad2 - pad2
	uint8_t pad2_06B: 2;

	// NAME: pad - pad
	uint8_t pad_06C[5];

	// NAME: age - 年齢
	// DESC: age - 年齢
	uint8_t age_071;

	// NAME: sex - 性別
	// DESC: sex - 性別
	uint8_t gender_072;

	// NAME: Exaggeration (model) - 誇張（モデル）
	// DESC: Exaggeration (model) - 誇張（モデル）
	uint8_t caricatureGeometry_073;

	// NAME: Exaggeration (texture) - 誇張（テクスチャ）
	// DESC: Exaggeration (texture) - 誇張（テクスチャ）
	uint8_t caricatureTexture_074;

	// NAME: Face creation geometry data 00 - 顔作成ジオメトリデータ00
	// DESC: Face creation geometry data 00 - 顔作成ジオメトリデータ00
	uint8_t faceGeoData00_075;

	// NAME: Face creation geometry data 01 - 顔作成ジオメトリデータ01
	// DESC: Face creation geometry data 01 - 顔作成ジオメトリデータ01
	uint8_t faceGeoData01_076;

	// NAME: Face creation geometry data 02 - 顔作成ジオメトリデータ02
	// DESC: Face creation geometry data 02 - 顔作成ジオメトリデータ02
	uint8_t faceGeoData02_077;

	// NAME: Face creation geometry data 03 - 顔作成ジオメトリデータ03
	// DESC: Face creation geometry data 03 - 顔作成ジオメトリデータ03
	uint8_t faceGeoData03_078;

	// NAME: Face creation geometry data 04 - 顔作成ジオメトリデータ04
	// DESC: Face creation geometry data 04 - 顔作成ジオメトリデータ04
	uint8_t faceGeoData04_079;

	// NAME: Face creation geometry data 05 - 顔作成ジオメトリデータ05
	// DESC: Face creation geometry data 05 - 顔作成ジオメトリデータ05
	uint8_t faceGeoData05_07A;

	// NAME: Face creation geometry data 06 - 顔作成ジオメトリデータ06
	// DESC: Face creation geometry data 06 - 顔作成ジオメトリデータ06
	uint8_t faceGeoData06_07B;

	// NAME: Face creation geometry data 07 - 顔作成ジオメトリデータ07
	// DESC: Face creation geometry data 07 - 顔作成ジオメトリデータ07
	uint8_t faceGeoData07_07C;

	// NAME: Face creation geometry data 08 - 顔作成ジオメトリデータ08
	// DESC: Face creation geometry data 08 - 顔作成ジオメトリデータ08
	uint8_t faceGeoData08_07D;

	// NAME: Face creation geometry data 09 - 顔作成ジオメトリデータ09
	// DESC: Face creation geometry data 09 - 顔作成ジオメトリデータ09
	uint8_t faceGeoData09_07E;

	// NAME: Face creation geometry data 10 - 顔作成ジオメトリデータ10
	// DESC: Face creation geometry data 10 - 顔作成ジオメトリデータ10
	uint8_t faceGeoData10_07F;

	// NAME: Face creation geometry data 11 - 顔作成ジオメトリデータ11
	// DESC: Face creation geometry data 11 - 顔作成ジオメトリデータ11
	uint8_t faceGeoData11_080;

	// NAME: Face creation geometry data 12 - 顔作成ジオメトリデータ12
	// DESC: Face creation geometry data 12 - 顔作成ジオメトリデータ12
	uint8_t faceGeoData12_081;

	// NAME: Face creation geometry data 13 - 顔作成ジオメトリデータ13
	// DESC: Face creation geometry data 13 - 顔作成ジオメトリデータ13
	uint8_t faceGeoData13_082;

	// NAME: Face creation geometry data 14 - 顔作成ジオメトリデータ14
	// DESC: Face creation geometry data 14 - 顔作成ジオメトリデータ14
	uint8_t faceGeoData14_083;

	// NAME: Face creation geometry data 15 - 顔作成ジオメトリデータ15
	// DESC: Face creation geometry data 15 - 顔作成ジオメトリデータ15
	uint8_t faceGeoData15_084;

	// NAME: Face creation geometry data 16 - 顔作成ジオメトリデータ16
	// DESC: Face creation geometry data 16 - 顔作成ジオメトリデータ16
	uint8_t faceGeoData16_085;

	// NAME: Face creation geometry data 17 - 顔作成ジオメトリデータ17
	// DESC: Face creation geometry data 17 - 顔作成ジオメトリデータ17
	uint8_t faceGeoData17_086;

	// NAME: Face creation geometry data 18 - 顔作成ジオメトリデータ18
	// DESC: Face creation geometry data 18 - 顔作成ジオメトリデータ18
	uint8_t faceGeoData18_087;

	// NAME: Face creation geometry data 19 - 顔作成ジオメトリデータ19
	// DESC: Face creation geometry data 19 - 顔作成ジオメトリデータ19
	uint8_t faceGeoData19_088;

	// NAME: Face creation geometry data 20 - 顔作成ジオメトリデータ20
	// DESC: Face creation geometry data 20 - 顔作成ジオメトリデータ20
	uint8_t faceGeoData20_089;

	// NAME: Face creation geometry data 21 - 顔作成ジオメトリデータ21
	// DESC: Face creation geometry data 21 - 顔作成ジオメトリデータ21
	uint8_t faceGeoData21_08A;

	// NAME: Face creation geometry data 22 - 顔作成ジオメトリデータ22
	// DESC: Face creation geometry data 22 - 顔作成ジオメトリデータ22
	uint8_t faceGeoData22_08B;

	// NAME: Face creation geometry data 23 - 顔作成ジオメトリデータ23
	// DESC: Face creation geometry data 23 - 顔作成ジオメトリデータ23
	uint8_t faceGeoData23_08C;

	// NAME: Face creation geometry data 24 - 顔作成ジオメトリデータ24
	// DESC: Face creation geometry data 24 - 顔作成ジオメトリデータ24
	uint8_t faceGeoData24_08D;

	// NAME: Face creation geometry data 25 - 顔作成ジオメトリデータ25
	// DESC: Face creation geometry data 25 - 顔作成ジオメトリデータ25
	uint8_t faceGeoData25_08E;

	// NAME: Face creation geometry data 26 - 顔作成ジオメトリデータ26
	// DESC: Face creation geometry data 26 - 顔作成ジオメトリデータ26
	uint8_t faceGeoData26_08F;

	// NAME: Face creation geometry data 27 - 顔作成ジオメトリデータ27
	// DESC: Face creation geometry data 27 - 顔作成ジオメトリデータ27
	uint8_t faceGeoData27_090;

	// NAME: Face creation geometry data 28 - 顔作成ジオメトリデータ28
	// DESC: Face creation geometry data 28 - 顔作成ジオメトリデータ28
	uint8_t faceGeoData28_091;

	// NAME: Face creation geometry data 29 - 顔作成ジオメトリデータ29
	// DESC: Face creation geometry data 29 - 顔作成ジオメトリデータ29
	uint8_t faceGeoData29_092;

	// NAME: Face creation geometry data 30 - 顔作成ジオメトリデータ30
	// DESC: Face creation geometry data 30 - 顔作成ジオメトリデータ30
	uint8_t faceGeoData30_093;

	// NAME: Face creation geometry data 31 - 顔作成ジオメトリデータ31
	// DESC: Face creation geometry data 31 - 顔作成ジオメトリデータ31
	uint8_t faceGeoData31_094;

	// NAME: Face creation geometry data 32 - 顔作成ジオメトリデータ32
	// DESC: Face creation geometry data 32 - 顔作成ジオメトリデータ32
	uint8_t faceGeoData32_095;

	// NAME: Face creation geometry data 33 - 顔作成ジオメトリデータ33
	// DESC: Face creation geometry data 33 - 顔作成ジオメトリデータ33
	uint8_t faceGeoData33_096;

	// NAME: Face creation geometry data 34 - 顔作成ジオメトリデータ34
	// DESC: Face creation geometry data 34 - 顔作成ジオメトリデータ34
	uint8_t faceGeoData34_097;

	// NAME: Face creation geometry data 35 - 顔作成ジオメトリデータ35
	// DESC: Face creation geometry data 35 - 顔作成ジオメトリデータ35
	uint8_t faceGeoData35_098;

	// NAME: Face creation geometry data 36 - 顔作成ジオメトリデータ36
	// DESC: Face creation geometry data 36 - 顔作成ジオメトリデータ36
	uint8_t faceGeoData36_099;

	// NAME: Face creation geometry data 37 - 顔作成ジオメトリデータ37
	// DESC: Face creation geometry data 37 - 顔作成ジオメトリデータ37
	uint8_t faceGeoData37_09A;

	// NAME: Face creation geometry data 38 - 顔作成ジオメトリデータ38
	// DESC: Face creation geometry data 38 - 顔作成ジオメトリデータ38
	uint8_t faceGeoData38_09B;

	// NAME: Face creation geometry data 39 - 顔作成ジオメトリデータ39
	// DESC: Face creation geometry data 39 - 顔作成ジオメトリデータ39
	uint8_t faceGeoData39_09C;

	// NAME: Face creation geometry data 40 - 顔作成ジオメトリデータ40
	// DESC: Face creation geometry data 40 - 顔作成ジオメトリデータ40
	uint8_t faceGeoData40_09D;

	// NAME: Face creation geometry data 41 - 顔作成ジオメトリデータ41
	// DESC: Face creation geometry data 41 - 顔作成ジオメトリデータ41
	uint8_t faceGeoData41_09E;

	// NAME: Face creation geometry data 42 - 顔作成ジオメトリデータ42
	// DESC: Face creation geometry data 42 - 顔作成ジオメトリデータ42
	uint8_t faceGeoData42_09F;

	// NAME: Face creation geometry data 43 - 顔作成ジオメトリデータ43
	// DESC: Face creation geometry data 43 - 顔作成ジオメトリデータ43
	uint8_t faceGeoData43_0A0;

	// NAME: Face creation geometry data 44 - 顔作成ジオメトリデータ44
	// DESC: Face creation geometry data 44 - 顔作成ジオメトリデータ44
	uint8_t faceGeoData44_0A1;

	// NAME: Face creation geometry data 45 - 顔作成ジオメトリデータ45
	// DESC: Face creation geometry data 45 - 顔作成ジオメトリデータ45
	uint8_t faceGeoData45_0A2;

	// NAME: Face creation geometry data 46 - 顔作成ジオメトリデータ46
	// DESC: Face creation geometry data 46 - 顔作成ジオメトリデータ46
	uint8_t faceGeoData46_0A3;

	// NAME: Face creation geometry data 47 - 顔作成ジオメトリデータ47
	// DESC: Face creation geometry data 47 - 顔作成ジオメトリデータ47
	uint8_t faceGeoData47_0A4;

	// NAME: Face creation geometry data 48 - 顔作成ジオメトリデータ48
	// DESC: Face creation geometry data 48 - 顔作成ジオメトリデータ48
	uint8_t faceGeoData48_0A5;

	// NAME: Face creation geometry data 49 - 顔作成ジオメトリデータ49
	// DESC: Face creation geometry data 49 - 顔作成ジオメトリデータ49
	uint8_t faceGeoData49_0A6;

	// NAME: Face creation geometry data 50 - 顔作成ジオメトリデータ50
	// DESC: Face creation geometry data 50 - 顔作成ジオメトリデータ50
	uint8_t faceGeoData50_0A7;

	// NAME: Face creation geometry data 51 - 顔作成ジオメトリデータ51
	// DESC: Face creation geometry data 51 - 顔作成ジオメトリデータ51
	uint8_t faceGeoData51_0A8;

	// NAME: Face creation geometry data 52 - 顔作成ジオメトリデータ52
	// DESC: Face creation geometry data 52 - 顔作成ジオメトリデータ52
	uint8_t faceGeoData52_0A9;

	// NAME: Face creation geometry data 53 - 顔作成ジオメトリデータ53
	// DESC: Face creation geometry data 53 - 顔作成ジオメトリデータ53
	uint8_t faceGeoData53_0AA;

	// NAME: Face creation geometry data 54 - 顔作成ジオメトリデータ54
	// DESC: Face creation geometry data 54 - 顔作成ジオメトリデータ54
	uint8_t faceGeoData54_0AB;

	// NAME: Face creation geometry data 55 - 顔作成ジオメトリデータ55
	// DESC: Face creation geometry data 55 - 顔作成ジオメトリデータ55
	uint8_t faceGeoData55_0AC;

	// NAME: Face creation geometry data 56 - 顔作成ジオメトリデータ56
	// DESC: Face creation geometry data 56 - 顔作成ジオメトリデータ56
	uint8_t faceGeoData56_0AD;

	// NAME: Face creation geometry data 57 - 顔作成ジオメトリデータ57
	// DESC: Face creation geometry data 57 - 顔作成ジオメトリデータ57
	uint8_t faceGeoData57_0AE;

	// NAME: Face creation geometry data 58 - 顔作成ジオメトリデータ58
	// DESC: Face creation geometry data 58 - 顔作成ジオメトリデータ58
	uint8_t faceGeoData58_0AF;

	// NAME: Face creation geometry data 59 - 顔作成ジオメトリデータ59
	// DESC: Face creation geometry data 59 - 顔作成ジオメトリデータ59
	uint8_t faceGeoData59_0B0;

	// NAME: Face creation geometry data 60 - 顔作成ジオメトリデータ60
	// DESC: Face creation geometry data 60 - 顔作成ジオメトリデータ60
	uint8_t faceGeoData60_0B1;

	// NAME: Face creation texture data 00 - 顔作成テクスチャデータ00
	// DESC: Face creation texture data 00 - 顔作成テクスチャデータ00
	uint8_t faceTexData00_0B2;

	// NAME: Face creation texture data 01 - 顔作成テクスチャデータ01
	// DESC: Face creation texture data 01 - 顔作成テクスチャデータ01
	uint8_t faceTexData01_0B3;

	// NAME: Face creation texture data 02 - 顔作成テクスチャデータ02
	// DESC: Face creation texture data 02 - 顔作成テクスチャデータ02
	uint8_t faceTexData02_0B4;

	// NAME: Face creation texture data 03 - 顔作成テクスチャデータ03
	// DESC: Face creation texture data 03 - 顔作成テクスチャデータ03
	uint8_t faceTexData03_0B5;

	// NAME: Face creation texture data 04 - 顔作成テクスチャデータ04
	// DESC: Face creation texture data 04 - 顔作成テクスチャデータ04
	uint8_t faceTexData04_0B6;

	// NAME: Face creation texture data 05 - 顔作成テクスチャデータ05
	// DESC: Face creation texture data 05 - 顔作成テクスチャデータ05
	uint8_t faceTexData05_0B7;

	// NAME: Face creation texture data 06 - 顔作成テクスチャデータ06
	// DESC: Face creation texture data 06 - 顔作成テクスチャデータ06
	uint8_t faceTexData06_0B8;

	// NAME: Face creation texture data 07 - 顔作成テクスチャデータ07
	// DESC: Face creation texture data 07 - 顔作成テクスチャデータ07
	uint8_t faceTexData07_0B9;

	// NAME: Face creation texture data 08 - 顔作成テクスチャデータ08
	// DESC: Face creation texture data 08 - 顔作成テクスチャデータ08
	uint8_t faceTexData08_0BA;

	// NAME: Face creation texture data 09 - 顔作成テクスチャデータ09
	// DESC: Face creation texture data 09 - 顔作成テクスチャデータ09
	uint8_t faceTexData09_0BB;

	// NAME: Face creation texture data 10 - 顔作成テクスチャデータ10
	// DESC: Face creation texture data 10 - 顔作成テクスチャデータ10
	uint8_t faceTexData10_0BC;

	// NAME: Face creation texture data 11 - 顔作成テクスチャデータ11
	// DESC: Face creation texture data 11 - 顔作成テクスチャデータ11
	uint8_t faceTexData11_0BD;

	// NAME: Face creation texture data 12 - 顔作成テクスチャデータ12
	// DESC: Face creation texture data 12 - 顔作成テクスチャデータ12
	uint8_t faceTexData12_0BE;

	// NAME: Face creation texture data 13 - 顔作成テクスチャデータ13
	// DESC: Face creation texture data 13 - 顔作成テクスチャデータ13
	uint8_t faceTexData13_0BF;

	// NAME: Face creation texture data 14 - 顔作成テクスチャデータ14
	// DESC: Face creation texture data 14 - 顔作成テクスチャデータ14
	uint8_t faceTexData14_0C0;

	// NAME: Face creation texture data 15 - 顔作成テクスチャデータ15
	// DESC: Face creation texture data 15 - 顔作成テクスチャデータ15
	uint8_t faceTexData15_0C1;

	// NAME: Face creation texture data 16 - 顔作成テクスチャデータ16
	// DESC: Face creation texture data 16 - 顔作成テクスチャデータ16
	uint8_t faceTexData16_0C2;

	// NAME: Face creation texture data 17 - 顔作成テクスチャデータ17
	// DESC: Face creation texture data 17 - 顔作成テクスチャデータ17
	uint8_t faceTexData17_0C3;

	// NAME: Face creation texture data 18 - 顔作成テクスチャデータ18
	// DESC: Face creation texture data 18 - 顔作成テクスチャデータ18
	uint8_t faceTexData18_0C4;

	// NAME: Face creation texture data 19 - 顔作成テクスチャデータ19
	// DESC: Face creation texture data 19 - 顔作成テクスチャデータ19
	uint8_t faceTexData19_0C5;

	// NAME: Face creation texture data 20 - 顔作成テクスチャデータ20
	// DESC: Face creation texture data 20 - 顔作成テクスチャデータ20
	uint8_t faceTexData20_0C6;

	// NAME: Face creation texture data 21 - 顔作成テクスチャデータ21
	// DESC: Face creation texture data 21 - 顔作成テクスチャデータ21
	uint8_t faceTexData21_0C7;

	// NAME: Face creation texture data 22 - 顔作成テクスチャデータ22
	// DESC: Face creation texture data 22 - 顔作成テクスチャデータ22
	uint8_t faceTexData22_0C8;

	// NAME: Face creation texture data 23 - 顔作成テクスチャデータ23
	// DESC: Face creation texture data 23 - 顔作成テクスチャデータ23
	uint8_t faceTexData23_0C9;

	// NAME: Face creation texture data 24 - 顔作成テクスチャデータ24
	// DESC: Face creation texture data 24 - 顔作成テクスチャデータ24
	uint8_t faceTexData24_0CA;

	// NAME: Face creation texture data 25 - 顔作成テクスチャデータ25
	// DESC: Face creation texture data 25 - 顔作成テクスチャデータ25
	uint8_t faceTexData25_0CB;

	// NAME: Face creation texture data 26 - 顔作成テクスチャデータ26
	// DESC: Face creation texture data 26 - 顔作成テクスチャデータ26
	uint8_t faceTexData26_0CC;

	// NAME: Face creation texture data 27 - 顔作成テクスチャデータ27
	// DESC: Face creation texture data 27 - 顔作成テクスチャデータ27
	uint8_t faceTexData27_0CD;

	// NAME: Face creation texture data 28 - 顔作成テクスチャデータ28
	// DESC: Face creation texture data 28 - 顔作成テクスチャデータ28
	uint8_t faceTexData28_0CE;

	// NAME: Face creation texture data 29 - 顔作成テクスチャデータ29
	// DESC: Face creation texture data 29 - 顔作成テクスチャデータ29
	uint8_t faceTexData29_0CF;

	// NAME: Face creation texture data 30 - 顔作成テクスチャデータ30
	// DESC: Face creation texture data 30 - 顔作成テクスチャデータ30
	uint8_t faceTexData30_0D0;

	// NAME: Face creation texture data 31 - 顔作成テクスチャデータ31
	// DESC: Face creation texture data 31 - 顔作成テクスチャデータ31
	uint8_t faceTexData31_0D1;

	// NAME: Face creation texture data 32 - 顔作成テクスチャデータ32
	// DESC: Face creation texture data 32 - 顔作成テクスチャデータ32
	uint8_t faceTexData32_0D2;

	// NAME: Face creation texture data 33 - 顔作成テクスチャデータ33
	// DESC: Face creation texture data 33 - 顔作成テクスチャデータ33
	uint8_t faceTexData33_0D3;

	// NAME: Face creation texture data 34 - 顔作成テクスチャデータ34
	// DESC: Face creation texture data 34 - 顔作成テクスチャデータ34
	uint8_t faceTexData34_0D4;

	// NAME: Face creation texture data 35 - 顔作成テクスチャデータ35
	// DESC: Face creation texture data 35 - 顔作成テクスチャデータ35
	uint8_t faceTexData35_0D5;

	// NAME: Face creation geometry asymmetric data 00 - 顔作成ジオメトリ非対称データ00
	// DESC: Face creation geometry asymmetric data 00 - 顔作成ジオメトリ非対称データ00
	uint8_t faceGeoAsymData00_0D6;

	// NAME: Face creation geometry asymmetric data 01 - 顔作成ジオメトリ非対称データ01
	// DESC: Face creation geometry asymmetric data 01 - 顔作成ジオメトリ非対称データ01
	uint8_t faceGeoAsymData01_0D7;

	// NAME: Face creation geometry asymmetric data 02 - 顔作成ジオメトリ非対称データ02
	// DESC: Face creation geometry asymmetric data 02 - 顔作成ジオメトリ非対称データ02
	uint8_t faceGeoAsymData02_0D8;

	// NAME: Face creation geometry asymmetric data 03 - 顔作成ジオメトリ非対称データ03
	// DESC: Face creation geometry asymmetric data 03 - 顔作成ジオメトリ非対称データ03
	uint8_t faceGeoAsymData03_0D9;

	// NAME: Face creation geometry asymmetric data 04 - 顔作成ジオメトリ非対称データ04
	// DESC: Face creation geometry asymmetric data 04 - 顔作成ジオメトリ非対称データ04
	uint8_t faceGeoAsymData04_0DA;

	// NAME: Face creation geometry asymmetric data 05 - 顔作成ジオメトリ非対称データ05
	// DESC: Face creation geometry asymmetric data 05 - 顔作成ジオメトリ非対称データ05
	uint8_t faceGeoAsymData05_0DB;

	// NAME: Face creation geometry asymmetric data 06 - 顔作成ジオメトリ非対称データ06
	// DESC: Face creation geometry asymmetric data 06 - 顔作成ジオメトリ非対称データ06
	uint8_t faceGeoAsymData06_0DC;

	// NAME: Face creation geometry asymmetric data 07 - 顔作成ジオメトリ非対称データ07
	// DESC: Face creation geometry asymmetric data 07 - 顔作成ジオメトリ非対称データ07
	uint8_t faceGeoAsymData07_0DD;

	// NAME: Face creation geometry asymmetric data 08 - 顔作成ジオメトリ非対称データ08
	// DESC: Face creation geometry asymmetric data 08 - 顔作成ジオメトリ非対称データ08
	uint8_t faceGeoAsymData08_0DE;

	// NAME: Face creation geometry asymmetric data 09 - 顔作成ジオメトリ非対称データ09
	// DESC: Face creation geometry asymmetric data 09 - 顔作成ジオメトリ非対称データ09
	uint8_t faceGeoAsymData09_0DF;

	// NAME: Face creation geometry asymmetric data 10 - 顔作成ジオメトリ非対称データ10
	// DESC: Face creation geometry asymmetric data 10 - 顔作成ジオメトリ非対称データ10
	uint8_t faceGeoAsymData10_0E0;

	// NAME: Face creation geometry asymmetric data 11 - 顔作成ジオメトリ非対称データ11
	// DESC: Face creation geometry asymmetric data 11 - 顔作成ジオメトリ非対称データ11
	uint8_t faceGeoAsymData11_0E1;

	// NAME: Face creation geometry asymmetric data 12 - 顔作成ジオメトリ非対称データ12
	// DESC: Face creation geometry asymmetric data 12 - 顔作成ジオメトリ非対称データ12
	uint8_t faceGeoAsymData12_0E2;

	// NAME: Face creation geometry asymmetric data 13 - 顔作成ジオメトリ非対称データ13
	// DESC: Face creation geometry asymmetric data 13 - 顔作成ジオメトリ非対称データ13
	uint8_t faceGeoAsymData13_0E3;

	// NAME: Face creation geometry asymmetric data 14 - 顔作成ジオメトリ非対称データ14
	// DESC: Face creation geometry asymmetric data 14 - 顔作成ジオメトリ非対称データ14
	uint8_t faceGeoAsymData14_0E4;

	// NAME: Face creation geometry asymmetric data 15 - 顔作成ジオメトリ非対称データ15
	// DESC: Face creation geometry asymmetric data 15 - 顔作成ジオメトリ非対称データ15
	uint8_t faceGeoAsymData15_0E5;

	// NAME: Face creation geometry asymmetric data 16 - 顔作成ジオメトリ非対称データ16
	// DESC: Face creation geometry asymmetric data 16 - 顔作成ジオメトリ非対称データ16
	uint8_t faceGeoAsymData16_0E6;

	// NAME: Face creation geometry asymmetric data 17 - 顔作成ジオメトリ非対称データ17
	// DESC: Face creation geometry asymmetric data 17 - 顔作成ジオメトリ非対称データ17
	uint8_t faceGeoAsymData17_0E7;

	// NAME: Face creation geometry asymmetric data 18 - 顔作成ジオメトリ非対称データ18
	// DESC: Face creation geometry asymmetric data 18 - 顔作成ジオメトリ非対称データ18
	uint8_t faceGeoAsymData18_0E8;

	// NAME: Face creation geometry asymmetric data 19 - 顔作成ジオメトリ非対称データ19
	// DESC: Face creation geometry asymmetric data 19 - 顔作成ジオメトリ非対称データ19
	uint8_t faceGeoAsymData19_0E9;

	// NAME: Face creation geometry asymmetric data 20 - 顔作成ジオメトリ非対称データ20
	// DESC: Face creation geometry asymmetric data 20 - 顔作成ジオメトリ非対称データ20
	uint8_t faceGeoAsymData20_0EA;

	// NAME: Face creation geometry asymmetric data 21 - 顔作成ジオメトリ非対称データ21
	// DESC: Face creation geometry asymmetric data 21 - 顔作成ジオメトリ非対称データ21
	uint8_t faceGeoAsymData21_0EB;

	// NAME: Face creation geometry asymmetric data 22 - 顔作成ジオメトリ非対称データ22
	// DESC: Face creation geometry asymmetric data 22 - 顔作成ジオメトリ非対称データ22
	uint8_t faceGeoAsymData22_0EC;

	// NAME: Face creation geometry asymmetric data 23 - 顔作成ジオメトリ非対称データ23
	// DESC: Face creation geometry asymmetric data 23 - 顔作成ジオメトリ非対称データ23
	uint8_t faceGeoAsymData23_0ED;

	// NAME: Face creation geometry asymmetric data 24 - 顔作成ジオメトリ非対称データ24
	// DESC: Face creation geometry asymmetric data 24 - 顔作成ジオメトリ非対称データ24
	uint8_t faceGeoAsymData24_0EE;

	// NAME: Face creation geometry asymmetric data 25 - 顔作成ジオメトリ非対称データ25
	// DESC: Face creation geometry asymmetric data 25 - 顔作成ジオメトリ非対称データ25
	uint8_t faceGeoAsymData25_0EF;

} FaceParam;

#endif
