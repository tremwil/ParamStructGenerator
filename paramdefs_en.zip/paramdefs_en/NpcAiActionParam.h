/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_NpcAiActionParam_H
#define _PARAM_NpcAiActionParam_H
#include <stdint.h>

// NPC_AI_ACTION_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _NpcAiActionParam {

	// NAME: Move direction input - 移動方向入力
	// DESC: Moving direction to enter - 入力する移動方向
	uint8_t moveDir_000;

	// NAME: Key input 1 - キー入力1
	// DESC: Key to enter - 入力するキー
	uint8_t key1_001;

	// NAME: Key input 2 - キー入力2
	// DESC: Key to enter - 入力するキー
	uint8_t key2_002;

	// NAME: Key input 3 - キー入力3
	// DESC: Key to enter - 入力するキー
	uint8_t key3_003;

	// NAME: Press and hold the movement direction input? - 移動方向入力は長押し？
	// DESC: Whether to handle the input movement direction as long press - 入力する移動方向を長押し扱いするか
	uint8_t bMoveDirHold_004;

	// NAME: Press and hold key input 1? - キー入力1は長押し？
	// DESC: Whether to treat the key to be entered as a long press - 入力するキーを長押扱いするか
	uint8_t bKeyHold1_005;

	// NAME: Press and hold key input 2? - キー入力2は長押し？
	// DESC: Whether to treat the key to be entered as a long press - 入力するキーを長押扱いするか
	uint8_t bKeyHold2_006;

	// NAME: Press and hold key input 3? - キー入力3は長押し？
	// DESC: Whether to treat the key to be entered as a long press - 入力するキーを長押扱いするか
	uint8_t bKeyHold3_007;

	// NAME: Gesture ID (valid only when any key input is GESTURE) - ジェスチャーID（どれかのキー入力がGESTUREの時のみ有効）
	// DESC: Gesture ID - ジェスチャーID
	int32_t gestureId_008;

	// NAME: Treat as successful when life is over - 寿命が尽きた時成功扱いにする
	// DESC: If this is ON, the AI goal will not be successful until the end of its life - これがONならAIのゴールが寿命まで成功にならない
	uint8_t bLifeEndSuccess_00C;

	// NAME: pad - パッド
	// DESC: pad - pad
	uint8_t pad1_00D[3];

} NpcAiActionParam;

#endif
