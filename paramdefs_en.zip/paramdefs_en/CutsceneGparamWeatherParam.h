/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CutsceneGparamWeatherParam_H
#define _PARAM_CutsceneGparamWeatherParam_H
#include <stdint.h>

// CUTSCENE_GPARAM_WEATHER_PARAM_ST
// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CutsceneGparamWeatherParam {

	// NAME: Do you remove it from the NT version output? - NT版出力から外すか
	// DESC: Parameters marked with ○ are excluded in the NT version package. - ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// NAME: Is it a debug parameter? - デバッグパラメータか
	// DESC: Parameters marked with a circle are excluded from all packages (because they are for debugging). - ○をつけたパラメータは全パッケージから除外します（デバッグ用なので）
	uint8_t disableParam_Debug_000: 1;

	// NAME: Reserve for package output 1 - パッケージ出力用リザーブ1
	// DESC: Reserve for package output 1 - パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 6;

	// NAME: Reserve for package output 2 - パッケージ出力用リザーブ2
	// DESC: Reserve for package output 2 - パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// NAME: Sunny - 晴れ
	// DESC: Sunny - 晴れ
	int16_t DstWeather_Sunny_004;

	// NAME: Sunny - 快晴
	// DESC: Sunny - 快晴
	int16_t DstWeather_ClearSky_006;

	// NAME: Light cloudy - 薄曇り
	// DESC: Light cloudy - 薄曇り
	int16_t DstWeather_WeakCloudy_008;

	// NAME: cloudy - 曇り
	// DESC: cloudy - 曇り
	int16_t DstWeather_Cloud_00A;

	// NAME: rain - 雨
	// DESC: rain - 雨
	int16_t DstWeather_Rain_00C;

	// NAME: Heavy rain - 豪雨
	// DESC: Heavy rain - 豪雨
	int16_t DstWeather_HeavyRain_00E;

	// NAME: storm - 嵐
	// DESC: storm - 嵐
	int16_t DstWeather_Storm_010;

	// NAME: Storm (for combat with the descendants of the guardian) - 嵐（守護者の末裔との戦闘用）
	// DESC: Storm (for combat with the descendants of the guardian) - 嵐（守護者の末裔との戦闘用）
	int16_t DstWeather_StormForBattle_012;

	// NAME: snow - 雪
	// DESC: snow - 雪
	int16_t DstWeather_Snow_014;

	// NAME: heavy snow - 大雪
	// DESC: heavy snow - 大雪
	int16_t DstWeather_HeavySnow_016;

	// NAME: fog - 霧
	// DESC: fog - 霧
	int16_t DstWeather_Fog_018;

	// NAME: Thick fog - 濃霧
	// DESC: Thick fog - 濃霧
	int16_t DstWeather_HeavyFog_01A;

	// NAME: Sandstorm - 砂嵐
	// DESC: Sandstorm - 砂嵐
	int16_t DstWeather_SandStorm_01C;

	// NAME: Thick fog (rain) - 濃霧（雨）
	// DESC: Thick fog (rain) - 濃霧（雨）
	int16_t DstWeather_HeavyFogRain_01E;

	// NAME: In-game weather specifications at the end of playback (unused, invalid) - 再生終了時のインゲーム天候指定(未使用、無効)
	// DESC: In-game weather specifications at the end of playback (nothing is done if blank or "invalid") - 再生終了時のインゲーム天候指定(空白または「無効」の場合は何も行われない。)
	int16_t PostPlayIngameWeather_020;

	// NAME: Indoor / outdoor designation - 屋内屋外指定
	// DESC: When indoors, the SFX specified by "Weather SfxId (Outdoor)" and "Wind SfxId (Outdoor)" in "Weather Parameter.xlsm" will be invalid in the cutscene. - 屋内にすると「天候パラメータ.xlsm」の「天候SfxId(屋外)」と「風SfxId(屋外)」で指定されたSFXがカットシーン内で無効になります。
	uint8_t IndoorOutdoorType_022;

	// NAME: In-game weather SFX to take over? _Sunny - インゲームの天候SFX引き継ぐか？_晴れ
	// DESC: In-game weather SFX to take over? _Sunny - インゲームの天候SFX引き継ぐか？_晴れ
	uint8_t TakeOverDstWeather_Sunny_023;

	// NAME: In-game weather SFX to take over? _ Sunny - インゲームの天候SFX引き継ぐか？_快晴
	// DESC: In-game weather SFX to take over? _ Sunny - インゲームの天候SFX引き継ぐか？_快晴
	uint8_t TakeOverDstWeather_ClearSky_024;

	// NAME: Will the in-game weather SFX be taken over? _ Light cloudy - インゲームの天候SFX引き継ぐか？_薄曇り
	// DESC: Will the in-game weather SFX be taken over? _ Light cloudy - インゲームの天候SFX引き継ぐか？_薄曇り
	uint8_t TakeOverDstWeather_WeakCloudy_025;

	// NAME: In-game weather SFX to take over? _cloudy - インゲームの天候SFX引き継ぐか？_曇り
	// DESC: Will the in-game weather SFX be taken over? _cloudy - インゲームの天候SFX引き継ぐか？_曇り
	uint8_t TakeOverDstWeather_Cloud_026;

	// NAME: In-game weather SFX to take over? _rain - インゲームの天候SFX引き継ぐか？_雨
	// DESC: In-game weather SFX to take over? _rain - インゲームの天候SFX引き継ぐか？_雨
	uint8_t TakeOverDstWeather_Rain_027;

	// NAME: Will the in-game weather SFX be taken over? _ Heavy rain - インゲームの天候SFX引き継ぐか？_豪雨
	// DESC: In-game weather SFX to take over? _ Heavy rain - インゲームの天候SFX引き継ぐか？_豪雨
	uint8_t TakeOverDstWeather_HeavyRain_028;

	// NAME: Will the in-game weather SFX be taken over? _storm - インゲームの天候SFX引き継ぐか？_嵐
	// DESC: In-game weather SFX to take over? _storm - インゲームの天候SFX引き継ぐか？_嵐
	uint8_t TakeOverDstWeather_Storm_029;

	// NAME: In-game weather SFX to take over? _ Storm (for battle with the descendants of the guardian) - インゲームの天候SFX引き継ぐか？_嵐（守護者の末裔との戦闘用）
	// DESC: In-game weather SFX to take over? _ Storm (for battle with the descendants of the guardian) - インゲームの天候SFX引き継ぐか？_嵐（守護者の末裔との戦闘用）
	uint8_t TakeOverDstWeather_StormForBattle_02A;

	// NAME: In-game weather SFX to take over? _snow - インゲームの天候SFX引き継ぐか？_雪
	// DESC: In-game weather SFX to take over? _snow - インゲームの天候SFX引き継ぐか？_雪
	uint8_t TakeOverDstWeather_Snow_02B;

	// NAME: In-game weather SFX to take over? _heavy snow - インゲームの天候SFX引き継ぐか？_大雪
	// DESC: In-game weather SFX to take over? _heavy snow - インゲームの天候SFX引き継ぐか？_大雪
	uint8_t TakeOverDstWeather_HeavySnow_02C;

	// NAME: In-game weather SFX to take over? _fog - インゲームの天候SFX引き継ぐか？_霧
	// DESC: Will the in-game weather SFX be taken over? _fog - インゲームの天候SFX引き継ぐか？_霧
	uint8_t TakeOverDstWeather_Fog_02D;

	// NAME: In-game weather SFX to take over? _ Thick fog - インゲームの天候SFX引き継ぐか？_濃霧
	// DESC: Will the in-game weather SFX be taken over? _ Thick fog - インゲームの天候SFX引き継ぐか？_濃霧
	uint8_t TakeOverDstWeather_HeavyFog_02E;

	// NAME: Will the in-game weather SFX be taken over? _ Sandstorm - インゲームの天候SFX引き継ぐか？_砂嵐
	// DESC: In-game weather SFX to take over? _ Sandstorm - インゲームの天候SFX引き継ぐか？_砂嵐
	uint8_t TakeOverDstWeather_SandStorm_02F;

	// NAME: In-game weather SFX to take over? _ Thick fog (rain) - インゲームの天候SFX引き継ぐか？_濃霧（雨）
	// DESC: In-game weather SFX to take over? _ Thick fog (rain) - インゲームの天候SFX引き継ぐか？_濃霧（雨）
	uint8_t TakeOverDstWeather_HeavyFogRain_030;

	// NAME: reserved - reserved
	// DESC: reserved - reserved
	uint8_t reserved_031[7];

	// NAME: Snowstorm - 吹雪
	// DESC: Snowstorm - 吹雪
	int16_t DstWeather_Snowstorm_038;

	// NAME: Storm (thunder) - 嵐（雷）
	// DESC: Preliminary weather 2 - 予備天候2
	int16_t DstWeather_LightningStorm_03A;

	// NAME: Snow special (spare 3) - 雪特殊(予備3)
	// DESC: Preliminary weather 3 - 予備天候3
	int16_t DstWeather_Reserved3_03C;

	// NAME: Preliminary weather 4 - 予備天候4
	// DESC: Preliminary weather 4 - 予備天候4
	int16_t DstWeather_Reserved4_03E;

	// NAME: Preliminary weather 5 - 予備天候5
	// DESC: Preliminary weather 5 - 予備天候5
	int16_t DstWeather_Reserved5_040;

	// NAME: Preliminary weather 6 - 予備天候6
	// DESC: Preliminary weather 6 - 予備天候6
	int16_t DstWeather_Reserved6_042;

	// NAME: Preliminary weather 7 - 予備天候7
	// DESC: Preliminary weather 7 - 予備天候7
	int16_t DstWeather_Reserved7_044;

	// NAME: Preliminary weather 8 - 予備天候8
	// DESC: Preliminary weather 8 - 予備天候8
	int16_t DstWeather_Reserved8_046;

	// NAME: In-game weather SFX to take over? _ Snowstorm - インゲームの天候SFX引き継ぐか？_吹雪
	// DESC: In-game weather SFX to take over? _ Snowstorm - インゲームの天候SFX引き継ぐか？_吹雪
	uint8_t TakeOverDstWeather_Snowstorm_048;

	// NAME: Will the in-game weather SFX be taken over? _ Storm (thunder) - インゲームの天候SFX引き継ぐか？_嵐（雷）
	// DESC: In-game weather SFX to take over? _ Storm (thunder) - インゲームの天候SFX引き継ぐか？_嵐（雷）
	uint8_t TakeOverDstWeather_LightningStorm_049;

	// NAME: In-game weather SFX to take over? _ Snow Special (Spare 3) - インゲームの天候SFX引き継ぐか？_雪特殊(予備3)
	// DESC: Will the in-game weather SFX be taken over? _ Preliminary weather 3 - インゲームの天候SFX引き継ぐか？_予備天候3
	uint8_t TakeOverDstWeather_Reserved3_04A;

	// NAME: Will the in-game weather SFX be taken over? _ Preliminary weather 4 - インゲームの天候SFX引き継ぐか？_予備天候4
	// DESC: In-game weather SFX to take over? _ Preliminary weather 4 - インゲームの天候SFX引き継ぐか？_予備天候4
	uint8_t TakeOverDstWeather_Reserved4_04B;

	// NAME: In-game weather SFX to take over? _ Preliminary weather 5 - インゲームの天候SFX引き継ぐか？_予備天候5
	// DESC: Will the in-game weather SFX be taken over? _ Preliminary weather 5 - インゲームの天候SFX引き継ぐか？_予備天候5
	uint8_t TakeOverDstWeather_Reserved5_04C;

	// NAME: In-game weather SFX to take over? _ Preliminary weather 6 - インゲームの天候SFX引き継ぐか？_予備天候6
	// DESC: Will the in-game weather SFX be taken over? _ Preliminary weather 6 - インゲームの天候SFX引き継ぐか？_予備天候6
	uint8_t TakeOverDstWeather_Reserved6_04D;

	// NAME: In-game weather SFX to take over? _ Preliminary weather 7 - インゲームの天候SFX引き継ぐか？_予備天候7
	// DESC: Will the in-game weather SFX be taken over? _ Preliminary weather 7 - インゲームの天候SFX引き継ぐか？_予備天候7
	uint8_t TakeOverDstWeather_Reserved7_04E;

	// NAME: Will the in-game weather SFX be taken over? _ Preliminary weather 8 - インゲームの天候SFX引き継ぐか？_予備天候8
	// DESC: In-game weather SFX to take over? _ Preliminary weather 8 - インゲームの天候SFX引き継ぐか？_予備天候8
	uint8_t TakeOverDstWeather_Reserved8_04F;

	// NAME: Do you want to apply the MapGD local ID to the weather Gparam? - 天候GparamにMapGD地方IDを適用するか？
	// DESC: Do you want to apply the mapGD local ID changes to the cutscene weather Gparam as in the in-game? ([GR] SEQ30194) - カットシーン天候Gparamにインゲーム同様MapGD地方IDによる変化を適用するか？(【GR】SEQ30194)
	uint8_t IsEnableApplyMapGdRegionIdForGparam_050;

	// NAME: reserved1 - reserved1
	// DESC: reserved1 ver4-> 5 64-> 96 - reserved1 ver4->5 64->96へ増量
	uint8_t reserved2_051[1];

	// NAME: Local ID overwrite for weather Gparam MapGD - 天候GparamMapGD用地方ID上書き
	// DESC: Overwrite the ID used for cutscene weather Gparam (-1: No overwrite. MapGD local ID during cutscene playback is used). If "Do you want to apply MapGD local ID to weather Gparam?" Is x, it is not referenced. - カットシーン天候Gparamに使用されるIDを上書きする(-1：上書きなし。カットシーン再生時のMapGD地方IDが使用される)。「天候GparamにMapGD地方IDを適用するか？」が×の場合は参照されない
	int16_t OverrideMapGdRegionId_052;

	// NAME: reserved1 - reserved1
	// DESC: reserved1 ver4-> 5 64-> 96 - reserved1 ver4->5 64->96へ増量
	uint8_t reserved1_054[12];

} CutsceneGparamWeatherParam;

#endif
