/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PostureControlParam_WepRight_H
#define _PARAM_PostureControlParam_WepRight_H
#include <stdint.h>

// POSTURE_CONTROL_PARAM_WEP_RIGHT_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _PostureControlParam_WepRight {

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a000_rightArmFB_000;

	// NAME: Right wrist_front and back - 右手首_前後
	// DESC: Right wrist_front and back - 右手首_前後
	int16_t a000_rightWristFB_002;

	// NAME: Right wrist_inside and outside - 右手首_内外
	// DESC: Right wrist_inside and outside - 右手首_内外
	int16_t a000_rightWristIO_004;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a000_leftArmFB_006;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a000_leftWristFB_008;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a000_leftWristIO_00A;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a002_rightArmFB_00C;

	// NAME: Right wrist_front and back - 右手首_前後
	// DESC: Right wrist_front and back - 右手首_前後
	int16_t a002_rightWristFB_00E;

	// NAME: Right wrist_inside and outside - 右手首_内外
	// DESC: Right wrist_inside and outside - 右手首_内外
	int16_t a002_rightWristIO_010;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a002_leftArmFB_012;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a002_leftWristFB_014;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a002_leftWristIO_016;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a003_rightArmFB_018;

	// NAME: Right wrist_front and back - 右手首_前後
	// DESC: Right wrist_front and back - 右手首_前後
	int16_t a003_rightWristFB_01A;

	// NAME: Right wrist_inside and outside - 右手首_内外
	// DESC: Right wrist_inside and outside - 右手首_内外
	int16_t a003_rightWristIO_01C;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a003_leftArmFB_01E;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a003_leftWristFB_020;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a003_leftWristIO_022;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a010_rightArmFB_024;

	// NAME: Right wrist_front and back - 右手首_前後
	// DESC: Right wrist_front and back - 右手首_前後
	int16_t a010_rightWristFB_026;

	// NAME: Right wrist_inside and outside - 右手首_内外
	// DESC: Right wrist_inside and outside - 右手首_内外
	int16_t a010_rightWristIO_028;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a010_leftArmFB_02A;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a010_leftWristFB_02C;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a010_leftWristIO_02E;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a012_rightArmFB_030;

	// NAME: Right wrist_front and back - 右手首_前後
	// DESC: Right wrist_front and back - 右手首_前後
	int16_t a012_rightWristFB_032;

	// NAME: Right wrist_inside and outside - 右手首_内外
	// DESC: Right wrist_inside and outside - 右手首_内外
	int16_t a012_rightWristIO_034;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a012_leftArmFB_036;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a012_leftWristFB_038;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a012_leftWristIO_03A;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a013_rightArmFB_03C;

	// NAME: Right wrist_front and back - 右手首_前後
	// DESC: Right wrist_front and back - 右手首_前後
	int16_t a013_rightWristFB_03E;

	// NAME: Right wrist_inside and outside - 右手首_内外
	// DESC: Right wrist_inside and outside - 右手首_内外
	int16_t a013_rightWristIO_040;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a013_leftArmFB_042;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a013_leftWristFB_044;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a013_leftWristIO_046;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a014_rightArmFB_048;

	// NAME: Right wrist_front and back - 右手首_前後
	// DESC: Right wrist_front and back - 右手首_前後
	int16_t a014_rightWristFB_04A;

	// NAME: Right wrist_inside and outside - 右手首_内外
	// DESC: Right wrist_inside and outside - 右手首_内外
	int16_t a014_rightWristIO_04C;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a014_leftArmFB_04E;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a014_leftWristFB_050;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a014_leftWristIO_052;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a015_rightArmFB_054;

	// NAME: Right wrist_front and back - 右手首_前後
	// DESC: Right wrist_front and back - 右手首_前後
	int16_t a015_rightWristFB_056;

	// NAME: Right wrist_inside and outside - 右手首_内外
	// DESC: Right wrist_inside and outside - 右手首_内外
	int16_t a015_rightWristIO_058;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a015_leftArmFB_05A;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a015_leftWristFB_05C;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a015_leftWristIO_05E;

	// NAME: Right arm_front and back - 右腕_前後
	// DESC: Right arm_front and back - 右腕_前後
	int16_t a016_rightArmFB_060;

	// NAME: Right wrist_front and back - 右手首_前後
	// DESC: Right wrist_front and back - 右手首_前後
	int16_t a016_rightWristFB_062;

	// NAME: Right wrist_inside and outside - 右手首_内外
	// DESC: Right wrist_inside and outside - 右手首_内外
	int16_t a016_rightWristIO_064;

	// NAME: Left arm_front and back - 左腕_前後
	// DESC: Left arm_front and back - 左腕_前後
	int16_t a016_leftArmFB_066;

	// NAME: Left wrist_front and back - 左手首_前後
	// DESC: Left wrist_front and back - 左手首_前後
	int16_t a016_leftWristFB_068;

	// NAME: Left wrist_inside and outside - 左手首_内外
	// DESC: Left wrist_inside and outside - 左手首_内外
	int16_t a016_leftWristIO_06A;

	// NAME: pad - pad
	uint8_t pad_06C[4];

} PostureControlParam_WepRight;

#endif
