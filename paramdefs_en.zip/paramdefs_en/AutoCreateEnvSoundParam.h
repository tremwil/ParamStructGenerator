/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AutoCreateEnvSoundParam_H
#define _PARAM_AutoCreateEnvSoundParam_H
#include <stdint.h>

// AUTO_CREATE_ENV_SOUND_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AutoCreateEnvSoundParam {

	// NAME: Appearance distance Min [m] - 出現距離Min[m]
	// DESC: Appearance distance Min [m] - 出現距離Min[m]
	float RangeMin_000;

	// NAME: Appearance distance Max [m] - 出現距離Max[m]
	// DESC: Appearance distance Max [ - 出現距離Max[
	float RangeMax_004;

	// NAME: Lifespan Min [seconds] - 寿命Min[秒]
	// DESC: Lifespan Min [seconds] - 寿命Min[秒]
	float LifeTimeMin_008;

	// NAME: Lifespan Max [seconds] - 寿命Max[秒]
	// DESC: Lifespan Max [seconds] - 寿命Max[秒]
	float LifeTimeMax_00C;

	// NAME: Delete distance [m] - 削除距離[m]
	// DESC: Delete distance [m] - 削除距離[m]
	float DeleteDist_010;

	// NAME: Neighborhood judgment distance [m] - 近傍判定距離[m]
	// DESC: Neighborhood judgment distance [m] - 近傍判定距離[m]
	float NearDist_014;

	// NAME: Generation angle limit Min [degree] - 生成角度制限Min[度]
	// DESC: Angle limit Min [degree] (Specify the Y-axis angle +-in front of the camera. 180 is omnidirectional) - 角度制限Min[度](カメラの前方のY軸角度+-の指定。180なら全方位) 
	float LimiteRotateMin_018;

	// NAME: Generation angle limit Max [degrees] - 生成角度制限Max[度]
	// DESC: Angle limit Max [degree] (Specify the Y-axis angle +-in front of the camera. 180 is omnidirectional) - 角度制限Max[度](カメラの前方のY軸角度+-の指定。180なら全方位) 
	float LimiteRotateMax_01C;

} AutoCreateEnvSoundParam;

#endif
