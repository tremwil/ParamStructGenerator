/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CutsceneWeatherOverrideGparamIdConvertParam_H
#define _PARAM_CutsceneWeatherOverrideGparamIdConvertParam_H
#include <stdint.h>

// CUTSCENE_WEATHER_OVERRIDE_GPARAM_ID_CONVERT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CutsceneWeatherOverrideGparamIdConvertParam {

	// NAME: Cutscene Weather Overwrite Gparam Suffix ID - カットシーン天候上書きGparamサフィックスID
	// DESC: The ID of the ?? part of s00_00_0000_WeatherOverride_ ??. Gparam - s00_00_0000_WeatherOverride_??.gparamの??の部分のIDです
	uint32_t weatherOverrideGparamId_000;

} CutsceneWeatherOverrideGparamIdConvertParam;

#endif
