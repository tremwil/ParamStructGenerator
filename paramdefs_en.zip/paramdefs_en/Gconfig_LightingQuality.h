/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_LightingQuality_H
#define _PARAM_Gconfig_LightingQuality_H
#include <stdint.h>

// CS_LIGHTING_QUALITY_DETAIL
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_LightingQuality {

	// NAME: Local light effective distance coefficient - ローカルライト有効距離係数
	// DESC: Local light effective distance coefficient (smaller, it disappears at a short distance) - ローカルライト有効距離係数(小さくすると、近い距離で消える)
	float localLightDistFactor_000;

	// NAME: Local light shadow enabled - ローカルライトシャドウ有効
	// DESC: Local light shadow enabled - ローカルライトシャドウ有効
	uint8_t localLightShadowEnabled_004;

	// NAME: Forward pass writing enabled - フォワードパスライティング有効
	// DESC: Forward pass writing enabled - フォワードパスライティング有効
	uint8_t forwardPassLightingEnabled_005;

	// NAME: Local light shadow spec level - ローカルライトシャドウスペックレベル
	// DESC: Local light shadow spec level. The larger the value, the more light sources will be shadowed. - ローカルライトシャドウスペックレベル。大きいほど、より多くの光源にシャドウが設定される
	uint8_t localLightShadowSpecLevelMax_006;

	// NAME: dmy - dmy
	uint8_t dmy_007[1];

} Gconfig_LightingQuality;

#endif
