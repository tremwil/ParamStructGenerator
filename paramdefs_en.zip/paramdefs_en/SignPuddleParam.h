/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SignPuddleParam_H
#define _PARAM_SignPuddleParam_H
#include <stdint.h>

// SIGN_PUDDLE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SignPuddleParam {

	// NAME: Do you remove it from the NT version output? - NT版出力から外すか
	// DESC: Parameters marked with ○ are excluded in the NT version package. - ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// NAME: Reserve for package output 1 - パッケージ出力用リザーブ1
	// DESC: Reserve for package output 1 - パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// NAME: Reserve for package output 2 - パッケージ出力用リザーブ2
	// DESC: Reserve for package output 2 - パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// NAME: Simple match area ID - 簡易マッチエリアID
	// DESC: ID of the simple match area to which it belongs - 属している簡易マッチエリアのID
	int32_t matchAreaId_004;

	// NAME: pad1 - pad1
	uint8_t pad1_008[24];

} SignPuddleParam;

#endif
