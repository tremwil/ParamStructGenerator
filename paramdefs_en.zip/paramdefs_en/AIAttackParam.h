/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AIAttackParam_H
#define _PARAM_AIAttackParam_H
#include <stdint.h>

// AI_ATTACK_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AIAttackParam {

	// NAME: Reference ID - 参照ID
	// DESC: ID specified by NPC thinking parameters - NPC思考パラメータで指定するID
	int32_t attackTableId_000;

	// NAME: Attack ID - 攻撃ID
	// DESC: Attack number - 攻撃の番号
	int32_t attackId_004;

	// NAME: Success judgment distance - 成功判定距離
	// DESC: For arguments of Common_Attack type subgoals - Common_Attack系のサブゴールの引数用
	float successDistance_008;

	// NAME: Turn time before attack - 攻撃前旋回時間
	// DESC: For arguments of Common_Attack type subgoals - Common_Attack系のサブゴールの引数用
	float turnTimeBeforeAttack_00C;

	// NAME: Front judgment angle - 正面判定角度
	// DESC: For arguments of Common_Attack type subgoals - Common_Attack系のサブゴールの引数用
	int16_t frontAngleRange_010;

	// NAME: Upward execution threshold - 上方実行閾値
	// DESC: For arguments of Common_Attack type subgoals - Common_Attack系のサブゴールの引数用
	int16_t upAngleThreshold_012;

	// NAME: Downward execution threshold - 下方実行閾値
	// DESC: For arguments of Common_Attack type subgoals - Common_Attack系のサブゴールの引数用
	int16_t downAngleThershold_014;

	// NAME: Is it a starting technique? - 始動技か
	// DESC: Attacks from the second stage of the combo are × - コンボの2段目以降の攻撃は×
	uint8_t isFirstAttack_016;

	// NAME: Whether to select outside the proper distance - 適正距離外で選択するか
	// DESC: Whether to select when the distance is out of the proper distance - 適正距離外の時に選択対象にするかどうか
	uint8_t doesSelectOnOutRange_017;

	// NAME: Minimum proper distance - 最小適正距離
	// DESC: Minimum value of proper attack distance - 攻撃の適正距離の最小値
	float minOptimalDistance_018;

	// NAME: Maximum proper distance - 最大適正距離
	// DESC: Maximum attack suitability distance - 攻撃の適性距離の最大値
	float maxOptimalDistance_01C;

	// NAME: Appropriate angle reference direction 1 - 適正角度基準方向1
	// DESC: Direction that serves as a reference for the proper angle of attack (XZ plane) - 攻撃の適正角度の基準となる方向（XZ平面）
	int16_t baseDirectionForOptimalAngle1_020;

	// NAME: Appropriate angle reference range 1 - 適正角度基準範囲1
	// DESC: Range of aptitude angles for attacks - 攻撃の適性角度の範囲
	int16_t optimalAttackAngleRange1_022;

	// NAME: Appropriate angle reference direction 2 - 適正角度基準方向2
	// DESC: Direction that serves as a reference for attack aptitude accuracy (XZ plane) - 攻撃の適性確度の基準となる方向（XZ平面）
	int16_t baseDirectionForOptimalAngle2_024;

	// NAME: Appropriate angle reference range 2 - 適正角度基準範囲2
	// DESC: Range of aptitude angles for attacks - 攻撃の適性角度の範囲
	int16_t optimalAttackAngleRange2_026;

	// NAME: Executable interval - 実行可能インターバル
	// DESC: Time required to attack once and then use it again - 一度攻撃を行ってから再度使うために必要な時間
	float intervalForExec_028;

	// NAME: Selection rate - 選択レート
	// DESC: Specify the ease of selection by magnification - 選択されやすさを倍率で指定する
	float selectionTendency_02C;

	// NAME: Short range selection rate - 近距離選択レート
	// DESC: Selection rate at close range - 近距離での選択レート
	float shortRangeTendency_030;

	// NAME: Medium range selection rate - 中距離選択レート
	// DESC: Selection rate at medium range - 中距離での選択レート
	float middleRangeTendency_034;

	// NAME: Distance selection rate - 遠距離選択レート
	// DESC: Selection rate at long distances - 遠距離での選択レート
	float farRangeTendency_038;

	// NAME: Out of range rate - 範囲外レート
	// DESC: Selection rate out of range - 範囲外での選択レート
	float outRangeTendency_03C;

	// NAME: Derived attack 1 - 派生攻撃1
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId1_040;

	// NAME: Derived attack 2 - 派生攻撃2
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId2_044;

	// NAME: Derived attack 3 - 派生攻撃3
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId3_048;

	// NAME: Derived attack 4 - 派生攻撃4
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId4_04C;

	// NAME: Derived attack 5 - 派生攻撃5
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId5_050;

	// NAME: Derived attack 6 - 派生攻撃6
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId6_054;

	// NAME: Derived attack 7 - 派生攻撃7
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId7_058;

	// NAME: Derived attack 8 - 派生攻撃8
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId8_05C;

	// NAME: Derived attack 9 - 派生攻撃9
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId9_060;

	// NAME: Derived attack 10 - 派生攻撃10
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId10_064;

	// NAME: Derived attack 11 - 派生攻撃11
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId11_068;

	// NAME: Derived attack 12 - 派生攻撃12
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId12_06C;

	// NAME: Derived attack 13 - 派生攻撃13
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId13_070;

	// NAME: Derived attack 14 - 派生攻撃14
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId14_074;

	// NAME: Derived attack 15 - 派生攻撃15
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId15_078;

	// NAME: Derived attack 16 - 派生攻撃16
	// DESC: Derivable attack number - 派生可能な攻撃の番号
	int32_t deriveAttackId16_07C;

	// NAME: Minimum life of the goal - ゴールの最小寿命
	// DESC: Minimum life of the goal - ゴールの最小寿命
	float goalLifeMin_080;

	// NAME: Maximum life span of the goal - ゴールの最大寿命
	// DESC: Maximum life span of the goal - ゴールの最大寿命
	float goalLifeMax_084;

	// NAME: Whether to select within the appropriate distance - 適正距離内で選択するか
	// DESC: Whether to select when within the appropriate distance - 適正距離内の時に選択対象にするかどうか
	uint8_t doesSelectOnInnerRange_088;

	// NAME: Whether to use it as the first hit - 初撃として使用するか
	// DESC: Whether to use it as the first hit - 初撃として使用するか
	uint8_t enableAttackOnBattleStart_089;

	// NAME: Whether to select when the target is down - ターゲットダウン時選択するか
	// DESC: Whether to select when the target is down - ターゲットダウン時選択するか
	uint8_t doesSelectOnTargetDown_08A;

	// NAME: pad - pad
	uint8_t pad1_08B[1];

	// NAME: Minimum reach judgment distance - 最小到達判定距離
	// DESC: Minimum reach judgment distance - 最小到達判定距離
	float minArriveDistance_08C;

	// NAME: Maximum reach judgment distance - 最大到達判定距離
	// DESC: Maximum reach judgment distance - 最大到達判定距離
	float maxArriveDistance_090;

	// NAME: Continuous attack execution distance - 連続攻撃実行距離
	// DESC: Distance used to determine the execution of attacks from the second stage onward - 二段目以降の攻撃の実行判定に使用する距離
	float comboExecDistance_094;

	// NAME: Continuous attack execution angle - 連続攻撃実行角度
	// DESC: Distance used to determine the execution of attacks from the second stage onward - 二段目以降の攻撃の実行判定に使用する距離
	float comboExecRange_098;

} AIAttackParam;

#endif
