/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SeActivationRangeParam_H
#define _PARAM_SeActivationRangeParam_H
#include <stdint.h>

// SE_ACTIVATION_RANGE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SeActivationRangeParam {

	// NAME: Activate distance - アクティベート距離
	// DESC: Distance to enable placement SE (m) (0 or less: always enabled) - 配置SEを有効化する距離(m) (0以下：常に有効化)
	float activateRange_000;

} SeActivationRangeParam;

#endif
