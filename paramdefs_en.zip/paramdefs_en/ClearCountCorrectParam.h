/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ClearCountCorrectParam_H
#define _PARAM_ClearCountCorrectParam_H
#include <stdint.h>

// CLEAR_COUNT_CORRECT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ClearCountCorrectParam {

	// NAME: 《Maximum HP magnification [%]》 - 《最大HP倍率[%]》
	// DESC: Maximum HP magnification [%] - 最大HP倍率[%]
	float MaxHpRate_000;

	// NAME: 《Maximum MP magnification [%]》 - 《最大MP倍率[%]》
	// DESC: Maximum MP magnification [%] - 最大MP倍率[%]
	float MaxMpRate_004;

	// NAME: 《Maximum stamina magnification [%]》 - 《最大スタミナ倍率[%]》
	// DESC: Maximum stamina magnification [%] - 最大スタミナ倍率[%]
	float MaxStaminaRate_008;

	// NAME: 《Physical attack power multiplier》 - 《物理攻撃力倍率》
	// DESC: Physical attack power multiplier - 物理攻撃力倍率
	float PhysicsAttackRate_00C;

	// NAME: 《Slashing attack power multiplier》 - 《斬撃攻撃力倍率》
	// DESC: Slash attack power multiplier - 斬撃攻撃力倍率
	float SlashAttackRate_010;

	// NAME: 《Batter attack power multiplier》 - 《打撃攻撃力倍率》
	// DESC: Batter attack power multiplier - 打撃攻撃力倍率
	float BlowAttackRate_014;

	// NAME: 《Puncture attack power multiplier》 - 《刺突攻撃力倍率》
	// DESC: Puncture attack power multiplier - 刺突攻撃力倍率
	float ThrustAttackRate_018;

	// NAME: 《Non-attribute attack power multiplier》 - 《無属性攻撃力倍率》
	// DESC: Non-attribute attack power multiplier - 無属性攻撃力倍率
	float NeturalAttackRate_01C;

	// NAME: 《Magic attack power multiplier》 - 《魔法攻撃力倍率》
	// DESC: Magic attack power multiplier - 魔法攻撃力倍率
	float MagicAttackRate_020;

	// NAME: 《Flame attack power multiplier》 - 《炎攻撃力倍率》
	// DESC: Fire attack power multiplier - 炎攻撃力倍率
	float FireAttackRate_024;

	// NAME: 《Electric shock attack power multiplier》 - 《電撃攻撃力倍率》
	// DESC: Electric shock attack power multiplier - 電撃攻撃力倍率
	float ThunderAttackRate_028;

	// NAME: 《Dark attack power multiplier》 - 《闇攻撃力倍率》
	// DESC: Dark attack power multiplier - 闇攻撃力倍率
	float DarkAttackRate_02C;

	// NAME: 《Physical defense multiplier》 - 《物理防御力倍率》
	// DESC: Physical defense power multiplier - 物理防御力倍率
	float PhysicsDefenseRate_030;

	// NAME: 《Magic Defense Multiplier》 - 《魔法防御力倍率》
	// DESC: Magic defense multiplier - 魔法防御力倍率
	float MagicDefenseRate_034;

	// NAME: 《Flame defense multiplier》 - 《炎防御力倍率》
	// DESC: Fire defense multiplier - 炎防御力倍率
	float FireDefenseRate_038;

	// NAME: 《Dengeki Defense Magnification》 - 《電撃防御力倍率》
	// DESC: Electric shock defense power multiplier - 電撃防御力倍率
	float ThunderDefenseRate_03C;

	// NAME: 《Darkness Defense Multiplier》 - 《闇防御力倍率》
	// DESC: Dark defense multiplier - 闇防御力倍率
	float DarkDefenseRate_040;

	// NAME: 《Stamina attack power multiplier》 - 《スタミナ攻撃力倍率》
	// DESC: Stamina attack power multiplier - スタミナ攻撃力倍率
	float StaminaAttackRate_044;

	// NAME: 《Soul possession rate》 - 《所持ソウル率》
	// DESC: Possession soul rate - 所持ソウル率
	float SoulRate_048;

	// NAME: 《Poison resistance change rate》 - 《毒耐性変化倍率》
	// DESC: Poison resistance change rate - 毒耐性変化倍率
	float PoisionResistRate_04C;

	// NAME: 《Pesticide resistance change rate》 - 《疫病耐性変化倍率》
	// DESC: Epidemic resistance change rate - 疫病耐性変化倍率
	float DiseaseResistRate_050;

	// NAME: 《Bleeding resistance change rate》 - 《出血耐性変化倍率》
	// DESC: Bleeding resistance change rate - 出血耐性変化倍率
	float BloodResistRate_054;

	// NAME: 《Curse resistance change rate》 - 《呪耐性変化倍率》
	// DESC: Curse resistance change rate - 呪耐性変化倍率
	float CurseResistRate_058;

	// NAME: 《Cold air resistance change rate》 - 《冷気耐性変化倍率》
	// DESC: Cold resistance change rate - 冷気耐性変化倍率
	float FreezeResistRate_05C;

	// NAME: 《Bleeding damage correction factor》 - 《出血ダメージ補正倍率》
	// DESC: Bleeding damage correction factor - 出血ダメージ補正倍率
	float BloodDamageRate_060;

	// NAME: 《SA damage correction factor》 - 《SAダメージ補正倍率》
	// DESC: SA damage correction factor - SAダメージ補正倍率
	float SuperArmorDamageRate_064;

	// NAME: 《Cold air damage correction factor》 - 《冷気ダメージ補正倍率》
	// DESC: Cold damage correction factor - 冷気ダメージ補正倍率
	float FreezeDamageRate_068;

	// NAME: 《Sleep tolerance change rate》 - 《睡眠耐性変化倍率》
	// DESC: Sleep tolerance change rate - 睡眠耐性変化倍率
	float SleepResistRate_06C;

	// NAME: 《Madness resistance change rate》 - 《発狂耐性変化倍率》
	// DESC: Madness resistance change rate - 発狂耐性変化倍率
	float MadnessResistRate_070;

	// NAME: 《Sleep damage correction factor》 - 《睡眠ダメージ補正倍率》
	// DESC: Sleep damage correction factor - 睡眠ダメージ補正倍率
	float SleepDamageRate_074;

	// NAME: 《Crazy damage correction factor》 - 《発狂ダメージ補正倍率》
	// DESC: Mad damage correction factor - 発狂ダメージ補正倍率
	float MadnessDamageRate_078;

	// NAME: pad - pad
	uint8_t pad1_07C[4];

} ClearCountCorrectParam;

#endif
