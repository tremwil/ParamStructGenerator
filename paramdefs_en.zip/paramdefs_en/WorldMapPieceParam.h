/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WorldMapPieceParam_H
#define _PARAM_WorldMapPieceParam_H
#include <stdint.h>

// WORLD_MAP_PIECE_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WorldMapPieceParam {

	// NAME: Do you remove it from the NT version output? - NT版出力から外すか
	// DESC: Parameters marked with ○ are excluded in the NT version package. - ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// NAME: Reserve for package output 1 - パッケージ出力用リザーブ1
	// DESC: Reserve for package output 1 - パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// NAME: Reserve for package output 2 - パッケージ出力用リザーブ2
	// DESC: Reserve for package output 2 - パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// NAME: Open event flag ID - 開放イベントフラグID
	// DESC: Event flag ID of open condition - 開放条件のイベントフラグID
	uint32_t openEventFlagId_004;

	// NAME: Opened traversal area: Xmin - 開放される踏破エリア：Xmin
	// DESC: Coordinates of the traversal area that expands when opened (Xmin) - 開放時に拡張する踏破エリアの座標（Xmin）
	float openTravelAreaLeft_008;

	// NAME: Opened traversal area: Xmax - 開放される踏破エリア：Xmax
	// DESC: Coordinates of the traversal area that expands when opened (Xmax) - 開放時に拡張する踏破エリアの座標（Xmax）
	float openTravelAreaRight_00C;

	// NAME: Opened traversal area: Ymin - 開放される踏破エリア：Ymin
	// DESC: Coordinates of the traversal area that expands when opened (Ymin) - 開放時に拡張する踏破エリアの座標（Ymin）
	float openTravelAreaTop_010;

	// NAME: Opened traversal area: Ymax - 開放される踏破エリア：Ymax
	// DESC: Coordinates of the traversal area that expands when opened (Ymax) - 開放時に拡張する踏破エリアの座標（Ymax）
	float openTravelAreaBottom_014;

	// NAME: Acquisition production event flag ID - 入手演出イベントフラグID
	// DESC: Event flag ID of the acquisition production start condition. Assuming that only one of the map fragments is On - 入手演出開始条件のイベントフラグID。いずれかの地図断片ひとつのみがOnになっている想定
	uint32_t acquisitionEventFlagId_018;

	// NAME: Acquisition effect: Display magnification - 入手演出：表示倍率
	// DESC: Display magnification at the time of acquisition production - 入手演出時の表示倍率
	float acquisitionEventScale_01C;

	// NAME: Obtained production: Center coordinates X - 入手演出：中心座標X
	// DESC: Center coordinates (X) at the time of acquisition production - 入手演出時の中心座標（X）
	float acquisitionEventCenterX_020;

	// NAME: Obtained production: Center coordinates Y - 入手演出：中心座標Y
	// DESC: For the central seat at the time of acquisition production (Y) - 入手演出時の中心座用（Y）
	float acquisitionEventCenterY_024;

	// NAME: Acquisition effect: Resource multiplier - 入手演出：リソース倍率
	// DESC: Display magnification of blindfold resources for acquisition production - 入手演出用目隠しリソースの表示倍率
	float acquisitionEventResScale_028;

	// NAME: Acquisition effect: Resource offset X - 入手演出：リソースオフセットX
	// DESC: Display position offset (X) of blindfold resource for acquisition production - 入手演出用目隠しリソースの表示位置オフセット（X）
	float acquisitionEventResOffsetX_02C;

	// NAME: Acquisition effect: Resource offset Y - 入手演出：リソースオフセットY
	// DESC: Offset of display position of blindfold resource for acquisition production (Y) - 入手演出用目隠しリソースの表示位置オフセット（Y）
	float acquisitionEventResOffsetY_030;

	// NAME: pad - パッド
	uint8_t pad_034[12];

} WorldMapPieceParam;

#endif
