/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SpeedtreeModel_H
#define _PARAM_SpeedtreeModel_H
#include <stdint.h>

// SPEEDTREE_MODEL_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SpeedtreeModel {

	// NAME: Leaf minimum fade value - Leafの最小フェード値
	float MinFadeLeaf_000;

	// NAME: Frond minimum fade value - Frondの最小フェード値
	float MinFadeFrond_004;

	// NAME: Branch minimum fade value - Branchの最小フェード値
	float MinFadeBranch_008;

	// NAME: Minimum transmitted light of Leaf - Leafの透過光最小値
	float MinTranslucencyLeaf_00C;

	// NAME: Maximum transmitted light of Leaf - Leafの透過光最大値
	float MaxTranslucencyLeaf_010;

	// NAME: Minimum transmitted light of Frond - Frondの透過光最小値
	float MinTranslucencyFrond_014;

	// NAME: Maximum transmitted light of Frond - Frondの透過光最大値
	float MaxTranslucencyFrond_018;

	// NAME: Minimum transmitted light of Branch - Branchの透過光最小値
	float MinTranslucencyBranch_01C;

	// NAME: Maximum transmitted light of Branch - Branchの透過光最大値
	float MaxTranslucencyBranch_020;

	// NAME: Billboard Specular suppression value - ビルボードのSpecular抑制値
	float BillboardBackSpecularWeakenParam_024;

} SpeedtreeModel;

#endif
