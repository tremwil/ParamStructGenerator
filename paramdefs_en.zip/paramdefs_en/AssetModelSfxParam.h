/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AssetModelSfxParam_H
#define _PARAM_AssetModelSfxParam_H
#include <stdint.h>

// ASSET_MODEL_SFX_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AssetModelSfxParam {

	// NAME: 0: SfxID - 0:SfxID
	// DESC: 0: SfxID - 0:SfxID
	int32_t sfxId_0_000;

	// NAME: 0: Damipoli ID - 0：ダミポリID
	// DESC: 0: Damipoli ID - 0：ダミポリID
	int32_t dmypolyId_0_004;

	// NAME: 0: Reservation - 0:予約
	// DESC: 0: Reservation - 0:予約
	uint8_t reserve_0_008[8];

	// NAME: 1: SfxID - 1:SfxID
	// DESC: 1: SfxID - 1:SfxID
	int32_t sfxId_1_010;

	// NAME: 1: Damipoli ID - 1：ダミポリID
	// DESC: 1: Damipoli ID - 1：ダミポリID
	int32_t dmypolyId_1_014;

	// NAME: 1: Reservation - 1:予約
	// DESC: 1: Reservation - 1:予約
	uint8_t reserve_1_018[8];

	// NAME: 2: SfxID - 2:SfxID
	// DESC: 2: SfxID - 2:SfxID
	int32_t sfxId_2_020;

	// NAME: 2: Damipoli ID - 2：ダミポリID
	// DESC: 2: Damipoli ID - 2：ダミポリID
	int32_t dmypolyId_2_024;

	// NAME: 2: Reservation - 2:予約
	// DESC: 2: Reservation - 2:予約
	uint8_t reserve_2_028[8];

	// NAME: 3: SfxID - 3:SfxID
	// DESC: 3: SfxID - 3:SfxID
	int32_t sfxId_3_030;

	// NAME: 3: Damipoli ID - 3：ダミポリID
	// DESC: 3: Damipoli ID - 3：ダミポリID
	int32_t dmypolyId_3_034;

	// NAME: 3: Reservation - 3:予約
	// DESC: 3: Reservation - 3:予約
	uint8_t reserve_3_038[8];

	// NAME: 4: SfxID - 4:SfxID
	// DESC: 4: SfxID - 4:SfxID
	int32_t sfxId_4_040;

	// NAME: 4: Damipoli ID - 4：ダミポリID
	// DESC: 4: Damipoli ID - 4：ダミポリID
	int32_t dmypolyId_4_044;

	// NAME: 4: Reservation - 4:予約
	// DESC: 4: Reservation - 4:予約
	uint8_t reserve_4_048[8];

	// NAME: 5: SfxID - 5:SfxID
	// DESC: 5: SfxID - 5:SfxID
	int32_t sfxId_5_050;

	// NAME: 5: Damipoli ID - 5：ダミポリID
	// DESC: 5: Damipoli ID - 5：ダミポリID
	int32_t dmypolyId_5_054;

	// NAME: 5: Reservation - 5:予約
	// DESC: 5: Reservation - 5:予約
	uint8_t reserve_5_058[8];

	// NAME: 6: SfxID - 6:SfxID
	// DESC: 6: SfxID - 6:SfxID
	int32_t sfxId_6_060;

	// NAME: 6: Damipoli ID - 6：ダミポリID
	// DESC: 6: Damipoli ID - 6：ダミポリID
	int32_t dmypolyId_6_064;

	// NAME: 6: Reservation - 6:予約
	// DESC: 6: Reservation - 6:予約
	uint8_t reserve_6_068[8];

	// NAME: 7: SfxID - 7:SfxID
	// DESC: 7: SfxID - 7:SfxID
	int32_t sfxId_7_070;

	// NAME: 7: Damipoli ID - 7：ダミポリID
	// DESC: 7: Damipoli ID - 7：ダミポリID
	int32_t dmypolyId_7_074;

	// NAME: Disables the effect on irradiance volume - イラディアンスボリュームへの影響を無効化
	// DESC: When enabled, the effect on irradiance volume shooting is disabled. - 有効にするとイラディアンスボリューム撮影への影響を無効化します
	uint8_t isDisableIV_078;

	// NAME: 7: Reservation - 7:予約
	// DESC: 7: Reservation - 7:予約
	uint8_t reserve_7_079[7];

} AssetModelSfxParam;

#endif
