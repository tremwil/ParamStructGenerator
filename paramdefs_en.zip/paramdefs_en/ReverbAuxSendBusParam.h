/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ReverbAuxSendBusParam_H
#define _PARAM_ReverbAuxSendBusParam_H
#include <stdint.h>

// REVERB_AUX_SEND_BUS_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 202
typedef struct _ReverbAuxSendBusParam {

	// NAME: ReverbAuxSendBus name - ReverbAuxSendBus名
	// DESC: ReverbAuxSendBus name - ReverbAuxSendBus名
	char ReverbAuxSendBusName_000[32];

} ReverbAuxSendBusParam;

#endif
