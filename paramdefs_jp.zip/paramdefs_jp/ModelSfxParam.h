/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ModelSfxParam_H
#define _PARAM_ModelSfxParam_H
#include <stdint.h>

// MODEL_SFX_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ModelSfxParam {

	// 名前：0:SfxID
	// 説明：0:SfxID
	int32_t sfxId_0_000;

	// 名前：0：ダミポリID
	// 説明：0：ダミポリID
	int32_t dmypolyId_0_004;

	// 名前：0:予約
	// 説明：0:予約
	uint8_t reserve_0_008[8];

	// 名前：1:SfxID
	// 説明：1:SfxID
	int32_t sfxId_1_010;

	// 名前：1：ダミポリID
	// 説明：1：ダミポリID
	int32_t dmypolyId_1_014;

	// 名前：1:予約
	// 説明：1:予約
	uint8_t reserve_1_018[8];

	// 名前：2:SfxID
	// 説明：2:SfxID
	int32_t sfxId_2_020;

	// 名前：2：ダミポリID
	// 説明：2：ダミポリID
	int32_t dmypolyId_2_024;

	// 名前：2:予約
	// 説明：2:予約
	uint8_t reserve_2_028[8];

	// 名前：3:SfxID
	// 説明：3:SfxID
	int32_t sfxId_3_030;

	// 名前：3：ダミポリID
	// 説明：3：ダミポリID
	int32_t dmypolyId_3_034;

	// 名前：3:予約
	// 説明：3:予約
	uint8_t reserve_3_038[8];

	// 名前：4:SfxID
	// 説明：4:SfxID
	int32_t sfxId_4_040;

	// 名前：4：ダミポリID
	// 説明：4：ダミポリID
	int32_t dmypolyId_4_044;

	// 名前：4:予約
	// 説明：4:予約
	uint8_t reserve_4_048[8];

	// 名前：5:SfxID
	// 説明：5:SfxID
	int32_t sfxId_5_050;

	// 名前：5：ダミポリID
	// 説明：5：ダミポリID
	int32_t dmypolyId_5_054;

	// 名前：5:予約
	// 説明：5:予約
	uint8_t reserve_5_058[8];

	// 名前：6:SfxID
	// 説明：6:SfxID
	int32_t sfxId_6_060;

	// 名前：6：ダミポリID
	// 説明：6：ダミポリID
	int32_t dmypolyId_6_064;

	// 名前：6:予約
	// 説明：6:予約
	uint8_t reserve_6_068[8];

	// 名前：7:SfxID
	// 説明：7:SfxID
	int32_t sfxId_7_070;

	// 名前：7：ダミポリID
	// 説明：7：ダミポリID
	int32_t dmypolyId_7_074;

	// 名前：7:予約
	// 説明：7:予約
	uint8_t reserve_7_078[8];

} ModelSfxParam;

#endif
