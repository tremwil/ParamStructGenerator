/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_RideParam_H
#define _PARAM_RideParam_H
#include <stdint.h>

// RIDE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _RideParam {

	// 名前：乗る側キャラID
	// 説明：騎乗時に「乗る側」のキャラクタを特定するパラメータです
	uint32_t atkChrId_000;

	// 名前：乗られる側キャラID
	// 説明：騎乗時に「乗られる側」のキャラクタを特定するパラメータです
	uint32_t defChrId_004;

	// 名前：騎乗時カメラID
	// 説明：騎乗時のカメラパラメータを専用のカメラに変更するパラメータです。PC専用のパラメータで、敵に設定しても機能しません。
	int32_t rideCamParamId_008;

	// 名前：乗る側_騎乗アニメの種類と方向変数値
	// 説明：キャラクタアニメ再生を制御しているツール「HavokAnimationTool（HAT）」の「RideOn（騎乗時再生）ステート」内に設定しているvariable（変数）"RideOnAnimId"の値を書き換えるパラメータです
	uint32_t atkChrAnimId_00C;

	// 名前：乗られる側_騎乗アニメの種類と方向変数値
	// 説明：キャラクタアニメ再生を制御しているツール「HavokAnimationTool（HAT）」の「RiddenOn（被騎乗時再生）ステート」内に設定しているvariable（変数）"RiddenOnAnimId"の値を書き換えるパラメータです
	uint32_t defChrAnimId_010;

	// 名前：騎乗アニメ開始時の乗られる側の位置合わせダミポリID
	// 説明：乗られる側にのみ必要なダミポリ設定です（乗る側キャラクタには、設定の必要ありません）
	int32_t defAdjustDmyId_014;

	// 名前：騎乗判定_乗られる側の判定基準ダミポリID
	// 説明：乗る側のキャラには、ダミポリの設定はとくに必要ありません
	int32_t defCheckDmyId_018;

	// 名前：騎乗判定_乗る側の正面判定角度範囲[deg]
	// 説明：乗る側の【向き】と、乗られる側の「正面判定ダミポリID」の角度差で判定します。値が大きいほど、「そっぽを向いていても乗れる」ようになります
	float diffAngMyToDef_01C;

	// 名前：騎乗判定_有効距離[m]
	// 説明：「対象との騎乗可能距離」を決定するパラメータです
	float dist_020;

	// 名前：騎乗判定_有効高さ上方向[m]
	// 説明：乗られる対象が、乗る対象よりどの程度上方にいても騎乗可能か？を、メートル単位で設定します
	float upperYRange_024;

	// 名前：騎乗判定_有効高さ下方向[m]
	// 説明：乗られる対象が、乗る対象よりどの程度下方にいても騎乗可能か？を、メートル単位で設定します
	float lowerYRange_028;

	// 名前：騎乗判定_対象間の角度差範囲min[deg]
	// 説明：乗る側が、乗られる側のどの範囲(角度)にいれば騎乗できるか？の最小値を設定します
	float diffAngMin_02C;

	// 名前：騎乗判定_対象間の角度差範囲max[deg]
	// 説明：乗る側が、乗られる側のどの範囲(角度)にいれば騎乗できるか？の最大値を設定します
	float diffAngMax_030;

	// 名前：予約
	// 説明：予約領域
	uint8_t pad_034[12];

} RideParam;

#endif
