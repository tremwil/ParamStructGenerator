/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_DOFQuality_H
#define _PARAM_Gconfig_DOFQuality_H
#include <stdint.h>

// CS_DOF_QUALITY_DETAIL
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_DOFQuality {

	// 名前：DOF許可
	// 説明：DOF許可
	uint8_t enabled_000;

	// 名前：dmy
	uint8_t dmy_001[3];

	// 名前：HiResolutionBlur の設定を変更する
	// 説明：HiResolutionBlur の設定を変更する(-1:強制オフ、0:そのまま、1:強制オン)
	int32_t forceHiResoBlur_004;

	// 名前：最大ブラーレベル
	// 説明：最大ブラーレベル。2:最大、1:レベルを一段落とす、0:さらに精度を落とす
	int32_t maxBlurLevel_008;

} Gconfig_DOFQuality;

#endif
