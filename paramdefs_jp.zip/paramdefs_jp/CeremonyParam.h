/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CeremonyParam_H
#define _PARAM_CeremonyParam_H
#include <stdint.h>

// CEREMONY_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CeremonyParam {

	// 名前：イベントレイヤーID
	// 説明：イベントメーカーのレイヤーID
	int32_t eventLayerId_000;

	// 名前：MapStudioレイヤーID
	// 説明：MapStudioのレイヤーID
	int32_t mapStudioLayerId_004;

	// 名前：マルチプレイエリアオフセット
	// 説明：マルチプレイエリアIDのオフセット。例えば「100」と入れるとマルチプレイエリアIDが「100」オフセットされる。
	int32_t multiPlayAreaOffset_008;

	// 名前：マップ名ID上書き_地名表示
	// 説明：マップ名ID_地名表示を指定IDに上書きする。-1:上書き無し、-2以下,0以上:そのIDに上書き。
	int32_t overrideMapPlaceNameId_00C;

	// 名前：マップ名ID上書き_セーブデータ表示
	// 説明：マップ名ID_セーブデータ表示を指定IDに上書きする。-1:上書き無し、-2以下,0以上:そのIDに上書き。
	int32_t overrideSaveMapNameId_010;

	// 名前：pad2
	uint8_t pad2_014[16];

} CeremonyParam;

#endif
