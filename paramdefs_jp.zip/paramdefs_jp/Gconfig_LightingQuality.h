/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_LightingQuality_H
#define _PARAM_Gconfig_LightingQuality_H
#include <stdint.h>

// CS_LIGHTING_QUALITY_DETAIL
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_LightingQuality {

	// 名前：ローカルライト有効距離係数
	// 説明：ローカルライト有効距離係数(小さくすると、近い距離で消える)
	float localLightDistFactor_000;

	// 名前：ローカルライトシャドウ有効
	// 説明：ローカルライトシャドウ有効
	uint8_t localLightShadowEnabled_004;

	// 名前：フォワードパスライティング有効
	// 説明：フォワードパスライティング有効
	uint8_t forwardPassLightingEnabled_005;

	// 名前：ローカルライトシャドウスペックレベル
	// 説明：ローカルライトシャドウスペックレベル。大きいほど、より多くの光源にシャドウが設定される
	uint8_t localLightShadowSpecLevelMax_006;

	// 名前：dmy
	uint8_t dmy_007[1];

} Gconfig_LightingQuality;

#endif
