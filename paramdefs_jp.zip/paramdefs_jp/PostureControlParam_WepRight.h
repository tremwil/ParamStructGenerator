/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PostureControlParam_WepRight_H
#define _PARAM_PostureControlParam_WepRight_H
#include <stdint.h>

// POSTURE_CONTROL_PARAM_WEP_RIGHT_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _PostureControlParam_WepRight {

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a000_rightArmFB_000;

	// 名前：右手首_前後
	// 説明：右手首_前後
	int16_t a000_rightWristFB_002;

	// 名前：右手首_内外
	// 説明：右手首_内外
	int16_t a000_rightWristIO_004;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a000_leftArmFB_006;

	// 名前：左手首_前後
	// 説明：左手首_前後
	int16_t a000_leftWristFB_008;

	// 名前：左手首_内外
	// 説明：左手首_内外
	int16_t a000_leftWristIO_00A;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a002_rightArmFB_00C;

	// 名前：右手首_前後
	// 説明：右手首_前後
	int16_t a002_rightWristFB_00E;

	// 名前：右手首_内外
	// 説明：右手首_内外
	int16_t a002_rightWristIO_010;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a002_leftArmFB_012;

	// 名前：左手首_前後
	// 説明：左手首_前後
	int16_t a002_leftWristFB_014;

	// 名前：左手首_内外
	// 説明：左手首_内外
	int16_t a002_leftWristIO_016;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a003_rightArmFB_018;

	// 名前：右手首_前後
	// 説明：右手首_前後
	int16_t a003_rightWristFB_01A;

	// 名前：右手首_内外
	// 説明：右手首_内外
	int16_t a003_rightWristIO_01C;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a003_leftArmFB_01E;

	// 名前：左手首_前後
	// 説明：左手首_前後
	int16_t a003_leftWristFB_020;

	// 名前：左手首_内外
	// 説明：左手首_内外
	int16_t a003_leftWristIO_022;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a010_rightArmFB_024;

	// 名前：右手首_前後
	// 説明：右手首_前後
	int16_t a010_rightWristFB_026;

	// 名前：右手首_内外
	// 説明：右手首_内外
	int16_t a010_rightWristIO_028;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a010_leftArmFB_02A;

	// 名前：左手首_前後
	// 説明：左手首_前後
	int16_t a010_leftWristFB_02C;

	// 名前：左手首_内外
	// 説明：左手首_内外
	int16_t a010_leftWristIO_02E;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a012_rightArmFB_030;

	// 名前：右手首_前後
	// 説明：右手首_前後
	int16_t a012_rightWristFB_032;

	// 名前：右手首_内外
	// 説明：右手首_内外
	int16_t a012_rightWristIO_034;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a012_leftArmFB_036;

	// 名前：左手首_前後
	// 説明：左手首_前後
	int16_t a012_leftWristFB_038;

	// 名前：左手首_内外
	// 説明：左手首_内外
	int16_t a012_leftWristIO_03A;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a013_rightArmFB_03C;

	// 名前：右手首_前後
	// 説明：右手首_前後
	int16_t a013_rightWristFB_03E;

	// 名前：右手首_内外
	// 説明：右手首_内外
	int16_t a013_rightWristIO_040;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a013_leftArmFB_042;

	// 名前：左手首_前後
	// 説明：左手首_前後
	int16_t a013_leftWristFB_044;

	// 名前：左手首_内外
	// 説明：左手首_内外
	int16_t a013_leftWristIO_046;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a014_rightArmFB_048;

	// 名前：右手首_前後
	// 説明：右手首_前後
	int16_t a014_rightWristFB_04A;

	// 名前：右手首_内外
	// 説明：右手首_内外
	int16_t a014_rightWristIO_04C;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a014_leftArmFB_04E;

	// 名前：左手首_前後
	// 説明：左手首_前後
	int16_t a014_leftWristFB_050;

	// 名前：左手首_内外
	// 説明：左手首_内外
	int16_t a014_leftWristIO_052;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a015_rightArmFB_054;

	// 名前：右手首_前後
	// 説明：右手首_前後
	int16_t a015_rightWristFB_056;

	// 名前：右手首_内外
	// 説明：右手首_内外
	int16_t a015_rightWristIO_058;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a015_leftArmFB_05A;

	// 名前：左手首_前後
	// 説明：左手首_前後
	int16_t a015_leftWristFB_05C;

	// 名前：左手首_内外
	// 説明：左手首_内外
	int16_t a015_leftWristIO_05E;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a016_rightArmFB_060;

	// 名前：右手首_前後
	// 説明：右手首_前後
	int16_t a016_rightWristFB_062;

	// 名前：右手首_内外
	// 説明：右手首_内外
	int16_t a016_rightWristIO_064;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a016_leftArmFB_066;

	// 名前：左手首_前後
	// 説明：左手首_前後
	int16_t a016_leftWristFB_068;

	// 名前：左手首_内外
	// 説明：左手首_内外
	int16_t a016_leftWristIO_06A;

	// 名前：pad
	uint8_t pad_06C[4];

} PostureControlParam_WepRight;

#endif
