/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AutoCreateEnvSoundParam_H
#define _PARAM_AutoCreateEnvSoundParam_H
#include <stdint.h>

// AUTO_CREATE_ENV_SOUND_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AutoCreateEnvSoundParam {

	// 名前：出現距離Min[m]
	// 説明：出現距離Min[m]
	float RangeMin_000;

	// 名前：出現距離Max[m]
	// 説明：出現距離Max[
	float RangeMax_004;

	// 名前：寿命Min[秒]
	// 説明：寿命Min[秒]
	float LifeTimeMin_008;

	// 名前：寿命Max[秒]
	// 説明：寿命Max[秒]
	float LifeTimeMax_00C;

	// 名前：削除距離[m]
	// 説明：削除距離[m]
	float DeleteDist_010;

	// 名前：近傍判定距離[m]
	// 説明：近傍判定距離[m]
	float NearDist_014;

	// 名前：生成角度制限Min[度]
	// 説明：角度制限Min[度](カメラの前方のY軸角度+-の指定。180なら全方位) 
	float LimiteRotateMin_018;

	// 名前：生成角度制限Max[度]
	// 説明：角度制限Max[度](カメラの前方のY軸角度+-の指定。180なら全方位) 
	float LimiteRotateMax_01C;

} AutoCreateEnvSoundParam;

#endif
