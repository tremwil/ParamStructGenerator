/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SwordArtsParam_H
#define _PARAM_SwordArtsParam_H
#include <stdint.h>

// SWORD_ARTS_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SwordArtsParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：剣戟ID
	// 説明：ビヘイビアスクリプトに渡してどの剣戟か判定するためのもの
	uint8_t swordArtsType_004;

	// 名前：アーツ速度
	// 説明：どのキャンセルタイミングを見るか。0：通常（左手攻撃）／1：早い／2：遅い
	uint8_t artsSpeedType_005;

	// 名前：関連ステータス
	// 説明：どの系統のアーツポイントを参照するか
	int8_t refStatus_006;

	// 名前：左手（片手持ち）時に右手のアーツを表示するか
	// 説明：左手武器のアーツに設定されている場合、右手武器のアーツをFEに表示します。「武器戦技」などに使われる想定
	uint8_t isRefRightArts_007: 1;

	// 名前：左手（片手持ち）時にグレーアウトするか
	// 説明：左手（片手持ち）のアーツ名を表示するときにグレーアウトするか
	uint8_t isGrayoutLeftHand_007: 1;

	// 名前：右手（片手持ち）時にグレーアウトするか
	// 説明：右手（片手持ち）のアーツ名を表示するときにグレーアウトするか
	uint8_t isGrayoutRightHand_007: 1;

	// 名前：両手持ち時にグレーアウトするか
	// 説明：両手持ちのアーツ名を表示するときにグレーアウトするか
	uint8_t isGrayoutBothHand_007: 1;

	// 名前：予約領域
	uint8_t reserve2_007: 4;

	// 名前：消費ポイント L1
	// 説明：L1によりアーツを出したときに消費するポイント
	int8_t usePoint_L1_008;

	// 名前：消費ポイント L2
	// 説明：L2によりアーツを出したときに消費するポイント
	int8_t usePoint_L2_009;

	// 名前：消費ポイント R1
	// 説明：R1によりアーツを出したときに消費するポイント
	int8_t usePoint_R1_00A;

	// 名前：消費ポイント R2
	// 説明：R2によりアーツを出したときに消費するポイント
	int8_t usePoint_R2_00B;

	// 名前：テキストID
	// 説明：アーツ説明用のテキストID
	int32_t textId_00C;

	// 名前：消費MP L1
	// 説明：L1によりアーツを出したときに消費するMP
	int16_t useMagicPoint_L1_010;

	// 名前：消費MP L2
	// 説明：L2によりアーツを出したときに消費するMP
	int16_t useMagicPoint_L2_012;

	// 名前：消費MP R1
	// 説明：R1によりアーツを出したときに消費するMP
	int16_t useMagicPoint_R1_014;

	// 名前：消費MP R2
	// 説明：R2によりアーツを出したときに消費するMP
	int16_t useMagicPoint_R2_016;

	// 名前：盾種別アイコン（上書き）
	// 説明：上書きしない場合は、武器パラの剣戟IDを元にアイコン表示されます。
	int8_t shieldIconType_018;

	// 名前：pad
	uint8_t pad_019[1];

	// 名前：アイコンID
	// 説明：FEなどで表示するアイコンのID
	uint16_t iconId_01A;

	// 名前：AI使用判断ID
	// 説明：AI使用判断ID
	int32_t aiUsageId_01C;

} SwordArtsParam;

#endif
