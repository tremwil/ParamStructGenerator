/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CoolTimeParam_H
#define _PARAM_CoolTimeParam_H
#include <stdint.h>

// COOL_TIME_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CoolTimeParam {

	// 名前：制限時間（協力霊数0）
	// 説明：制限時間[sec]（協力霊数0）
	float limitationTime_000;

	// 名前：監視時間（協力霊数0）
	// 説明：監視時間[sec]（協力霊数0）
	float observeTime_004;

	// 名前：制限時間（協力霊数1）
	// 説明：制限時間[sec]（協力霊数1）
	float limitationTime_008;

	// 名前：監視時間（協力霊数1）
	// 説明：監視時間[sec]（協力霊数1）
	float observeTime_00C;

	// 名前：制限時間（協力霊数2）
	// 説明：制限時間[sec]（協力霊数2）
	float limitationTime_010;

	// 名前：監視時間（協力霊数2）
	// 説明：監視時間[sec]（協力霊数2）
	float observeTime_014;

	// 名前：制限時間（協力霊数3）
	// 説明：制限時間[sec]（協力霊数3）
	float limitationTime_018;

	// 名前：監視時間（協力霊数3）
	// 説明：監視時間[sec]（協力霊数3）
	float observeTime_01C;

} CoolTimeParam;

#endif
