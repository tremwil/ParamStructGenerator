/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_GrassMapSettings_H
#define _PARAM_GrassMapSettings_H
#include <stdint.h>

// GRASS_MAP_SETTINGS_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 106
typedef struct _GrassMapSettings {

	// 名前：草の種類０
	uint32_t grassType0_000;

	// 名前：草の種類１
	uint32_t grassType1_004;

	// 名前：草の種類２
	uint32_t grassType2_008;

} GrassMapSettings;

#endif
