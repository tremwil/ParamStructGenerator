/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ReinforceParamWeapon_H
#define _PARAM_ReinforceParamWeapon_H
#include <stdint.h>

// REINFORCE_PARAM_WEAPON_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ReinforceParamWeapon {

	// 名前：物理攻撃力基本値
	// 説明：物理攻撃力の補正値
	float physicsAtkRate_000;

	// 名前：魔法攻撃力基本値
	// 説明：魔法攻撃力の補正値
	float magicAtkRate_004;

	// 名前：炎攻撃力基本値
	// 説明：炎攻撃力の補正値
	float fireAtkRate_008;

	// 名前：電撃攻撃力基本値
	// 説明：電撃攻撃力の補正値
	float thunderAtkRate_00C;

	// 名前：スタミナ攻撃力
	// 説明：スタミナ攻撃力の補正値
	float staminaAtkRate_010;

	// 名前：SA武器攻撃力
	// 説明：スーパーアーマー武器攻撃色の補正値
	float saWeaponAtkRate_014;

	// 名前：SA耐久値
	// 説明：SA耐久力の補正値
	float saDurabilityRate_018;

	// 名前：筋力補正
	// 説明：筋力補正の補正値
	float correctStrengthRate_01C;

	// 名前：俊敏補正
	// 説明：俊敏補正の補正値
	float correctAgilityRate_020;

	// 名前：魔力補正
	// 説明：魔力補正の補正値
	float correctMagicRate_024;

	// 名前：信仰補正
	// 説明：信仰補正の補正値
	float correctFaithRate_028;

	// 名前：ガード時物理攻撃カット率
	// 説明：ガード時物理攻撃カット率の補正値
	float physicsGuardCutRate_02C;

	// 名前：ガード時魔法攻撃カット率
	// 説明：ガード時魔法攻撃カット率の補正値
	float magicGuardCutRate_030;

	// 名前：ガード時炎攻撃カット率
	// 説明：ガード時炎攻撃カット率の補正値
	float fireGuardCutRate_034;

	// 名前：ガード時電撃攻撃カット率
	// 説明：ガード時電撃攻撃カット率の補正値
	float thunderGuardCutRate_038;

	// 名前：ガード時毒攻撃カット率
	// 説明：ガード時毒攻撃カット率の補正値
	float poisonGuardResistRate_03C;

	// 名前：ガード時疫病攻撃カット率
	// 説明：ガード時疫病攻撃カット率の補正値
	float diseaseGuardResistRate_040;

	// 名前：ガード時出血攻撃カット率
	// 説明：ガード時出血攻撃カット率の補正値
	float bloodGuardResistRate_044;

	// 名前：ガード時呪攻撃カット率
	// 説明：ガード時呪い攻撃カット率の補正値
	float curseGuardResistRate_048;

	// 名前：ガード時スタミナ防御力
	// 説明：ガード時スタミナ防御力の補正値
	float staminaGuardDefRate_04C;

	// 名前：特殊効果ID1
	// 説明：特殊効果ID1の加算補正値
	uint8_t spEffectId1_050;

	// 名前：特殊効果ID2
	// 説明：特殊効果ID2の加算補正値
	uint8_t spEffectId2_051;

	// 名前：特殊効果ID3
	// 説明：特殊効果ID3の加算補正値
	uint8_t spEffectId3_052;

	// 名前：常駐特殊効果ID1
	// 説明：常駐特殊効果ID1の加算補正値
	uint8_t residentSpEffectId1_053;

	// 名前：常駐特殊効果ID2
	// 説明：常駐特殊効果ID2の加算補正値
	uint8_t residentSpEffectId2_054;

	// 名前：常駐特殊効果ID3
	// 説明：常駐特殊効果ID3の加算補正値
	uint8_t residentSpEffectId3_055;

	// 名前：素材ID加算値
	// 説明：素材パラメータIDの加算補正値
	uint8_t materialSetId_056;

	// 名前：最大強化武器レベル用レベル値
	// 説明：最大強化武器レベル用レベル値
	uint8_t maxReinforceLevel_057;

	// 名前：闇攻撃力基本値
	// 説明：闇攻撃力の補正値
	float darkAtkRate_058;

	// 名前：ガード時闇攻撃カット率
	// 説明：ガード時闇攻撃カット率の補正値
	float darkGuardCutRate_05C;

	// 名前：運補正
	// 説明：運補正の補正値
	float correctLuckRate_060;

	// 名前：ガード時冷気攻撃カット率
	// 説明：ガード時冷気攻撃カット率の補正値
	float freezeGuardDefRate_064;

	// 名前：強化価格補正値
	// 説明：武器パラメータの強化価格に乗算する補正値
	float reinforcePriceRate_068;

	// 名前：進化価格補正値
	// 説明：武器パラメータの進化価格に乗算する補正値
	float baseChangePriceRate_06C;

	// 名前：装着可能魔石ランク
	// 説明：装着可能魔石ランク
	int8_t enableGemRank_070;

	// 名前：pad
	uint8_t pad2_071[3];

	// 名前：ガード時睡眠攻撃カット率
	// 説明：ガード時睡眠攻撃カット率の補正値
	float sleepGuardDefRate_074;

	// 名前：ガード時発狂攻撃カット率
	// 説明：ガード時発狂攻撃カット率の補正値
	float madnessGuardDefRate_078;

	// 名前：加算攻撃力倍率
	// 説明：加算攻撃力倍率
	float baseAtkRate_07C;

} ReinforceParamWeapon;

#endif
