/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_RandomAppearEditParam_H
#define _PARAM_RandomAppearEditParam_H
#include <stdint.h>

// RANDOM_APPEAR_EDIT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _RandomAppearEditParam {

	// 名前：同時出現数
	// 説明：同時出現数
	uint32_t appearNum_000;

	// 名前：ランダム出現抽選パラID1
	// 説明：ランダム出現抽選パラID1
	int32_t paramId1_004;

	// 名前：抽選重率1
	// 説明：抽選重率1
	uint32_t rate1_008;

	// 名前：ランダム出現抽選パラID2
	// 説明：ランダム出現抽選パラID2
	int32_t paramId2_00C;

	// 名前：抽選重率2
	// 説明：抽選重率2
	uint32_t rate2_010;

	// 名前：ランダム出現抽選パラID3
	// 説明：ランダム出現抽選パラID3
	int32_t paramId3_014;

	// 名前：抽選重率3
	// 説明：抽選重率3
	uint32_t rate3_018;

	// 名前：ランダム出現抽選パラID4
	// 説明：ランダム出現抽選パラID4
	int32_t paramId4_01C;

	// 名前：抽選重率4
	// 説明：抽選重率4
	uint32_t rate4_020;

	// 名前：ランダム出現抽選パラID5
	// 説明：ランダム出現抽選パラID5
	int32_t paramId5_024;

	// 名前：抽選重率5
	// 説明：抽選重率5
	uint32_t rate5_028;

	// 名前：ランダム出現抽選パラID6
	// 説明：ランダム出現抽選パラID6
	int32_t paramId6_02C;

	// 名前：抽選重率6
	// 説明：抽選重率6
	uint32_t rate6_030;

	// 名前：ランダム出現抽選パラID7
	// 説明：ランダム出現抽選パラID7
	int32_t paramId7_034;

	// 名前：抽選重率7
	// 説明：抽選重率7
	uint32_t rate7_038;

	// 名前：ランダム出現抽選パラID8
	// 説明：ランダム出現抽選パラID8
	int32_t paramId8_03C;

	// 名前：抽選重率8
	// 説明：抽選重率8
	uint32_t rate8_040;

	// 名前：ランダム出現抽選パラID9
	// 説明：ランダム出現抽選パラID9
	int32_t paramId9_044;

	// 名前：抽選重率9
	// 説明：抽選重率9
	uint32_t rate9_048;

	// 名前：ランダム出現抽選パラID10
	// 説明：ランダム出現抽選パラID10
	int32_t paramId10_04C;

	// 名前：抽選重率10
	// 説明：抽選重率10
	uint32_t rate10_050;

	// 名前：ランダム出現抽選パラID11
	// 説明：ランダム出現抽選パラID11
	int32_t paramId11_054;

	// 名前：抽選重率11
	// 説明：抽選重率11
	uint32_t rate11_058;

	// 名前：ランダム出現抽選パラID12
	// 説明：ランダム出現抽選パラID12
	int32_t paramId12_05C;

	// 名前：抽選重率12
	// 説明：抽選重率12
	uint32_t rate12_060;

	// 名前：ランダム出現抽選パラID13
	// 説明：ランダム出現抽選パラID13
	int32_t paramId13_064;

	// 名前：抽選重率13
	// 説明：抽選重率13
	uint32_t rate13_068;

	// 名前：ランダム出現抽選パラID14
	// 説明：ランダム出現抽選パラID14
	int32_t paramId14_06C;

	// 名前：抽選重率14
	// 説明：抽選重率14
	uint32_t rate14_070;

	// 名前：ランダム出現抽選パラID15
	// 説明：ランダム出現抽選パラID15
	int32_t paramId15_074;

	// 名前：抽選重率15
	// 説明：抽選重率15
	uint32_t rate15_078;

	// 名前：ランダム出現抽選パラID16
	// 説明：ランダム出現抽選パラID16
	int32_t paramId16_07C;

	// 名前：抽選重率16
	// 説明：抽選重率16
	uint32_t rate16_080;

	// 名前：ランダム出現抽選パラID17
	// 説明：ランダム出現抽選パラID17
	int32_t paramId17_084;

	// 名前：抽選重率17
	// 説明：抽選重率17
	uint32_t rate17_088;

	// 名前：ランダム出現抽選パラID18
	// 説明：ランダム出現抽選パラID18
	int32_t paramId18_08C;

	// 名前：抽選重率18
	// 説明：抽選重率18
	uint32_t rate18_090;

	// 名前：ランダム出現抽選パラID19
	// 説明：ランダム出現抽選パラID19
	int32_t paramId19_094;

	// 名前：抽選重率19
	// 説明：抽選重率19
	uint32_t rate19_098;

	// 名前：ランダム出現抽選パラID20
	// 説明：ランダム出現抽選パラID20
	int32_t paramId20_09C;

	// 名前：抽選重率20
	// 説明：抽選重率20
	uint32_t rate20_0A0;

	// 名前：ランダム出現抽選パラID21
	// 説明：ランダム出現抽選パラID21
	int32_t paramId21_0A4;

	// 名前：抽選重率21
	// 説明：抽選重率21
	uint32_t rate21_0A8;

	// 名前：ランダム出現抽選パラID22
	// 説明：ランダム出現抽選パラID22
	int32_t paramId22_0AC;

	// 名前：抽選重率22
	// 説明：抽選重率22
	uint32_t rate22_0B0;

	// 名前：ランダム出現抽選パラID23
	// 説明：ランダム出現抽選パラID23
	int32_t paramId23_0B4;

	// 名前：抽選重率23
	// 説明：抽選重率23
	uint32_t rate23_0B8;

	// 名前：ランダム出現抽選パラID24
	// 説明：ランダム出現抽選パラID24
	int32_t paramId24_0BC;

	// 名前：抽選重率24
	// 説明：抽選重率24
	uint32_t rate24_0C0;

} RandomAppearEditParam;

#endif
