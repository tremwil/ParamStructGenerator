/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_LockCamParam_H
#define _PARAM_LockCamParam_H
#include <stdint.h>

// LOCK_CAM_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _LockCamParam {

	// 名前：カメラ距離目標[m]
	// 説明：カメラ距離目標
	float camDistTarget_000;

	// 名前：X軸回転最小値[deg]
	// 説明：X軸回転最小値
	float rotRangeMinX_004;

	// 名前：ロックX回転シフト率(0.0～1.0)
	// 説明：ロックX回転シフト率
	float lockRotXShiftRatio_008;

	// 名前：キャラ基点オフセット(キャラ空間)
	// 説明：キャラ基点オフセット
	float chrOrgOffset_Y_00C;

	// 名前：キャラ範囲最大半径[m]
	// 説明：キャラ範囲最大半径
	float chrLockRangeMaxRadius_010;

	// 名前：縦画角[deg]
	// 説明：縦画角
	float camFovY_014;

	// 名前：暗闇用キャラ範囲最大半径[m]
	// 説明：暗いところでのキャラのロック可能範囲
	float chrLockRangeMaxRadius_forD_018;

	// 名前：真っ暗闇用キャラ範囲最大半径[m]
	// 説明：真っ暗闇でのキャラのロック可能範囲
	float chrLockRangeMaxRadius_forPD_01C;

	// 名前：近接攻撃自動捕捉 上限高さ[m]
	// 説明：非ロックオン時の自動ロックオン判定高さ上限　近接
	float closeMaxHeight_020;

	// 名前：近接攻撃自動捕捉 下限高さ[m]
	// 説明：非ロックオン時の自動ロックオン判定高さ下限　近接
	float closeMinHeight_024;

	// 名前：近接攻撃自動捕捉 角度範囲 左右[deg]
	// 説明：非ロックオン時の自動ロックオン判定左右角度[deg]　近接
	float closeAngRange_028;

	// 名前：近接攻撃自動捕捉 キャラ範囲最大半径[m]
	// 説明：非ロックオン時の自動ロックオン判定距離　近接
	float closeMaxRadius_02C;

	// 名前：近接攻撃自動捕捉 暗闇用キャラ範囲最大半径[m]
	// 説明：非ロックオン時の自動ロックオン判定距離_暗闇　近接
	float closeMaxRadius_forD_030;

	// 名前：近接攻撃自動捕捉 真っ暗闇用キャラ範囲最大半径[m]
	// 説明：非ロックオン時の自動ロックオン_真っ暗　近接
	float closeMaxRadius_forPD_034;

	// 名前：弾丸自動捕捉 キャラ範囲最大半径[m]
	// 説明：非ロックオン時の自動ロックオン判定距離　弾丸
	float bulletMaxRadius_038;

	// 名前：弾丸自動捕捉 暗闇用キャラ範囲最大半径[m]
	// 説明：非ロックオン時の自動ロックオン判定距離_暗闇　弾丸
	float bulletMaxRadius_forD_03C;

	// 名前：弾丸自動捕捉 真っ暗闇用キャラ範囲最大半径[m]
	// 説明：非ロックオン時の自動ロックオン判定距離_真っ暗　弾丸
	float bulletMaxRadius_forPD_040;

	// 名前：弾丸自動捕捉 角度範囲 左右[deg]
	// 説明：非ロックオン時の自動ロックオン左右角度　弾丸
	float bulletAngRange_044;

	// 名前：ロック条件を満たさなくてもロック継続する時間[s]
	// 説明：ロック条件を満たさなくてもロック継続する時間(0.0で無効)
	float lockTgtKeepTime_048;

	// 名前：通常用キャラ並進追尾率
	// 説明：通常用キャラ並進追尾率(-1.0で無効)
	float chrTransChaseRateForNormal_04C;

	// 名前：パディング
	uint8_t pad_050[48];

} LockCamParam;

#endif
