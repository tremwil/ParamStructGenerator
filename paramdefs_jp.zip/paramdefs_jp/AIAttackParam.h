/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AIAttackParam_H
#define _PARAM_AIAttackParam_H
#include <stdint.h>

// AI_ATTACK_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AIAttackParam {

	// 名前：参照ID
	// 説明：NPC思考パラメータで指定するID
	int32_t attackTableId_000;

	// 名前：攻撃ID
	// 説明：攻撃の番号
	int32_t attackId_004;

	// 名前：成功判定距離
	// 説明：Common_Attack系のサブゴールの引数用
	float successDistance_008;

	// 名前：攻撃前旋回時間
	// 説明：Common_Attack系のサブゴールの引数用
	float turnTimeBeforeAttack_00C;

	// 名前：正面判定角度
	// 説明：Common_Attack系のサブゴールの引数用
	int16_t frontAngleRange_010;

	// 名前：上方実行閾値
	// 説明：Common_Attack系のサブゴールの引数用
	int16_t upAngleThreshold_012;

	// 名前：下方実行閾値
	// 説明：Common_Attack系のサブゴールの引数用
	int16_t downAngleThershold_014;

	// 名前：始動技か
	// 説明：コンボの2段目以降の攻撃は×
	uint8_t isFirstAttack_016;

	// 名前：適正距離外で選択するか
	// 説明：適正距離外の時に選択対象にするかどうか
	uint8_t doesSelectOnOutRange_017;

	// 名前：最小適正距離
	// 説明：攻撃の適正距離の最小値
	float minOptimalDistance_018;

	// 名前：最大適正距離
	// 説明：攻撃の適性距離の最大値
	float maxOptimalDistance_01C;

	// 名前：適正角度基準方向1
	// 説明：攻撃の適正角度の基準となる方向（XZ平面）
	int16_t baseDirectionForOptimalAngle1_020;

	// 名前：適正角度基準範囲1
	// 説明：攻撃の適性角度の範囲
	int16_t optimalAttackAngleRange1_022;

	// 名前：適正角度基準方向2
	// 説明：攻撃の適性確度の基準となる方向（XZ平面）
	int16_t baseDirectionForOptimalAngle2_024;

	// 名前：適正角度基準範囲2
	// 説明：攻撃の適性角度の範囲
	int16_t optimalAttackAngleRange2_026;

	// 名前：実行可能インターバル
	// 説明：一度攻撃を行ってから再度使うために必要な時間
	float intervalForExec_028;

	// 名前：選択レート
	// 説明：選択されやすさを倍率で指定する
	float selectionTendency_02C;

	// 名前：近距離選択レート
	// 説明：近距離での選択レート
	float shortRangeTendency_030;

	// 名前：中距離選択レート
	// 説明：中距離での選択レート
	float middleRangeTendency_034;

	// 名前：遠距離選択レート
	// 説明：遠距離での選択レート
	float farRangeTendency_038;

	// 名前：範囲外レート
	// 説明：範囲外での選択レート
	float outRangeTendency_03C;

	// 名前：派生攻撃1
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId1_040;

	// 名前：派生攻撃2
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId2_044;

	// 名前：派生攻撃3
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId3_048;

	// 名前：派生攻撃4
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId4_04C;

	// 名前：派生攻撃5
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId5_050;

	// 名前：派生攻撃6
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId6_054;

	// 名前：派生攻撃7
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId7_058;

	// 名前：派生攻撃8
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId8_05C;

	// 名前：派生攻撃9
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId9_060;

	// 名前：派生攻撃10
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId10_064;

	// 名前：派生攻撃11
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId11_068;

	// 名前：派生攻撃12
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId12_06C;

	// 名前：派生攻撃13
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId13_070;

	// 名前：派生攻撃14
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId14_074;

	// 名前：派生攻撃15
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId15_078;

	// 名前：派生攻撃16
	// 説明：派生可能な攻撃の番号
	int32_t deriveAttackId16_07C;

	// 名前：ゴールの最小寿命
	// 説明：ゴールの最小寿命
	float goalLifeMin_080;

	// 名前：ゴールの最大寿命
	// 説明：ゴールの最大寿命
	float goalLifeMax_084;

	// 名前：適正距離内で選択するか
	// 説明：適正距離内の時に選択対象にするかどうか
	uint8_t doesSelectOnInnerRange_088;

	// 名前：初撃として使用するか
	// 説明：初撃として使用するか
	uint8_t enableAttackOnBattleStart_089;

	// 名前：ターゲットダウン時選択するか
	// 説明：ターゲットダウン時選択するか
	uint8_t doesSelectOnTargetDown_08A;

	// 名前：pad
	uint8_t pad1_08B[1];

	// 名前：最小到達判定距離
	// 説明：最小到達判定距離
	float minArriveDistance_08C;

	// 名前：最大到達判定距離
	// 説明：最大到達判定距離
	float maxArriveDistance_090;

	// 名前：連続攻撃実行距離
	// 説明：二段目以降の攻撃の実行判定に使用する距離
	float comboExecDistance_094;

	// 名前：連続攻撃実行角度
	// 説明：二段目以降の攻撃の実行判定に使用する距離
	float comboExecRange_098;

} AIAttackParam;

#endif
