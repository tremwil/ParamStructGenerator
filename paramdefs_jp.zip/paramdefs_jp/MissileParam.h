/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MissileParam_H
#define _PARAM_MissileParam_H
#include <stdint.h>

// MISSILE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MissileParam {

	// 名前：FFXID
	// 説明：ＦＦＸエディタ上のＩＤ
	int32_t FFXID_000;

	// 名前：生存時間[frame]
	// 説明：生存時間。
	uint16_t LifeTime_004;

	// 名前：当たり球半径[cm]
	// 説明：当たり球半径。単位cm
	uint16_t HitSphereRadius_006;

	// 名前：着弾ダメージ
	// 説明：着弾時のダメージ量
	uint16_t HitDamage_008;

	// 名前：予約
	uint8_t reserve0_00A[6];

	// 名前：初速度[m/s]
	// 説明：初速度[m/s]
	float InitVelocity_010;

	// 名前：射程距離
	// 説明：射程距離
	float distance_014;

	// 名前：射程距離内重力
	// 説明：射程距離内重力
	float gravityInRange_018;

	// 名前：射程距離外重力
	// 説明：射程距離外重力
	float gravityOutRange_01C;

	// 名前：消費MP
	// 説明：消費MP
	int32_t mp_020;

	// 名前：射程距離内加速度
	// 説明：射程距離内加速度
	float accelInRange_024;

	// 名前：射程距離外加速度
	// 説明：射程距離外加速度
	float accelOutRange_028;

	// 名前：予約
	uint8_t reserve1_02C[20];

	// 名前：着弾ＩＤ
	// 説明：着弾ＩＤ
	uint16_t HitMissileID_040;

	// 名前：寿命で死ぬか？
	// 説明：着弾しても、死なずに、寿命を使い切るか？
	uint8_t DiedNaturaly_042;

	// 名前：寿命が切れたときに着弾するか
	// 説明：寿命が切れたときに着弾するか
	uint8_t ExplosionDie_043;

	// 名前：ヒット時行動ID
	// 説明：ダメージを与えたとき相手に与える行動ID
	int32_t behaviorId_044;

	// 名前：予約
	uint8_t reserve_last_048[56];

} MissileParam;

#endif
