/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_ShaderQuality_H
#define _PARAM_Gconfig_ShaderQuality_H
#include <stdint.h>

// CS_SHADER_QUALITY_DETAIL
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_ShaderQuality {

	// 名前：SSS有効
	// 説明：SSS有効
	uint8_t sssEnabled_000;

	// 名前：テッセレーション有効
	// 説明：テッセレーション有効
	uint8_t tessellationEnabled_001;

	// 名前：高精度ノーマル有効
	// 説明：高精度ノーマル有効(G-Bufferに格納する法線の精度の設定)
	uint8_t highPrecisionNormalEnabled_002;

	// 名前：dmy
	char dmy_003[1];

} Gconfig_ShaderQuality;

#endif
