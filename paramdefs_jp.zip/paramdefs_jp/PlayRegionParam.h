/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PlayRegionParam_H
#define _PARAM_PlayRegionParam_H
#include <stdint.h>

// PLAY_REGION_PARAM_ST
// Data Version: 9
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _PlayRegionParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：簡易マッチエリアID
	// 説明：簡易マッチエリアID
	int32_t matchAreaId_004;

	// 名前：マルチプレイ開始制限イベントフラグID
	// 説明：マルチプレイ開始制限イベントフラグID
	uint32_t multiPlayStartLimitEventFlagId_008;

	// 名前：その他霊侵入不可能距離
	// 説明：その他霊侵入不可能距離。ホスト位置から「その他霊侵入不可能距離」～「その他霊侵入範囲上限」以内の侵入ポイントを対象に侵入位置検索を行う。
	float otherDisableDistance_00C;

	// 名前：PC位置セーブ制限イベントフラグID
	// 説明：PC位置セーブ制限イベントフラグID　（フラグON：PC位置セーブ有効　フラグOFF：PC位置セーブ無効　0：PC位置セーブ常に有効）
	uint32_t pcPositionSaveLimitEventFlagId_010;

	// 名前：ボスエリアID
	// 説明：このIDが同じものを設定された領域同士は、同一のボスエリアとして扱う。
	uint32_t bossAreaId_014;

	// 名前：NPC白霊召喚儀式の召還NPCのエンティティIDの自由枠ID
	// 説明：NPC白霊召喚儀式の召還NPCのエンティティIDとして使われる自由枠IDの先頭
	int16_t cultNpcWhiteGhostEntityId_byFree_018;

	// 名前：マップ守護領域か？
	// 説明：マップ守護領域の枠の増減にするか
	uint8_t bMapGuradianRegion_01A;

	// 名前：黄衣の翁サイン領域か？
	// 説明：黄衣の翁サイン領域か？
	uint8_t bYellowCostumeRegion_01B: 1;

	// 名前：制限するフラグ状態
	// 説明：「マルチプレイ開始制限イベントフラグID」の制限を行うフラグ状態
	uint8_t multiPlayStartLimitEventFlagId_targetFlagState_01B: 1;

	// 名前：制限するフラグ状態
	// 説明：「侵入制限イベントフラグID1」の制限を行うフラグ状態
	uint8_t breakInLimitEventFlagId_1_targetFlagState_01B: 1;

	// 名前：制限するフラグ状態
	// 説明：「白サイン制限イベントフラグID1」の制限を行うフラグ状態
	uint8_t whiteSignLimitEventFlagId_1_targetFlagState_01B: 1;

	// 名前：制限するフラグ状態
	// 説明：「赤サイン制限イベントフラグID1」の制限を行うフラグ状態
	uint8_t redSignLimitEventFlagId_1_targetFlagState_01B: 1;

	// 名前：制限するフラグ状態
	// 説明：「侵入制限イベントフラグID2」の制限を行うフラグ状態
	uint8_t breakInLimitEventFlagId_2_targetFlagState_01B: 1;

	// 名前：制限するフラグ状態
	// 説明：「侵入制限イベントフラグID3」の制限を行うフラグ状態
	uint8_t breakInLimitEventFlagId_3_targetFlagState_01B: 1;

	// 名前：制限するフラグ状態
	// 説明：「白サイン制限イベントフラグID2」の制限を行うフラグ状態
	uint8_t whiteSignLimitEventFlagId_2_targetFlagState_01B: 1;

	// 名前：ワープアイテム許可篝火ID1
	// 説明：ワープアイテムの使用を許可する判定に使う篝火のエンティティID1
	uint32_t warpItemUsePermitBonfireId_1_01C;

	// 名前：ワープアイテム許可篝火ID2
	// 説明：ワープアイテムの使用を許可する判定に使う篝火のエンティティID2
	uint32_t warpItemUsePermitBonfireId_2_020;

	// 名前：ワープアイテム許可篝火ID3
	// 説明：ワープアイテムの使用を許可する判定に使う篝火のエンティティID3
	uint32_t warpItemUsePermitBonfireId_3_024;

	// 名前：ワープアイテム許可篝火ID4
	// 説明：ワープアイテムの使用を許可する判定に使う篝火のエンティティID4
	uint32_t warpItemUsePermitBonfireId_4_028;

	// 名前：ワープアイテム許可篝火ID5
	// 説明：ワープアイテムの使用を許可する判定に使う篝火のエンティティID5
	uint32_t warpItemUsePermitBonfireId_5_02C;

	// 名前：ワープアイテム禁止イベントフラグID1
	// 説明：ワープアイテムの使用禁止を判定するイベントフラグID1。ワープアイテム許可篝火IDによる判定より優先度が上
	uint32_t warpItemProhibitionEventFlagId_1_030;

	// 名前：ワープアイテム禁止イベントフラグID2
	// 説明：ワープアイテムの使用禁止を判定するイベントフラグID2。ワープアイテム許可篝火IDによる判定より優先度が上
	uint32_t warpItemProhibitionEventFlagId_2_034;

	// 名前：ワープアイテム禁止イベントフラグID3
	// 説明：ワープアイテムの使用禁止を判定するイベントフラグID3。ワープアイテム許可篝火IDによる判定より優先度が上
	uint32_t warpItemProhibitionEventFlagId_3_038;

	// 名前：ワープアイテム禁止イベントフラグID4
	// 説明：ワープアイテムの使用禁止を判定するイベントフラグID4。ワープアイテム許可篝火IDによる判定より優先度が上
	uint32_t warpItemProhibitionEventFlagId_4_03C;

	// 名前：ワープアイテム禁止イベントフラグID5
	// 説明：ワープアイテムの使用禁止を判定するイベントフラグID5。ワープアイテム許可篝火IDによる判定より優先度が上
	uint32_t warpItemProhibitionEventFlagId_5_040;

	// 名前：血痕・死亡幻影有効
	// 説明：血痕・死亡幻影有効
	uint8_t enableBloodstain_044: 1;

	// 名前：血文字有効
	// 説明：血文字有効
	uint8_t enableBloodMessage_044: 1;

	// 名前：幻影有効
	// 説明：幻影有効
	uint8_t enableGhost_044: 1;

	// 名前：地図表示用_表示設定M00
	// 説明：地図M00で表示するか
	uint8_t dispMask00_044: 1;

	// 名前：地図表示用_表示設定M01
	// 説明：地図M01で表示するか
	uint8_t dispMask01_044: 1;

	// 名前：制限するフラグ状態
	// 説明：「白サイン制限イベントフラグID3」の制限を行うフラグ状態
	uint8_t whiteSignLimitEventFlagId_3_targetFlagState_044: 1;

	// 名前：制限するフラグ状態
	// 説明：「赤サイン制限イベントフラグID2」の制限を行うフラグ状態
	uint8_t redSignLimitEventFlagId_2_targetFlagState_044: 1;

	// 名前：制限するフラグ状態
	// 説明：「赤サイン制限イベントフラグID3」の制限を行うフラグ状態
	uint8_t redSignLimitEventFlagId_3_targetFlagState_044: 1;

	// 名前：侵入ポイント自動生成か
	// 説明：侵入ポイント自動生成か。○にした場合は自動生成された侵入ポイント用のロジックで侵入位置を検索。
	uint8_t isAutoIntrudePoint_045: 1;

	// 名前：pad1
	uint8_t pad1_045: 7;

	// 名前：pad2
	uint8_t pad2_046[2];

	// 名前：黄衣の翁ホスト制限イベントフラグ
	// 説明：黄衣の翁ホスト制限イベントフラグ：このフラグがONになると黄衣の翁のホストとしてのマルチプレイが禁止される。ブロッククリアフラグを入れる想定。0：制限しない
	uint32_t multiPlayHASHostLimitEventFlagId_048;

	// 名前：その他霊侵入範囲上限
	// 説明：その他霊侵入範囲上限。ホスト位置から「その他霊侵入不可能距離」～「その他霊侵入範囲上限」以内の侵入ポイントを対象に侵入位置検索を行う。
	float otherMaxDistance_04C;

	// 名前：サイン溜まり解放イベントフラグID
	// 説明：サイン溜まり解放イベントフラグID
	uint32_t signPuddleOpenEventFlagId_050;

	// 名前：地図表示用_エリア番号（mXX_00_00_00）
	// 説明：エリア番号（mXX_00_00_00）。地図メニューでの表示位置を指定するためのデータ
	uint8_t areaNo_054;

	// 名前：地図表示用_グリッドX番号（m00_XX_00_00）
	// 説明：グリッドX番号（m00_XX_00_00）。地図メニューでの表示位置を指定するためのデータ
	uint8_t gridXNo_055;

	// 名前：地図表示用_グリッドZ番号（m00_00_XX_00）
	// 説明：グリッドZ番号（m00_00_XX_00）。地図メニューでの表示位置を指定するためのデータ
	uint8_t gridZNo_056;

	// 名前：pad4
	uint8_t pad4_057[1];

	// 名前：地図表示用_X座標
	// 説明：X座標（指定したマップからの相対座標）。地図メニューでの表示位置を指定するためのデータ
	float posX_058;

	// 名前：地図表示用_Y座標
	// 説明：Y座標（指定したマップからの相対座標）。地図メニューでの表示位置を指定するためのデータ。実際には使われていないがXYZ一揃えにしておく
	float posY_05C;

	// 名前：地図表示用_Z座標
	// 説明：Z座標（指定したマップからの相対座標）。地図メニューでの表示位置を指定するためのデータ
	float posZ_060;

	// 名前：侵入制限イベントフラグID1
	// 説明：侵入制限イベントフラグID1
	uint32_t breakInLimitEventFlagId_1_064;

	// 名前：白サイン制限イベントフラグID1
	// 説明：白サイン制限イベントフラグID1
	uint32_t whiteSignLimitEventFlagId_1_068;

	// 名前：サイン溜まり登録制限イベントフラグID
	// 説明：サイン溜まり登録制限イベントフラグID　（フラグON：サイン溜まり登録を許可　フラグOFF：サイン溜まり登録を禁止　0：サイン溜まり登録を常に許可）
	uint32_t matchAreaSignCreateLimitEventFlagId_06C;

	// 名前：マルチ目的ID01
	// 説明：目的設定時にリストに表示するマルチ目的ID
	uint32_t signAimId_1_070;

	// 名前：マルチ目的ID02
	// 説明：目的設定時にリストに表示するマルチ目的ID
	uint32_t signAimId_2_074;

	// 名前：マルチ目的ID03
	// 説明：目的設定時にリストに表示するマルチ目的ID
	uint32_t signAimId_3_078;

	// 名前：マルチ目的ID04
	// 説明：目的設定時にリストに表示するマルチ目的ID
	uint32_t signAimId_4_07C;

	// 名前：マルチ目的ID05
	// 説明：目的設定時にリストに表示するマルチ目的ID
	uint32_t signAimId_5_080;

	// 名前：マルチ目的ID06
	// 説明：目的設定時にリストに表示するマルチ目的ID
	uint32_t signAimId_6_084;

	// 名前：マルチ目的ID07
	// 説明：目的設定時にリストに表示するマルチ目的ID
	uint32_t signAimId_7_088;

	// 名前：マルチ目的ID08
	// 説明：目的設定時にリストに表示するマルチ目的ID
	uint32_t signAimId_8_08C;

	// 名前：赤サイン制限イベントフラグID1
	// 説明：赤サイン制限イベントフラグID1
	uint32_t redSignLimitEventFlagId_1_090;

	// 名前：侵入制限イベントフラグID2
	// 説明：侵入制限イベントフラグID2
	uint32_t breakInLimitEventFlagId_2_094;

	// 名前：侵入制限イベントフラグID3
	// 説明：侵入制限イベントフラグID3
	uint32_t breakInLimitEventFlagId_3_098;

	// 名前：白サイン制限イベントフラグID2
	// 説明：白サイン制限イベントフラグID2
	uint32_t whiteSignLimitEventFlagId_2_09C;

	// 名前：白サイン制限イベントフラグID3
	// 説明：白サイン制限イベントフラグID3
	uint32_t whiteSignLimitEventFlagId_3_0A0;

	// 名前：赤サイン制限イベントフラグID2
	// 説明：赤サイン制限イベントフラグID2
	uint32_t redSignLimitEventFlagId_2_0A4;

	// 名前：赤サイン制限イベントフラグID3
	// 説明：赤サイン制限イベントフラグID3
	uint32_t redSignLimitEventFlagId_3_0A8;

	// 名前：領域内ボスID01
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_1_0AC;

	// 名前：領域内ボスID02
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_2_0B0;

	// 名前：領域内ボスID03
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_3_0B4;

	// 名前：領域内ボスID04
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_4_0B8;

	// 名前：領域内ボスID05
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_5_0BC;

	// 名前：領域内ボスID06
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_6_0C0;

	// 名前：領域内ボスID07
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_7_0C4;

	// 名前：領域内ボスID08
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_8_0C8;

	// 名前：領域内ボスID09
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_9_0CC;

	// 名前：領域内ボスID10
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_10_0D0;

	// 名前：領域内ボスID11
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_11_0D4;

	// 名前：領域内ボスID12
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_12_0D8;

	// 名前：領域内ボスID13
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_13_0DC;

	// 名前：領域内ボスID14
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_14_0E0;

	// 名前：領域内ボスID15
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_15_0E4;

	// 名前：領域内ボスID16
	// 説明：領域内ボスID。「侵入ポイント自動生成か」が○のときに目的とするボスを選ぶのに使われる。
	uint32_t bossId_16_0E8;

	// 名前：地図表示用_イベントフラグID
	// 説明：地図表示用_イベントフラグID(0:常に表示)。このイベントフラグが立っているときだけ、マップメニューに賑わい表示される
	uint32_t mapMenuUnlockEventId_0EC;

	// 名前：pad5
	uint8_t pad5_0F0[32];

} PlayRegionParam;

#endif
