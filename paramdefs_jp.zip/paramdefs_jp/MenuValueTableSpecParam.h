/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MenuValueTableSpecParam_H
#define _PARAM_MenuValueTableSpecParam_H
#include <stdint.h>

// MENU_VALUE_TABLE_SPEC
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MenuValueTableSpecParam {

	// 名前：比較する値
	// 説明：比較する値
	int32_t value_000;

	// 名前：変換後のテキストID
	// 説明：変換後のテキストID
	int32_t textId_004;

	// 名前：比較タイプ
	// 説明：比較タイプ
	int8_t compareType_008;

	// 名前：パディング
	// 説明：パディング
	uint8_t padding_009[3];

} MenuValueTableSpecParam;

#endif
