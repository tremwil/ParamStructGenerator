/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_DefaultKeyAssign_H
#define _PARAM_DefaultKeyAssign_H
#include <stdint.h>

// DEFAULT_KEY_ASSIGN
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 202
typedef struct _DefaultKeyAssign {

	// 名前：パッド0
	// 説明：下位抑制パッド0
	uint8_t priority0_000: 1;

	// 名前：GUIフレームワーク用
	// 説明：下位抑制GUIフレームワーク用パッド
	uint8_t priority1_000: 1;

	// 名前：パッド2
	// 説明：下位抑制パッド2
	uint8_t priority2_000: 1;

	// 名前：デバッグメニューモード切替
	// 説明：下位抑制デバッグメニューモード切替パッド
	uint8_t priority3_000: 1;

	// 名前：パッド4
	// 説明：下位抑制パッド4
	uint8_t priority4_000: 1;

	// 名前：パッドデバッグメニュー
	// 説明：下位抑制パッドデバッグメニューパッド
	uint8_t priority5_000: 1;

	// 名前：パッド6
	// 説明：下位抑制パッド6
	uint8_t priority6_000: 1;

	// 名前：パッド7
	// 説明：下位抑制パッド7
	uint8_t priority7_000: 1;

	// 名前：パッド8
	// 説明：下位抑制パッド8
	uint8_t priority8_001: 1;

	// 名前：パッド9
	// 説明：下位抑制パッド9
	uint8_t priority9_001: 1;

	// 名前：パッド10
	// 説明：下位抑制パッド10
	uint8_t priority10_001: 1;

	// 名前：パッド11
	// 説明：下位抑制パッド11
	uint8_t priority11_001: 1;

	// 名前：パッド12
	// 説明：下位抑制パッド12
	uint8_t priority12_001: 1;

	// 名前：パッド13
	// 説明：下位抑制パッド13
	uint8_t priority13_001: 1;

	// 名前：パッド14
	// 説明：下位抑制パッド14
	uint8_t priority14_001: 1;

	// 名前：パッド15
	// 説明：下位抑制パッド15
	uint8_t priority15_001: 1;

	// 名前：パッド16
	// 説明：下位抑制パッド16
	uint8_t priority16_002: 1;

	// 名前：パッド17
	// 説明：下位抑制パッド17
	uint8_t priority17_002: 1;

	// 名前：パッド18
	// 説明：下位抑制パッド18
	uint8_t priority18_002: 1;

	// 名前：パッド19
	// 説明：下位抑制パッド19
	uint8_t priority19_002: 1;

	// 名前：パッド20
	// 説明：下位抑制パッド20
	uint8_t priority20_002: 1;

	// 名前：パッド21
	// 説明：下位抑制パッド21
	uint8_t priority21_002: 1;

	// 名前：パッド22
	// 説明：下位抑制パッド22
	uint8_t priority22_002: 1;

	// 名前：パッド23
	// 説明：下位抑制パッド23
	uint8_t priority23_002: 1;

	// 名前：パッド24
	// 説明：下位抑制パッド24
	uint8_t priority24_003: 1;

	// 名前：パッド25
	// 説明：下位抑制パッド25
	uint8_t priority25_003: 1;

	// 名前：パッド26
	// 説明：下位抑制パッド26
	uint8_t priority26_003: 1;

	// 名前：パッド27
	// 説明：下位抑制パッド27
	uint8_t priority27_003: 1;

	// 名前：パッド28
	// 説明：下位抑制パッド28
	uint8_t priority28_003: 1;

	// 名前：パッド29
	// 説明：下位抑制パッド29
	uint8_t priority29_003: 1;

	// 名前：パッド30
	// 説明：下位抑制パッド30
	uint8_t priority30_003: 1;

	// 名前：パッド31
	// 説明：下位抑制パッド31
	uint8_t priority31_003: 1;

	// 名前：ダミー
	uint8_t dummy_004[12];

	// 名前：パッド物理キー
	// 説明：パッド物理キー
	int32_t phyisicalKey_010;

	// 名前：押され方
	// 説明：押され方
	uint8_t traitsType_014;

	// 名前：アナログ→デジタル変換方法
	// 説明：アナログ→デジタル変換方法
	uint8_t a2dOperator_015;

	// 名前：適用ターゲット
	// 説明：反映ターゲット
	uint8_t applyTarget_016;

	// 名前：デジタル・アナログ
	// 説明：デジタルorアナログ
	uint8_t isAnalog_017: 1;

	// 名前：Win64
	// 説明：Win64で使用されるか
	uint8_t enableWin64_017: 1;

	// 名前：PS4
	// 説明：PS4で使用されるか
	uint8_t enablePS4_017: 1;

	// 名前：XboxOne
	// 説明：XboxOneで使用されるか
	uint8_t enableXboxOne_017: 1;

	// 名前：時間
	// 説明：時間
	float time1_017;

	// 名前：リピート用インターバル時間
	// 説明：リピート用インターバル時間
	float time2_01B;

	// 名前：アナログ→デジタル変換閾値
	// 説明：アナログ→デジタル変換閾値
	float a2dThreshold_01F;

	// 名前：パッド物理キー
	// 説明：パッド物理キー
	int32_t phyisicalKey_023;

	// 名前：押され方
	// 説明：押され方
	uint8_t traitsType_027;

	// 名前：アナログ→デジタル変換方法
	// 説明：アナログ→デジタル変換方法
	uint8_t a2dOperator_028;

	// 名前：適用ターゲット
	// 説明：反映ターゲット
	uint8_t applyTarget_029;

	// 名前：デジタル・アナログ
	// 説明：デジタルorアナログ
	uint8_t isAnalog_02A: 1;

	// 名前：Win64
	// 説明：Win64で使用されるか
	uint8_t enableWin64_02A: 1;

	// 名前：PS4
	// 説明：PS4で使用されるか
	uint8_t enablePS4_02A: 1;

	// 名前：XboxOne
	// 説明：XboxOneで使用されるか
	uint8_t enableXboxOne_02A: 1;

	// 名前：時間
	// 説明：時間
	float time1_02B;

	// 名前：リピート用インターバル時間
	// 説明：リピート用インターバル時間
	float time2_02F;

	// 名前：アナログ→デジタル変換閾値
	// 説明：アナログ→デジタル変換閾値
	float a2dThreshold_033;

	// 名前：パッド物理キー
	// 説明：パッド物理キー
	int32_t phyisicalKey_037;

	// 名前：押され方
	// 説明：押され方
	uint8_t traitsType_03B;

	// 名前：アナログ→デジタル変換方法
	// 説明：アナログ→デジタル変換方法
	uint8_t a2dOperator_03C;

	// 名前：適用ターゲット
	// 説明：反映ターゲット
	uint8_t applyTarget_03D;

	// 名前：デジタル・アナログ
	// 説明：デジタルorアナログ
	uint8_t isAnalog_03E: 1;

	// 名前：Win64
	// 説明：Win64で使用されるか
	uint8_t enableWin64_03E: 1;

	// 名前：PS4
	// 説明：PS4で使用されるか
	uint8_t enablePS4_03E: 1;

	// 名前：XboxOne
	// 説明：XboxOneで使用されるか
	uint8_t enableXboxOne_03E: 1;

	// 名前：時間
	// 説明：時間
	float time1_03E;

	// 名前：リピート用インターバル時間
	// 説明：リピート用インターバル時間
	float time2_042;

	// 名前：アナログ→デジタル変換閾値
	// 説明：アナログ→デジタル変換閾値
	float a2dThreshold_046;

	// 名前：パッド物理キー
	// 説明：パッド物理キー
	int32_t phyisicalKey_04A;

	// 名前：押され方
	// 説明：押され方
	uint8_t traitsType_04E;

	// 名前：アナログ→デジタル変換方法
	// 説明：アナログ→デジタル変換方法
	uint8_t a2dOperator_04F;

	// 名前：適用ターゲット
	// 説明：反映ターゲット
	uint8_t applyTarget_050;

	// 名前：デジタル・アナログ
	// 説明：デジタルorアナログ
	uint8_t isAnalog_051: 1;

	// 名前：Win64
	// 説明：Win64で使用されるか
	uint8_t enableWin64_051: 1;

	// 名前：PS4
	// 説明：PS4で使用されるか
	uint8_t enablePS4_051: 1;

	// 名前：XboxOne
	// 説明：XboxOneで使用されるか
	uint8_t enableXboxOne_051: 1;

	// 名前：時間
	// 説明：時間
	float time1_052;

	// 名前：リピート用インターバル時間
	// 説明：リピート用インターバル時間
	float time2_056;

	// 名前：アナログ→デジタル変換閾値
	// 説明：アナログ→デジタル変換閾値
	float a2dThreshold_05A;

	// 名前：PC物理キー
	// 説明：PC物理キー
	int32_t phyisicalKey_05E;

	// 名前：押され方
	// 説明：押され方
	uint8_t traitsType_062;

	// 名前：アナログ→デジタル変換方法
	// 説明：アナログ→デジタル変換方法
	uint8_t a2dOperator_063;

	// 名前：適用ターゲット
	// 説明：反映ターゲット
	uint8_t applyTarget_064;

	// 名前：デジタル・アナログ
	// 説明：デジタルorアナログ
	uint8_t isAnalog_065: 1;

	// 名前：Win64
	// 説明：Win64で使用されるか
	uint8_t enableWin64_065: 1;

	// 名前：PS4
	// 説明：PS4で使用されるか
	uint8_t enablePS4_065: 1;

	// 名前：XboxOne
	// 説明：XboxOneで使用されるか
	uint8_t enableXboxOne_065: 1;

	// 名前：時間
	// 説明：時間
	float time1_065;

	// 名前：リピート用インターバル時間
	// 説明：リピート用インターバル時間
	float time2_069;

	// 名前：アナログ→デジタル変換閾値
	// 説明：アナログ→デジタル変換閾値
	float a2dThreshold_06D;

	// 名前：PC物理キー
	// 説明：PC物理キー
	int32_t phyisicalKey_071;

	// 名前：押され方
	// 説明：押され方
	uint8_t traitsType_075;

	// 名前：アナログ→デジタル変換方法
	// 説明：アナログ→デジタル変換方法
	uint8_t a2dOperator_076;

	// 名前：適用ターゲット
	// 説明：反映ターゲット
	uint8_t applyTarget_077;

	// 名前：デジタル・アナログ
	// 説明：デジタルorアナログ
	uint8_t isAnalog_078: 1;

	// 名前：Win64
	// 説明：Win64で使用されるか
	uint8_t enableWin64_078: 1;

	// 名前：PS4
	// 説明：PS4で使用されるか
	uint8_t enablePS4_078: 1;

	// 名前：XboxOne
	// 説明：XboxOneで使用されるか
	uint8_t enableXboxOne_078: 1;

	// 名前：時間
	// 説明：時間
	float time1_079;

	// 名前：リピート用インターバル時間
	// 説明：リピート用インターバル時間
	float time2_07D;

	// 名前：アナログ→デジタル変換閾値
	// 説明：アナログ→デジタル変換閾値
	float a2dThreshold_081;

	// 名前：PC物理キー
	// 説明：PC物理キー
	int32_t phyisicalKey_085;

	// 名前：押され方
	// 説明：押され方
	uint8_t traitsType_089;

	// 名前：アナログ→デジタル変換方法
	// 説明：アナログ→デジタル変換方法
	uint8_t a2dOperator_08A;

	// 名前：適用ターゲット
	// 説明：反映ターゲット
	uint8_t applyTarget_08B;

	// 名前：デジタル・アナログ
	// 説明：デジタルorアナログ
	uint8_t isAnalog_08C: 1;

	// 名前：Win64
	// 説明：Win64で使用されるか
	uint8_t enableWin64_08C: 1;

	// 名前：PS4
	// 説明：PS4で使用されるか
	uint8_t enablePS4_08C: 1;

	// 名前：XboxOne
	// 説明：XboxOneで使用されるか
	uint8_t enableXboxOne_08C: 1;

	// 名前：時間
	// 説明：時間
	float time1_08C;

	// 名前：リピート用インターバル時間
	// 説明：リピート用インターバル時間
	float time2_090;

	// 名前：アナログ→デジタル変換閾値
	// 説明：アナログ→デジタル変換閾値
	float a2dThreshold_094;

	// 名前：PC物理キー
	// 説明：PC物理キー
	int32_t phyisicalKey_098;

	// 名前：押され方
	// 説明：押され方
	uint8_t traitsType_09C;

	// 名前：アナログ→デジタル変換方法
	// 説明：アナログ→デジタル変換方法
	uint8_t a2dOperator_09D;

	// 名前：適用ターゲット
	// 説明：反映ターゲット
	uint8_t applyTarget_09E;

	// 名前：デジタル・アナログ
	// 説明：デジタルorアナログ
	uint8_t isAnalog_09F: 1;

	// 名前：Win64
	// 説明：Win64で使用されるか
	uint8_t enableWin64_09F: 1;

	// 名前：PS4
	// 説明：PS4で使用されるか
	uint8_t enablePS4_09F: 1;

	// 名前：XboxOne
	// 説明：XboxOneで使用されるか
	uint8_t enableXboxOne_09F: 1;

	// 名前：時間
	// 説明：時間
	float time1_0A0;

	// 名前：リピート用インターバル時間
	// 説明：リピート用インターバル時間
	float time2_0A4;

	// 名前：アナログ→デジタル変換閾値
	// 説明：アナログ→デジタル変換閾値
	float a2dThreshold_0A8;

} DefaultKeyAssign;

#endif
