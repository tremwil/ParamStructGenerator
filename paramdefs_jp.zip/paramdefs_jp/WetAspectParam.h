/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WetAspectParam_H
#define _PARAM_WetAspectParam_H
#include <stdint.h>

// WET_ASPECT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WetAspectParam {

	// 名前：ベースカラー 値R
	// 説明：ベースカラー色Rです。
	uint8_t baseColorR_000;

	// 名前：ベースカラー 値G
	// 説明：ベースカラー色Gです。
	uint8_t baseColorG_001;

	// 名前：ベースカラー 値B
	// 説明：ベースカラー色Bです。
	uint8_t baseColorB_002;

	// 名前：予備1
	uint8_t reserve_0_003[1];

	// 名前：ベースカラー ％
	// 説明：ベースカラーのオーバーライド率です。 
	float baseColorA_004;

	// 名前：メタリック 値
	// 説明：メタリックです。
	uint8_t metallic_008;

	// 名前：予備2
	uint8_t reserve_1_009[1];

	// 名前：予備3
	uint8_t reserve_2_00A[1];

	// 名前：予備4
	uint8_t reserve_3_00B[1];

	// 名前：メタリック ％
	// 説明：メタリックのオーバーライド率です。
	float metallicRate_00C;

	// 名前：シャイニネス ％
	// 説明：シャイニネスのオーバーライド率です。
	float shininessRate_010;

	// 名前：シャイニネス 値
	// 説明：シャイニネスです。 
	uint8_t shininess_014;

	// 名前：予備5
	uint8_t reserve_4_015[11];

} WetAspectParam;

#endif
