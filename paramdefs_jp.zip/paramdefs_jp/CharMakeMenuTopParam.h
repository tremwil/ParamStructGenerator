/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CharMakeMenuTopParam_H
#define _PARAM_CharMakeMenuTopParam_H
#include <stdint.h>

// CHARMAKEMENUTOP_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CharMakeMenuTopParam {

	// 名前：コマンドタイプ
	// 説明：コマンドの種別
	int32_t commandType_000;

	// 名前：項目テキストID
	// 説明：表示するテキストのID
	int32_t captionId_004;

	// 名前：顔パラムID
	// 説明：顔パラムID
	int32_t faceParamId_008;

	// 名前：テーブルID（男性）
	// 説明：選択するアイテム一覧の先頭ID（男）。コマンドタイプが[スライダー：最小値ラベル(n)と最大値ラベル(n+1)のテキストID、カラー：カラーテーブルのID、グリッド or テキスト：キャラメイクリストアイテムの先頭ID、それ以外：無視]
	int32_t tableId_00C;

	// 名前：表示条件
	// 説明：このコマンドを表示する条件
	int32_t viewCondition_010;

	// 名前：プレビューモード
	// 説明：プレビュー表示しているキャラクターモデルの表示モード
	int8_t previewMode_014;

	// 名前：予約
	uint8_t reserved2_015[3];

	// 名前：テーブルID（女性）
	// 説明：テーブルIDの女用。-1なら男用を参照する
	int32_t tableId2_018;

	// 名前：参照先の顔パラムID
	// 説明：「○○に合わせる」用の合わせ先の顔パラムID
	int32_t refFaceParamId_01C;

	// 名前：参照先テキストID
	// 説明：「○○に合わせる」用の表示テキストID
	int32_t refTextId_020;

	// 名前：1行ヘルプテキストID（上書き）
	// 説明：1行ヘルプのテキストID(-1: 項目テキストIDで1行ヘルプを取得する)。基本的に項目テキストID＝1行ヘルプテキストIDになっているが、一部上書きしたいときにこのパラメータで指定する
	int32_t helpTextId_024;

	// 名前：イベントフラグID
	// 説明：この項目をアンロックするイベントフラグ(0:無効値)。無効値なら常にアンロックされる
	uint32_t unlockEventFlagId_028;

	// 名前：予約
	uint8_t reserved_02C[4];

} CharMakeMenuTopParam;

#endif
