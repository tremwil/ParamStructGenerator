/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WeatherAssetReplaceParam_H
#define _PARAM_WeatherAssetReplaceParam_H
#include <stdint.h>

// WEATHER_ASSET_REPLACE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WeatherAssetReplaceParam {

	// 名前：マップ番号
	// 説明：マップ番号を8桁で指定します。オープン、レガシーの天球配置マップのみ指定可能です
	uint32_t mapId_000;

	// 名前：天候
	// 説明：この天候で有効になるアセットを指定します。
	int16_t TransitionSrcWeather_004;

	// 名前：reserved0
	uint8_t padding0_006[2];

	// 名前：「火の灰」後か？
	// 説明：マップの「火の灰」状態での適応の有無を指定します。
	uint8_t isFireAsh_008;

	// 名前：padding0
	uint8_t padding1_009[3];

	// 名前：reserved2
	uint32_t reserved2_00C;

	// 名前：表示アセット1
	// 説明：-1:無効 生成するアセットIDを指定します。AEG999_999 -> 999999
	int32_t AssetId0_010;

	// 名前：表示アセット2
	// 説明：-1:無効 生成するアセットIDを指定します。AEG999_999 -> 999999
	int32_t AssetId1_014;

	// 名前：表示アセット3
	// 説明：-1:無効 生成するアセットIDを指定します。AEG999_999 -> 999999
	int32_t AssetId2_018;

	// 名前：表示アセット4
	// 説明：-1:無効 生成するアセットIDを指定します。AEG999_999 -> 999999
	int32_t AssetId3_01C;

	// 名前：表示アセット5
	// 説明：-1:無効 生成するアセットIDを指定します。AEG999_999 -> 999999
	int32_t AssetId4_020;

	// 名前：表示アセット6
	// 説明：-1:無効 生成するアセットIDを指定します。AEG999_999 -> 999999
	int32_t AssetId5_024;

	// 名前：表示アセット7
	// 説明：-1:無効 生成するアセットIDを指定します。AEG999_999 -> 999999
	int32_t AssetId6_028;

	// 名前：表示アセット8
	// 説明：-1:無効 生成するアセットIDを指定します。AEG999_999 -> 999999
	int32_t AssetId7_02C;

	// 名前：reserved0
	uint8_t reserved0_030[8];

	// 名前：生成制限ID0
	// 説明：生成制限用のIDです。-1:無制限。「マップデフォルトパラメータ.xlsm」の生成制限IDと一致した場合のみ生成が許可されます(SEQ08921)
	int8_t CreateAssetLimitId0_038;

	// 名前：生成制限ID1
	// 説明：生成制限用のIDです。-1:無制限。「マップデフォルトパラメータ.xlsm」の生成制限IDと一致した場合のみ生成が許可されます(SEQ08921)
	int8_t CreateAssetLimitId1_039;

	// 名前：生成制限ID2
	// 説明：生成制限用のIDです。-1:無制限。「マップデフォルトパラメータ.xlsm」の生成制限IDと一致した場合のみ生成が許可されます(SEQ08921)
	int8_t CreateAssetLimitId2_03A;

	// 名前：生成制限ID3
	// 説明：生成制限用のIDです。-1:無制限。「マップデフォルトパラメータ.xlsm」の生成制限IDと一致した場合のみ生成が許可されます(SEQ08921)
	int8_t CreateAssetLimitId3_03B;

	// 名前：reserved1
	uint8_t reserved1_03C[4];

} WeatherAssetReplaceParam;

#endif
