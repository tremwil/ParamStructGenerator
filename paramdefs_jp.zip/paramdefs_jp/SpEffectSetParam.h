/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SpEffectSetParam_H
#define _PARAM_SpEffectSetParam_H
#include <stdint.h>

// SP_EFFECT_SET_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SpEffectSetParam {

	// 名前：特殊効果ID1
	// 説明：特殊効果ID1
	int32_t spEffectId1_000;

	// 名前：特殊効果ID2
	// 説明：特殊効果ID2
	int32_t spEffectId2_004;

	// 名前：特殊効果ID3
	// 説明：特殊効果ID3
	int32_t spEffectId3_008;

	// 名前：特殊効果ID4
	// 説明：特殊効果ID4
	int32_t spEffectId4_00C;

} SpEffectSetParam;

#endif
