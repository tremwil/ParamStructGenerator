/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MoveParam_H
#define _PARAM_MoveParam_H
#include <stdint.h>

// MOVE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MoveParam {

	// 名前：待機
	// 説明：待機
	int32_t stayId_000;

	// 名前：歩行 前
	// 説明：歩行 前
	int32_t walkF_004;

	// 名前：歩行 後
	// 説明：歩行 後
	int32_t walkB_008;

	// 名前：歩行 左
	// 説明：歩行 左
	int32_t walkL_00C;

	// 名前：歩行 右
	// 説明：歩行 右
	int32_t walkR_010;

	// 名前：走行 前
	// 説明：走行 前
	int32_t dashF_014;

	// 名前：走行 後
	// 説明：走行 後
	int32_t dashB_018;

	// 名前：走行 左
	// 説明：走行 左
	int32_t dashL_01C;

	// 名前：走行 右
	// 説明：走行 右
	int32_t dashR_020;

	// 名前：ダッシュ移動
	// 説明：ダッシュ移動
	int32_t superDash_024;

	// 名前：緊急回避 前
	// 説明：緊急回避 前
	int32_t escapeF_028;

	// 名前：緊急回避 後
	// 説明：緊急回避 後
	int32_t escapeB_02C;

	// 名前：緊急回避 左
	// 説明：緊急回避 左
	int32_t escapeL_030;

	// 名前：緊急回避 右
	// 説明：緊急回避 右
	int32_t escapeR_034;

	// 名前：90度旋回 左
	// 説明：90度旋回 左
	int32_t turnL_038;

	// 名前：90度旋回 右
	// 説明：90度旋回 右
	int32_t trunR_03C;

	// 名前：180度旋回 左
	// 説明：180度旋回 左
	int32_t largeTurnL_040;

	// 名前：180度旋回 右
	// 説明：180度旋回 右
	int32_t largeTurnR_044;

	// 名前：ステップ移動
	// 説明：180度旋回 右
	int32_t stepMove_048;

	// 名前：飛行待機
	// 説明：飛行待機
	int32_t flyStay_04C;

	// 名前：飛行前進
	// 説明：飛行前進
	int32_t flyWalkF_050;

	// 名前：飛行左前進
	// 説明：飛行左前進。低回転
	int32_t flyWalkFL_054;

	// 名前：飛行右前進
	// 説明：飛行右前進。低回転
	int32_t flyWalkFR_058;

	// 名前：飛行左前進2
	// 説明：飛行左前進2。高回転
	int32_t flyWalkFL2_05C;

	// 名前：飛行右前進2
	// 説明：飛行右前進2。高回転
	int32_t flyWalkFR2_060;

	// 名前：高速飛行前進
	// 説明：高速飛行前進
	int32_t flyDashF_064;

	// 名前：高速飛行左前進
	// 説明：高速飛行左前進。低回転
	int32_t flyDashFL_068;

	// 名前：高速飛行右前進
	// 説明：高速飛行右前進。低回転
	int32_t flyDashFR_06C;

	// 名前：高速飛行左前進2
	// 説明：高速飛行左前進2。高回転
	int32_t flyDashFL2_070;

	// 名前：高速飛行右前進2
	// 説明：高速飛行右前進2。高回転
	int32_t flyDashFR2_074;

	// 名前：ダッシュ緊急回避前
	// 説明：ダッシュ緊急回避前
	int32_t dashEscapeF_078;

	// 名前：ダッシュ緊急回避後
	// 説明：ダッシュ緊急回避後
	int32_t dashEscapeB_07C;

	// 名前：ダッシュ緊急回避左
	// 説明：ダッシュ緊急回避左
	int32_t dashEscapeL_080;

	// 名前：ダッシュ緊急回避右
	// 説明：ダッシュ緊急回避右
	int32_t dashEscapeR_084;

	// 名前：アナログ移動パラＩＤ
	// 説明：移動アニメブレンドで使用される移動アニメパラメータＩＤ
	int32_t analogMoveParamId_088;

	// 名前：アニメなし旋回角度[deg]
	// 説明：旋回角度がこの値以下だと旋回アニメを再生しません（敵旋回制御のみ有効）
	uint8_t turnNoAnimAngle_08C;

	// 名前：45度旋回アニメ角度[deg]
	// 説明：旋回角度がこの値以下だと45度旋回アニメを再生します（ボス2足のみ有効）
	uint8_t turn45Angle_08D;

	// 名前：90度旋回アニメ角度[deg]
	// 説明：旋回角度がこの値以下だと90度旋回アニメを再生します（敵旋回制御のみ有効）
	uint8_t turn90Angle_08E;

	// 名前：停止時アニメなし旋回角度[deg]
	// 説明：旋回角度がこの値以下だと旋回アニメを再生しません[停止時]（ボス2足のみ有効）
	uint8_t turnWaitNoAnimAngle_08F;

} MoveParam;

#endif
