/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MaterialEx_H
#define _PARAM_MaterialEx_H
#include <stdint.h>

// MATERIAL_EX_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MaterialEx {

	// 名前：マテリアルパラメータ名
	// 説明：マテリアルのパラメータ名を設定する。最大31文字まで
	wchar_t paramName_000[32];

	// 名前：対象マテリアルID
	// 説明：NPCパラ：常駐マテリアル拡張パラID用設定　-1なら全マテリアル対象
	int32_t materialId_040;

	// 名前：上書き値1(R)
	// 説明：NPCパラ：常駐マテリアル拡張パラID用設定
	float materialParamValue0_044;

	// 名前：上書き値2(G)
	// 説明：NPCパラ：常駐マテリアル拡張パラID用設定
	float materialParamValue1_048;

	// 名前：上書き値3(B)
	// 説明：NPCパラ：常駐マテリアル拡張パラID用設定
	float materialParamValue2_04C;

	// 名前：上書き値4(A)
	// 説明：NPCパラ：常駐マテリアル拡張パラID用設定
	float materialParamValue3_050;

	// 名前：上書き値5(I)
	// 説明：NPCパラ：常駐マテリアル拡張パラID用設定
	float materialParamValue4_054;

	// 名前：パディング
	// 説明：パディング
	uint8_t pad_058[8];

} MaterialEx;

#endif
