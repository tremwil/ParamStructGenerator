/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_NpcAiActionParam_H
#define _PARAM_NpcAiActionParam_H
#include <stdint.h>

// NPC_AI_ACTION_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _NpcAiActionParam {

	// 名前：移動方向入力
	// 説明：入力する移動方向
	uint8_t moveDir_000;

	// 名前：キー入力1
	// 説明：入力するキー
	uint8_t key1_001;

	// 名前：キー入力2
	// 説明：入力するキー
	uint8_t key2_002;

	// 名前：キー入力3
	// 説明：入力するキー
	uint8_t key3_003;

	// 名前：移動方向入力は長押し？
	// 説明：入力する移動方向を長押し扱いするか
	uint8_t bMoveDirHold_004;

	// 名前：キー入力1は長押し？
	// 説明：入力するキーを長押扱いするか
	uint8_t bKeyHold1_005;

	// 名前：キー入力2は長押し？
	// 説明：入力するキーを長押扱いするか
	uint8_t bKeyHold2_006;

	// 名前：キー入力3は長押し？
	// 説明：入力するキーを長押扱いするか
	uint8_t bKeyHold3_007;

	// 名前：ジェスチャーID（どれかのキー入力がGESTUREの時のみ有効）
	// 説明：ジェスチャーID
	int32_t gestureId_008;

	// 名前：寿命が尽きた時成功扱いにする
	// 説明：これがONならAIのゴールが寿命まで成功にならない
	uint8_t bLifeEndSuccess_00C;

	// 名前：パッド
	// 説明：pad
	uint8_t pad1_00D[3];

} NpcAiActionParam;

#endif
