/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MenuParamColorTable_H
#define _PARAM_MenuParamColorTable_H
#include <stdint.h>

// MENU_PARAM_COLOR_TABLE_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MenuParamColorTable {

	// 名前：補間方法
	// 説明：補間方法
	uint8_t lerpMode_000;

	// 名前：パッド
	uint8_t pad1_001[3];

	// 名前：色相
	// 説明：色相。補間では固定値として扱う
	uint16_t h_004;

	// 名前：パッド
	uint8_t pad2_006[2];

	// 名前：彩度
	// 説明：彩度1。補間の1点目として扱われる
	float s1_008;

	// 名前：明度
	// 説明：明度1。補間の1点目として扱われる
	float v1_00C;

	// 名前：彩度
	// 説明：彩度2。補間の2点目として扱われる
	float s2_010;

	// 名前：明度
	// 説明：明度2。補間の2点目として扱われる
	float v2_014;

	// 名前：彩度
	// 説明：彩度3。補間の3点目として扱われる
	float s3_018;

	// 名前：明度
	// 説明：明度3。補間の3点目として扱われる
	float v3_01C;

} MenuParamColorTable;

#endif
