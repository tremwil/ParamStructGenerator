/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_EffectQuality_H
#define _PARAM_Gconfig_EffectQuality_H
#include <stdint.h>

// CS_EFFECT_QUALITY_DETAIL
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_EffectQuality {

	// 名前：ソフトパーティクル有効
	// 説明：ソフトパーティクル有効
	uint8_t softParticleEnabled_000;

	// 名前：グロー有効
	// 説明：グロー有効
	uint8_t glowEnabled_001;

	// 名前：歪み有効
	// 説明：歪み有効
	uint8_t distortionEnable_002;

	// 名前：バイラテラルアップスケールを有効
	// 説明：バイラテラルアップスケール有効
	uint8_t cs_upScaleEnabledType_003;

	// 名前：一回のエミット数
	// 説明：一回のエミット数
	float fNumOnceEmitsScale_004;

	// 名前：エミット間隔
	// 説明：エミット間隔
	float fEmitSpanScale_008;

	// 名前：1段階目のLOD距離スケール
	// 説明：1段階目のLOD距離スケール
	float fLodDistance1Scale_00C;

	// 名前：2段階目のLOD距離スケール
	// 説明：2段階目のLOD距離スケール
	float fLodDistance2Scale_010;

	// 名前：3段階目のLOD距離スケール
	// 説明：3段階目のLOD距離スケール
	float fLodDistance3Scale_014;

	// 名前：4段階目のLOD距離スケール
	// 説明：4段階目のLOD距離スケール
	float fLodDistance4Scale_018;

	// 名前：縮小バッファへ登録される距離への倍率
	// 説明：縮小バッファへ登録される距離への倍率
	float fScaleRenderDistanceScale_01C;

	// 名前：ダミー
	uint8_t dmy_020[4];

} Gconfig_EffectQuality;

#endif
