/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_RuntimeBoneControlParam_H
#define _PARAM_RuntimeBoneControlParam_H
#include <stdint.h>

// RUNTIME_BONE_CONTROL_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _RuntimeBoneControlParam {

	// 名前：キャラID
	// 説明：キャラID
	uint32_t chrId_000;

	// 名前：制御タイプ
	// 説明：制御タイプ
	uint8_t ctrlType_004;

	// 名前：pad
	uint8_t pad_005[11];

	// 名前：適用関節
	// 説明：適用関節
	char applyBone_010[32];

	// 名前：ターゲット関節１
	// 説明：ターゲット関節１
	char targetBone1_030[32];

	// 名前：ターゲット関節２
	// 説明：ターゲット関節２
	char targetBone2_050[32];

} RuntimeBoneControlParam;

#endif
