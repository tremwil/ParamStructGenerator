/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_KeyAssignMenuItemParam_H
#define _PARAM_KeyAssignMenuItemParam_H
#include <stdint.h>

// CS_KEY_ASSIGN_MENUITEM_PARAM
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _KeyAssignMenuItemParam {

	// 名前：テキスト
	// 説明：キー指定あり⇒項目名、1行ヘルプのID。キー指定なし⇒カテゴリ名のID。テキスト指定なし⇒パッド/キー設定に表示しない(操作一覧表示のみ)
	int32_t textID_000;

	// 名前：キー
	// 説明：割り当て対象のユーザー入力キー。指定が無い時はカテゴリ表示用項目として扱う
	int32_t key_004;

	// 名前：解除
	// 説明：割り当ての解除が可能か(デフォルト:可能)
	uint8_t enableUnassign_008;

	// 名前：パッド
	// 説明：パッド操作の割り当て変更が可能か(デフォルト:可能)
	uint8_t enablePadConfig_009;

	// 名前：マウス
	// 説明：マウス操作の割り当て変更が可能か(デフォルト:可能)
	uint8_t enableMouseConfig_00A;

	// 名前：グループ
	// 説明：割り当ての重複判定用グループ。同一グループでは重複不可
	uint8_t group_00B;

	// 名前：テキスト
	// 説明：操作一覧で表示する項目名。0:：一覧に表示しない
	int32_t mappingTextID_00C;

	// 名前：パッド
	// 説明：キーコンフィグ（パッド）で表示するか(デフォルト:表示)
	uint8_t viewPad_010;

	// 名前：マウス・キーボード
	// 説明：キーコンフィグ（マウス・キーボード）で表示するか(デフォルト:表示）
	uint8_t viewKeyboardMouse_011;

	// 名前：padding
	// 説明：パッド操作の割り当て変更が可能か(デフォルト:可能)
	uint8_t padding_012[6];

} KeyAssignMenuItemParam;

#endif
