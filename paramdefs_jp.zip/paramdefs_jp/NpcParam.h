/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_NpcParam_H
#define _PARAM_NpcParam_H
#include <stdint.h>

// NPC_PARAM_ST
// Data Version: 9
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _NpcParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：行動バリエーションID
	// 説明：行動IDを算出するときに使用するバリエーションID.
	int32_t behaviorVariationId_004;

	// 名前：毒耐性 補正ルールID
	// 説明：状態異常の発動時、状態異常耐性補正パラメータの設定値を使って、一時的に最大値を変動させる
	int32_t resistCorrectId_poison_008;

	// 名前：NPC名ID
	// 説明：NPC名メッセージパラメータ用ID
	int32_t nameId_00C;

	// 名前：旋回速度[deg/sec]
	// 説明：1秒間に旋回できる回転速度[度/秒].
	float turnVellocity_010;

	// 名前：対マップあたりの高さ[m]
	// 説明：対キャラ当たりカプセルの高さ.
	float hitHeight_014;

	// 名前：対マップあたりの半径[m]
	// 説明：対キャラ当たりカプセルの半径.
	float hitRadius_018;

	// 名前：重量[kg]
	// 説明：重量.
	uint32_t weight_01C;

	// 名前：表示位置Yオフセット[m]
	// 説明：モデル表示位置のY（高さ）方向のオフセット。あたり位置より浮かせることができる。
	float hitYOffset_020;

	// 名前：ＨＰ
	// 説明：死亡猶予.
	uint32_t hp_024;

	// 名前：ＭＰ
	// 説明：魔法使用量.
	uint32_t mp_028;

	// 名前：ソウル
	// 説明：死亡時に、キャラクターが取得できるソウル量.
	uint32_t getSoul_02C;

	// 名前：アイテム抽選ID_エネミー用
	// 説明：死亡時に取得するアイテムの抽選ID_エネミー用を指定。どちらか片方のみ設定してください。
	int32_t itemLotId_enemy_030;

	// 名前：アイテム抽選ID_マップ用
	// 説明：死亡時に取得するアイテムの抽選ID_マップ用を指定。どちらか片方のみ設定してください。
	int32_t itemLotId_map_034;

	// 名前：FootIK足首の制限角度_ロール
	// 説明：FootIK足首のロールの制限角度（-1：制限なし）
	float maxAnkleRollAngle_038;

	// 名前：あたりグループと使用ナビメッシュ
	// 説明：他のキャラとのあたり判定を設定（ラグドールあたりにすると他のキャラがラグドールに当たるようになる）
	uint8_t chrHitGroupAndNavimesh_03C;

	// 名前：NPC顔画像ID
	// 説明：NPC顔画像ID(0:無効値(デフォルト))。「サイン閲覧メニュー」「キックメニュー」などで表示する顔画像のIDを指定する。無効値なら着せ替えモデルを表示する
	uint8_t faceIconId_03D;

	// 名前：ディアクティベート距離設定[m]
	// 説明：キャラがディアクティベートされる距離（オープン配置キャラのみ有効）
	int16_t deactivateDist_03E;

	// 名前：キャラ出現条件パラ
	// 説明：キャラ出現条件パラメータID
	uint32_t chrActivateConditionParamId_040;

	// 名前：FootIK見た目の上下制限値
	// 説明：FootIK見た目の上下制限値
	float footIkErrorHeightLimit_044;

	// 名前：人間性抽選ID
	// 説明：死亡時に取得する人間性の抽選IDを指定
	int32_t humanityLotId_048;

	// 名前：常駐特殊効果0
	// 説明：常駐特殊効果0
	int32_t spEffectID0_04C;

	// 名前：常駐特殊効果1
	// 説明：常駐特殊効果1
	int32_t spEffectID1_050;

	// 名前：常駐特殊効果2
	// 説明：常駐特殊効果2
	int32_t spEffectID2_054;

	// 名前：常駐特殊効果3
	// 説明：常駐特殊効果3
	int32_t spEffectID3_058;

	// 名前：常駐特殊効果4
	// 説明：常駐特殊効果4
	int32_t spEffectID4_05C;

	// 名前：常駐特殊効果5
	// 説明：常駐特殊効果5
	int32_t spEffectID5_060;

	// 名前：常駐特殊効果6
	// 説明：常駐特殊効果6
	int32_t spEffectID6_064;

	// 名前：常駐特殊効果7
	// 説明：常駐特殊効果7
	int32_t spEffectID7_068;

	// 名前：周回ボーナス用特殊効果ＩＤ
	// 説明：周回ボーナス用特殊効果ＩＤ
	int32_t GameClearSpEffectID_06C;

	// 名前：物理攻撃カット率[％]
	// 説明：ガード時のダメージカット率を各攻撃ごとに設定
	float physGuardCutRate_070;

	// 名前：魔法攻撃カット率[％]
	// 説明：ガード攻撃でない場合は、0を入れる
	float magGuardCutRate_074;

	// 名前：炎攻撃力カット率[％]
	// 説明：炎攻撃をどれだけカットするか？
	float fireGuardCutRate_078;

	// 名前：電撃攻撃力カット率[％]
	// 説明：電撃攻撃をどれだけカットするか？
	float thunGuardCutRate_07C;

	// 名前：アニメIDオフセット1
	// 説明：すべてのアニメをこの数だけずらしたIDで再生します。なければ元のアニメIDを参照します。
	int32_t animIdOffset_080;

	// 名前：ロックダミポリ0の注視点
	// 説明：ロックオンダミポリ22Xをロックしている際に指定したダミポリを注視する（-1：無効）
	int16_t lockGazePoint0_084;

	// 名前：ロックダミポリ1の注視点
	// 説明：ロックオンダミポリ22Xをロックしている際に指定したダミポリを注視する（-1：無効）
	int16_t lockGazePoint1_086;

	// 名前：ロックダミポリ2の注視点
	// 説明：ロックオンダミポリ22Xをロックしている際に指定したダミポリを注視する（-1：無効）
	int16_t lockGazePoint2_088;

	// 名前：ロックダミポリ3の注視点
	// 説明：ロックオンダミポリ22Xをロックしている際に指定したダミポリを注視する（-1：無効）
	int16_t lockGazePoint3_08A;

	// 名前：ロックダミポリ4の注視点
	// 説明：ロックオンダミポリ22Xをロックしている際に指定したダミポリを注視する（-1：無効）
	int16_t lockGazePoint4_08C;

	// 名前：ロックダミポリ5の注視点
	// 説明：ロックオンダミポリ22Xをロックしている際に指定したダミポリを注視する（-1：無効）
	int16_t lockGazePoint5_08E;

	// 名前：ネットワークワープ判定距離[m/秒]
	// 説明：ネットワークの同期で、補完移動でなくワープさせる距離。スピードの速い人（exドラゴン)は長めにしてあげる必要がある。
	float networkWarpDist_090;

	// 名前：R1
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorR1_094;

	// 名前：L1
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorL1_098;

	// 名前：R2
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorR2_09C;

	// 名前：L2
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorL2_0A0;

	// 名前：□
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorRL_0A4;

	// 名前：○
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorRR_0A8;

	// 名前：×
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorRD_0AC;

	// 名前：△
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorRU_0B0;

	// 名前：←
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorLL_0B4;

	// 名前：→
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorLR_0B8;

	// 名前：↓
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorLD_0BC;

	// 名前：↑
	// 説明：行動パラメータツールからIDを登録し、行動を指定する.
	int32_t dbgBehaviorLU_0C0;

	// 名前：アニメIDオフセット2
	// 説明：すべてのアニメをこの数だけずらしたIDで再生します。なければアニメIDオフセット1のアニメIDを参照します。
	int32_t animIdOffset2_0C4;

	// 名前：ダメージグループ1ダメージ倍率
	// 説明：部位1に対するダメージ処理に適応する倍率
	float partsDamageRate1_0C8;

	// 名前：ダメージグループ2ダメージ倍率
	// 説明：部位2に対するダメージ処理に適応する倍率
	float partsDamageRate2_0CC;

	// 名前：ダメージグループ3ダメージ倍率
	// 説明：部位3に対するダメージ処理に適応する倍率
	float partsDamageRate3_0D0;

	// 名前：ダメージグループ4ダメージ倍率
	// 説明：部位4に対するダメージ処理に適応する倍率
	float partsDamageRate4_0D4;

	// 名前：ダメージグループ5ダメージ倍率
	// 説明：部位5に対するダメージ処理に適応する倍率
	float partsDamageRate5_0D8;

	// 名前：ダメージグループ6ダメージ倍率
	// 説明：部位6に対するダメージ処理に適応する倍率
	float partsDamageRate6_0DC;

	// 名前：ダメージグループ7ダメージ倍率
	// 説明：部位7に対するダメージ処理に適応する倍率
	float partsDamageRate7_0E0;

	// 名前：ダメージグループ8ダメージ倍率
	// 説明：部位8に対するダメージ処理に適応する倍率
	float partsDamageRate8_0E4;

	// 名前：弱点部位ダメージ倍率
	// 説明：弱点部位に対するダメージ処理に適応する倍率
	float weakPartsDamageRate_0E8;

	// 名前：SA回復時間補正値
	// 説明：スーパーアーマー回復時間用の補正値
	float superArmorRecoverCorrection_0EC;

	// 名前：SAブレイク時ノックバック距離
	// 説明：SAブレイクの時だけに使えるノックバック距離
	float superArmorBrakeKnockbackDist_0F0;

	// 名前：スタミナ
	// 説明：スタミナ総量.
	uint16_t stamina_0F4;

	// 名前：スタミナ回復基本速度[point/s]
	// 説明：スタミナ回復基本速度[point/s]
	uint16_t staminaRecoverBaseVel_0F6;

	// 名前：物理防御力
	// 説明：物理攻撃に対するダメージ減少基本値.
	uint16_t def_phys_0F8;

	// 名前：斬撃防御力[％]
	// 説明：攻撃属性を見て、斬撃属性のときは、防御力を減少させる.
	int16_t def_slash_0FA;

	// 名前：打撃防御力[％]
	// 説明：攻撃属性を見て、打撃属性のときは、防御力を減少させる.
	int16_t def_blow_0FC;

	// 名前：刺突防御力[％]
	// 説明：攻撃属性を見て、刺突属性のときは、防御力を減少させる.
	int16_t def_thrust_0FE;

	// 名前：魔法防御力
	// 説明：魔法攻撃に対するダメージ減少基本値.
	uint16_t def_mag_100;

	// 名前：炎防御力
	// 説明：炎攻撃に対するダメージ減少基本値.
	uint16_t def_fire_102;

	// 名前：電撃防御力
	// 説明：電撃攻撃に対するダメージ減少基本値.
	uint16_t def_thunder_104;

	// 名前：はじき防御力
	// 説明：敵の攻撃のはじき判定に使用。//ガード以外の通常攻撃でもはじけるようにするためのものです.//硬い表皮の敵は、何もしなくてもはじかれることがある…みたいな感じ通常の敵なら関係ないです.
	uint16_t defFlickPower_106;

	// 名前：毒耐性
	// 説明：毒状態異常へのかかりにくさ
	uint16_t resist_poison_108;

	// 名前：疫病耐性
	// 説明：疫病状態異常へのかかりにくさ
	uint16_t resist_desease_10A;

	// 名前：出血耐性
	// 説明：出血状態異常へのかかりにくさ
	uint16_t resist_blood_10C;

	// 名前：呪耐性
	// 説明：呪状態異常へのかかりにくさ
	uint16_t resist_curse_10E;

	// 名前：徘徊ゴースト時差し替えモデルID
	// 説明：徘徊ゴースト化したときの差し替えモデル、テクスチャID
	int16_t ghostModelId_110;

	// 名前：通常時差し替えリソースID
	// 説明：通常時のリソースID差し替え（むやみに使わないこと）
	int16_t normalChangeResouceId_112;

	// 名前：ガード範囲[deg]
	// 説明：武器のガード時の防御発生範囲角度.保留中
	int16_t guardAngle_114;

	// 名前：斬撃攻撃カット率[％]
	// 説明：攻撃タイプを見て、斬撃属性のダメージを何％カットするか？を指定
	int16_t slashGuardCutRate_116;

	// 名前：打撃攻撃カット率[％]
	// 説明：攻撃タイプを見て、打撃属性のダメージを何％カットするか？を指定
	int16_t blowGuardCutRate_118;

	// 名前：刺突攻撃カット率[％]
	// 説明：攻撃タイプを見て、刺突属性のダメージを何％カットするか？を指定
	int16_t thrustGuardCutRate_11A;

	// 名前：ロックダミポリ6の注視点
	// 説明：ロックオンダミポリ22Xをロックしている際に指定したダミポリを注視する（-1：無効）
	int16_t lockGazePoint6_11C;

	// 名前：通常時差し替えテクスチャキャラID
	// 説明：通常時差し替えテクスチャキャラID（むやみに使わないこと）
	int16_t normalChangeTexChrId_11E;

	// 名前：ドロップアイテムの表示形式
	// 説明：アイテムドロップ時の表示方法(死体発光orアイテム表示)
	uint16_t dropType_120;

	// 名前：ノックバックカット率[％]
	// 説明：ノックバックダメージを受けたときの減少値／具体的には、攻撃側のノックバック初速度をカットする
	uint8_t knockbackRate_122;

	// 名前：ノックバックパラメータID
	// 説明：ノックバック時に使用するパラメータIDを設定
	uint8_t knockbackParamId_123;

	// 名前：落下ダメージ軽減補正[％]
	// 説明：落下ダメージ軽減補正[％]
	uint8_t fallDamageDump_124;

	// 名前：スタミナ攻撃カット率[％]
	// 説明：ガード成功時に、敵のスタミナ攻撃に対する防御力
	uint8_t staminaGuardDef_125;

	// 名前：睡眠耐性
	// 説明：睡眠状態異常へのかかりにくさ
	uint16_t resist_sleep_126;

	// 名前：発狂耐性
	// 説明：発狂状態異常へのかかりにくさ
	uint16_t resist_madness_128;

	// 名前：睡眠攻撃カット率[％]
	// 説明：睡眠に対する攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t sleepGuardResist_12A;

	// 名前：発狂攻撃カット率[％]
	// 説明：発狂に対する攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t madnessGuardResist_12B;

	// 名前：ロックダミポリ7の注視点
	// 説明：ロックオンダミポリ22Xをロックしている際に指定したダミポリを注視する（-1：無効）
	int16_t lockGazePoint7_12C;

	// 名前：MP回復基本速度[％/s]
	// 説明：MP回復基本速度[％/s]
	uint8_t mpRecoverBaseVel_12E;

	// 名前：はじき時ダメージ減衰率[%]
	// 説明：攻撃をはじいた時にダメージを減衰する値を設定
	uint8_t flickDamageCutRate_12F;

	// 名前：デフォルトLODパラムID
	// 説明：デフォルトLODパラムID(-1：なし)
	int8_t defaultLodParamId_130;

	// 名前：描画タイプ
	// 説明：描画タイプ
	int8_t drawType_131;

	// 名前：NPCタイプ
	// 説明：NPCの種類.ザコ敵/ボス敵が区別されていればOK
	uint8_t npcType_132;

	// 名前：チームタイプ
	// 説明：NPCの攻撃が当たる/当たらない、狙う/狙わない設定
	uint8_t teamType_133;

	// 名前：移動タイプ
	// 説明：移動方法。これにより制御が変更される.
	uint8_t moveType_134;

	// 名前：ロック距離
	// 説明：ロックオンできる距離[m]
	uint8_t lockDist_135;

	// 名前：弱点防御材質1【SE】
	// 説明：弱点部位ダメージを受けた時に鳴らすSEを判定する。1
	uint16_t materialSe_Weak1_136;

	// 名前：弱点防御材質1【SFX】
	// 説明：弱点部位ダメージを受けた時に発生するSFXを判定する。1
	uint16_t materialSfx_Weak1_138;

	// 名前：部位ダメージ適用攻撃
	// 説明：部位ダメージを適用する攻撃タイプを設定する
	uint8_t partsDamageType_13A;

	// 名前：誓約
	// 説明：誓約タイプ
	uint8_t vowType_13B;

	// 名前：ガードレベル
	// 説明：ガードしたとき、敵の攻撃をどのガードモーションで受けるか？を決める
	int8_t guardLevel_13C;

	// 名前：燃焼SFXタイプ
	// 説明：燃焼時のSFXタイプ
	uint8_t burnSfxType_13D;

	// 名前：毒耐性カット率[％]
	// 説明：毒にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t poisonGuardResist_13E;

	// 名前：疫病攻撃カット率[％]
	// 説明：疫病にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t diseaseGuardResist_13F;

	// 名前：出血攻撃カット率[％]
	// 説明：出血にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t bloodGuardResist_140;

	// 名前：呪攻撃カット率[％]
	// 説明：呪にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t curseGuardResist_141;

	// 名前：パリィ攻撃力
	// 説明：パリィ攻撃力。パリィする側が使用
	uint8_t parryAttack_142;

	// 名前：パリィ防御力
	// 説明：パリィ防御力。パリィされる側が使用。
	uint8_t parryDefence_143;

	// 名前：SFXサイズ
	// 説明：SFXサイズ
	uint8_t sfxSize_144;

	// 名前：カメラ押し出し領域半径[m]
	// 説明：カメラ押し出し領域半径[m]
	uint8_t pushOutCamRegionRadius_145;

	// 名前：ヒットストップするか
	// 説明：ヒットストップ処理を行うかどうかの設定
	uint8_t hitStopType_146;

	// 名前：はしご上終端オフセット[1/10m]
	// 説明：はしご終端判定用オフセット上側
	uint8_t ladderEndChkOffsetTop_147;

	// 名前：はしご下終端オフセット[1/10m]
	// 説明：はしご終端判定用オフセット下側
	uint8_t ladderEndChkOffsetLow_148;

	// 名前：カメラヒットあたりラグドール
	// 説明：敵のラグドールにカメラがあたるか。(プレイヤにも当たるときのみ有効)
	uint8_t useRagdollCamHit_149: 1;

	// 名前：クロスリジッドヒットを無効
	// 説明：クロスリジッドが自分に当たらないようにしたければ○
	uint8_t disableClothRigidHit_149: 1;

	// 名前：前後の起伏加算を使用するか
	// 説明：前後の起伏加算を使用するか
	uint8_t useUndulationAddAnimFB_149: 1;

	// 名前：特攻Aか
	// 説明：特攻Aか。特攻Aダメージ倍率が計算に含まれるようになります
	uint8_t isWeakA_149: 1;

	// 名前：霊体か
	// 説明：相手の攻撃がすり抜けるようになります。武器パラの「対霊武器」が○の武器で攻撃された時のみ攻撃が当たります。徘徊ゴーストと混同しないように注意
	uint8_t isGhost_149: 1;

	// 名前：ダメージ0のときにダメージモーションなしか
	// 説明：ダメージ0のときにダメージモーションを再生しないか。
	uint8_t isNoDamageMotion_149: 1;

	// 名前：起伏に角度をあわせるか
	// 説明：キャラの前後回転を地面の起伏に合わせるか。飛行キャラの場合は使用不可
	uint8_t isUnduration_149: 1;

	// 名前：徘徊ゴーストになるか
	// 説明：プレイヤーがクライアントのときに徘徊ゴーストになるか
	uint8_t isChangeWanderGhost_149: 1;

	// 名前：モデル表示マスク0
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask0_14A: 1;

	// 名前：モデル表示マスク1
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask1_14A: 1;

	// 名前：モデル表示マスク2
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask2_14A: 1;

	// 名前：モデル表示マスク3
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask3_14A: 1;

	// 名前：モデル表示マスク4
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask4_14A: 1;

	// 名前：モデル表示マスク5
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask5_14A: 1;

	// 名前：モデル表示マスク6
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask6_14A: 1;

	// 名前：モデル表示マスク7
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask7_14A: 1;

	// 名前：モデル表示マスク8
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask8_14B: 1;

	// 名前：モデル表示マスク9
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask9_14B: 1;

	// 名前：モデル表示マスク10
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask10_14B: 1;

	// 名前：モデル表示マスク11
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask11_14B: 1;

	// 名前：モデル表示マスク12
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask12_14B: 1;

	// 名前：モデル表示マスク13
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask13_14B: 1;

	// 名前：モデル表示マスク14
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask14_14B: 1;

	// 名前：モデル表示マスク15
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask15_14B: 1;

	// 名前：首振り有効にするか
	// 説明：パラムウィーバで設定された首振りを有効にするか。
	uint8_t isEnableNeckTurn_14C: 1;

	// 名前：リスポン禁止か
	// 説明：リスポンを禁止するか
	uint8_t disableRespawn_14C: 1;

	// 名前：移動アニメを待つか
	// 説明：移動アニメをアニメが終わるまで再生するか。（カゲロウ龍の様に。）
	uint8_t isMoveAnimWait_14C: 1;

	// 名前：群集用処理軽減するか
	// 説明：群集時の処理負荷軽減を行なうか。赤子用（できればファランクスも）
	uint8_t isCrowd_14C: 1;

	// 名前：特攻Bか
	// 説明：特攻Bか。特攻Bダメージ倍率が計算に含まれるようになります
	uint8_t isWeakB_14C: 1;

	// 名前：特攻Cか
	// 説明：特攻Cか。特攻Cダメージ倍率が計算に含まれるようになります
	uint8_t isWeakC_14C: 1;

	// 名前：特攻Dか
	// 説明：特攻Dか。特攻Dダメージ倍率が計算に含まれるようになります
	uint8_t isWeakD_14C: 1;

	// 名前：常時特殊旋回するか
	// 説明：常時特殊旋回を実行するか(旋回移動先にナビメッシュがない場合も特殊旋回を継続実行します)
	uint8_t doesAlwaysUseSpecialTurn_14C: 1;

	// 名前：騎乗特攻か
	// 説明：（騎乗中であれば）騎乗特攻の対象になるか
	uint8_t isRideAtkTarget_14D: 1;

	// 名前：段差越え表示補間を使用するか
	// 説明：段差越え表示補間を使用するか
	uint8_t isEnableStepDispInterpolate_14D: 1;

	// 名前：ステルス攻撃対象か
	// 説明：ステルス攻撃対象か
	uint8_t isStealthTarget_14D: 1;

	// 名前：初期死亡しない
	// 説明：初期死亡をしない場合にTRUE、殺してセーブしても死体再現されません。
	uint8_t disableInitializeDead_14D: 1;

	// 名前：ヒット時振動するか
	// 説明：ヒット時振動をする場合TRUE。亡者など、普通のヒットストップと変えたいときにつかう。
	uint8_t isHitRumble_14D: 1;

	// 名前：スムーズ旋回するか
	// 説明：ルート移動でのノード間旋回時、補間を行うか否か
	uint8_t isSmoothTurn_14D: 1;

	// 名前：特攻Eか
	// 説明：特攻Eか。特攻Eダメージ倍率が計算に含まれるようになります
	uint8_t isWeakE_14D: 1;

	// 名前：特攻Fか
	// 説明：特攻Fか。特攻Fダメージ倍率が計算に含まれるようになります
	uint8_t isWeakF_14D: 1;

	// 名前：モデル表示マスク16
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask16_14E: 1;

	// 名前：モデル表示マスク17
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask17_14E: 1;

	// 名前：モデル表示マスク18
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask18_14E: 1;

	// 名前：モデル表示マスク19
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask19_14E: 1;

	// 名前：モデル表示マスク20
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask20_14E: 1;

	// 名前：モデル表示マスク21
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask21_14E: 1;

	// 名前：モデル表示マスク22
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask22_14E: 1;

	// 名前：モデル表示マスク23
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask23_14E: 1;

	// 名前：モデル表示マスク24
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask24_14F: 1;

	// 名前：モデル表示マスク25
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask25_14F: 1;

	// 名前：モデル表示マスク26
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask26_14F: 1;

	// 名前：モデル表示マスク27
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask27_14F: 1;

	// 名前：モデル表示マスク28
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask28_14F: 1;

	// 名前：モデル表示マスク29
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask29_14F: 1;

	// 名前：モデル表示マスク30
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask30_14F: 1;

	// 名前：モデル表示マスク31
	// 説明：表示マスクに対応するモデルを表示します。
	uint8_t modelDispMask31_14F: 1;

	// 名前：ドロップアイテム半径補正
	// 説明：通常のItem検索判定の円柱半径に、補正として足し合わせる半径(敵ドロップアイテムに適用。大きなキャラなどで使用する)
	float itemSearchRadius_150;

	// 名前：対キャラあたりの高さ[m]
	// 説明：対キャラ当たりカプセルの高さ.
	float chrHitHeight_154;

	// 名前：対キャラあたりの半径[m]
	// 説明：対キャラ当たりカプセルの半径.
	float chrHitRadius_158;

	// 名前：特殊旋回のタイプ
	// 説明：特殊旋回のタイプ
	uint8_t specialTurnType_15C;

	// 名前：ソウルはボス入手か
	// 説明：ソウルはボス入手か
	uint8_t isSoulGetByBoss_15D: 1;

	// 名前：オブジェクト扱いの弾丸オーナか
	// 説明：弾丸のオーナーとなった場合、弾丸に関連するダメージ計算などをオブジェのものを適用するようにするフラグ。勢力別ダメージ補正で使用。
	uint8_t isBulletOwner_byObject_15D: 1;

	// 名前：ロウヒットFootIKを使うか？
	// 説明：ロウヒット用のFootIkフィルターを使用するか
	uint8_t isUseLowHitFootIk_15D: 1;

	// 名前：PvPのダメージ補正制御を適用するか
	// 説明：ダメージ計算時に「プレイヤー」としてダメージ計算するのかを決める。無効の場合は「敵」扱い。
	uint8_t isCalculatePvPDamage_15D: 1;

	// 名前：ホスト世界でアクティブ時のみアクティベート可
	// 説明：ホスト世界でアクティブ時のみアクティベート可
	uint8_t isHostSyncChr_15D: 1;

	// 名前：弱点アニメをスキップするか
	// 説明：弱点ダメージアニメ再生をスキップするかどうか。アニメを再生しないだけで「部位ダメージ率」「防御材質」は弱点として扱われます。
	uint8_t isSkipWeakDamageAnim_15D: 1;

	// 名前：騎乗された時、乗る側のカプセルあたりを有効にするか
	// 説明：このパラメータが○のキャラに騎乗する際、騎乗中、キャラのアタリが残ったままになる 
	uint8_t isKeepHitOnRide_15D: 1;

	// 名前：特殊あたりキャラか
	// 説明：特殊あたりに当たるキャラか
	uint8_t isSpCollide_15D: 1;

	// 名前：闇防御力
	// 説明：闇攻撃に対するダメージ減少基本値.
	uint16_t def_dark_15E;

	// 名前：脅威度
	// 説明：脅威度。0ならPCが見つかっても「見つかりそうFE」を表示しない
	uint32_t threatLv_160;

	// 名前：特殊旋回の使用距離の閾値[m]
	// 説明：ターゲットとの距離が設定された閾値以上の場合に、特殊旋回を行う
	float specialTurnDistanceThreshold_164;

	// 名前：フットエフェクト識別子
	// 説明：自動フットエフェクトで使用するSFX識別子。（XYYZZZのZZZ）
	int32_t autoFootEffectSfxId_168;

	// 名前：防御材質1【SE】
	// 説明：ダメージを受けたときに鳴らすＳＥを判定する。1.見た目で設定してＯＫ.
	uint16_t materialSe1_16C;

	// 名前：防御材質1【SFX】
	// 説明：ダメージを受けたときに発生するSFXを判定する。1.見た目で設定してＯＫ.
	uint16_t materialSfx1_16E;

	// 名前：弱点防御材質2【SE】
	// 説明：弱点部位ダメージを受けた時に鳴らすSEを判定する。2
	uint16_t materialSe_Weak2_170;

	// 名前：弱点防御材質2【SFX】
	// 説明：弱点部位ダメージを受けた時に発生するSFXを判定する。2
	uint16_t materialSfx_Weak2_172;

	// 名前：防御材質2【SE】
	// 説明：ダメージを受けたときに鳴らすＳＥを判定する。2.見た目で設定してＯＫ.
	uint16_t materialSe2_174;

	// 名前：防御材質2【SFX】
	// 説明：ダメージを受けたときに発生するSFXを判定する。2.見た目で設定してＯＫ.
	uint16_t materialSfx2_176;

	// 名前：常駐特殊効果8
	// 説明：常駐特殊効果8
	int32_t spEffectID8_178;

	// 名前：常駐特殊効果9
	// 説明：常駐特殊効果9
	int32_t spEffectID9_17C;

	// 名前：常駐特殊効果10
	// 説明：常駐特殊効果10
	int32_t spEffectID10_180;

	// 名前：常駐特殊効果11
	// 説明：常駐特殊効果11
	int32_t spEffectID11_184;

	// 名前：常駐特殊効果12
	// 説明：常駐特殊効果12
	int32_t spEffectID12_188;

	// 名前：常駐特殊効果13
	// 説明：常駐特殊効果13
	int32_t spEffectID13_18C;

	// 名前：常駐特殊効果14
	// 説明：常駐特殊効果14
	int32_t spEffectID14_190;

	// 名前：常駐特殊効果15
	// 説明：常駐特殊効果15
	int32_t spEffectID15_194;

	// 名前：フットデカール識別子1
	// 説明：フットエフェクト発生時に貼られるデカール。床材質も考慮される
	int32_t autoFootEffectDecalBaseId1_198;

	// 名前：強靭度
	// 説明：強靭度の基本値
	uint32_t toughness_19C;

	// 名前：強靭度 回復時間補正値
	// 説明：強靭度の回復時間用の補正値
	float toughnessRecoverCorrection_1A0;

	// 名前：無属性ダメージ倍率
	// 説明：無属性ダメージ倍率。ダメージ計算結果にこの値をかけた値が最終ダメージ値になります。
	float neutralDamageCutRate_1A4;

	// 名前：斬撃ダメージ倍率
	// 説明：斬撃ダメージ倍率。ダメージ計算結果にこの値をかけた値が最終ダメージ値になります。
	float slashDamageCutRate_1A8;

	// 名前：打撃ダメージ倍率
	// 説明：打撃ダメージ倍率。ダメージ計算結果にこの値をかけた値が最終ダメージ値になります。
	float blowDamageCutRate_1AC;

	// 名前：刺突ダメージ倍率
	// 説明：刺突ダメージ倍率。ダメージ計算結果にこの値をかけた値が最終ダメージ値になります。
	float thrustDamageCutRate_1B0;

	// 名前：魔法ダメージ倍率
	// 説明：魔法ダメージ倍率。ダメージ計算結果にこの値をかけた値が最終ダメージ値になります。
	float magicDamageCutRate_1B4;

	// 名前：火炎ダメージ倍率
	// 説明：火炎ダメージ倍率。ダメージ計算結果にこの値をかけた値が最終ダメージ値になります。
	float fireDamageCutRate_1B8;

	// 名前：電撃ダメージ倍率
	// 説明：電撃ダメージ倍率。ダメージ計算結果にこの値をかけた値が最終ダメージ値になります。
	float thunderDamageCutRate_1BC;

	// 名前：闇ダメージ倍率
	// 説明：闇ダメージ倍率。ダメージ計算結果にこの値をかけた値が最終ダメージ値になります。
	float darkDamageCutRate_1C0;

	// 名前：闇攻撃力カット率[％]
	// 説明：闇攻撃をどれだけカットするか？
	float darkGuardCutRate_1C4;

	// 名前：クロス更新優先度オフセット[m]
	// 説明：クロス更新優先度オフセット[m]
	int8_t clothUpdateOffset_1C8;

	// 名前：NPCプレイヤー時重量設定
	// 説明：NPCプレイヤーのときに適用される装備重量タイプ
	uint8_t npcPlayerWeightType_1C9;

	// 名前：通常時差し替えモデルID
	// 説明：通常時の差し替えモデル、テクスチャID
	int16_t normalChangeModelId_1CA;

	// 名前：通常時差し替えアニメキャラID
	// 説明：対象のアニメを指定IDのAnibndで差し替える
	int16_t normalChangeAnimChrId_1CC;

	// 名前：ペイントレンダーターゲットサイズ[pix]
	// 説明：ペイントレンダーターゲットサイズ[pix]
	uint16_t paintRenderTargetSize_1CE;

	// 名前：疫病耐性 補正ルールID
	// 説明：状態異常の発動時、状態異常耐性補正パラメータの設定値を使って、一時的に最大値を変動させる
	int32_t resistCorrectId_disease_1D0;

	// 名前：適用シェーダーID
	// 説明：適用するファントムパラメータ.xlsmのID
	int32_t phantomShaderId_1D4;

	// 名前：マルチプレイ補正パラメータID
	// 説明：マルチプレイ補正パラメータID
	int32_t multiPlayCorrectionParamId_1D8;

	// 名前：FootIK足首の制限角度_ピッチ
	// 説明：FootIK足首のピッチの制限角度（-1：制限なし）。HATでFoot End L Sを設定していない場合はこの角度がロールと共通で使用される。
	float maxAnklePitchAngle_1DC;

	// 名前：冷気耐性
	// 説明：冷気状態異常へのかかりにくさ
	uint16_t resist_freeze_1E0;

	// 名前：冷気攻撃カット率[％]
	// 説明：冷気に対する攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t freezeGuardResist_1E2;

	// 名前：pad
	uint8_t pad1_1E3[1];

	// 名前：ロックカメラパラメータID
	// 説明：ロックオンされた際にカメラに適用させるロックカメラパラメータのID。最も優先度が高い。-1なら未使用
	int32_t lockCameraParamId_1E4;

	// 名前：常駐特殊効果16
	// 説明：常駐特殊効果16
	int32_t spEffectID16_1E8;

	// 名前：常駐特殊効果17
	// 説明：常駐特殊効果17
	int32_t spEffectID17_1EC;

	// 名前：常駐特殊効果18
	// 説明：常駐特殊効果18
	int32_t spEffectID18_1F0;

	// 名前：常駐特殊効果19
	// 説明：常駐特殊効果19
	int32_t spEffectID19_1F4;

	// 名前：常駐特殊効果20
	// 説明：常駐特殊効果20
	int32_t spEffectID20_1F8;

	// 名前：常駐特殊効果21
	// 説明：常駐特殊効果21
	int32_t spEffectID21_1FC;

	// 名前：常駐特殊効果22
	// 説明：常駐特殊効果22
	int32_t spEffectID22_200;

	// 名前：常駐特殊効果23
	// 説明：常駐特殊効果23
	int32_t spEffectID23_204;

	// 名前：常駐特殊効果24
	// 説明：常駐特殊効果24
	int32_t spEffectID24_208;

	// 名前：常駐特殊効果25
	// 説明：常駐特殊効果25
	int32_t spEffectID25_20C;

	// 名前：常駐特殊効果26
	// 説明：常駐特殊効果26
	int32_t spEffectID26_210;

	// 名前：常駐特殊効果27
	// 説明：常駐特殊効果27
	int32_t spEffectID27_214;

	// 名前：常駐特殊効果28
	// 説明：常駐特殊効果28
	int32_t spEffectID28_218;

	// 名前：常駐特殊効果29
	// 説明：常駐特殊効果29
	int32_t spEffectID29_21C;

	// 名前：常駐特殊効果30
	// 説明：常駐特殊効果30
	int32_t spEffectID30_220;

	// 名前：常駐特殊効果31
	// 説明：常駐特殊効果31
	int32_t spEffectID31_224;

	// 名前：ロック不可領域の中心角[deg]
	// 説明：敵の真下に円錐状のロックオン不可領域を作る。円錐の広さの角度。TAEから一時的に変更可能
	float disableLockOnAng_228;

	// 名前：クロスOffLODレベル
	// 説明：クロスの処理を切るLODレベルを設定する
	int8_t clothOffLodLevel_22C;

	// 名前：起伏にあわせるのにFootIK結果を用いるか
	// 説明：キャラを地面の起伏に合わせる際に、FootIK結果を用いるか。飛行キャラの場合は使用不可
	uint8_t isUseFootIKNormalByUnduration_22D: 1;

	// 名前：初期死亡時にカプセル接地するか
	// 説明：初期死亡時にカプセル接地するか
	uint8_t attachHitInitializeDead_22D: 1;

	// 名前：グループ報酬判定から外すか
	// 説明：グループ報酬：「全員死亡」の判定において、このパラメータが○のキャラは判定から除外する 
	uint8_t excludeGroupRewardCheck_22D: 1;

	// 名前：ロックダミポリ(エネミー用)212が有効か
	// 説明：ロックダミポリ(エネミー用)212が有効か
	uint8_t enableAILockDmyPoly_212_22D: 1;

	// 名前：ロックダミポリ(エネミー用)213が有効か
	// 説明：ロックダミポリ(エネミー用)213が有効か
	uint8_t enableAILockDmyPoly_213_22D: 1;

	// 名前：ロックダミポリ(エネミー用)214が有効か
	// 説明：ロックダミポリ(エネミー用)214が有効か
	uint8_t enableAILockDmyPoly_214_22D: 1;

	// 名前：オープン_XB1から除外
	// 説明：オープン_XB1から除外
	uint8_t disableActivateOpen_xb1_22D: 1;

	// 名前：レガシー_XB1から除外
	// 説明：レガシー_XB1から除外
	uint8_t disableActivateLegacy_xb1_22D: 1;

	// 名前：HPエスト瓶／MPエスト瓶回復数パラメータID
	// 説明：キャラクター死亡時に値と同じ エスト使用回数回復パラメータ.xlsm　のデータIDを取得してエスト瓶を回復させる。 -1なら未使用
	int16_t estusFlaskRecoveryParamId_22E;

	// 名前：ロール名テキストID
	// 説明：召喚時のロール名を指定する。-1:対象霊体のデフォルトロール名を使用。0:表示なし。1以上:テキストＩＤとして利用。
	int32_t roleNameId_230;

	// 名前：HP&MPエスト瓶回復 抽選確率
	// 説明：敵を倒した際のHP/MPエストの回復確率。10000 を分母とし、分子をNPCパラから取得する。 
	uint16_t estusFlaskLotPoint_234;

	// 名前：HPエスト瓶回復 抽選確率
	// 説明：敵を倒した際のMPエストの回復確率。10000 を分母とし、分子をNPCパラから取得する。 
	uint16_t hpEstusFlaskLotPoint_236;

	// 名前：MPエスト瓶回復 抽選確率
	// 説明：敵を倒した際のMPエストの回復確率。10000 を分母とし、分子をNPCパラから取得する。 
	uint16_t mpEstusFlaskLotPoint_238;

	// 名前：HP&MPエスト瓶回復 落選時 加算抽選確率
	// 説明：HP/MPエスト回復抽選に外れた際の次回確率上昇値。分子の加算値。
	uint16_t estusFlaskRecovery_failedLotPointAdd_23A;

	// 名前：HPエスト瓶回復 落選時 加算抽選確率
	// 説明：HPエスト回復抽選に外れた際の次回確率上昇値。分子の加算値。
	uint16_t hpEstusFlaskRecovery_failedLotPointAdd_23C;

	// 名前：MPエスト瓶回復 落選時 加算抽選確率
	// 説明：MPエスト回復抽選に外れた際の次回確率上昇値。分子の加算値。
	uint16_t mpEstusFlaskRecovery_failedLotPointAdd_23E;

	// 名前：ファントムシェーダを使用して徘徊ゴーストになるか
	// 説明：ゲスト側でだけ指定されたIDのファントムシェーダIDを指定して幻影化
	int32_t WanderGhostPhantomId_240;

	// 名前：聴覚用 頭のサイズ[m]
	// 説明：聴覚判定時のカプセルオフセットの代わりに、設定するオフセットサイズ。0以上が設定されている場合のみ、この値をオフセットとして使用。
	float hearingHeadSize_244;

	// 名前：サウンドバンクID
	// 説明：サウンドバンクIDが指定できます -1：キャラID(リソース名)のバンクを使用
	int16_t SoundBankId_248;

	// 名前：起伏にあわせる最大前後角度
	// 説明：起伏に前後の角度を合わせる場合の上限角度。全長が長い場合には低めに設定したほうがよいです。
	uint8_t forwardUndulationLimit_24A;

	// 名前：起伏にあわせる最大左右角度
	// 説明：起伏に左右の角度を合わせる場合の上限角度。全長が長い場合には低めに設定したほうがよいです。
	uint8_t sideUndulationLimit_24B;

	// 名前：小隊ディアクティブ移動の移動速度[m/s]
	// 説明：小隊ディアクティブ移動の移動速度[m/s]
	float deactiveMoveSpeed_24C;

	// 名前：小隊ディアクティブ移動に切り替わる距離[m]
	// 説明：小隊ディアクティブ移動に切り替わる距離[m]
	float deactiveMoveDist_250;

	// 名前：サウンド音源有効距離[m]
	// 説明：キャラ音源が有効なプレイヤーからの距離です。-1：全距離で有効
	float enableSoundObjDist_254;

	// 名前：起伏にあわせる補正ゲイン値
	// 説明：起伏に角度を合わせる際の速度を設定する
	float undulationCorrectGain_258;

	// 名前：フットデカール識別子2
	// 説明：フットエフェクト発生時に貼られるデカール。床材質も考慮される
	int16_t autoFootEffectDecalBaseId2_25C;

	// 名前：フットデカール識別子3
	// 説明：フットエフェクト発生時に貼られるデカール。床材質も考慮される
	int16_t autoFootEffectDecalBaseId3_25E;

	// 名前：リターゲット参照キャラID
	// 説明：モーションのリターゲット先の指定の際に参照するキャラID
	int16_t RetargetReferenceChrId_260;

	// 名前：SFXリソースバンクID
	// 説明：SFXリソースバンクIDが指定できます -1：キャラID(リソース名)のバンクを使用
	int16_t SfxResBankId_262;

	// 名前：更新とアクティベイトの優先度
	// 説明：アクティベート・更新レベルの決定に使用する。大きいほどプレイヤーから離れていても更新レベルが下がらない。
	float updateActivatePriolity_264;

	// 名前：死亡前ナビメッシュフラグ
	// 説明：キャラクターが生存してる間、触れているナビメッシュに値のフラグを設定する。移動に追従しない。
	uint8_t chrNavimeshFlag_Alive_268;

	// 名前：死亡後ナビメッシュフラグ
	// 説明：キャラクターが死亡してる間、触れているナビメッシュに値のフラグを設定する。移動に追従しない。
	uint8_t chrNavimeshFlag_Dead_269;

	// 名前：pad
	uint8_t pad7_26A[1];

	// 名前：車輪制御タイプ
	// 説明：車輪制御タイプ
	uint8_t wheelRotType_26B;

	// 名前：車輪の半径
	// 説明：車輪の半径を指定[m]
	float wheelRotRadius_26C;

	// 名前：リターゲット移動量倍率
	// 説明：リターゲット時の移動量の倍率
	float retargetMoveRate_270;

	// 名前：はしごワープ位置オフセット
	// 説明：指定された値でダミポリZ軸方向にオフセットします。正数・負数どちらも指定可能です。
	float ladderWarpOffset_274;

	// 名前：読み込みアセットID
	// 説明：キャラロード時に関連して読み込むアセットID（キャラが動的に生成するなど用。
	int32_t loadAssetId_278;

	// 名前：オーバーラップカメラ対象ロックダミポリID
	// 説明：オーバーラップカメラを有効にするダミポリID(220～227)を設定します。-1の場合は無効になります。
	int32_t overlapCameraDmypolyId_27C;

	// 名前：常駐マテリアル拡張パラID0
	// 説明：常駐マテリアル拡張パラID0
	int32_t residentMaterialExParamId00_280;

	// 名前：常駐マテリアル拡張パラID1
	// 説明：常駐マテリアル拡張パラID1
	int32_t residentMaterialExParamId01_284;

	// 名前：常駐マテリアル拡張パラID2
	// 説明：常駐マテリアル拡張パラID2
	int32_t residentMaterialExParamId02_288;

	// 名前：常駐マテリアル拡張パラID3
	// 説明：常駐マテリアル拡張パラID3
	int32_t residentMaterialExParamId03_28C;

	// 名前：常駐マテリアル拡張パラID4
	// 説明：常駐マテリアル拡張パラID4
	int32_t residentMaterialExParamId04_290;

	// 名前：ネムリ時アイテム抽選ID_エネミー用
	// 説明：ネムリ収集時に取得するアイテムの抽選ID_エネミー用を指定。どちらか片方のみ設定してください。
	int32_t sleepCollectorItemLotId_enemy_294;

	// 名前：ネムリ時アイテム抽選ID_マップ用
	// 説明：ネムリ収集時に取得するアイテムの抽選ID_マップ用を指定。どちらか片方のみ設定してください。
	int32_t sleepCollectorItemLotId_map_298;

	// 名前：FootIK見た目の高さ補正ONゲイン値
	// 説明：FootIK見た目の高さ補正ONゲイン値
	float footIkErrorOnGain_29C;

	// 名前：FootIK見た目の高さ補正OFFゲイン値
	// 説明：FootIK見た目の高さ補正OFFゲイン値
	float footIkErrorOffGain_2A0;

	// 名前：追加サウンドバンクID
	// 説明：追加のサウンドバンクIDが指定できます -1 or 0：追加なし(SEQ16135)
	int16_t SoundAddBankId_2A4;

	// 名前：防御材質バリエーション値
	// 説明：防御材質と組み合わせて状態異常、ダメージSFX,SEのバリエーション分けに使用する値です。SEQ16473
	uint8_t materialVariationValue_2A6;

	// 名前：弱点防御材質バリエーション値
	// 説明：弱点防御材質と組み合わせて状態異常、ダメージSFX,SEのバリエーション分けに使用する値です。SEQ16473
	uint8_t materialVariationValue_Weak_2A7;

	// 名前：SA耐久力
	// 説明：スーパーアーマー耐久値
	float superArmorDurability_2A8;

	// 名前：SA回復速度補正値
	// 説明：SA基礎回復量に乗算してSA回復速度を補正する
	float saRecoveryRate_2AC;

	// 名前：SA攻撃カット率[％]
	// 説明：ガード成功時のSＡダメージのカット率
	float saGuardCutRate_2B0;

	// 名前：出血耐性 補正ルールID
	// 説明：状態異常の発動時、状態異常耐性補正パラメータの設定値を使って、一時的に最大値を変動させる
	int32_t resistCorrectId_blood_2B4;

	// 名前：呪耐性 補正ルールID
	// 説明：状態異常の発動時、状態異常耐性補正パラメータの設定値を使って、一時的に最大値を変動させる
	int32_t resistCorrectId_curse_2B8;

	// 名前：冷気耐性 補正ルールID
	// 説明：状態異常の発動時、状態異常耐性補正パラメータの設定値を使って、一時的に最大値を変動させる
	int32_t resistCorrectId_freeze_2BC;

	// 名前：睡眠耐性 補正ルールID
	// 説明：状態異常の発動時、状態異常耐性補正パラメータの設定値を使って、一時的に最大値を変動させる
	int32_t resistCorrectId_sleep_2C0;

	// 名前：発狂耐性 補正ルールID
	// 説明：状態異常の発動時、状態異常耐性補正パラメータの設定値を使って、一時的に最大値を変動させる
	int32_t resistCorrectId_madness_2C4;

	// 名前：キャラ死亡チュートリアル判定フラグID
	// 説明：初めてキャラ倒した時のチュートリアル用のイベントフラグID。キャラ死亡時にフラグON。
	uint32_t chrDeadTutorialFlagId_2C8;

	// 名前：段差越え表示補間時間
	// 説明：段差越え表示補間時間
	float stepDispInterpolateTime_2CC;

	// 名前：段差越え表示起動判定値
	// 説明：段差越え表示起動判定値
	float stepDispInterpolateTriggerValue_2D0;

	// 名前：ロックスコア補正値
	// 説明：ロックスコア補正値
	float lockScoreOffset_2D4;

	// 名前：パディング12
	uint8_t pad12_2D8[8];

} NpcParam;

#endif
