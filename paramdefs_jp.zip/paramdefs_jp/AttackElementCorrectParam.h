/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AttackElementCorrectParam_H
#define _PARAM_AttackElementCorrectParam_H
#include <stdint.h>

// ATTACK_ELEMENT_CORRECT_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AttackElementCorrectParam {

	// 名前：筋力補正するか（物理）
	uint8_t isStrengthCorrect_byPhysics_000: 1;

	// 名前：技量補正するか（物理）
	uint8_t isDexterityCorrect_byPhysics_000: 1;

	// 名前：理力補正するか（物理）
	uint8_t isMagicCorrect_byPhysics_000: 1;

	// 名前：信仰補正するか（物理）
	uint8_t isFaithCorrect_byPhysics_000: 1;

	// 名前：運補正するか（物理）
	uint8_t isLuckCorrect_byPhysics_000: 1;

	// 名前：筋力補正するか（魔法）
	uint8_t isStrengthCorrect_byMagic_000: 1;

	// 名前：技量補正するか（魔法）
	uint8_t isDexterityCorrect_byMagic_000: 1;

	// 名前：理力補正するか（魔法）
	uint8_t isMagicCorrect_byMagic_000: 1;

	// 名前：信仰補正するか（魔法）
	uint8_t isFaithCorrect_byMagic_001: 1;

	// 名前：運補正するか（魔法）
	uint8_t isLuckCorrect_byMagic_001: 1;

	// 名前：筋力補正するか（炎）
	uint8_t isStrengthCorrect_byFire_001: 1;

	// 名前：技量補正するか（炎）
	uint8_t isDexterityCorrect_byFire_001: 1;

	// 名前：理力補正するか（炎）
	uint8_t isMagicCorrect_byFire_001: 1;

	// 名前：信仰補正するか（炎）
	uint8_t isFaithCorrect_byFire_001: 1;

	// 名前：運補正するか（炎）
	uint8_t isLuckCorrect_byFire_001: 1;

	// 名前：筋力補正するか（雷）
	uint8_t isStrengthCorrect_byThunder_001: 1;

	// 名前：技量補正するか（雷）
	uint8_t isDexterityCorrect_byThunder_002: 1;

	// 名前：理力補正するか（雷）
	uint8_t isMagicCorrect_byThunder_002: 1;

	// 名前：信仰補正するか（雷）
	uint8_t isFaithCorrect_byThunder_002: 1;

	// 名前：運補正するか（雷）
	uint8_t isLuckCorrect_byThunder_002: 1;

	// 名前：筋力補正するか（闇）
	uint8_t isStrengthCorrect_byDark_002: 1;

	// 名前：技量補正するか（闇）
	uint8_t isDexterityCorrect_byDark_002: 1;

	// 名前：理力補正するか（闇）
	uint8_t isMagicCorrect_byDark_002: 1;

	// 名前：信仰補正するか（闇）
	uint8_t isFaithCorrect_byDark_002: 1;

	// 名前：運補正するか（闇）
	uint8_t isLuckCorrect_byDark_003: 1;

	// 名前：パディング
	uint8_t pad1_003: 7;

	// 名前：筋力補正値上書き（物理）
	int16_t overwriteStrengthCorrectRate_byPhysics_004;

	// 名前：技量補正値上書き（物理）
	int16_t overwriteDexterityCorrectRate_byPhysics_006;

	// 名前：理力補正値上書き（物理）
	int16_t overwriteMagicCorrectRate_byPhysics_008;

	// 名前：信仰補正値上書き（物理）
	int16_t overwriteFaithCorrectRate_byPhysics_00A;

	// 名前：運補正値上書き（物理）
	int16_t overwriteLuckCorrectRate_byPhysics_00C;

	// 名前：筋力補正値上書き（魔法）
	int16_t overwriteStrengthCorrectRate_byMagic_00E;

	// 名前：技量補正値上書き（魔法）
	int16_t overwriteDexterityCorrectRate_byMagic_010;

	// 名前：理力補正値上書き（魔法）
	int16_t overwriteMagicCorrectRate_byMagic_012;

	// 名前：信仰補正値上書き（魔法）
	int16_t overwriteFaithCorrectRate_byMagic_014;

	// 名前：運補正値上書き（魔法）
	int16_t overwriteLuckCorrectRate_byMagic_016;

	// 名前：筋力補正値上書き（炎）
	int16_t overwriteStrengthCorrectRate_byFire_018;

	// 名前：技量補正値上書き（炎）
	int16_t overwriteDexterityCorrectRate_byFire_01A;

	// 名前：理力補正値上書き（炎）
	int16_t overwriteMagicCorrectRate_byFire_01C;

	// 名前：信仰補正値上書き（炎）
	int16_t overwriteFaithCorrectRate_byFire_01E;

	// 名前：運補正値上書き（炎）
	int16_t overwriteLuckCorrectRate_byFire_020;

	// 名前：筋力補正値上書き（雷）
	int16_t overwriteStrengthCorrectRate_byThunder_022;

	// 名前：技量補正値上書き（雷）
	int16_t overwriteDexterityCorrectRate_byThunder_024;

	// 名前：理力補正値上書き（雷）
	int16_t overwriteMagicCorrectRate_byThunder_026;

	// 名前：信仰補正値上書き（雷）
	int16_t overwriteFaithCorrectRate_byThunder_028;

	// 名前：運補正値上書き（雷）
	int16_t overwriteLuckCorrectRate_byThunder_02A;

	// 名前：筋力補正値上書き（闇）
	int16_t overwriteStrengthCorrectRate_byDark_02C;

	// 名前：技量補正値上書き（闇）
	int16_t overwriteDexterityCorrectRate_byDark_02E;

	// 名前：理力補正値上書き（闇）
	int16_t overwriteMagicCorrectRate_byDark_030;

	// 名前：信仰補正値上書き（闇）
	int16_t overwriteFaithCorrectRate_byDark_032;

	// 名前：運補正値上書き（闇）
	int16_t overwriteLuckCorrectRate_byDark_034;

	// 名前：筋力補正値影響率（物理）
	// 説明：補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byPhysics_036;

	// 名前：技量補正値影響率（物理）
	// 説明：補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byPhysics_038;

	// 名前：理力補正値影響率（物理）
	// 説明：補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byPhysics_03A;

	// 名前：信仰補正値影響率（物理）
	// 説明：補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byPhysics_03C;

	// 名前：運補正値影響率（物理）
	// 説明：補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byPhysics_03E;

	// 名前：筋力補正値影響率（魔法）
	// 説明：補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byMagic_040;

	// 名前：技量補正値影響率（魔法）
	// 説明：補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byMagic_042;

	// 名前：理力補正値影響率（魔法）
	// 説明：補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byMagic_044;

	// 名前：信仰補正値影響率（魔法）
	// 説明：補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byMagic_046;

	// 名前：運補正値影響率（魔法）
	// 説明：補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byMagic_048;

	// 名前：筋力補正値影響率（炎）
	// 説明：補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byFire_04A;

	// 名前：技量補正値影響率（炎）
	// 説明：補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byFire_04C;

	// 名前：理力補正値影響率（炎）
	// 説明：補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byFire_04E;

	// 名前：信仰補正値影響率（炎）
	// 説明：補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byFire_050;

	// 名前：運補正値影響率（炎）
	// 説明：補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byFire_052;

	// 名前：筋力補正値影響率（雷）
	// 説明：補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byThunder_054;

	// 名前：技量補正値影響率（雷）
	// 説明：補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byThunder_056;

	// 名前：理力補正値影響率（雷）
	// 説明：補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byThunder_058;

	// 名前：信仰補正値影響率（雷）
	// 説明：補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byThunder_05A;

	// 名前：運補正値影響率（雷）
	// 説明：補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byThunder_05C;

	// 名前：筋力補正値影響率（闇）
	// 説明：補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byDark_05E;

	// 名前：技量補正値影響率（闇）
	// 説明：補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byDark_060;

	// 名前：理力補正値影響率（闇）
	// 説明：補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byDark_062;

	// 名前：信仰補正値影響率（闇）
	// 説明：補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byDark_064;

	// 名前：運補正値影響率（闇）
	// 説明：補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byDark_066;

	// 名前：パディング
	uint8_t pad2_068[24];

} AttackElementCorrectParam;

#endif
