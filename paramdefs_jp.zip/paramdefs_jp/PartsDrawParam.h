/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PartsDrawParam_H
#define _PARAM_PartsDrawParam_H
#include <stdint.h>

// PARTS_DRAW_PARAM_ST
// Data Version: 5
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _PartsDrawParam {

	// 名前：LODレベル0-1境界距離[m]
	// 説明：切り替わる中心
	float lv01_BorderDist_000;

	// 名前：LODレベル0-1遊び距離[m]
	// 説明：境界中心で±遊び
	float lv01_PlayDist_004;

	// 名前：LODレベル1-2境界距離[m]
	// 説明：切り替わる中心
	float lv12_BorderDist_008;

	// 名前：LODレベル1-2遊び距離[m]
	// 説明：境界中心で±遊び
	float lv12_PlayDist_00C;

	// 名前：LODレベル2-3境界距離[m]
	// 説明：切り替わる中心
	float lv23_BorderDist_010;

	// 名前：LODレベル2-3遊び距離[m]
	// 説明：境界中心で±遊び
	float lv23_PlayDist_014;

	// 名前：LODレベル3-4境界距離[m]
	// 説明：切り替わる中心
	float lv34_BorderDist_018;

	// 名前：LODレベル3-4遊び距離[m]
	// 説明：境界中心で±遊び
	float lv34_PlayDist_01C;

	// 名前：LODレベル4-5境界距離[m]
	// 説明：切り替わる中心
	float lv45_BorderDist_020;

	// 名前：LODレベル4-5遊び距離[m]
	// 説明：境界中心で±遊び
	float lv45_PlayDist_024;

	// 名前：TextureLODレベル0-1境界距離[m]
	// 説明：Texture切り替わる中心(0でTexureLOD無効)
	float tex_lv01_BorderDist_028;

	// 名前：TextureLODレベル0-1遊び距離[m]
	// 説明：Texture境界中心で±遊び
	float tex_lv01_PlayDist_02C;

	// 名前：クロスフェード有効
	// 説明：クロスフェード有効か(0:無効,1:有効)
	uint32_t enableCrossFade_030: 1;

	// 名前：描画距離[m]
	// 説明：描画最大距離。オープンではアクティベート距離に利用されます
	float drawDist_030;

	// 名前：フェード範囲[m]
	// 説明：描画最大距離から、実際に消えるまでのフェード距離
	float drawFadeRange_034;

	// 名前：影描画距離[m]
	// 説明：影の描画最大距離
	float shadowDrawDist_038;

	// 名前：影フェード範囲[m]
	// 説明：影の描画最大距離から、実際に消えるまでのフェード距離
	float shadowFadeRange_03C;

	// 名前：モーションブラー描画境界距離[m]
	// 説明：モーションブラーが有効になる距離
	float motionBlur_BorderDist_040;

	// 名前：点光源の影を落とす
	// 説明：点光源の影を落とす
	int8_t isPointLightShadowSrc_044;

	// 名前：平行光源の影を落とす
	// 説明：平行光源の影を落とす
	int8_t isDirLightShadowSrc_045;

	// 名前：影を受ける
	// 説明：影を受ける
	int8_t isShadowDst_046;

	// 名前：影描画のみ
	// 説明：影描画のみ
	int8_t isShadowOnly_047;

	// 名前：映り込む
	// 説明：映り込む
	int8_t drawByReflectCam_048;

	// 名前：映り込み描画のみ
	// 説明：映り込み描画のみ
	int8_t drawOnlyReflectCam_049;

	// 名前：どのレベルのLodMapまで含めるか
	// 説明：どのレベルのLodMapまで含めるか
	int8_t IncludeLodMapLv_04A;

	// 名前：FarClipしない
	// 説明：ファークリップを無効にし、常にクリップ空間の一番奥の深度に描画する。主に天球用
	uint8_t isNoFarClipDraw_04B;

	// 名前：LODタイプ
	// 説明：LOD対象の種類、大きさ
	uint8_t lodType_04C;

	// 名前：影描画LODレベルオフセット
	// 説明：影描画時のLODレベルオフセット値
	int8_t shadowDrawLodOffset_04D;

	// 名前：カメラをXZ平面上で追従する
	// 説明：カメラをXZ平面上で追従する(GR SEQ09242)
	uint8_t isTraceCameraXZ_04E;

	// 名前：天球描画フェイズに切り替え
	// 説明：描画フェイズを天球に設定する(GR SEQ09242)
	uint8_t isSkydomeDrawPhase_04F;

	// 名前：遠景切り替え距離[m]
	// 説明：遠景切り替え距離[m]
	float DistantViewModel_BorderDist_050;

	// 名前：遠景切り替え遊び距離[m]
	// 説明：遠景切り替え遊び距離[m]
	float DistantViewModel_PlayDist_054;

	// 名前：オープン用構築制限距離[m]
	// 説明：オープン用構築制限距離[m]。オープンにおいてカメラとの距離がこの距離未満だと構築されないようになります。遠景アセット用の機能です。-1:機能無効(デフォルト)
	float LimtedActivate_BorderDist_forGrid_058;

	// 名前：オープン用構築制限遊び距離[m]
	// 説明：オープン構築制限遊び距離[m]
	float LimtedActivate_PlayDist_forGrid_05C;

	// 名前：Zソートオフセット
	// 説明：同じ描画フェーズ内でカメラからの距離が同じ場合、半透明系は小さいほうが手前、不透明系は値が大きいほうが手前に描画されます。 オフセットの基点は天球描画フェーズのものは原点。それ以外はModelAABB中心。(GR SEQ09242)
	float zSortOffsetForNoFarClipDraw_060;

	// 名前：影描画アルファテスト有効距離[m]
	// 説明：影描画時にアルファテストを行う距離[m]
	float shadowDrawAlphaTestDist_064;

	// 名前：Forward描画物の環境マップブレンドタイプ
	// 説明：Forward描画物の環境マップブレンドタイプ
	uint8_t fowardDrawEnvmapBlendType_068;

	// 名前：描画距離スケールパラメータID
	// 説明：ロードバランサー描画距離スケールパラメータID
	uint8_t LBDrawDistScaleParamID_069;

	// 名前：予約
	// 説明：予約
	uint8_t resereve_06A[34];

} PartsDrawParam;

#endif
