/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MultiSoulBonusRateParam_H
#define _PARAM_MultiSoulBonusRateParam_H
#include <stdint.h>

// MULTI_SOUL_BONUS_RATE_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MultiSoulBonusRateParam {

	// 名前：ホスト
	// 説明：ホストの報酬ソウル倍率
	float host_000;

	// 名前：白サイン
	// 説明：協力サインの白霊の報酬ソウル倍率
	float WhiteGhost_None_004;

	// 名前：金霊（太陽）
	// 説明：協力サインの金霊の報酬ソウル倍率
	float WhiteGhost_Umbasa_008;

	// 名前：白バーサーカー
	// 説明：協力サインの白バーサーカーの報酬ソウル倍率
	float WhiteGhost_Berserker_00C;

	// 名前：赤サイン
	// 説明：敵対サインの赤霊の報酬ソウル倍率
	float BlackGhost_None_Sign_010;

	// 名前：赤金霊（サイン）
	// 説明：敵対サインの赤金霊の報酬ソウル倍率
	float BlackGhost_Umbasa_Sign_014;

	// 名前：赤バーサーカー（サイン）
	// 説明：敵対サインの赤バーサーカーの報酬ソウル倍率
	float BlackGhost_Berserker_Sign_018;

	// 名前：侵入
	// 説明：侵入の報酬ソウル倍率
	float BlackGhost_None_Invade_01C;

	// 名前：赤金霊（侵入）
	// 説明：侵入オーブの赤金霊の報酬ソウル倍率
	float BlackGhost_Umbasa_Invade_020;

	// 名前：赤バーサーカー（侵入）
	// 説明：侵入オーブの赤バーサーカーの報酬ソウル倍率
	float BlackGhost_Berserker_Invade_024;

	// 名前：救援ゲスト
	// 説明：救援ゲストの報酬ソウル倍率
	float RedHunter1_028;

	// 名前：赤狩り霊２
	// 説明：赤狩り霊２の報酬ソウル倍率
	float RedHunter2_02C;

	// 名前：マップ守護霊(森)
	// 説明：マップ守護霊（森）の報酬ソウル倍率
	float GuardianOfForest_030;

	// 名前：マップ守護霊(アノール)
	// 説明：マップ守護霊(アノール)の報酬ソウル倍率
	float GuardianOfAnor_034;

	// 名前：闘技場
	// 説明：闘技場の報酬ソウル倍率
	float BattleRoyal_038;

	// 名前：黄衣の翁
	// 説明：黄衣の翁の報酬ソウル倍率
	float YellowMonk_03C;

	// 名前：pad
	uint8_t pad1_040[64];

} MultiSoulBonusRateParam;

#endif
