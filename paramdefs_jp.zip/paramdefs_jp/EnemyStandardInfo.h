/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EnemyStandardInfo_H
#define _PARAM_EnemyStandardInfo_H
#include <stdint.h>

// ENEMY_STANDARD_INFO_BANK
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EnemyStandardInfo {

	// 名前：挙動ｉｄ
	// 説明：敵の挙動ＩＤ
	int32_t EnemyBehaviorID_000;

	// 名前：ヒットポイント
	// 説明：ヒットポイント
	uint16_t HP_004;

	// 名前：攻撃力
	// 説明：攻撃力（プロト専用）
	uint16_t AttackPower_006;

	// 名前：キャラタイプ
	// 説明：キャラタイプ
	int32_t ChrType_008;

	// 名前：あたりの高さ[m]
	// 説明：あたりの高さ（直径以上のサイズを指定してください）
	float HitHeight_00C;

	// 名前：あたりの半径[m]
	// 説明：あたりの半径
	float HitRadius_010;

	// 名前：重さ[kg]
	// 説明：キャラの重さ
	float Weight_014;

	// 名前：動摩擦力
	// 説明：動摩擦力
	float DynamicFriction_018;

	// 名前：静摩擦力
	// 説明：静止摩擦力
	float StaticFriction_01C;

	// 名前：上半身初期状態
	// 説明：上半身初期状態（PG入力）
	int32_t UpperDefState_020;

	// 名前：アクション初期状態
	// 説明：アクション初期状態（PG入力）
	int32_t ActionDefState_024;

	// 名前：単位時間当たり旋回できる角度[deg/s]
	// 説明：単位時間当たりのＹ軸旋回角度[deg/s]
	float RotY_per_Second_028;

	// 名前：予約
	uint8_t reserve0_02C[20];

	// 名前：未使用
	// 説明：未使用
	uint8_t RotY_per_Second_old_040;

	// 名前：左右移動できるか
	// 説明：左右移動できるか
	uint8_t EnableSideStep_041;

	// 名前：キャラあたりにラグドールを使用するか
	// 説明：キャラあたりにラグドールを使用するか
	uint8_t UseRagdollHit_042;

	// 名前：予約
	uint8_t reserve_last_043[5];

	// 名前：スタミナ量
	// 説明：スタミナ総量
	uint16_t stamina_048;

	// 名前：スタミナ回復
	// 説明：1秒間あたりのスタミナ回復量
	uint16_t staminaRecover_04A;

	// 名前：スタミナ基本消費
	// 説明：攻撃、ガード時に使用するスタミナ消費の基本値
	uint16_t staminaConsumption_04C;

	// 名前：物理防御力
	// 説明：物理攻撃に対するダメージ減少基本値
	uint16_t deffenct_Phys_04E;

	// 名前：予約1
	uint8_t reserve_last2_050[48];

} EnemyStandardInfo;

#endif
