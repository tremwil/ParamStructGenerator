/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_GameAreaParam_H
#define _PARAM_GameAreaParam_H
#include <stdint.h>

// GAME_AREA_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GameAreaParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：シングル時クリアボーナスソウル量
	// 説明：エリアボスを倒したときに取得できるソウル量(シングルプレイ時)
	uint32_t bonusSoul_single_004;

	// 名前：マルチプレイ時クリアボーナスソウル量
	// 説明：エリアボスを倒したときに取得できるソウル量(マルチプレイ時)
	uint32_t bonusSoul_multi_008;

	// 名前：人間性ドロップポイントカウント先頭フラグID
	// 説明：人間性ドロップポイントを管理する為の先頭フラグID(20Bit使用)
	uint32_t humanityPointCountFlagIdTop_00C;

	// 名前：人間性ドロップ必要ポイント1
	// 説明：人間性を取得する為の閾値1
	uint16_t humanityDropPoint1_010;

	// 名前：人間性ドロップ必要ポイント2
	// 説明：人間性を取得する為の閾値2
	uint16_t humanityDropPoint2_012;

	// 名前：人間性ドロップ必要ポイント3
	// 説明：人間性を取得する為の閾値3
	uint16_t humanityDropPoint3_014;

	// 名前：人間性ドロップ必要ポイント4
	// 説明：人間性を取得する為の閾値4
	uint16_t humanityDropPoint4_016;

	// 名前：人間性ドロップ必要ポイント5
	// 説明：人間性を取得する為の閾値5
	uint16_t humanityDropPoint5_018;

	// 名前：人間性ドロップ必要ポイント6
	// 説明：人間性を取得する為の閾値6
	uint16_t humanityDropPoint6_01A;

	// 名前：人間性ドロップ必要ポイント7
	// 説明：人間性を取得する為の閾値7
	uint16_t humanityDropPoint7_01C;

	// 名前：人間性ドロップ必要ポイント8
	// 説明：人間性を取得する為の閾値8
	uint16_t humanityDropPoint8_01E;

	// 名前：人間性ドロップ必要ポイント9
	// 説明：人間性を取得する為の閾値9
	uint16_t humanityDropPoint9_020;

	// 名前：人間性ドロップ必要ポイント10
	// 説明：人間性を取得する為の閾値10
	uint16_t humanityDropPoint10_022;

	// 名前：ソロ侵入ポイント加算値下限
	// 説明：エリアボスを倒したときに加算するソロ侵入ポイントの最小値。
	uint32_t soloBreakInPoint_Min_024;

	// 名前：ソロ侵入ポイント加算値上限
	// 説明：エリアボスを倒したときに加算するソロ侵入ポイントの最大値。
	uint32_t soloBreakInPoint_Max_028;

	// 名前：ボス撃破済みフラグID(ホスト化時の目的表示用)
	// 説明：このフラグがONの場合はホスト化時の目的設定のリストに表示しない。0の場合は常時表示。
	uint32_t defeatBossFlagId_forSignAimList_02C;

	// 名前：目的表示フラグID
	uint32_t displayAimFlagId_030;

	// 名前：ボス発見フラグID
	uint32_t foundBossFlagId_034;

	// 名前：発見時テキストID
	int32_t foundBossTextId_038;

	// 名前：未発見時テキストID
	int32_t notFindBossTextId_03C;

	// 名前：ボス挑戦可能フラグID
	// 説明：ボス挑戦可能フラグID。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索で目的のボスを選ぶ時にこのフラグがONのボスが対象になる。0の場合は常に対象になる。
	uint32_t bossChallengeFlagId_040;

	// 名前：ボス撃破フラグID
	// 説明：ボス撃破フラグID。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索で目的のボスを選ぶ時にこのフラグがOFFのボスが対象になる。
	uint32_t defeatBossFlagId_044;

	// 名前：ボス位置_X座標
	// 説明：ボス位置_X座標（指定したマップからの相対座標）。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	float bossPosX_048;

	// 名前：ボス位置_Y座標
	// 説明：ボス位置_Y座標（指定したマップからの相対座標）。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	float bossPosY_04C;

	// 名前：ボス位置_Z座標
	// 説明：ボス位置_Z座標（指定したマップからの相対座標）。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	float bossPosZ_050;

	// 名前：ボス位置_エリア番号(mXX_00_00_00)
	// 説明：ボス位置_エリア番号(mXX_00_00_00)。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	uint8_t bossMapAreaNo_054;

	// 名前：ボス位置_グリッドX番号(m00_XX_00_00)
	// 説明：ボス位置_グリッドX番号(m00_XX_00_00)。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	uint8_t bossMapBlockNo_055;

	// 名前：ボス位置_グリッドZ番号(m00_00_XX_00)
	// 説明：ボス位置_グリッドZ番号(m00_00_XX_00)。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	uint8_t bossMapMapNo_056;

	// 名前：予約領域
	// 説明：予約領域
	uint8_t reserve_057[9];

} GameAreaParam;

#endif
