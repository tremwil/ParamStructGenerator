/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SfxBlockResShareParam_H
#define _PARAM_SfxBlockResShareParam_H
#include <stdint.h>

// SFX_BLOCK_RES_SHARE_PARAM
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SfxBlockResShareParam {

	// 名前：ブロックSfxリソース参照先マップ番号
	// 説明：リソースを参照するマップ番号。マップ番号を数値化した値を設定します。(m12_34_56_78→12345678)
	uint32_t shareBlockRsMapUidVal_000;

} SfxBlockResShareParam;

#endif
