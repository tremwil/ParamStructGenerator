/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_WaterQuality_H
#define _PARAM_Gconfig_WaterQuality_H
#include <stdint.h>

// CS_WATER_QUALITY_DETAIL
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_WaterQuality {

	// 名前：インタラクション有効
	// 説明：インタラクション有効
	uint8_t interactionEnabled_000;

	// 名前：dmy
	uint8_t dmy_001[3];

} Gconfig_WaterQuality;

#endif
