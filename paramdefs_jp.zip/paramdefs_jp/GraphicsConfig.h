/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_GraphicsConfig_H
#define _PARAM_GraphicsConfig_H
#include <stdint.h>

// CS_GRAPHICS_CONFIG_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GraphicsConfig {

	// 名前：テクスチャフィルタ品質
	// 説明：テクスチャフィルタ品質(デフォルトMidele)
	uint8_t m_textureFilterQuality_000;

	// 名前：AA品質
	// 説明：AA品質(デフォルトHigh)
	uint8_t m_aaQuality_001;

	// 名前：SSAO品質
	// 説明：SSAO品質(デフォルトHigh)
	uint8_t m_ssaoQuality_002;

	// 名前：被写界深度品質
	// 説明：被写界深度品質(デフォルトHigh)
	uint8_t m_dofQuality_003;

	// 名前：モーションブラー品質
	// 説明：モーションブラー品質(デフォルトHigh)
	uint8_t m_motionBlurQuality_004;

	// 名前：シャドウ品質
	// 説明：シャドウ品質(デフォルトHigh)
	uint8_t m_shadowQuality_005;

	// 名前：ライティング品質
	// 説明：ライティング品質(デフォルトHigh)
	uint8_t m_lightingQuality_006;

	// 名前：エフェクト品質
	// 説明：エフェクト品質(デフォルトHigh)
	uint8_t m_effectQuality_007;

	// 名前：デカール品質
	// 説明：デカール品質(デフォルトHigh)
	uint8_t m_decalQuality_008;

	// 名前：反射品質
	// 説明：反射品質(デフォルトHigh)
	uint8_t m_reflectionQuality_009;

	// 名前：ウォーター品質
	// 説明：ウォーター品質(デフォルトHigh)
	uint8_t m_waterQuality_00A;

	// 名前：シェーダー品質
	// 説明：シェーダー品質(デフォルトHigh)
	uint8_t m_shaderQuality_00B;

	// 名前：ボリューメトリック効果品質
	// 説明：ボリューメトリック効果品質(デフォルトHigh)
	uint8_t m_volumetricEffectQuality_00C;

	// 名前：dmy
	uint8_t m_dummy_00D[3];

} GraphicsConfig;

#endif
