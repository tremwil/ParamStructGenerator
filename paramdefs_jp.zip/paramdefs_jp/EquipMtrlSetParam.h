/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EquipMtrlSetParam_H
#define _PARAM_EquipMtrlSetParam_H
#include <stdint.h>

// EQUIP_MTRL_SET_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EquipMtrlSetParam {

	// 名前：必要素材アイテムID01
	// 説明：武具強化に必要な素材アイテムIDです。
	int32_t materialId01_000;

	// 名前：必要素材アイテムID02
	// 説明：武具強化に必要な素材アイテムIDです。
	int32_t materialId02_004;

	// 名前：必要素材アイテムID03
	// 説明：武具強化に必要な素材アイテムIDです。
	int32_t materialId03_008;

	// 名前：必要素材アイテムID04
	// 説明：武具強化に必要な素材アイテムIDです。
	int32_t materialId04_00C;

	// 名前：必要素材アイテムID05
	// 説明：武具強化に必要な素材アイテムIDです。
	int32_t materialId05_010;

	// 名前：必要素材アイテムID06
	// 説明：武具強化に必要な素材アイテムIDです。
	int32_t materialId06_014;

	// 名前：パディング
	// 説明：パディング。素材アイテムIDが増えたとき用
	uint8_t pad_id_018[8];

	// 名前：必要個数01
	// 説明：武具強化に必要な素材アイテムの個数です。
	int8_t itemNum01_020;

	// 名前：必要個数02
	// 説明：武具強化に必要な素材アイテムの個数です。
	int8_t itemNum02_021;

	// 名前：必要個数03
	// 説明：武具強化に必要な素材アイテムの個数です。
	int8_t itemNum03_022;

	// 名前：必要個数04
	// 説明：武具強化に必要な素材アイテムの個数です。
	int8_t itemNum04_023;

	// 名前：必要個数05
	// 説明：武具強化に必要な素材アイテムの個数です。
	int8_t itemNum05_024;

	// 名前：必要個数06
	// 説明：武具強化に必要な素材アイテムの個数です。
	int8_t itemNum06_025;

	// 名前：パディング
	// 説明：パディング。アイテムの個数が増えたとき用
	uint8_t pad_num_026[2];

	// 名前：必要素材アイテムカテゴリ01
	// 説明：武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate01_028;

	// 名前：必要素材アイテムカテゴリ02
	// 説明：武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate02_029;

	// 名前：必要素材アイテムカテゴリ03
	// 説明：武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate03_02A;

	// 名前：必要素材アイテムカテゴリ04
	// 説明：武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate04_02B;

	// 名前：必要素材アイテムカテゴリ05
	// 説明：武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate05_02C;

	// 名前：必要素材アイテムカテゴリ06
	// 説明：武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate06_02D;

	// 名前：パディング
	// 説明：パディング。カテゴリが増えたとき用
	uint8_t pad_cate_02E[2];

	// 名前：個数表示を無効化01
	// 説明：個数表示を無効化するか(強化ショップ用)
	uint8_t isDisableDispNum01_030: 1;

	// 名前：個数表示を無効化02
	// 説明：個数表示を無効化するか
	uint8_t isDisableDispNum02_030: 1;

	// 名前：個数表示を無効化03
	// 説明：個数表示を無効化するか
	uint8_t isDisableDispNum03_030: 1;

	// 名前：個数表示を無効化04
	// 説明：個数表示を無効化するか
	uint8_t isDisableDispNum04_030: 1;

	// 名前：個数表示を無効化05
	// 説明：個数表示を無効化するか
	uint8_t isDisableDispNum05_030: 1;

	// 名前：個数表示を無効化06
	// 説明：個数表示を無効化するか
	uint8_t isDisableDispNum06_030: 1;

	// 名前：パディング
	// 説明：パディングです。
	uint8_t pad_030[3];

} EquipMtrlSetParam;

#endif
