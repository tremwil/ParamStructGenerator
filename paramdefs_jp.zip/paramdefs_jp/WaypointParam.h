/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WaypointParam_H
#define _PARAM_WaypointParam_H
#include <stdint.h>

// WAYPOINT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WaypointParam {

	// 名前：属性1
	int16_t attribute1_000;

	// 名前：属性2
	int16_t attribute2_002;

	// 名前：属性3
	int16_t attribute3_004;

	// 名前：属性4
	int16_t attribute4_006;

	// 名前：パディング4
	uint8_t padding4_008[8];

} WaypointParam;

#endif
