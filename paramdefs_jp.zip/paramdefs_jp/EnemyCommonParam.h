/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EnemyCommonParam_H
#define _PARAM_EnemyCommonParam_H
#include <stdint.h>

// ENEMY_COMMON_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EnemyCommonParam {

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved0_000[8];

	// 名前：音ターゲットに対して接近を試みる時間
	int32_t soundTargetTryApproachTime_008;

	// 名前：索敵ターゲットに対して接近を試みる時間
	int32_t searchTargetTryApproachTime_00C;

	// 名前：記憶ターゲットに対して接近を試みる時間
	int32_t memoryTargetTryApproachTime_010;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved5_014[40];

	// 名前：特定時間帯配置のエネミーの出現・消滅に演出に使うファントムシェーダID
	// 説明：出現・消滅の演出でファントムシェーダをフェイドする、
	int32_t activateChrByTime_PhantomId_03C;

	// 名前：パス終端まで行くと敵が見切れそうなことがわかったインタラプト、を発生させる距離
	// 説明：Unreachパス時、終端と対象がこの距離以内ならインタラプトを発生させる
	float findUnfavorableFailedPointDist_040;

	// 名前：パス終端まで行くと敵が見切れそうなことがわかったインタラプト、を発生させる高さ
	// 説明：Unreachパス時、終端と対象がこの距離以上ならインタラプトを発生させる
	float findUnfavorableFailedPointHeight_044;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved18_048[184];

} EnemyCommonParam;

#endif
