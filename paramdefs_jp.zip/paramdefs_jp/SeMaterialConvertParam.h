/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SeMaterialConvertParam_H
#define _PARAM_SeMaterialConvertParam_H
#include <stdint.h>

// SE_MATERIAL_CONVERT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SeMaterialConvertParam {

	// 名前：SE材質ID
	// 説明：SFX材質ID（３桁）からSE材質ID（２桁）への変換
	uint8_t seMaterialId_000;

	// 名前：パディング
	// 説明：パディング
	uint8_t pad_001[3];

} SeMaterialConvertParam;

#endif
