/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PhantomParam_H
#define _PARAM_PhantomParam_H
#include <stdint.h>

// PHANTOM_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _PhantomParam {

	// 名前：A
	// 説明：エッジ色Aです。
	float edgeColorA_000;

	// 名前：A
	// 説明：正面色Aです。
	float frontColorA_004;

	// 名前：A
	// 説明：ディフューズ乗算色Aです。
	float diffMulColorA_008;

	// 名前：A
	// 説明：スペキュラ乗算色Aです。
	float specMulColorA_00C;

	// 名前：A
	// 説明：ライト色Aです。
	float lightColorA_010;

	// 名前：R
	// 説明：エッジ色Rです。
	uint8_t edgeColorR_014;

	// 名前：G
	// 説明：エッジ色Gです。
	uint8_t edgeColorG_015;

	// 名前：B
	// 説明：エッジ色Bです。
	uint8_t edgeColorB_016;

	// 名前：R
	// 説明：正面色Rです。
	uint8_t frontColorR_017;

	// 名前：G
	// 説明：正面色Gです。
	uint8_t frontColorG_018;

	// 名前：B
	// 説明：正面色Bです。
	uint8_t frontColorB_019;

	// 名前：R
	// 説明：ディフューズ乗算色Rです。
	uint8_t diffMulColorR_01A;

	// 名前：G
	// 説明：ディフューズ乗算色Gです。
	uint8_t diffMulColorG_01B;

	// 名前：B
	// 説明：ディフューズ乗算色Bです。
	uint8_t diffMulColorB_01C;

	// 名前：R
	// 説明：スペキュラ乗算色Rです。
	uint8_t specMulColorR_01D;

	// 名前：G
	// 説明：スペキュラ乗算色Gです。
	uint8_t specMulColorG_01E;

	// 名前：B
	// 説明：スペキュラ乗算色Bです。
	uint8_t specMulColorB_01F;

	// 名前：R
	// 説明：ライト色Rです。
	uint8_t lightColorR_020;

	// 名前：G
	// 説明：ライト色Gです。
	uint8_t lightColorG_021;

	// 名前：B
	// 説明：ライト色Bです。
	uint8_t lightColorB_022;

	// 名前：予備
	uint8_t reserve_023[1];

	// 名前：α
	// 説明：全体の透過度です。
	float alpha_024;

	// 名前：ブレンド率
	// 説明：ブレンド率です。
	float blendRate_028;

	// 名前：α種類
	// 説明：αブレンドの種類です。
	uint8_t blendType_02C;

	// 名前：エッジ色減算を行うか
	// 説明：エッジ色減算を行うかです。
	uint8_t isEdgeSubtract_02D;

	// 名前：正面色減算を行うか
	// 説明：正面色減算を行うかです。
	uint8_t isFrontSubtract_02E;

	// 名前：2passを行わない
	// 説明：2passを行わないかです。
	uint8_t isNo2Pass_02F;

	// 名前：エッジの幅
	// 説明：エッジの幅
	float edgePower_030;

	// 名前：Glowの強さ
	// 説明：Glowの強さ
	float glowScale_034;

} PhantomParam;

#endif
