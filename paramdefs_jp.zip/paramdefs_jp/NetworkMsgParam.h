/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_NetworkMsgParam_H
#define _PARAM_NetworkMsgParam_H
#include <stdint.h>

// NETWORK_MSG_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _NetworkMsgParam {

	// 名前：優先度
	// 説明：優先度
	uint16_t priority_000;

	// 名前：強制割り込み
	// 説明：強制割り込み
	uint8_t forcePlay_002;

	// 名前：予約
	// 説明：予約
	uint8_t pad1_003[1];

	// 名前：白霊（白サイン）
	// 説明：白霊（白サイン）
	int32_t normalWhite_004;

	// 名前：太陽霊（白サイン）
	// 説明：太陽霊（白サイン）
	int32_t umbasaWhite_008;

	// 名前：バーサーカー霊（白サイン）
	// 説明：バーサーカー霊（白サイン）
	int32_t berserkerWhite_00C;

	// 名前：罪人英雄霊（白サイン ）
	// 説明：罪人英雄霊（白サイン ）
	int32_t sinnerHeroWhite_010;

	// 名前：闇霊（赤サイン）
	// 説明：闇霊（赤サイン）
	int32_t normalBlack_014;

	// 名前：太陽霊（赤サイン）
	// 説明：太陽霊（赤サイン）
	int32_t umbasaBlack_018;

	// 名前：バーサーカー霊（赤サイン）
	// 説明：バーサーカー霊（赤サイン）
	int32_t berserkerBlack_01C;

	// 名前：侵入_A
	// 説明：侵入_A
	int32_t forceJoinBlack_020;

	// 名前：太陽霊（乱入）
	// 説明：太陽霊（乱入）
	int32_t forceJoinUmbasaBlack_024;

	// 名前：バーサーカー霊（乱入）
	// 説明：バーサーカー霊（乱入）
	int32_t forceJoinBerserkerBlack_028;

	// 名前：罪人狩り霊（訪問）
	// 説明：罪人狩り霊（訪問）
	int32_t sinnerHunterVisitor_02C;

	// 名前：赤狩り霊（訪問）
	// 説明：赤狩り霊（訪問）
	int32_t redHunterVisitor_030;

	// 名前：ボス守護霊（訪問）
	// 説明：ボス守護霊（訪問）
	int32_t guardianOfBossVisitor_034;

	// 名前：マップ守護霊_森（訪問）
	// 説明：マップ守護霊_森（訪問）
	int32_t guardianOfForestMapVisitor_038;

	// 名前：マップ守護霊_アノール（訪問）
	// 説明：マップ守護霊_アノール（訪問）
	int32_t guardianOfAnolisVisitor_03C;

	// 名前：ロザリア霊（赤サイン）
	// 説明：ロザリア霊（赤サイン）
	int32_t rosaliaBlack_040;

	// 名前：ロザリア霊（乱入）
	// 説明：ロザリア霊（乱入）
	int32_t forceJoinRosaliaBlack_044;

	// 名前：赤狩り霊2（訪問）
	// 説明：赤狩り霊2（訪問）
	int32_t redHunterVisitor2_048;

	// 名前：NPC擬似マルチ1
	// 説明：NPC擬似マルチ1
	int32_t npc1_04C;

	// 名前：NPC擬似マルチ2
	// 説明：NPC擬似マルチ2
	int32_t npc2_050;

	// 名前：NPC擬似マルチ3
	// 説明：NPC擬似マルチ3
	int32_t npc3_054;

	// 名前：NPC擬似マルチ4
	// 説明：NPC擬似マルチ4
	int32_t npc4_058;

	// 名前：バトルロイヤル
	// 説明：バトルロイヤル
	int32_t battleRoyal_05C;

	// 名前：NPC擬似マルチ5
	// 説明：NPC擬似マルチ5
	int32_t npc5_060;

	// 名前：NPC擬似マルチ6
	// 説明：NPC擬似マルチ6
	int32_t npc6_064;

	// 名前：NPC擬似マルチ7
	// 説明：NPC擬似マルチ7
	int32_t npc7_068;

	// 名前：NPC擬似マルチ8
	// 説明：NPC擬似マルチ8
	int32_t npc8_06C;

	// 名前：NPC擬似マルチ9
	// 説明：NPC擬似マルチ9
	int32_t npc9_070;

	// 名前：NPC擬似マルチ10
	// 説明：NPC擬似マルチ10
	int32_t npc10_074;

	// 名前：NPC擬似マルチ11
	// 説明：NPC擬似マルチ11
	int32_t npc11_078;

	// 名前：NPC擬似マルチ12
	// 説明：NPC擬似マルチ12
	int32_t npc12_07C;

	// 名前：NPC擬似マルチ13
	// 説明：NPC擬似マルチ13
	int32_t npc13_080;

	// 名前：NPC擬似マルチ14
	// 説明：NPC擬似マルチ14
	int32_t npc14_084;

	// 名前：NPC擬似マルチ15
	// 説明：NPC擬似マルチ15
	int32_t npc15_088;

	// 名前：NPC擬似マルチ16
	// 説明：NPC擬似マルチ16
	int32_t npc16_08C;

	// 名前：侵入_B
	// 説明：侵入_B
	int32_t forceJoinBlack_B_090;

	// 名前：白霊（白サイン）_NPC用
	// 説明：白霊（白サイン）_NPC用
	int32_t normalWhite_Npc_094;

	// 名前：侵入_A_NPC用
	// 説明：侵入_A_NPC用
	int32_t forceJoinBlack_Npc_098;

	// 名前：侵入_B_NPC用
	// 説明：侵入_B_NPC用
	int32_t forceJoinBlack_B_Npc_09C;

	// 名前：侵入_C_NPC用
	// 説明：侵入_C_NPC用
	int32_t forceJoinBlack_C_Npc_0A0;

	// 名前：予約
	// 説明：予約
	uint8_t pad2_0A4[28];

} NetworkMsgParam;

#endif
