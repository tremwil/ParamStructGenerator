/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WeatherLotParam_H
#define _PARAM_WeatherLotParam_H
#include <stdint.h>

// WEATHER_LOT_PARAM_ST
// Data Version: 5
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WeatherLotParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：天候種類0
	// 説明：天候種類0
	int16_t weatherType0_004;

	// 名前：天候種類1
	// 説明：天候種類1
	int16_t weatherType1_006;

	// 名前：天候種類2
	// 説明：天候種類2
	int16_t weatherType2_008;

	// 名前：天候種類3
	// 説明：天候種類3
	int16_t weatherType3_00A;

	// 名前：天候種類4
	// 説明：天候種類4
	int16_t weatherType4_00C;

	// 名前：天候種類5
	// 説明：天候種類5
	int16_t weatherType5_00E;

	// 名前：天候種類6
	// 説明：天候種類6
	int16_t weatherType6_010;

	// 名前：天候種類7
	// 説明：天候種類7
	int16_t weatherType7_012;

	// 名前：天候種類8
	// 説明：天候種類8
	int16_t weatherType8_014;

	// 名前：天候種類9
	// 説明：天候種類9
	int16_t weatherType9_016;

	// 名前：天候種類10
	// 説明：天候種類10
	int16_t weatherType10_018;

	// 名前：天候種類11
	// 説明：天候種類11
	int16_t weatherType11_01A;

	// 名前：天候種類12
	// 説明：天候種類12
	int16_t weatherType12_01C;

	// 名前：天候種類13
	// 説明：天候種類13
	int16_t weatherType13_01E;

	// 名前：天候種類14
	// 説明：天候種類14
	int16_t weatherType14_020;

	// 名前：天候種類15
	// 説明：天候種類15
	int16_t weatherType15_022;

	// 名前：抽選ウェイト0
	// 説明：抽選ウェイト0
	uint16_t lotteryWeight0_024;

	// 名前：抽選ウェイト1
	// 説明：抽選ウェイト1
	uint16_t lotteryWeight1_026;

	// 名前：抽選ウェイト2
	// 説明：抽選ウェイト2
	uint16_t lotteryWeight2_028;

	// 名前：抽選ウェイト3
	// 説明：抽選ウェイト3
	uint16_t lotteryWeight3_02A;

	// 名前：抽選ウェイト4
	// 説明：抽選ウェイト4
	uint16_t lotteryWeight4_02C;

	// 名前：抽選ウェイト5
	// 説明：抽選ウェイト5
	uint16_t lotteryWeight5_02E;

	// 名前：抽選ウェイト6
	// 説明：抽選ウェイト6
	uint16_t lotteryWeight6_030;

	// 名前：抽選ウェイト7
	// 説明：抽選ウェイト7
	uint16_t lotteryWeight7_032;

	// 名前：抽選ウェイト8
	// 説明：抽選ウェイト8
	uint16_t lotteryWeight8_034;

	// 名前：抽選ウェイト9
	// 説明：抽選ウェイト9
	uint16_t lotteryWeight9_036;

	// 名前：抽選ウェイト10
	// 説明：抽選ウェイト10
	uint16_t lotteryWeight10_038;

	// 名前：抽選ウェイト11
	// 説明：抽選ウェイト11
	uint16_t lotteryWeight11_03A;

	// 名前：抽選ウェイト12
	// 説明：抽選ウェイト12
	uint16_t lotteryWeight12_03C;

	// 名前：抽選ウェイト13
	// 説明：抽選ウェイト13
	uint16_t lotteryWeight13_03E;

	// 名前：抽選ウェイト14
	// 説明：抽選ウェイト14
	uint16_t lotteryWeight14_040;

	// 名前：抽選ウェイト15
	// 説明：抽選ウェイト15
	uint16_t lotteryWeight15_042;

	// 名前：時間帯条件リスト
	// 説明：時間帯条件リスト
	uint8_t timezoneLimit_044;

	// 名前：直接時間指定_開始_時
	// 説明：直接時間指定_開始_時
	uint8_t timezoneStartHour_045;

	// 名前：直接時間指定_開始_分
	// 説明：直接時間指定_開始_分
	uint8_t timezoneStartMinute_046;

	// 名前：直接時間指定_開始_時
	// 説明：直接時間指定_開始_時
	uint8_t timezoneEndHour_047;

	// 名前：直接時間指定_開始_分
	// 説明：直接時間指定_開始_分
	uint8_t timezoneEndMinute_048;

	// 名前：リザーブ
	// 説明：予約領域
	uint8_t reserve_049[9];

} WeatherLotParam;

#endif
