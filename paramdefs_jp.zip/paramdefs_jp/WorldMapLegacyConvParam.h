/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WorldMapLegacyConvParam_H
#define _PARAM_WorldMapLegacyConvParam_H
#include <stdint.h>

// WORLD_MAP_LEGACY_CONV_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WorldMapLegacyConvParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：変換元マップID：エリア番号
	// 説明：変換元マップID：エリア番号
	uint8_t srcAreaNo_004;

	// 名前：変換元マップID：グリッドX
	// 説明：変換元マップID：グリッドX
	uint8_t srcGridXNo_005;

	// 名前：変換元マップID：グリッドZ
	// 説明：変換元マップID：グリッドZ
	uint8_t srcGridZNo_006;

	// 名前：パディング１
	// 説明：パディング１
	uint8_t pad1_007[1];

	// 名前：変換元マップ基準座標X
	// 説明：変換元マップ基準座標X
	float srcPosX_008;

	// 名前：変換元マップ基準座標Y
	// 説明：変換元マップ基準座標Y
	float srcPosY_00C;

	// 名前：変換元マップ基準座標Z
	// 説明：変換元マップ基準座標Z
	float srcPosZ_010;

	// 名前：変換先マップID：エリア番号
	// 説明：変換先マップID：エリア番号
	uint8_t dstAreaNo_014;

	// 名前：変換先マップID：グリッドX
	// 説明：変換先マップID：グリッドX
	uint8_t dstGridXNo_015;

	// 名前：変換先マップID：グリッドZ
	// 説明：変換先マップID：グリッドZ
	uint8_t dstGridZNo_016;

	// 名前：パディング２
	// 説明：パディング２
	uint8_t pad2_017[1];

	// 名前：変換先マップ基準座標X
	// 説明：変換先マップ基準座標X
	float dstPosX_018;

	// 名前：変換先マップ基準座標Y
	// 説明：変換先マップ基準座標Y
	float dstPosY_01C;

	// 名前：変換先マップ基準座標Z
	// 説明：変換先マップ基準座標Z
	float dstPosZ_020;

	// 名前：基準となる接続点か
	// 説明：基準となる接続点か。１つの変換元マップIDには必ず一つは基準となる接続点が設定される
	uint8_t isBasePoint_024: 1;

	// 名前：パディング３
	// 説明：パディング３
	uint8_t pad3_024: 7;

	// 名前：パディング４
	// 説明：パディング４
	uint8_t pad4_025[11];

} WorldMapLegacyConvParam;

#endif
