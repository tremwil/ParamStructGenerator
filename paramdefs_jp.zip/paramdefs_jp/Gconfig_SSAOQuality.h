/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_SSAOQuality_H
#define _PARAM_Gconfig_SSAOQuality_H
#include <stdint.h>

// CS_SSAO_QUALITY_DETAIL
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_SSAOQuality {

	// 名前：SSAO有効
	// 説明：SSAO有効
	uint8_t enabled_000;

	// 名前：リプロジェクション有効
	// 説明：リプロジェクション強制有効の時は、PreventGhostも有効になる
	uint8_t cs_reprojEnabledType_001;

	// 名前：バイラテラルアップスケール有効
	// 説明：バイラテラルアップスケール有効
	uint8_t cs_upScaleEnabledType_002;

	// 名前：法線使用有効
	// 説明：法線使用有効
	uint8_t cs_useNormalEnabledType_003;

	// 名前：dmy
	uint8_t dmy_004[1];

} Gconfig_SSAOQuality;

#endif
