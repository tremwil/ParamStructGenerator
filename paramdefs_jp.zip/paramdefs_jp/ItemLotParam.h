/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ItemLotParam_H
#define _PARAM_ItemLotParam_H
#include <stdint.h>

// ITEMLOT_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ItemLotParam {

	// 名前：１：アイテムID
	// 説明：取得できるアイテムのID
	int32_t lotItemId01_000;

	// 名前：２：アイテムID
	// 説明：取得できるアイテムのID
	int32_t lotItemId02_004;

	// 名前：３：アイテムID
	// 説明：取得できるアイテムのID
	int32_t lotItemId03_008;

	// 名前：４：アイテムID
	// 説明：取得できるアイテムのID
	int32_t lotItemId04_00C;

	// 名前：５：アイテムID
	// 説明：取得できるアイテムのID
	int32_t lotItemId05_010;

	// 名前：６：アイテムID
	// 説明：取得できるアイテムのID
	int32_t lotItemId06_014;

	// 名前：７：アイテムID
	// 説明：取得できるアイテムのID
	int32_t lotItemId07_018;

	// 名前：８：アイテムID
	// 説明：取得できるアイテムのID
	int32_t lotItemId08_01C;

	// 名前：１：アイテムカテゴリ
	// 説明：取得できるアイテムのカテゴリ
	int32_t lotItemCategory01_020;

	// 名前：２：アイテムカテゴリ
	// 説明：取得できるアイテムのカテゴリ
	int32_t lotItemCategory02_024;

	// 名前：３：アイテムカテゴリ
	// 説明：取得できるアイテムのカテゴリ
	int32_t lotItemCategory03_028;

	// 名前：４：アイテムカテゴリ
	// 説明：取得できるアイテムのカテゴリ
	int32_t lotItemCategory04_02C;

	// 名前：５：アイテムカテゴリ
	// 説明：取得できるアイテムのカテゴリ
	int32_t lotItemCategory05_030;

	// 名前：６：アイテムカテゴリ
	// 説明：取得できるアイテムのカテゴリ
	int32_t lotItemCategory06_034;

	// 名前：７：アイテムカテゴリ
	// 説明：取得できるアイテムのカテゴリ
	int32_t lotItemCategory07_038;

	// 名前：８：アイテムカテゴリ
	// 説明：取得できるアイテムのカテゴリ
	int32_t lotItemCategory08_03C;

	// 名前：基本出現ポイント
	// 説明：通常時の出現ポイント
	uint16_t lotItemBasePoint01_040;

	// 名前：基本出現ポイント
	// 説明：通常時の出現ポイント
	uint16_t lotItemBasePoint02_042;

	// 名前：基本出現ポイント
	// 説明：通常時の出現ポイント
	uint16_t lotItemBasePoint03_044;

	// 名前：基本出現ポイント
	// 説明：通常時の出現ポイント
	uint16_t lotItemBasePoint04_046;

	// 名前：基本出現ポイント
	// 説明：通常時の出現ポイント
	uint16_t lotItemBasePoint05_048;

	// 名前：基本出現ポイント
	// 説明：通常時の出現ポイント
	uint16_t lotItemBasePoint06_04A;

	// 名前：基本出現ポイント
	// 説明：通常時の出現ポイント
	uint16_t lotItemBasePoint07_04C;

	// 名前：基本出現ポイント
	// 説明：通常時の出現ポイント
	uint16_t lotItemBasePoint08_04E;

	// 名前：累積後出現ポイント
	// 説明：最大累積時の出現ポイント
	uint16_t cumulateLotPoint01_050;

	// 名前：累積後出現ポイント
	// 説明：最大累積時の出現ポイント
	uint16_t cumulateLotPoint02_052;

	// 名前：累積後出現ポイント
	// 説明：最大累積時の出現ポイント
	uint16_t cumulateLotPoint03_054;

	// 名前：累積後出現ポイント
	// 説明：最大累積時の出現ポイント
	uint16_t cumulateLotPoint04_056;

	// 名前：累積後出現ポイント
	// 説明：最大累積時の出現ポイント
	uint16_t cumulateLotPoint05_058;

	// 名前：累積後出現ポイント
	// 説明：最大累積時の出現ポイント
	uint16_t cumulateLotPoint06_05A;

	// 名前：累積後出現ポイント
	// 説明：最大累積時の出現ポイント
	uint16_t cumulateLotPoint07_05C;

	// 名前：累積後出現ポイント
	// 説明：最大累積時の出現ポイント
	uint16_t cumulateLotPoint08_05E;

	// 名前：別ザクザクフラグID
	// 説明：取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId01_060;

	// 名前：別ザクザクフラグID
	// 説明：取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId02_064;

	// 名前：別ザクザクフラグID
	// 説明：取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId03_068;

	// 名前：別ザクザクフラグID
	// 説明：取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId04_06C;

	// 名前：別ザクザクフラグID
	// 説明：取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId05_070;

	// 名前：別ザクザクフラグID
	// 説明：取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId06_074;

	// 名前：別ザクザクフラグID
	// 説明：取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId07_078;

	// 名前：別ザクザクフラグID
	// 説明：取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId08_07C;

	// 名前：ザクザクフラグID
	// 説明：取得済みフラグとザクザク枠兼用(0:フラグ無効)
	uint32_t getItemFlagId_080;

	// 名前：抽選累積保存フラグID
	// 説明：抽選回数保存用(※8フラグ連番使用)
	uint32_t cumulateNumFlagId_084;

	// 名前：抽選累積最大数
	// 説明：抽選累積最大数(0:累積なし)
	uint8_t cumulateNumMax_088;

	// 名前：レア度上書き
	// 説明：宝箱などに、どれくらい貴重なアイテムが入っているかを指定する。-1の時は上書きせず装備品パラのレア度を使用する
	int8_t lotItem_Rarity_089;

	// 名前：個数
	// 説明：取得できるアイテムの個数
	uint8_t lotItemNum01_08A;

	// 名前：個数
	// 説明：取得できるアイテムの個数
	uint8_t lotItemNum02_08B;

	// 名前：個数
	// 説明：取得できるアイテムの個数
	uint8_t lotItemNum03_08C;

	// 名前：個数
	// 説明：取得できるアイテムの個数
	uint8_t lotItemNum04_08D;

	// 名前：個数
	// 説明：取得できるアイテムの個数
	uint8_t lotItemNum05_08E;

	// 名前：個数
	// 説明：取得できるアイテムの個数
	uint8_t lotItemNum06_08F;

	// 名前：個数
	// 説明：取得できるアイテムの個数
	uint8_t lotItemNum07_090;

	// 名前：個数
	// 説明：取得できるアイテムの個数
	uint8_t lotItemNum08_091;

	// 名前：運パラメータ有効
	// 説明：抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck01_092: 1;

	// 名前：運パラメータ有効
	// 説明：抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck02_092: 1;

	// 名前：運パラメータ有効
	// 説明：抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck03_092: 1;

	// 名前：運パラメータ有効
	// 説明：抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck04_092: 1;

	// 名前：運パラメータ有効
	// 説明：抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck05_092: 1;

	// 名前：運パラメータ有効
	// 説明：抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck06_092: 1;

	// 名前：運パラメータ有効
	// 説明：抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck07_092: 1;

	// 名前：運パラメータ有効
	// 説明：抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck08_092: 1;

	// 名前：累積リセット
	// 説明：累積リセットするか
	uint16_t cumulateReset01_093: 1;

	// 名前：累積リセット
	// 説明：累積リセットするか
	uint16_t cumulateReset02_093: 1;

	// 名前：累積リセット
	// 説明：累積リセットするか
	uint16_t cumulateReset03_093: 1;

	// 名前：累積リセット
	// 説明：累積リセットするか
	uint16_t cumulateReset04_093: 1;

	// 名前：累積リセット
	// 説明：累積リセットするか
	uint16_t cumulateReset05_093: 1;

	// 名前：累積リセット
	// 説明：累積リセットするか
	uint16_t cumulateReset06_093: 1;

	// 名前：累積リセット
	// 説明：累積リセットするか
	uint16_t cumulateReset07_093: 1;

	// 名前：累積リセット
	// 説明：累積リセットするか
	uint16_t cumulateReset08_093: 1;

	// 名前：X週目以降オフセット
	// 説明：周回プレイ時のオフセット
	int8_t GameClearOffset_094;

	// 名前：協力霊でも抽選するか
	// 説明：自身が協力霊の時でも抽選するか
	uint8_t canExecByFriendlyGhost_095: 1;

	// 名前：敵対霊でも抽選するか
	// 説明：自身が敵対霊の時でも抽選するか
	uint8_t canExecByHostileGhost_095: 1;

	// 名前：PAD1
	// 説明：PAD1
	uint8_t PAD1_095: 6;

	// 名前：PAD2
	// 説明：PAD2
	uint16_t PAD2_096;

} ItemLotParam;

#endif
