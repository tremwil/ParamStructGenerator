/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_BuddyParam_H
#define _PARAM_BuddyParam_H
#include <stdint.h>

// BUDDY_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BuddyParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：召喚特殊効果ID
	// 説明：召喚条件になる特殊効果IDを設定します 
	int32_t triggerSpEffectId_004;

	// 名前：NPCパラメータID
	// 説明：召喚されるバディのNPCパラメータIDを設定します
	int32_t npcParamId_008;

	// 名前：思考パラメータID
	// 説明：召喚されるバディのNPC思考パラメータIDを設定します
	int32_t npcThinkParamId_00C;

	// 名前：騎乗（乗られる側）：NPCパラメータID
	// 説明：騎乗状態で召喚したいバディの場合、「乗られる側」のNPCパラメータIDを設定します 
	int32_t npcParamId_ridden_010;

	// 名前：騎乗（乗られる側）：思考パラメータID
	// 説明：騎乗状態で召喚したいバディの場合、「乗られる側」のNPC思考パラメータIDを設定します
	int32_t npcThinkParamId_ridden_014;

	// 名前：X：配置座標オフセット[m]
	// 説明：バディを召喚ポイントから、X座標にオフセットする距離をメートル単位で設定します
	float x_offset_018;

	// 名前：Z：配置座標オフセット[m]
	// 説明：バディを召喚ポイントから、Z座標にオフセットする距離をメートル単位で設定します
	float z_offset_01C;

	// 名前：Y：自分の配置角度[deg]
	// 説明：Y軸を中心に、自分を回転させる角度を設定します
	float y_angle_020;

	// 名前：石碑周辺から出現するか？
	// 説明：石碑周辺から出現するか？
	uint8_t appearOnAroundSekihi_024;

	// 名前：PCとのターゲット共有をスキップするか？
	// 説明：PCとのターゲット共有をスキップするか？
	uint8_t disablePCTargetShare_025;

	// 名前：PC追従＆ワープタイプ 
	// 説明：PC追従＆ワープタイプ 
	uint8_t pcFollowType_026;

	// 名前：リザーブ
	// 説明：リザーブ
	uint8_t Reserve_027[1];

	// 名前：+0時ドーピング特殊効果
	// 説明：+0時ドーピング特殊効果
	int32_t dopingSpEffect_lv0_028;

	// 名前：+1時ドーピング特殊効果
	// 説明：+0時ドーピング特殊効果
	int32_t dopingSpEffect_lv1_02C;

	// 名前：+2時ドーピング特殊効果
	// 説明：+0時ドーピング特殊効果
	int32_t dopingSpEffect_lv2_030;

	// 名前：+3時ドーピング特殊効果
	// 説明：+0時ドーピング特殊効果
	int32_t dopingSpEffect_lv3_034;

	// 名前：+4時ドーピング特殊効果
	// 説明：+0時ドーピング特殊効果
	int32_t dopingSpEffect_lv4_038;

	// 名前：+5時ドーピング特殊効果
	// 説明：+0時ドーピング特殊効果
	int32_t dopingSpEffect_lv5_03C;

	// 名前：+6時ドーピング特殊効果
	// 説明：+0時ドーピング特殊効果
	int32_t dopingSpEffect_lv6_040;

	// 名前：+7時ドーピング特殊効果
	// 説明：+0時ドーピング特殊効果
	int32_t dopingSpEffect_lv7_044;

	// 名前：+8時ドーピング特殊効果
	// 説明：+0時ドーピング特殊効果
	int32_t dopingSpEffect_lv8_048;

	// 名前：+9時ドーピング特殊効果
	// 説明：+0時ドーピング特殊効果
	int32_t dopingSpEffect_lv9_04C;

	// 名前：+10時ドーピング特殊効果
	// 説明：+0時ドーピング特殊効果
	int32_t dopingSpEffect_lv10_050;

	// 名前：アーキタイプ別初期パラメータID
	// 説明：アーキタイプ別初期パラメータID
	int32_t npcPlayerInitParamId_054;

	// 名前：ジェネレートアニメID
	// 説明：ジェネレートアニメID
	int32_t generateAnimId_058;

	// 名前：リザーブ2
	// 説明：リザーブ２
	uint8_t Reserve2_05C[4];

} BuddyParam;

#endif
