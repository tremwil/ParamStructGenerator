/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SeActivationRangeParam_H
#define _PARAM_SeActivationRangeParam_H
#include <stdint.h>

// SE_ACTIVATION_RANGE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SeActivationRangeParam {

	// 名前：アクティベート距離
	// 説明：配置SEを有効化する距離(m) (0以下：常に有効化)
	float activateRange_000;

} SeActivationRangeParam;

#endif
