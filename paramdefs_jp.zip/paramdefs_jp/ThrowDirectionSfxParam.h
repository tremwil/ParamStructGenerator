/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ThrowDirectionSfxParam_H
#define _PARAM_ThrowDirectionSfxParam_H
#include <stdint.h>

// THROW_DIRECTION_SFX_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 106
typedef struct _ThrowDirectionSfxParam {

	// 名前：0
	// 説明：使用するSFXのID
	int32_t sfxId_00_000;

	// 名前：1
	// 説明：使用するSFXのID
	int32_t sfxId_01_004;

	// 名前：2
	// 説明：使用するSFXのID
	int32_t sfxId_02_008;

	// 名前：3
	// 説明：使用するSFXのID
	int32_t sfxId_03_00C;

	// 名前：4
	// 説明：使用するSFXのID
	int32_t sfxId_04_010;

	// 名前：5
	// 説明：使用するSFXのID
	int32_t sfxId_05_014;

	// 名前：6
	// 説明：使用するSFXのID
	int32_t sfxId_06_018;

	// 名前：7
	// 説明：使用するSFXのID
	int32_t sfxId_07_01C;

	// 名前：8
	// 説明：使用するSFXのID
	int32_t sfxId_08_020;

	// 名前：9
	// 説明：使用するSFXのID
	int32_t sfxId_09_024;

	// 名前：10
	// 説明：使用するSFXのID
	int32_t sfxId_10_028;

	// 名前：11
	// 説明：使用するSFXのID
	int32_t sfxId_11_02C;

	// 名前：12
	// 説明：使用するSFXのID
	int32_t sfxId_12_030;

	// 名前：13
	// 説明：使用するSFXのID
	int32_t sfxId_13_034;

	// 名前：14
	// 説明：使用するSFXのID
	int32_t sfxId_14_038;

	// 名前：15
	// 説明：使用するSFXのID
	int32_t sfxId_15_03C;

	// 名前：16
	// 説明：使用するSFXのID
	int32_t sfxId_16_040;

	// 名前：17
	// 説明：使用するSFXのID
	int32_t sfxId_17_044;

	// 名前：18
	// 説明：使用するSFXのID
	int32_t sfxId_18_048;

	// 名前：19
	// 説明：使用するSFXのID
	int32_t sfxId_19_04C;

	// 名前：20
	// 説明：使用するSFXのID
	int32_t sfxId_20_050;

	// 名前：21
	// 説明：使用するSFXのID
	int32_t sfxId_21_054;

	// 名前：22
	// 説明：使用するSFXのID
	int32_t sfxId_22_058;

	// 名前：23
	// 説明：使用するSFXのID
	int32_t sfxId_23_05C;

	// 名前：24
	// 説明：使用するSFXのID
	int32_t sfxId_24_060;

	// 名前：25
	// 説明：使用するSFXのID
	int32_t sfxId_25_064;

	// 名前：26
	// 説明：使用するSFXのID
	int32_t sfxId_26_068;

	// 名前：27
	// 説明：使用するSFXのID
	int32_t sfxId_27_06C;

	// 名前：28
	// 説明：使用するSFXのID
	int32_t sfxId_28_070;

	// 名前：29
	// 説明：使用するSFXのID
	int32_t sfxId_29_074;

	// 名前：30
	// 説明：使用するSFXのID
	int32_t sfxId_30_078;

	// 名前：パッド
	// 説明：pad
	uint8_t pad1_07C[20];

} ThrowDirectionSfxParam;

#endif
