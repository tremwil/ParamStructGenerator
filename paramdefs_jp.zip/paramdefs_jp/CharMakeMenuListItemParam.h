/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CharMakeMenuListItemParam_H
#define _PARAM_CharMakeMenuListItemParam_H
#include <stdint.h>

// CHARMAKEMENU_LISTITEM_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CharMakeMenuListItemParam {

	// 名前：値
	// 説明：プログラム側に扱う値。1つのグループ内で通し番号にする
	int32_t value_000;

	// 名前：項目テキストID
	// 説明：表示するテキストのID
	int32_t captionId_004;

	// 名前：アイコンID
	// 説明：表示するアイコンのID
	uint8_t iconId_008;

	// 名前：予約
	uint8_t reserved_009[7];

} CharMakeMenuListItemParam;

#endif
