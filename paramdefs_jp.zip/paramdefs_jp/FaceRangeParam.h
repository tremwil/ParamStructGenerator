/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_FaceRangeParam_H
#define _PARAM_FaceRangeParam_H
#include <stdint.h>

// FACE_RANGE_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _FaceRangeParam {

	// 名前：顔パーツID
	// 説明：顔パーツID
	float face_partsId_000;

	// 名前：肌の色(Ｒ)
	// 説明：肌の色(Ｒ)
	float skin_color_R_004;

	// 名前：肌の色(Ｇ)
	// 説明：肌の色(Ｇ)
	float skin_color_G_008;

	// 名前：肌の色(Ｂ)
	// 説明：肌の色(Ｂ)
	float skin_color_B_00C;

	// 名前：肌のつや
	// 説明：肌のつや
	float skin_gloss_010;

	// 名前：毛穴
	// 説明：毛穴
	float skin_pores_014;

	// 名前：青ひげ
	// 説明：青ひげ
	float face_beard_018;

	// 名前：くま
	// 説明：くま
	float face_aroundEye_01C;

	// 名前：くまの色(R)
	// 説明：くまの色(R)
	float face_aroundEyeColor_R_020;

	// 名前：くまの色(G)
	// 説明：くまの色(G)
	float face_aroundEyeColor_G_024;

	// 名前：くまの色(B)
	// 説明：くまの色(B)
	float face_aroundEyeColor_B_028;

	// 名前：チーク
	// 説明：チーク
	float face_cheek_02C;

	// 名前：チークの色(R)
	// 説明：チークの色(R)
	float face_cheekColor_R_030;

	// 名前：チークの色(G)
	// 説明：チークの色(G)
	float face_cheekColor_G_034;

	// 名前：チークの色(B)
	// 説明：チークの色(B)
	float face_cheekColor_B_038;

	// 名前：アイライン
	// 説明：アイライン
	float face_eyeLine_03C;

	// 名前：アイラインの色(R)
	// 説明：アイラインの色(R)
	float face_eyeLineColor_R_040;

	// 名前：アイラインの色(G)
	// 説明：アイラインの色(G)
	float face_eyeLineColor_G_044;

	// 名前：アイラインの色(B)
	// 説明：アイラインの色(B)
	float face_eyeLineColor_B_048;

	// 名前：アイシャドウ(下)
	// 説明：アイシャドウ(下)
	float face_eyeShadowDown_04C;

	// 名前：アイシャドウ(下)の色(R)
	// 説明：アイシャドウ(下)の色(R)
	float face_eyeShadowDownColor_R_050;

	// 名前：アイシャドウ(下)の色(G)
	// 説明：アイシャドウ(下)の色(G)
	float face_eyeShadowDownColor_G_054;

	// 名前：アイシャドウ(下)の色(B)
	// 説明：アイシャドウ(下)の色(B)
	float face_eyeShadowDownColor_B_058;

	// 名前：アイシャドウ(上)
	// 説明：アイシャドウ(上)
	float face_eyeShadowUp_05C;

	// 名前：アイシャドウ(上)の色(R)
	// 説明：アイシャドウ(上)の色(R)
	float face_eyeShadowUpColor_R_060;

	// 名前：アイシャドウ(上)の色(G)
	// 説明：アイシャドウ(上)の色(G)
	float face_eyeShadowUpColor_G_064;

	// 名前：アイシャドウ(上)の色(B)
	// 説明：アイシャドウ(上)の色(B)
	float face_eyeShadowUpColor_B_068;

	// 名前：口紅
	// 説明：口紅
	float face_lip_06C;

	// 名前：口紅の色(R)
	// 説明：口紅の色(R)
	float face_lipColor_R_070;

	// 名前：口紅の色(G)
	// 説明：口紅の色(G)
	float face_lipColor_G_074;

	// 名前：口紅の色(B)
	// 説明：口紅の色(B)
	float face_lipColor_B_078;

	// 名前：体毛の濃さ
	// 説明：体毛の濃さ
	float body_hair_07C;

	// 名前：体毛の色(R)
	// 説明：体毛の色(R)
	float body_hairColor_R_080;

	// 名前：体毛の色(G)
	// 説明：体毛の色(G)
	float body_hairColor_G_084;

	// 名前：体毛の色(B)
	// 説明：体毛の色(B)
	float body_hairColor_B_088;

	// 名前：眼球パーツID
	// 説明：眼球パーツID
	float eye_partsId_08C;

	// 名前：虹彩の色(Ｒ)
	// 説明：右目の虹彩の色(Ｒ)
	float eyeR_irisColor_R_090;

	// 名前：虹彩の色(Ｇ)
	// 説明：右目の虹彩の色(Ｇ)
	float eyeR_irisColor_G_094;

	// 名前：虹彩の色(Ｂ)
	// 説明：右目の虹彩の色(Ｂ)
	float eyeR_irisColor_B_098;

	// 名前：虹彩の大きさ
	// 説明：右目の虹彩の大きさ
	float eyeR_irisScale_09C;

	// 名前：水晶体の濁り
	// 説明：右目の水晶体の濁り
	float eyeR_cataract_0A0;

	// 名前：水晶体の濁りの色(Ｒ)
	// 説明：右目の水晶体の濁りの色(Ｒ)
	float eyeR_cataractColor_R_0A4;

	// 名前：水晶体の濁りの色(Ｇ)
	// 説明：右目の水晶体の濁りの色(Ｇ)
	float eyeR_cataractColor_G_0A8;

	// 名前：水晶体の濁りの色(Ｂ)
	// 説明：右目の水晶体の濁りの色(Ｂ)
	float eyeR_cataractColor_B_0AC;

	// 名前：白目の色(Ｒ)
	// 説明：右目の白目の色(Ｒ)
	float eyeR_scleraColor_R_0B0;

	// 名前：白目の色(G)
	// 説明：右目の白目の色(G)
	float eyeR_scleraColor_G_0B4;

	// 名前：白目の色(B)
	// 説明：右目の白目の色(B)
	float eyeR_scleraColor_B_0B8;

	// 名前：虹彩の位置
	// 説明：右目の虹彩の位置
	float eyeR_irisDistance_0BC;

	// 名前：虹彩の色(Ｒ)
	// 説明：左目の虹彩の色(Ｒ)
	float eyeL_irisColor_R_0C0;

	// 名前：虹彩の色(Ｇ)
	// 説明：左目の虹彩の色(Ｇ)
	float eyeL_irisColor_G_0C4;

	// 名前：虹彩の色(Ｂ)
	// 説明：左目の虹彩の色(Ｂ)
	float eyeL_irisColor_B_0C8;

	// 名前：虹彩の大きさ
	// 説明：左目の虹彩の大きさ
	float eyeL_irisScale_0CC;

	// 名前：水晶体の濁り
	// 説明：左目の水晶体の濁り
	float eyeL_cataract_0D0;

	// 名前：水晶体の濁りの色(Ｒ)
	// 説明：左目の水晶体の濁りの色(Ｒ)
	float eyeL_cataractColor_R_0D4;

	// 名前：水晶体の濁りの色(Ｇ)
	// 説明：左目の水晶体の濁りの色(Ｇ)
	float eyeL_cataractColor_G_0D8;

	// 名前：水晶体の濁りの色(Ｂ)
	// 説明：左目の水晶体の濁りの色(Ｂ)
	float eyeL_cataractColor_B_0DC;

	// 名前：白目の色(Ｒ)
	// 説明：左目の白目の色(Ｒ)
	float eyeL_scleraColor_R_0E0;

	// 名前：白目の色(G)
	// 説明：左目の白目の色(G)
	float eyeL_scleraColor_G_0E4;

	// 名前：白目の色(B)
	// 説明：左目の白目の色(B)
	float eyeL_scleraColor_B_0E8;

	// 名前：虹彩の位置
	// 説明：左目の虹彩の位置
	float eyeL_irisDistance_0EC;

	// 名前：髪パーツID
	// 説明：髪パーツID
	float hair_partsId_0F0;

	// 名前：髪の色(Ｒ)
	// 説明：髪の色(Ｒ)
	float hair_color_R_0F4;

	// 名前：髪の色(Ｇ)
	// 説明：髪の色(Ｇ)
	float hair_color_G_0F8;

	// 名前：髪の色(Ｂ)
	// 説明：髪の色(Ｂ)
	float hair_color_B_0FC;

	// 名前：光沢
	// 説明：髪の光沢
	float hair_shininess_100;

	// 名前：根元の黒さ
	// 説明：髪の根元の黒さ
	float hair_rootBlack_104;

	// 名前：白髪の量
	// 説明：髪の白髪の量
	float hair_whiteDensity_108;

	// 名前：髭パーツID
	// 説明：髭パーツID
	float beard_partsId_10C;

	// 名前：髭の色(Ｒ)
	// 説明：髭の色(Ｒ)
	float beard_color_R_110;

	// 名前：髭の色(Ｇ)
	// 説明：髭の色(Ｇ)
	float beard_color_G_114;

	// 名前：髭の色(Ｂ)
	// 説明：髭の色(Ｂ)
	float beard_color_B_118;

	// 名前：光沢
	// 説明：髭の光沢
	float beard_shininess_11C;

	// 名前：根元の黒さ
	// 説明：髭の根元の黒さ
	float beard_rootBlack_120;

	// 名前：白髪の量
	// 説明：髭の白髪の量
	float beard_whiteDensity_124;

	// 名前：眉パーツID
	// 説明：眉パーツID
	float eyebrow_partsId_128;

	// 名前：眉の色(Ｒ)
	// 説明：眉の色(Ｒ)
	float eyebrow_color_R_12C;

	// 名前：眉の色(Ｇ)
	// 説明：眉の色(Ｇ)
	float eyebrow_color_G_130;

	// 名前：眉の色(Ｂ)
	// 説明：眉の色(Ｂ)
	float eyebrow_color_B_134;

	// 名前：光沢
	// 説明：眉の光沢
	float eyebrow_shininess_138;

	// 名前：根元の黒さ
	// 説明：眉の根元の黒さ
	float eyebrow_rootBlack_13C;

	// 名前：白髪の量
	// 説明：眉の白髪の量
	float eyebrow_whiteDensity_140;

	// 名前：まつげパーツID
	// 説明：まつげパーツID
	float eyelash_partsId_144;

	// 名前：まつげの色(Ｒ)
	// 説明：まつげの色(Ｒ)
	float eyelash_color_R_148;

	// 名前：まつげの色(Ｇ)
	// 説明：まつげの色(Ｇ)
	float eyelash_color_G_14C;

	// 名前：まつげの色(Ｂ)
	// 説明：まつげの色(Ｂ)
	float eyelash_color_B_150;

	// 名前：装飾パーツID
	// 説明：装飾パーツID
	float accessories_partsId_154;

	// 名前：装飾の色(Ｒ)
	// 説明：装飾の色(Ｒ)
	float accessories_color_R_158;

	// 名前：装飾の色(Ｇ)
	// 説明：装飾の色(Ｇ)
	float accessories_color_G_15C;

	// 名前：装飾の色(Ｂ)
	// 説明：装飾の色(Ｂ)
	float accessories_color_B_160;

	// 名前：デカールパーツID
	// 説明：デカールパーツID
	float decal_partsId_164;

	// 名前：デカール位置(x)
	// 説明：デカール位置(x)
	float decal_posX_168;

	// 名前：デカール位置(y)
	// 説明：デカール位置(y)
	float decal_posY_16C;

	// 名前：デカール角度
	// 説明：デカール角度
	float decal_angle_170;

	// 名前：デカールスケール
	// 説明：デカールスケール
	float decal_scale_174;

	// 名前：デカールの色(Ｒ)
	// 説明：デカールの色(Ｒ)
	float decal_color_R_178;

	// 名前：デカールの色(Ｇ)
	// 説明：デカールの色(Ｇ)
	float decal_color_G_17C;

	// 名前：デカールの色(Ｂ)
	// 説明：デカールの色(Ｂ)
	float decal_color_B_180;

	// 名前：デカールのつや
	// 説明：デカールのつや
	float decal_gloss_184;

	// 名前：デカールの反転
	// 説明：デカールの反転
	float decal_mirror_188;

	// 名前：キャラ体型頭部スケール
	// 説明：キャラ体型頭部スケール
	float chrBodyScaleHead_18C;

	// 名前：キャラ体型胸部スケール
	// 説明：キャラ体型胸部スケール
	float chrBodyScaleBreast_190;

	// 名前：キャラ体型腹部スケール
	// 説明：キャラ体型腹部スケール
	float chrBodyScaleAbdomen_194;

	// 名前：キャラ体型腕部スケール
	// 説明：キャラ体型腕部スケール
	float chrBodyScaleArm_198;

	// 名前：キャラ体型脚部スケール
	// 説明：キャラ体型脚部スケール
	float chrBodyScaleLeg_19C;

	// 名前：年齢
	// 説明：年齢
	float age_1A0;

	// 名前：性別
	// 説明：性別
	float gender_1A4;

	// 名前：誇張（モデル）
	// 説明：誇張（モデル）
	float caricatureGeometry_1A8;

	// 名前：誇張（テクスチャ）
	// 説明：誇張（テクスチャ）
	float caricatureTexture_1AC;

	// 名前：顔作成ジオメトリデータ00
	// 説明：顔作成ジオメトリデータ00
	float faceGeoData00_1B0;

	// 名前：顔作成ジオメトリデータ01
	// 説明：顔作成ジオメトリデータ01
	float faceGeoData01_1B4;

	// 名前：顔作成ジオメトリデータ02
	// 説明：顔作成ジオメトリデータ02
	float faceGeoData02_1B8;

	// 名前：顔作成ジオメトリデータ03
	// 説明：顔作成ジオメトリデータ03
	float faceGeoData03_1BC;

	// 名前：顔作成ジオメトリデータ04
	// 説明：顔作成ジオメトリデータ04
	float faceGeoData04_1C0;

	// 名前：顔作成ジオメトリデータ05
	// 説明：顔作成ジオメトリデータ05
	float faceGeoData05_1C4;

	// 名前：顔作成ジオメトリデータ06
	// 説明：顔作成ジオメトリデータ06
	float faceGeoData06_1C8;

	// 名前：顔作成ジオメトリデータ07
	// 説明：顔作成ジオメトリデータ07
	float faceGeoData07_1CC;

	// 名前：顔作成ジオメトリデータ08
	// 説明：顔作成ジオメトリデータ08
	float faceGeoData08_1D0;

	// 名前：顔作成ジオメトリデータ09
	// 説明：顔作成ジオメトリデータ09
	float faceGeoData09_1D4;

	// 名前：顔作成ジオメトリデータ10
	// 説明：顔作成ジオメトリデータ10
	float faceGeoData10_1D8;

	// 名前：顔作成ジオメトリデータ11
	// 説明：顔作成ジオメトリデータ11
	float faceGeoData11_1DC;

	// 名前：顔作成ジオメトリデータ12
	// 説明：顔作成ジオメトリデータ12
	float faceGeoData12_1E0;

	// 名前：顔作成ジオメトリデータ13
	// 説明：顔作成ジオメトリデータ13
	float faceGeoData13_1E4;

	// 名前：顔作成ジオメトリデータ14
	// 説明：顔作成ジオメトリデータ14
	float faceGeoData14_1E8;

	// 名前：顔作成ジオメトリデータ15
	// 説明：顔作成ジオメトリデータ15
	float faceGeoData15_1EC;

	// 名前：顔作成ジオメトリデータ16
	// 説明：顔作成ジオメトリデータ16
	float faceGeoData16_1F0;

	// 名前：顔作成ジオメトリデータ17
	// 説明：顔作成ジオメトリデータ17
	float faceGeoData17_1F4;

	// 名前：顔作成ジオメトリデータ18
	// 説明：顔作成ジオメトリデータ18
	float faceGeoData18_1F8;

	// 名前：顔作成ジオメトリデータ19
	// 説明：顔作成ジオメトリデータ19
	float faceGeoData19_1FC;

	// 名前：顔作成ジオメトリデータ20
	// 説明：顔作成ジオメトリデータ20
	float faceGeoData20_200;

	// 名前：顔作成ジオメトリデータ21
	// 説明：顔作成ジオメトリデータ21
	float faceGeoData21_204;

	// 名前：顔作成ジオメトリデータ22
	// 説明：顔作成ジオメトリデータ22
	float faceGeoData22_208;

	// 名前：顔作成ジオメトリデータ23
	// 説明：顔作成ジオメトリデータ23
	float faceGeoData23_20C;

	// 名前：顔作成ジオメトリデータ24
	// 説明：顔作成ジオメトリデータ24
	float faceGeoData24_210;

	// 名前：顔作成ジオメトリデータ25
	// 説明：顔作成ジオメトリデータ25
	float faceGeoData25_214;

	// 名前：顔作成ジオメトリデータ26
	// 説明：顔作成ジオメトリデータ26
	float faceGeoData26_218;

	// 名前：顔作成ジオメトリデータ27
	// 説明：顔作成ジオメトリデータ27
	float faceGeoData27_21C;

	// 名前：顔作成ジオメトリデータ28
	// 説明：顔作成ジオメトリデータ28
	float faceGeoData28_220;

	// 名前：顔作成ジオメトリデータ29
	// 説明：顔作成ジオメトリデータ29
	float faceGeoData29_224;

	// 名前：顔作成ジオメトリデータ30
	// 説明：顔作成ジオメトリデータ30
	float faceGeoData30_228;

	// 名前：顔作成ジオメトリデータ31
	// 説明：顔作成ジオメトリデータ31
	float faceGeoData31_22C;

	// 名前：顔作成ジオメトリデータ32
	// 説明：顔作成ジオメトリデータ32
	float faceGeoData32_230;

	// 名前：顔作成ジオメトリデータ33
	// 説明：顔作成ジオメトリデータ33
	float faceGeoData33_234;

	// 名前：顔作成ジオメトリデータ34
	// 説明：顔作成ジオメトリデータ34
	float faceGeoData34_238;

	// 名前：顔作成ジオメトリデータ35
	// 説明：顔作成ジオメトリデータ35
	float faceGeoData35_23C;

	// 名前：顔作成ジオメトリデータ36
	// 説明：顔作成ジオメトリデータ36
	float faceGeoData36_240;

	// 名前：顔作成ジオメトリデータ37
	// 説明：顔作成ジオメトリデータ37
	float faceGeoData37_244;

	// 名前：顔作成ジオメトリデータ38
	// 説明：顔作成ジオメトリデータ38
	float faceGeoData38_248;

	// 名前：顔作成ジオメトリデータ39
	// 説明：顔作成ジオメトリデータ39
	float faceGeoData39_24C;

	// 名前：顔作成ジオメトリデータ40
	// 説明：顔作成ジオメトリデータ40
	float faceGeoData40_250;

	// 名前：顔作成ジオメトリデータ41
	// 説明：顔作成ジオメトリデータ41
	float faceGeoData41_254;

	// 名前：顔作成ジオメトリデータ42
	// 説明：顔作成ジオメトリデータ42
	float faceGeoData42_258;

	// 名前：顔作成ジオメトリデータ43
	// 説明：顔作成ジオメトリデータ43
	float faceGeoData43_25C;

	// 名前：顔作成ジオメトリデータ44
	// 説明：顔作成ジオメトリデータ44
	float faceGeoData44_260;

	// 名前：顔作成ジオメトリデータ45
	// 説明：顔作成ジオメトリデータ45
	float faceGeoData45_264;

	// 名前：顔作成ジオメトリデータ46
	// 説明：顔作成ジオメトリデータ46
	float faceGeoData46_268;

	// 名前：顔作成ジオメトリデータ47
	// 説明：顔作成ジオメトリデータ47
	float faceGeoData47_26C;

	// 名前：顔作成ジオメトリデータ48
	// 説明：顔作成ジオメトリデータ48
	float faceGeoData48_270;

	// 名前：顔作成ジオメトリデータ49
	// 説明：顔作成ジオメトリデータ49
	float faceGeoData49_274;

	// 名前：顔作成ジオメトリデータ50
	// 説明：顔作成ジオメトリデータ50
	float faceGeoData50_278;

	// 名前：顔作成ジオメトリデータ51
	// 説明：顔作成ジオメトリデータ51
	float faceGeoData51_27C;

	// 名前：顔作成ジオメトリデータ52
	// 説明：顔作成ジオメトリデータ52
	float faceGeoData52_280;

	// 名前：顔作成ジオメトリデータ53
	// 説明：顔作成ジオメトリデータ53
	float faceGeoData53_284;

	// 名前：顔作成ジオメトリデータ54
	// 説明：顔作成ジオメトリデータ54
	float faceGeoData54_288;

	// 名前：顔作成ジオメトリデータ55
	// 説明：顔作成ジオメトリデータ55
	float faceGeoData55_28C;

	// 名前：顔作成ジオメトリデータ56
	// 説明：顔作成ジオメトリデータ56
	float faceGeoData56_290;

	// 名前：顔作成ジオメトリデータ57
	// 説明：顔作成ジオメトリデータ57
	float faceGeoData57_294;

	// 名前：顔作成ジオメトリデータ58
	// 説明：顔作成ジオメトリデータ58
	float faceGeoData58_298;

	// 名前：顔作成ジオメトリデータ59
	// 説明：顔作成ジオメトリデータ59
	float faceGeoData59_29C;

	// 名前：顔作成ジオメトリデータ60
	// 説明：顔作成ジオメトリデータ60
	float faceGeoData60_2A0;

	// 名前：顔作成テクスチャデータ00
	// 説明：顔作成テクスチャデータ00
	float faceTexData00_2A4;

	// 名前：顔作成テクスチャデータ01
	// 説明：顔作成テクスチャデータ01
	float faceTexData01_2A8;

	// 名前：顔作成テクスチャデータ02
	// 説明：顔作成テクスチャデータ02
	float faceTexData02_2AC;

	// 名前：顔作成テクスチャデータ03
	// 説明：顔作成テクスチャデータ03
	float faceTexData03_2B0;

	// 名前：顔作成テクスチャデータ04
	// 説明：顔作成テクスチャデータ04
	float faceTexData04_2B4;

	// 名前：顔作成テクスチャデータ05
	// 説明：顔作成テクスチャデータ05
	float faceTexData05_2B8;

	// 名前：顔作成テクスチャデータ06
	// 説明：顔作成テクスチャデータ06
	float faceTexData06_2BC;

	// 名前：顔作成テクスチャデータ07
	// 説明：顔作成テクスチャデータ07
	float faceTexData07_2C0;

	// 名前：顔作成テクスチャデータ08
	// 説明：顔作成テクスチャデータ08
	float faceTexData08_2C4;

	// 名前：顔作成テクスチャデータ09
	// 説明：顔作成テクスチャデータ09
	float faceTexData09_2C8;

	// 名前：顔作成テクスチャデータ10
	// 説明：顔作成テクスチャデータ10
	float faceTexData10_2CC;

	// 名前：顔作成テクスチャデータ11
	// 説明：顔作成テクスチャデータ11
	float faceTexData11_2D0;

	// 名前：顔作成テクスチャデータ12
	// 説明：顔作成テクスチャデータ12
	float faceTexData12_2D4;

	// 名前：顔作成テクスチャデータ13
	// 説明：顔作成テクスチャデータ13
	float faceTexData13_2D8;

	// 名前：顔作成テクスチャデータ14
	// 説明：顔作成テクスチャデータ14
	float faceTexData14_2DC;

	// 名前：顔作成テクスチャデータ15
	// 説明：顔作成テクスチャデータ15
	float faceTexData15_2E0;

	// 名前：顔作成テクスチャデータ16
	// 説明：顔作成テクスチャデータ16
	float faceTexData16_2E4;

	// 名前：顔作成テクスチャデータ17
	// 説明：顔作成テクスチャデータ17
	float faceTexData17_2E8;

	// 名前：顔作成テクスチャデータ18
	// 説明：顔作成テクスチャデータ18
	float faceTexData18_2EC;

	// 名前：顔作成テクスチャデータ19
	// 説明：顔作成テクスチャデータ19
	float faceTexData19_2F0;

	// 名前：顔作成テクスチャデータ20
	// 説明：顔作成テクスチャデータ20
	float faceTexData20_2F4;

	// 名前：顔作成テクスチャデータ21
	// 説明：顔作成テクスチャデータ21
	float faceTexData21_2F8;

	// 名前：顔作成テクスチャデータ22
	// 説明：顔作成テクスチャデータ22
	float faceTexData22_2FC;

	// 名前：顔作成テクスチャデータ23
	// 説明：顔作成テクスチャデータ23
	float faceTexData23_300;

	// 名前：顔作成テクスチャデータ24
	// 説明：顔作成テクスチャデータ24
	float faceTexData24_304;

	// 名前：顔作成テクスチャデータ25
	// 説明：顔作成テクスチャデータ25
	float faceTexData25_308;

	// 名前：顔作成テクスチャデータ26
	// 説明：顔作成テクスチャデータ26
	float faceTexData26_30C;

	// 名前：顔作成テクスチャデータ27
	// 説明：顔作成テクスチャデータ27
	float faceTexData27_310;

	// 名前：顔作成テクスチャデータ28
	// 説明：顔作成テクスチャデータ28
	float faceTexData28_314;

	// 名前：顔作成テクスチャデータ29
	// 説明：顔作成テクスチャデータ29
	float faceTexData29_318;

	// 名前：顔作成テクスチャデータ30
	// 説明：顔作成テクスチャデータ30
	float faceTexData30_31C;

	// 名前：顔作成テクスチャデータ31
	// 説明：顔作成テクスチャデータ31
	float faceTexData31_320;

	// 名前：顔作成テクスチャデータ32
	// 説明：顔作成テクスチャデータ32
	float faceTexData32_324;

	// 名前：顔作成テクスチャデータ33
	// 説明：顔作成テクスチャデータ33
	float faceTexData33_328;

	// 名前：顔作成テクスチャデータ34
	// 説明：顔作成テクスチャデータ34
	float faceTexData34_32C;

	// 名前：顔作成テクスチャデータ35
	// 説明：顔作成テクスチャデータ35
	float faceTexData35_330;

	// 名前：火傷跡
	// 説明：火傷跡
	float burn_scar_334;

} FaceRangeParam;

#endif
