/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ClearCountCorrectParam_H
#define _PARAM_ClearCountCorrectParam_H
#include <stdint.h>

// CLEAR_COUNT_CORRECT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ClearCountCorrectParam {

	// 名前：《最大HP倍率[%]》
	// 説明：最大HP倍率[%]
	float MaxHpRate_000;

	// 名前：《最大MP倍率[%]》
	// 説明：最大MP倍率[%]
	float MaxMpRate_004;

	// 名前：《最大スタミナ倍率[%]》
	// 説明：最大スタミナ倍率[%]
	float MaxStaminaRate_008;

	// 名前：《物理攻撃力倍率》
	// 説明：物理攻撃力倍率
	float PhysicsAttackRate_00C;

	// 名前：《斬撃攻撃力倍率》
	// 説明：斬撃攻撃力倍率
	float SlashAttackRate_010;

	// 名前：《打撃攻撃力倍率》
	// 説明：打撃攻撃力倍率
	float BlowAttackRate_014;

	// 名前：《刺突攻撃力倍率》
	// 説明：刺突攻撃力倍率
	float ThrustAttackRate_018;

	// 名前：《無属性攻撃力倍率》
	// 説明：無属性攻撃力倍率
	float NeturalAttackRate_01C;

	// 名前：《魔法攻撃力倍率》
	// 説明：魔法攻撃力倍率
	float MagicAttackRate_020;

	// 名前：《炎攻撃力倍率》
	// 説明：炎攻撃力倍率
	float FireAttackRate_024;

	// 名前：《電撃攻撃力倍率》
	// 説明：電撃攻撃力倍率
	float ThunderAttackRate_028;

	// 名前：《闇攻撃力倍率》
	// 説明：闇攻撃力倍率
	float DarkAttackRate_02C;

	// 名前：《物理防御力倍率》
	// 説明：物理防御力倍率
	float PhysicsDefenseRate_030;

	// 名前：《魔法防御力倍率》
	// 説明：魔法防御力倍率
	float MagicDefenseRate_034;

	// 名前：《炎防御力倍率》
	// 説明：炎防御力倍率
	float FireDefenseRate_038;

	// 名前：《電撃防御力倍率》
	// 説明：電撃防御力倍率
	float ThunderDefenseRate_03C;

	// 名前：《闇防御力倍率》
	// 説明：闇防御力倍率
	float DarkDefenseRate_040;

	// 名前：《スタミナ攻撃力倍率》
	// 説明：スタミナ攻撃力倍率
	float StaminaAttackRate_044;

	// 名前：《所持ソウル率》
	// 説明：所持ソウル率
	float SoulRate_048;

	// 名前：《毒耐性変化倍率》
	// 説明：毒耐性変化倍率
	float PoisionResistRate_04C;

	// 名前：《疫病耐性変化倍率》
	// 説明：疫病耐性変化倍率
	float DiseaseResistRate_050;

	// 名前：《出血耐性変化倍率》
	// 説明：出血耐性変化倍率
	float BloodResistRate_054;

	// 名前：《呪耐性変化倍率》
	// 説明：呪耐性変化倍率
	float CurseResistRate_058;

	// 名前：《冷気耐性変化倍率》
	// 説明：冷気耐性変化倍率
	float FreezeResistRate_05C;

	// 名前：《出血ダメージ補正倍率》
	// 説明：出血ダメージ補正倍率
	float BloodDamageRate_060;

	// 名前：《SAダメージ補正倍率》
	// 説明：SAダメージ補正倍率
	float SuperArmorDamageRate_064;

	// 名前：《冷気ダメージ補正倍率》
	// 説明：冷気ダメージ補正倍率
	float FreezeDamageRate_068;

	// 名前：《睡眠耐性変化倍率》
	// 説明：睡眠耐性変化倍率
	float SleepResistRate_06C;

	// 名前：《発狂耐性変化倍率》
	// 説明：発狂耐性変化倍率
	float MadnessResistRate_070;

	// 名前：《睡眠ダメージ補正倍率》
	// 説明：睡眠ダメージ補正倍率
	float SleepDamageRate_074;

	// 名前：《発狂ダメージ補正倍率》
	// 説明：発狂ダメージ補正倍率
	float MadnessDamageRate_078;

	// 名前：pad
	uint8_t pad1_07C[4];

} ClearCountCorrectParam;

#endif
