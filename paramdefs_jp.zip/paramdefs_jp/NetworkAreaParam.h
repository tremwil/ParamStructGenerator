/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_NetworkAreaParam_H
#define _PARAM_NetworkAreaParam_H
#include <stdint.h>

// NETWORK_AREA_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _NetworkAreaParam {

	// 名前：セルサイズX
	// 説明：セルサイズX
	float cellSizeX_000;

	// 名前：セルサイズY
	// 説明：セルサイズY
	float cellSizeY_004;

	// 名前：セルサイズZ
	// 説明：セルサイズZ
	float cellSizeZ_008;

	// 名前：セルオフセットX
	// 説明：セルオフセットX
	float cellOffsetX_00C;

	// 名前：セルオフセットY
	// 説明：セルオフセットY
	float cellOffsetY_010;

	// 名前：セルオフセットZ
	// 説明：セルオフセットZ
	float cellOffsetZ_014;

	// 名前：血痕・死亡幻影有効
	// 説明：血痕・死亡幻影有効
	uint8_t enableBloodstain_018: 1;

	// 名前：血文字有効
	// 説明：血文字有効
	uint8_t enableBloodMessage_018: 1;

	// 名前：幻影有効
	// 説明：幻影有効
	uint8_t enableGhost_018: 1;

	// 名前：マルチプレイ有効
	// 説明：マルチプレイ有効
	uint8_t enableMultiPlay_018: 1;

	// 名前：指輪検索有効
	// 説明：指輪検索の検索対象か？（鐘守灰霊・救援青霊として呼ばれるエリア）
	uint8_t enableRingSearch_018: 1;

	// 名前：乱入検索有効
	// 説明：乱入検索の対象か？
	uint8_t enableBreakInSearch_018: 1;

	// 名前：ダミー
	uint8_t dummy_018[3];

} NetworkAreaParam;

#endif
