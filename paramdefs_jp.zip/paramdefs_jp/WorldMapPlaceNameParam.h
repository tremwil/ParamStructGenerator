/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WorldMapPlaceNameParam_H
#define _PARAM_WorldMapPlaceNameParam_H
#include <stdint.h>

// WORLD_MAP_PLACE_NAME_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WorldMapPlaceNameParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：地図断片パラメータID
	// 説明：地図断片パラメータID。この地図断片を持っていればテキストを表示する
	int32_t worldMapPieceId_004;

	// 名前：テキストID
	// 説明：表示するテキストID。PlaceName.xlsm
	int32_t textId_008;

	// 名前：パディング
	uint8_t pad1_00C[4];

	// 名前：エリア番号
	// 説明：mAA_BB_CC_DD の AA 部分
	uint8_t areaNo_010;

	// 名前：グリッドX番号
	// 説明：mAA_BB_CC_DD の BB 部分
	uint8_t gridXNo_011;

	// 名前：グリッドZ番号
	// 説明：mAA_BB_CC_DD の CC 部分
	uint8_t gridZNo_012;

	// 名前：パディング
	// 説明：パディング
	uint8_t pad2_013[1];

	// 名前：X座標
	// 説明：X座標
	float posX_014;

	// 名前：Y座標
	// 説明：Y座標（使っていない）
	float posY_018;

	// 名前：Z座標
	// 説明：Z座標
	float posZ_01C;

} WorldMapPlaceNameParam;

#endif
