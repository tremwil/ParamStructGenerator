/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MapGridCreateHeightLimitInfo_H
#define _PARAM_MapGridCreateHeightLimitInfo_H
#include <stdint.h>

// MAP_GRID_CREATE_HEIGHT_LIMIT_INFO_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MapGridCreateHeightLimitInfo {

	// 名前：グリッド構築可能高さMin[m]
	// 説明：グリッド構築可能高さ最小値[m]。(LOD2単位)
	float GridEnableCreateHeightMin_000;

	// 名前：グリッド構築可能高さMax[m]
	// 説明：グリッド構築可能高さ最大値[m]。(LOD2単位)
	float GridEnableCreateHeightMax_004;

	// 名前：リザーブ
	// 説明：リザーブ
	uint8_t Reserve_008[24];

} MapGridCreateHeightLimitInfo;

#endif
