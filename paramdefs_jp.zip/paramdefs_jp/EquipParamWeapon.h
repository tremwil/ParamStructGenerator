/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EquipParamWeapon_H
#define _PARAM_EquipParamWeapon_H
#include <stdint.h>

// EQUIP_PARAM_WEAPON_ST
// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EquipParamWeapon {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：行動バリエーションID
	// 説明：攻撃時に参照する行動パラメータIDを決定するときに使う
	int32_t behaviorVariationId_004;

	// 名前：ソートID
	// 説明：ソートID(-1:集めない)(プログラム内で強化レベルを加味するため s32 では７桁が限界)
	int32_t sortId_008;

	// 名前：徘徊装備ID
	// 説明：徘徊ゴースト用の差し替え装備ID.
	uint32_t wanderingEquipId_00C;

	// 名前：重量[kg]
	// 説明：重量[kg].
	float weight_010;

	// 名前：装備重量比率
	// 説明：装備重量比率
	float weaponWeightRate_014;

	// 名前：修理価格
	// 説明：修理基本価格
	int32_t fixPrice_018;

	// 名前：強化価格
	// 説明：強化価格
	int32_t reinforcePrice_01C;

	// 名前：売却価格
	// 説明：販売価格
	int32_t sellValue_020;

	// 名前：筋力補正
	// 説明：キャラパラ補正値.
	float correctStrength_024;

	// 名前：俊敏補正
	// 説明：キャラパラ補正値.
	float correctAgility_028;

	// 名前：魔力補正
	// 説明：キャラパラ補正値.
	float correctMagic_02C;

	// 名前：信仰補正
	// 説明：キャラパラ補正値.
	float correctFaith_030;

	// 名前：ガード時物理攻撃カット率
	// 説明：ガード時のダメージカット率を各攻撃ごとに設定
	float physGuardCutRate_034;

	// 名前：ガード時魔法攻撃カット率
	// 説明：ガード攻撃でない場合は、0を入れる
	float magGuardCutRate_038;

	// 名前：ガード時炎攻撃力カット率
	// 説明：炎攻撃をどれだけカットするか？
	float fireGuardCutRate_03C;

	// 名前：ガード時電撃攻撃力カット率
	// 説明：電撃攻撃をどれだけカットするか？
	float thunGuardCutRate_040;

	// 名前：攻撃ヒット時特殊効果ID0
	// 説明：武器に特殊効果を追加するときに登録する
	int32_t spEffectBehaviorId0_044;

	// 名前：攻撃ヒット時特殊効果ID1
	// 説明：武器に特殊効果を追加するときに登録する
	int32_t spEffectBehaviorId1_048;

	// 名前：攻撃ヒット時特殊効果ID2
	// 説明：武器に特殊効果を追加するときに登録する
	int32_t spEffectBehaviorId2_04C;

	// 名前：常駐特殊効果ID
	// 説明：常駐特殊効果ID0
	int32_t residentSpEffectId_050;

	// 名前：常駐特殊効果ID1
	// 説明：常駐特殊効果ID1
	int32_t residentSpEffectId1_054;

	// 名前：常駐特殊効果ID2
	// 説明：常駐特殊効果ID2
	int32_t residentSpEffectId2_058;

	// 名前：素材ID
	// 説明：武器強化に必要な素材パラメータID
	int32_t materialSetId_05C;

	// 名前：派生元
	// 説明：この武器の強化元武器ID
	int32_t originEquipWep_060;

	// 名前：派生元 強化+1
	// 説明：この武器の強化元武器ID1
	int32_t originEquipWep1_064;

	// 名前：派生元 強化+2
	// 説明：この武器の強化元武器ID2
	int32_t originEquipWep2_068;

	// 名前：派生元 強化+3
	// 説明：この武器の強化元武器ID3
	int32_t originEquipWep3_06C;

	// 名前：派生元 強化+4
	// 説明：この武器の強化元武器ID4
	int32_t originEquipWep4_070;

	// 名前：派生元 強化+5
	// 説明：この武器の強化元武器ID5
	int32_t originEquipWep5_074;

	// 名前：派生元 強化+6
	// 説明：この武器の強化元武器ID6
	int32_t originEquipWep6_078;

	// 名前：派生元 強化+7
	// 説明：この武器の強化元武器ID7
	int32_t originEquipWep7_07C;

	// 名前：派生元 強化+8
	// 説明：この武器の強化元武器ID8
	int32_t originEquipWep8_080;

	// 名前：派生元 強化+9
	// 説明：この武器の強化元武器ID9
	int32_t originEquipWep9_084;

	// 名前：派生元 強化+10
	// 説明：この武器の強化元武器ID10
	int32_t originEquipWep10_088;

	// 名前：派生元 強化+11
	// 説明：この武器の強化元武器ID11
	int32_t originEquipWep11_08C;

	// 名前：派生元 強化+12
	// 説明：この武器の強化元武器ID12
	int32_t originEquipWep12_090;

	// 名前：派生元 強化+13
	// 説明：この武器の強化元武器ID13
	int32_t originEquipWep13_094;

	// 名前：派生元 強化+14
	// 説明：この武器の強化元武器ID14
	int32_t originEquipWep14_098;

	// 名前：派生元 強化+15
	// 説明：この武器の強化元武器ID15
	int32_t originEquipWep15_09C;

	// 名前：特攻Aダメージ倍率
	// 説明：特攻A用のダメージ倍率
	float weakA_DamageRate_0A0;

	// 名前：特攻Bダメージ倍率
	// 説明：特攻B用のダメージ倍率
	float weakB_DamageRate_0A4;

	// 名前：特攻Cダメージ倍率
	// 説明：特攻C用のダメージ倍率
	float weakC_DamageRate_0A8;

	// 名前：特攻Dダメージ倍率
	// 説明：特攻D用のダメージ倍率
	float weakD_DamageRate_0AC;

	// 名前：睡眠耐性カット率_最大補正値
	// 説明：睡眠に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float sleepGuardResist_MaxCorrect_0B0;

	// 名前：発狂耐性カット率_最大補正値
	// 説明：発狂に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float madnessGuardResist_MaxCorrect_0B4;

	// 名前：SA武器攻撃力
	// 説明：スーパーアーマー基本攻撃力
	float saWeaponDamage_0B8;

	// 名前：装備モデル番号
	// 説明：装備モデルの番号.
	uint16_t equipModelId_0BC;

	// 名前：アイコンID
	// 説明：メニューアイコンID.
	uint16_t iconId_0BE;

	// 名前：耐久度
	// 説明：初期耐久度.
	uint16_t durability_0C0;

	// 名前：耐久度最大値
	// 説明：新品耐久度.
	uint16_t durabilityMax_0C2;

	// 名前：投げ抜け攻撃力基本値
	// 説明：投げ抜け攻撃力の基本値
	uint16_t attackThrowEscape_0C4;

	// 名前：パリィ発生時間[frame]
	// 説明：パリィダメージの寿命を制限する。TimeActで設定されている以上には持続しない。
	int16_t parryDamageLife_0C6;

	// 名前：物理攻撃力基本値
	// 説明：敵のＨＰにダメージを与える物理属性攻撃の基本値
	uint16_t attackBasePhysics_0C8;

	// 名前：魔法攻撃力基本値
	// 説明：敵のＨＰにダメージを与える魔法属性攻撃の基本値
	uint16_t attackBaseMagic_0CA;

	// 名前：炎攻撃力基本値
	// 説明：敵のＨＰにダメージを与える炎属性攻撃の基本値
	uint16_t attackBaseFire_0CC;

	// 名前：電撃攻撃力基本値
	// 説明：敵のＨＰにダメージを与える電撃属性攻撃の基本値
	uint16_t attackBaseThunder_0CE;

	// 名前：スタミナ攻撃力
	// 説明：敵へのスタミナ攻撃力
	uint16_t attackBaseStamina_0D0;

	// 名前：ガード範囲[deg]
	// 説明：武器のガード時の防御発生範囲角度
	int16_t guardAngle_0D2;

	// 名前：SA耐久値
	// 説明：攻撃モーション中に使われる追加SA耐久値
	float saDurability_0D4;

	// 名前：ガード時スタミナ防御力
	// 説明：ガード成功時に、敵のスタミナ攻撃に対する防御力
	int16_t staminaGuardDef_0D8;

	// 名前：強化タイプID
	// 説明：強化タイプID
	int16_t reinforceTypeId_0DA;

	// 名前：トロフィーＳグレードID
	// 説明：トロフィーシステムに関係あるか？
	int16_t trophySGradeId_0DC;

	// 名前：トロフィーSEQ番号
	// 説明：トロフィーのSEQ番号（１３～２９）
	int16_t trophySeqId_0DE;

	// 名前：投げ攻撃力倍率
	// 説明：投げの攻撃力倍率
	int16_t throwAtkRate_0E0;

	// 名前：弓飛距離補正[％]
	// 説明：飛距離を伸ばすアップ％
	int16_t bowDistRate_0E2;

	// 名前：装備モデル種別
	// 説明：装備モデルの種別.
	uint8_t equipModelCategory_0E4;

	// 名前：装備モデル性別
	// 説明：装備モデルの性別.
	uint8_t equipModelGender_0E5;

	// 名前：武器カテゴリ
	// 説明：武器のカテゴリ.
	uint8_t weaponCategory_0E6;

	// 名前：武器モーションカテゴリ
	// 説明：武器モーションのカテゴリ.
	uint8_t wepmotionCategory_0E7;

	// 名前：ガードモーションカテゴリ
	// 説明：ガードモーションのカテゴリ
	uint8_t guardmotionCategory_0E8;

	// 名前：攻撃材質
	// 説明：攻撃パラから使用される攻撃材質
	uint8_t atkMaterial_0E9;

	// 名前：防御SE材質1
	// 説明：攻撃パラから使用される防御SE材質1
	uint16_t defSeMaterial1_0EA;

	// 名前：補正タイプ（物理攻撃力）
	// 説明：一次パラメータによる物理攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Physics_0EC;

	// 名前：特殊属性
	// 説明：武器の特殊属性値
	uint8_t spAttribute_0ED;

	// 名前：特殊攻撃カテゴリ
	// 説明：特殊攻撃カテゴリ（50～999まで可能)
	uint16_t spAtkcategory_0EE;

	// 名前：武器モーション片手ID
	// 説明：片手装備時の基本モーションID.
	uint8_t wepmotionOneHandId_0F0;

	// 名前：武器モーション両手ID
	// 説明：両手装備時の基本モーションID.
	uint8_t wepmotionBothHandId_0F1;

	// 名前：装備適正筋力
	// 説明：装備適正値.
	uint8_t properStrength_0F2;

	// 名前：装備適正俊敏
	// 説明：装備適正値.
	uint8_t properAgility_0F3;

	// 名前：装備適正魔力
	// 説明：装備適正値.
	uint8_t properMagic_0F4;

	// 名前：装備適正信仰
	// 説明：装備適正値.
	uint8_t properFaith_0F5;

	// 名前：筋力オーバー開始値
	// 説明：筋力オーバー開始値
	uint8_t overStrength_0F6;

	// 名前：パリィ攻撃基本値
	// 説明：敵のパリィをやぶるための基本値
	uint8_t attackBaseParry_0F7;

	// 名前：パリィ防御値
	// 説明：パリィ判定時に、パリィになるかガードになるかの判定に利用
	uint8_t defenseBaseParry_0F8;

	// 名前：はじき防御力基本値
	// 説明：敵の攻撃をガードしたときに、はじけるかどうかの判定に利用
	uint8_t guardBaseRepel_0F9;

	// 名前：はじき攻撃力基本値
	// 説明：ガード敵を攻撃した時に、はじかれるかどうかの判定に利用
	uint8_t attackBaseRepel_0FA;

	// 名前：ガードカット無効化倍率
	// 説明：相手のガードカットを無効化させる倍率。-100で完全無効。100で相手の防御効果倍増。
	int8_t guardCutCancelRate_0FB;

	// 名前：ガードレベル
	// 説明：ガードしたとき、敵の攻撃をどのガードモーションで受けるか？を決める
	int8_t guardLevel_0FC;

	// 名前：斬撃攻撃カット率
	// 説明：攻撃タイプを見て、斬撃属性のダメージを何％カットするか？を指定
	int8_t slashGuardCutRate_0FD;

	// 名前：打撃攻撃カット率
	// 説明：攻撃タイプを見て、打撃属性のダメージを何％カットするか？を指定
	int8_t blowGuardCutRate_0FE;

	// 名前：刺突攻撃カット率
	// 説明：攻撃タイプを見て、刺突属性のダメージを何％カットするか？を指定
	int8_t thrustGuardCutRate_0FF;

	// 名前：毒耐性カット率
	// 説明：毒にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t poisonGuardResist_100;

	// 名前：疫病攻撃カット率
	// 説明：疫病にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t diseaseGuardResist_101;

	// 名前：出血攻撃カット率
	// 説明：出血にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t bloodGuardResist_102;

	// 名前：呪攻撃カット率
	// 説明：呪いにする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t curseGuardResist_103;

	// 名前：物理属性1
	// 説明：物理属性1
	uint8_t atkAttribute_104;

	// 名前：右手装備
	// 説明：右手装備可能か.
	uint8_t rightHandEquipable_105: 1;

	// 名前：左手装備
	// 説明：左手装備可能か.
	uint8_t leftHandEquipable_105: 1;

	// 名前：両手装備
	// 説明：両手装備可能か.
	uint8_t bothHandEquipable_105: 1;

	// 名前：弓矢弾装備
	// 説明：弓用矢弾装備可能か.
	uint8_t arrowSlotEquipable_105: 1;

	// 名前：弩矢弾装備
	// 説明：弩用矢弾装備可能か.
	uint8_t boltSlotEquipable_105: 1;

	// 名前：ガード可能
	// 説明：左手装備時L1でガード
	uint8_t enableGuard_105: 1;

	// 名前：パリィ可能
	// 説明：左手装備時L2でパリィ
	uint8_t enableParry_105: 1;

	// 名前：魔法可能
	// 説明：攻撃時に魔法発動
	uint8_t enableMagic_105: 1;

	// 名前：呪術可能
	// 説明：攻撃時に呪術発動
	uint8_t enableSorcery_106: 1;

	// 名前：奇蹟可能
	// 説明：攻撃時に奇蹟発動
	uint8_t enableMiracle_106: 1;

	// 名前：誓約魔法可能
	// 説明：攻撃時に誓約魔法発動
	uint8_t enableVowMagic_106: 1;

	// 名前：通常
	// 説明：メニュー表示用攻撃タイプ。通常か
	uint8_t isNormalAttackType_106: 1;

	// 名前：打撃
	// 説明：メニュー表示用攻撃タイプ。打撃か
	uint8_t isBlowAttackType_106: 1;

	// 名前：斬撃
	// 説明：メニュー表示用攻撃タイプ。斬撃か
	uint8_t isSlashAttackType_106: 1;

	// 名前：刺突
	// 説明：メニュー表示用攻撃タイプ。刺突か
	uint8_t isThrustAttackType_106: 1;

	// 名前：エンチャント可能か？
	// 説明：松脂などで、強化可能か？
	uint8_t isEnhance_106: 1;

	// 名前：人間性補正あるか
	// 説明：人間性による攻撃力補正があるか
	uint8_t isHeroPointCorrect_107: 1;

	// 名前：強化できるか？
	// 説明：強化ショップで強化対象リストに並ぶ(仕様変更で削除するかも？)
	uint8_t isCustom_107: 1;

	// 名前：転職リセット禁止か
	// 説明：転職リセット禁止か
	uint8_t disableBaseChangeReset_107: 1;

	// 名前：修理禁止か
	// 説明：修理禁止か
	uint8_t disableRepair_107: 1;

	// 名前：ダークハンドか
	// 説明：ダークハンドか
	uint8_t isDarkHand_107: 1;

	// 名前：DLC用シンプルモデルありか
	// 説明：ＤＬＣ用シンプルモデルが存在しているか
	uint8_t simpleModelForDlc_107: 1;

	// 名前：ランタン武器
	// 説明：ランタン武器か
	uint8_t lanternWep_107: 1;

	// 名前：対霊武器
	// 説明：NPCパラの「霊体か」が○の相手に攻撃を当たるようになります。また、攻撃パラの「霊体攻撃か」が○の攻撃をガードできるようになります。
	uint8_t isVersusGhostWep_107: 1;

	// 名前：武器転職カテゴリ
	// 説明：武器転職カテゴリ。属性アイコン表示に使用します。
	uint8_t baseChangeCategory_108: 6;

	// 名前：竜狩りか
	// 説明：竜狩り武器か
	uint8_t isDragonSlayer_108: 1;

	// 名前：預けれるか
	// 説明：倉庫に預けれるか
	uint8_t isDeposit_108: 1;

	// 名前：マルチドロップ共有禁止か
	// 説明：マルチドロップ共有禁止か
	uint8_t disableMultiDropShare_109: 1;

	// 名前：捨てれるか
	// 説明：アイテムを捨てれるか？TRUE=捨てれる
	uint8_t isDiscard_109: 1;

	// 名前：その場に置けるか
	// 説明：アイテムをその場に置けるか？TRUE=置ける
	uint8_t isDrop_109: 1;

	// 名前：取得ログ表示条件
	// 説明：アイテム取得時にアイテム取得ログに表示するか（未入力: ○）
	uint8_t showLogCondType_109: 1;

	// 名前：投げ可能
	// 説明：投げ可能な武器かどうか
	uint8_t enableThrow_109: 1;

	// 名前：取得ダイアログ表示条件
	// 説明：アイテム取得時にアイテム取得ダイアログに表示するか（未入力: newのみ）
	uint8_t showDialogCondType_109: 2;

	// 名前：魔石属性変更禁止か
	// 説明：魔石属性変更禁止か
	uint8_t disableGemAttr_109: 1;

	// 名前：防御SFX材質1
	// 説明：攻撃パラから使用される防御SFX材質1
	uint16_t defSfxMaterial1_10A;

	// 名前：武器コライダブル設定
	// 説明：武器のコライダブル設定
	uint8_t wepCollidableType0_10C;

	// 名前：武器1コライダブル設定
	// 説明：武器1のコライダブル設定
	uint8_t wepCollidableType1_10D;

	// 名前：姿勢制御ID(右手)
	// 説明：姿勢制御ID(右手)
	uint8_t postureControlId_Right_10E;

	// 名前：姿勢制御ID(左手)
	// 説明：姿勢制御ID(左手)
	uint8_t postureControlId_Left_10F;

	// 名前：剣閃SfxID_０
	// 説明：剣閃SfxID_０(-1無効)
	int32_t traceSfxId0_110;

	// 名前：根元剣閃ダミポリID_０
	// 説明：剣閃根元ダミポリID_０(-1無効)
	int32_t traceDmyIdHead0_114;

	// 名前：剣先剣閃ダミポリID_０
	// 説明：剣閃剣先ダミポリID_０
	int32_t traceDmyIdTail0_118;

	// 名前：剣閃SfxID_１
	// 説明：剣閃SfxID_１(-1無効)
	int32_t traceSfxId1_11C;

	// 名前：根元剣閃ダミポリID_１
	// 説明：剣閃根元ダミポリID_１(-1無効)
	int32_t traceDmyIdHead1_120;

	// 名前：剣先剣閃ダミポリID_１
	// 説明：剣閃剣先ダミポリID_１
	int32_t traceDmyIdTail1_124;

	// 名前：剣閃SfxID_２
	// 説明：剣閃SfxID_２(-1無効)
	int32_t traceSfxId2_128;

	// 名前：根元剣閃ダミポリID_２
	// 説明：剣閃根元ダミポリID_２(-1無効)
	int32_t traceDmyIdHead2_12C;

	// 名前：剣先剣閃ダミポリID_２
	// 説明：剣閃剣先ダミポリID_２
	int32_t traceDmyIdTail2_130;

	// 名前：剣閃SfxID_３
	// 説明：剣閃SfxID_３(-1無効)
	int32_t traceSfxId3_134;

	// 名前：根元剣閃ダミポリID_３
	// 説明：剣閃根元ダミポリID_３(-1無効)
	int32_t traceDmyIdHead3_138;

	// 名前：剣先剣閃ダミポリID_３
	// 説明：剣閃剣先ダミポリID_３
	int32_t traceDmyIdTail3_13C;

	// 名前：剣閃SfxID_４
	// 説明：剣閃SfxID_４(-1無効)
	int32_t traceSfxId4_140;

	// 名前：根元剣閃ダミポリID_４
	// 説明：剣閃根元ダミポリID_４(-1無効)
	int32_t traceDmyIdHead4_144;

	// 名前：剣先剣閃ダミポリID_４
	// 説明：剣閃剣先ダミポリID_４
	int32_t traceDmyIdTail4_148;

	// 名前：剣閃SfxID_５
	// 説明：剣閃SfxID_５(-1無効)
	int32_t traceSfxId5_14C;

	// 名前：根元剣閃ダミポリID_５
	// 説明：剣閃根元ダミポリID_５(-1無効)
	int32_t traceDmyIdHead5_150;

	// 名前：剣先剣閃ダミポリID_５
	// 説明：剣閃剣先ダミポリID_５
	int32_t traceDmyIdTail5_154;

	// 名前：剣閃SfxID_６
	// 説明：剣閃SfxID_６(-1無効)
	int32_t traceSfxId6_158;

	// 名前：根元剣閃ダミポリID_６
	// 説明：剣閃根元ダミポリID_６(-1無効)
	int32_t traceDmyIdHead6_15C;

	// 名前：剣先剣閃ダミポリID_６
	// 説明：剣閃剣先ダミポリID_６
	int32_t traceDmyIdTail6_160;

	// 名前：剣閃SfxID_７
	// 説明：剣閃SfxID_７(-1無効)
	int32_t traceSfxId7_164;

	// 名前：根元剣閃ダミポリID_７
	// 説明：剣閃根元ダミポリID_７(-1無効)
	int32_t traceDmyIdHead7_168;

	// 名前：剣先剣閃ダミポリID_７
	// 説明：剣閃剣先ダミポリID_７
	int32_t traceDmyIdTail7_16C;

	// 名前：防御SFX材質2
	// 説明：攻撃パラから使用される防御SFX材質2
	uint16_t defSfxMaterial2_170;

	// 名前：防御SE材質2
	// 説明：攻撃パラから使用される防御SE材質2
	uint16_t defSeMaterial2_172;

	// 名前：吸着位置Id
	// 説明：武器吸着位置パラメータのId。この値により武器が吸着する位置を決定する(-1：旧ソースコード直書きの値を参照する)
	int32_t absorpParamId_174;

	// 名前：強靭度 補正倍率
	// 説明：強靭度の基本値を補正する倍率です
	float toughnessCorrectRate_178;

	// 名前：防具SAダメージ倍率が初期値でも有効か？
	// 説明：防具SAが初期値でも強靭度計算が行われるかどうか。詳細は強靭度仕様書.xlsxを確認してください
	uint8_t isValidTough_ProtSADmg_17C: 1;

	// 名前：双剣か
	// 説明：この武器は双剣か。
	uint8_t isDualBlade_17C: 1;

	// 名前：自動装填可能か
	// 説明：矢・ボルトのみ有効。新しくこの武器を拾っ時に対象装備スロットが空の場合に自動で装備するかどうか
	uint8_t isAutoEquip_17C: 1;

	// 名前：緊急回避可能か
	// 説明：緊急回避可能な武器かどうか。ビヘイビアスクリプトに渡す。
	uint8_t isEnableEmergencyStep_17C: 1;

	// 名前：カットシーン中非表示か
	// 説明：カットシーン中非表示か
	uint8_t invisibleOnRemo_17C: 1;

	// 名前：pad
	uint8_t pad2_17C: 3;

	// 名前：補正タイプ（魔法攻撃力）
	// 説明：一次パラメータによる魔法攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Magic_17D;

	// 名前：補正タイプ（炎攻撃力）
	// 説明：一次パラメータによる炎攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Fire_17E;

	// 名前：補正タイプ（雷攻撃力）
	// 説明：一次パラメータによる雷攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Thunder_17F;

	// 名前：特攻Eダメージ倍率
	// 説明：特攻E用のダメージ倍率
	float weakE_DamageRate_180;

	// 名前：特攻Fダメージ倍率
	// 説明：特攻F用のダメージ倍率
	float weakF_DamageRate_184;

	// 名前：ガード時闇攻撃力カット率
	// 説明：闇攻撃をどれだけカットするか？
	float darkGuardCutRate_188;

	// 名前：闇攻撃力基本値
	// 説明：敵のＨＰにダメージを与える闇属性攻撃の基本値
	uint16_t attackBaseDark_18C;

	// 名前：補正タイプ（闇攻撃力）
	// 説明：一次パラメータによる闇攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Dark_18E;

	// 名前：補正タイプ（毒攻撃力）
	// 説明：一次パラメータによる毒攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Poison_18F;

	// 名前：ソートアイテム種別ID
	// 説明：ソートアイテム種別ID。ソート「アイテム種別順」にて、同じIDは同じグループとしてまとめて表示されます
	uint8_t sortGroupId_190;

	// 名前：物理属性2
	// 説明：物理属性2
	uint8_t atkAttribute2_191;

	// 名前：睡眠攻撃カット率
	// 説明：睡眠にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t sleepGuardResist_192;

	// 名前：発狂攻撃カット率
	// 説明：発狂にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t madnessGuardResist_193;

	// 名前：補正タイプ（出血攻撃力）
	// 説明：一次パラメータによる出血攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Blood_194;

	// 名前：装備適正運
	// 説明：装備適正値.
	uint8_t properLuck_195;

	// 名前：冷気攻撃カット率
	// 説明：冷気にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t freezeGuardResist_196;

	// 名前：自動補充タイプ
	// 説明：自動補充する/しないの可否およびデフォルト設定をコントロールします
	uint8_t autoReplenishType_197;

	// 名前：アーツパラメータID
	// 説明：アーツパラメータのID
	int32_t swordArtsParamId_198;

	// 名前：運補正
	// 説明：キャラパラ補正値.
	float correctLuck_19C;

	// 名前：矢筒(弾倉)表示モデル用装備ID
	// 説明：矢筒(弾倉)表示モデルの装備品番号。弓の場合は矢筒、弩の場合は弾倉として表示する。
	uint32_t arrowBoltEquipId_1A0;

	// 名前：還元時レベル設定
	// 説明：武器を還元・派生させるときに強化レベルをどう設定するかの種別
	uint8_t DerivationLevelType_1A4;

	// 名前：エンチャントSfxサイズ
	// 説明：エンチャントSfxIdにオフセットする値
	uint8_t enchantSfxSize_1A5;

	// 名前：武器種別
	// 説明：武器種別。テキストと、魔石の紐付けに使われる（※テキスト以外にも使われるようになった）
	uint16_t wepType_1A6;

	// 名前：ガード時物理攻撃カット率_最大補正値
	// 説明：ガード時のダメージ物理カット率の補正値の最大値
	float physGuardCutRate_MaxCorrect_1A8;

	// 名前：ガード時魔法攻撃カット率_最大補正値
	// 説明：ガード時のダメージ魔法カット率の補正値の最大値
	float magGuardCutRate_MaxCorrect_1AC;

	// 名前：ガード時炎攻撃力カット率_最大補正値
	// 説明：ガード時のダメージ炎カット率の補正値の最大値
	float fireGuardCutRate_MaxCorrect_1B0;

	// 名前：ガード時電撃攻撃力カット率_最大補正値
	// 説明：ガード時のダメージ電撃カット率の補正値の最大値
	float thunGuardCutRate_MaxCorrect_1B4;

	// 名前：ガード時闇攻撃力カット率_最大補正値
	// 説明：ガード時のダメージ闇カット率の補正値の最大値
	float darkGuardCutRate_MaxCorrect_1B8;

	// 名前：毒耐性カット率_最大補正値
	// 説明：毒に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float poisonGuardResist_MaxCorrect_1BC;

	// 名前：疫病耐性カット率_最大補正値
	// 説明：疫病に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float diseaseGuardResist_MaxCorrect_1C0;

	// 名前：出血耐性カット率_最大補正値
	// 説明：出血に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float bloodGuardResist_MaxCorrect_1C4;

	// 名前：呪耐性カット率_最大補正値
	// 説明：呪いに対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float curseGuardResist_MaxCorrect_1C8;

	// 名前：冷気耐性カット率_最大補正値
	// 説明：冷気に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float freezeGuardResist_MaxCorrect_1CC;

	// 名前：ガード時スタミナ防御力_最大補正値
	// 説明：ガード成功時に、敵のスタミナ攻撃に対する防御力の補正値の最大値
	float staminaGuardDef_MaxCorrect_1D0;

	// 名前：常駐SfxId１
	// 説明：常駐SfxId1
	int32_t residentSfxId_1_1D4;

	// 名前：常駐SfxId２
	// 説明：常駐SfxId2
	int32_t residentSfxId_2_1D8;

	// 名前：常駐SfxId３
	// 説明：常駐SfxId3
	int32_t residentSfxId_3_1DC;

	// 名前：常駐SfxId４
	// 説明：常駐SfxId4
	int32_t residentSfxId_4_1E0;

	// 名前：常駐SfxダミポリId１
	// 説明：常駐SfxダミポリId１
	int32_t residentSfx_DmyId_1_1E4;

	// 名前：常駐SfxダミポリId２
	// 説明：常駐SfxダミポリId２
	int32_t residentSfx_DmyId_2_1E8;

	// 名前：常駐SfxダミポリId３
	// 説明：常駐SfxダミポリId３
	int32_t residentSfx_DmyId_3_1EC;

	// 名前：常駐SfxダミポリId４
	// 説明：常駐SfxダミポリId４
	int32_t residentSfx_DmyId_4_1F0;

	// 名前：スタミナ消費量倍率
	// 説明：スタミナ消費量倍率
	float staminaConsumptionRate_1F4;

	// 名前：対プレイヤー 物理ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Physics_1F8;

	// 名前：対プレイヤー 魔法ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Magic_1FC;

	// 名前：対プレイヤー 炎ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Fire_200;

	// 名前：対プレイヤー 雷ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Thunder_204;

	// 名前：対プレイヤー 闇ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Dark_208;

	// 名前：対プレイヤー 毒ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Poison_20C;

	// 名前：対プレイヤー 出血ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Blood_210;

	// 名前：対プレイヤー 冷気ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Freeze_214;

	// 名前：武器能力解放ステータス値：筋力
	// 説明：特定の武器を使った際、ステータスがX以上だとR2攻撃が特殊なアクションに変わるようするためのもの
	int32_t attainmentWepStatusStr_218;

	// 名前：武器能力解放ステータス値：技量
	// 説明：特定の武器を使った際、ステータスがX以上だとR2攻撃が特殊なアクションに変わるようするためのもの
	int32_t attainmentWepStatusDex_21C;

	// 名前：武器能力解放ステータス値：理力
	// 説明：特定の武器を使った際、ステータスがX以上だとR2攻撃が特殊なアクションに変わるようするためのもの
	int32_t attainmentWepStatusMag_220;

	// 名前：武器能力解放ステータス値：信仰
	// 説明：特定の武器を使った際、ステータスがX以上だとR2攻撃が特殊なアクションに変わるようするためのもの
	int32_t attainmentWepStatusFai_224;

	// 名前：武器能力解放ステータス値：運
	// 説明：特定の武器を使った際、ステータスがX以上だとR2攻撃が特殊なアクションに変わるようするためのもの
	int32_t attainmentWepStatusLuc_228;

	// 名前：攻撃属性補正ID
	// 説明：攻撃属性を補正するパラメータのID
	int32_t attackElementCorrectId_22C;

	// 名前：販売価格
	// 説明：販売価格
	int32_t saleValue_230;

	// 名前：強化ショップカテゴリ
	// 説明：強化ショップカテゴリ
	uint8_t reinforceShopCategory_234;

	// 名前：矢の最大所持数
	// 説明：矢の最大所持数
	uint8_t maxArrowQuantity_235;

	// 名前：常駐SFX1納刀時表示するか
	// 説明：「常駐SFX1納刀時表示するか」がtrueの場合、武器が納刀された時に「常駐SFXID1」に設定されているSFXを非表示にする
	uint8_t residentSfx_1_IsVisibleForHang_236: 1;

	// 名前：常駐SFX2納刀時表示するか
	// 説明：「常駐SFX2納刀時表示するか」がtrueの場合、武器が納刀された時に「常駐SFXID2」に設定されているSFXを非表示にする
	uint8_t residentSfx_2_IsVisibleForHang_236: 1;

	// 名前：常駐SFX3納刀時表示するか
	// 説明：「常駐SFX3納刀時表示するか」がtrueの場合、武器が納刀された時に「常駐SFXID3」に設定されているSFXを非表示にする
	uint8_t residentSfx_3_IsVisibleForHang_236: 1;

	// 名前：常駐SFX4納刀時表示するか
	// 説明：「常駐SFX4納刀時表示するか」がtrueの場合、武器が納刀された時に「常駐SFXID4」に設定されているSFXを非表示にする
	uint8_t residentSfx_4_IsVisibleForHang_236: 1;

	// 名前：モデル_0 ソウルパラムID差し替え可能か
	// 説明：vfxパラメータの「武器エンチャント用ソウルパラムID」と「武器エンチャント用インビジブルウェポンか」設定が適応されるか
	uint8_t isSoulParamIdChange_model0_236: 1;

	// 名前：モデル_1 ソウルパラムID差し替え可能か
	// 説明：vfxパラメータの「武器エンチャント用ソウルパラムID」と「武器エンチャント用インビジブルウェポンか」設定が適応されるか
	uint8_t isSoulParamIdChange_model1_236: 1;

	// 名前：モデル_2 ソウルパラムID差し替え可能か
	// 説明：vfxパラメータの「武器エンチャント用ソウルパラムID」と「武器エンチャント用インビジブルウェポンか」設定が適応されるか
	uint8_t isSoulParamIdChange_model2_236: 1;

	// 名前：モデル_3 ソウルパラムID差し替え可能か
	// 説明：vfxパラメータの「武器エンチャント用ソウルパラムID」と「武器エンチャント用インビジブルウェポンか」設定が適応されるか
	uint8_t isSoulParamIdChange_model3_236: 1;

	// 名前：武器SEIDオフセット値
	// 説明：SEIDのオフセット値 
	int8_t wepSeIdOffset_237;

	// 名前：進化価格
	// 説明：進化価格
	int32_t baseChangePrice_238;

	// 名前：レベルシンク補正ID
	// 説明：レベルシンク補正ID
	int16_t levelSyncCorrectId_23C;

	// 名前：補正タイプ（睡眠攻撃力）
	// 説明：一次パラメータによる睡眠攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Sleep_23E;

	// 名前：補正タイプ（発狂攻撃力）
	// 説明：一次パラメータによる発狂攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Madness_23F;

	// 名前：レア度
	// 説明：アイテム取得ログで使うレア度
	uint8_t rarity_240;

	// 名前：魔石装着可能か
	// 説明：魔石装着可能か
	uint8_t gemMountType_241;

	// 名前：武器リゲイン量
	// 説明：武器リゲイン量
	uint16_t wepRegainHp_242;

	// 名前：効果テキストID00
	// 説明：効果テキストID00(Weapon_Effect)。ステータスに表示する武器固有効果のテキスト
	int32_t spEffectMsgId0_244;

	// 名前：効果テキストID01
	// 説明：効果テキストID01(Weapon_Effect)。ステータスに表示する武器固有効果のテキスト
	int32_t spEffectMsgId1_248;

	// 名前：効果テキストID02
	// 説明：効果テキストID02(Weapon_Effect)。ステータスに表示する武器固有効果のテキスト
	int32_t spEffectMsgId2_24C;

	// 名前：派生元 強化+16
	// 説明：この武器の強化元武器ID16
	int32_t originEquipWep16_250;

	// 名前：派生元 強化+17
	// 説明：この武器の強化元武器ID17
	int32_t originEquipWep17_254;

	// 名前：派生元 強化+18
	// 説明：この武器の強化元武器ID18
	int32_t originEquipWep18_258;

	// 名前：派生元 強化+19
	// 説明：この武器の強化元武器ID19
	int32_t originEquipWep19_25C;

	// 名前：派生元 強化+20
	// 説明：この武器の強化元武器ID20
	int32_t originEquipWep20_260;

	// 名前：派生元 強化+21
	// 説明：この武器の強化元武器ID21
	int32_t originEquipWep21_264;

	// 名前：派生元 強化+22
	// 説明：この武器の強化元武器ID22
	int32_t originEquipWep22_268;

	// 名前：派生元 強化+23
	// 説明：この武器の強化元武器ID23
	int32_t originEquipWep23_26C;

	// 名前：派生元 強化+24
	// 説明：この武器の強化元武器ID24
	int32_t originEquipWep24_270;

	// 名前：派生元 強化+25
	// 説明：この武器の強化元武器ID25
	int32_t originEquipWep25_274;

	// 名前：対プレイヤー 睡眠ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Sleep_278;

	// 名前：対プレイヤー 発狂ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Madness_27C;

	// 名前：ガード時SA攻撃カット率
	// 説明：ガード成功時のSAダメージのカット率
	float saGuardCutRate_280;

	// 名前：防御材質バリエーション値
	// 説明：ガード時に使用される防御材質と組み合わせてダメージSFX,SEのバリエーション分けに使用する値です。SEQ16473
	uint8_t defMaterialVariationValue_284;

	// 名前：特殊属性バリエーション値
	// 説明：武器の特殊属性と組み合わせて状態異常SFX,SEなどにバリエーションを持たせるために使用する値です。SEQ16473
	uint8_t spAttributeVariationValue_285;

	// 名前：ステルス攻撃力倍率
	// 説明：ステルス攻撃力倍率
	int16_t stealthAtkRate_286;

	// 名前：対プレイヤー 疫病ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Disease_288;

	// 名前：対プレイヤー 呪ダメージ補正倍率
	// 説明：プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Curse_28C;

	// 名前：pad
	// 説明：pad
	uint8_t pad_290[8];

} EquipParamWeapon;

#endif
