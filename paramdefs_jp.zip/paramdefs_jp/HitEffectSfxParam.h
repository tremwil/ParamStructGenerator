/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_HitEffectSfxParam_H
#define _PARAM_HitEffectSfxParam_H
#include <stdint.h>

// HIT_EFFECT_SFX_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _HitEffectSfxParam {

	// 名前：斬撃：標準
	// 説明：斬撃：標準
	int32_t Slash_Normal_000;

	// 名前：斬撃：小
	// 説明：斬撃：小
	int32_t Slash_S_004;

	// 名前：斬撃：大
	// 説明：斬撃：大
	int32_t Slash_L_008;

	// 名前：斬撃：指定1
	// 説明：斬撃：指定1
	int32_t Slash_Specific1_00C;

	// 名前：斬撃：指定2
	// 説明：斬撃：指定2
	int32_t Slash_Specific2_010;

	// 名前：打撃：標準
	// 説明：打撃：標準
	int32_t Blow_Normal_014;

	// 名前：打撃：小
	// 説明：打撃：小
	int32_t Blow_S_018;

	// 名前：打撃：大
	// 説明：打撃：大
	int32_t Blow_L_01C;

	// 名前：打撃：指定1
	// 説明：打撃：指定1
	int32_t Blow_Specific1_020;

	// 名前：打撃：指定2
	// 説明：打撃：指定2
	int32_t Blow_Specific2_024;

	// 名前：刺突：標準
	// 説明：刺突：標準
	int32_t Thrust_Normal_028;

	// 名前：刺突：小
	// 説明：刺突：小
	int32_t Thrust_S_02C;

	// 名前：刺突：大
	// 説明：刺突：大
	int32_t Thrust_L_030;

	// 名前：刺突：指定1
	// 説明：刺突：指定1
	int32_t Thrust_Specific1_034;

	// 名前：刺突：指定2
	// 説明：刺突：指定2
	int32_t Thrust_Specific2_038;

	// 名前：無属性：標準
	// 説明：無属性：標準
	int32_t Neutral_Normal_03C;

	// 名前：無属性：小
	// 説明：無属性：小
	int32_t Neutral_S_040;

	// 名前：無属性：大
	// 説明：無属性：大
	int32_t Neutral_L_044;

	// 名前：無属性：指定1
	// 説明：無属性：指定1
	int32_t Neutral_Specific1_048;

	// 名前：無属性：指定2
	// 説明：無属性：指定2
	int32_t Neutral_Specific2_04C;

} HitEffectSfxParam;

#endif
