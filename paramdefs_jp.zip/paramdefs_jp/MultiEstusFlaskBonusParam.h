/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MultiEstusFlaskBonusParam_H
#define _PARAM_MultiEstusFlaskBonusParam_H
#include <stdint.h>

// MULTI_ESTUS_FLASK_BONUS_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MultiEstusFlaskBonusParam {

	// 名前：ホスト
	// 説明：ホストのエスト回復数
	uint8_t host_000;

	// 名前：白サイン
	// 説明：協力サインの白霊のエスト回復数
	uint8_t WhiteGhost_None_001;

	// 名前：金霊（太陽）
	// 説明：協力サインの金霊のエスト回復数
	uint8_t WhiteGhost_Umbasa_002;

	// 名前：白バーサーカー
	// 説明：協力サインの白バーサーカーのエスト回復数
	uint8_t WhiteGhost_Berserker_003;

	// 名前：赤サイン
	// 説明：敵対サインの赤霊のエスト回復数
	uint8_t BlackGhost_None_Sign_004;

	// 名前：赤金霊（サイン）
	// 説明：敵対サインの赤金霊のエスト回復数
	uint8_t BlackGhost_Umbasa_Sign_005;

	// 名前：赤バーサーカー（サイン）
	// 説明：敵対サインの赤バーサーカーのエスト回復数
	uint8_t BlackGhost_Berserker_Sign_006;

	// 名前：侵入
	// 説明：侵入のエスト回復数
	uint8_t BlackGhost_None_Invade_007;

	// 名前：赤金霊（侵入）
	// 説明：侵入オーブの赤金霊のエスト回復数
	uint8_t BlackGhost_Umbasa_Invade_008;

	// 名前：赤バーサーカー（侵入）
	// 説明：侵入オーブの赤バーサーカーのエスト回復数
	uint8_t BlackGhost_Berserker_Invade_009;

	// 名前：救援ゲスト
	// 説明：救援ゲストのエスト回復数
	uint8_t RedHunter1_00A;

	// 名前：赤狩り霊２
	// 説明：赤狩り霊２のエスト回復数
	uint8_t RedHunter2_00B;

	// 名前：マップ守護霊(森)
	// 説明：マップ守護霊（森）のエスト回復数
	uint8_t GuardianOfForest_00C;

	// 名前：マップ守護霊(アノール)
	// 説明：マップ守護霊(アノール)のエスト回復数
	uint8_t GuardianOfAnor_00D;

	// 名前：闘技場
	// 説明：闘技場のエスト回復数
	uint8_t BattleRoyal_00E;

	// 名前：黄衣の翁
	// 説明：黄衣の翁のエスト回復数
	uint8_t YellowMonk_00F;

	// 名前：pad
	uint8_t pad1_010[48];

} MultiEstusFlaskBonusParam;

#endif
