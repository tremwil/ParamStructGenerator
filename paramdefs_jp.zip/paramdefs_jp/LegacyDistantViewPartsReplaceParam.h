/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_LegacyDistantViewPartsReplaceParam_H
#define _PARAM_LegacyDistantViewPartsReplaceParam_H
#include <stdint.h>

// LEGACY_DISTANT_VIEW_PARTS_REPLACE_PARAM
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _LegacyDistantViewPartsReplaceParam {

	// 名前：マップID
	// 説明：対象のマップIDを指定します。レガシーのみ。(m12_34_56_78→12345678) 。当初レガシーのみでしたがオープンの天球マップも対応しました
	int32_t TargetMapId_000;

	// 名前：天変地異イベントID
	// 説明：「300、310、311、312」の中から、対象天変地異イベントIDを入力した場合は【天変地異差し替えデータ】となります。0or空白の場合は【地方IDの切り替えデータ】となります(SEQ16039)
	uint32_t TargetEventId_004;

	// 名前：差し替え元アセットID
	// 説明：差し替え元AssetId：AEG123_456_9999→123456
	int32_t SrcAssetId_008;

	// 名前：差し替え元アセットパーツID
	// 説明：差し替え元PartsNo：AEG123_456_9999→9999
	int32_t SrcAssetPartsNo_00C;

	// 名前：差し替え先アセットID
	// 説明：差し替え先AssetId：AEG123_456_9999→123456
	int32_t DstAssetId_010;

	// 名前：差し替え先アセットパーツID
	// 説明：差し替え先PartsNo：AEG123_456_9999→9999
	int32_t DstAssetPartsNo_014;

	// 名前：差し替え元アセットID範囲指定Min
	// 説明：差し替え元アセットID範囲指定Min
	int32_t SrcAssetIdRangeMin_018;

	// 名前：差し替え元アセットID範囲指定Max
	// 説明：差し替え元アセットID範囲指定Max
	int32_t SrcAssetIdRangeMax_01C;

	// 名前：差し替え先アセットID範囲指定Min
	// 説明：差し替え先アセットID範囲指定Min
	int32_t DstAssetIdRangeMin_020;

	// 名前：差し替え先アセットID範囲指定Max
	// 説明：差し替え先アセットID範囲指定Max
	int32_t DstAssetIdRangeMax_024;

	// 名前：地方ID制限0
	// 説明：MapGD地方IDの制限0：「天変地異イベントID」が0の時だけ有効。設定したMapGD地方IDでのみパーツが有効になります(SEQ16039)
	int8_t LimitedMapRegionId0_028;

	// 名前：地方ID制限1
	// 説明：MapGD地方IDの制限1：「天変地異イベントID」が0の時だけ有効。設定したMapGD地方IDでのみパーツが有効になります(SEQ16039)
	int8_t LimitedMapRegionId1_029;

	// 名前：地方ID制限2
	// 説明：MapGD地方IDの制限2：「天変地異イベントID」が0の時だけ有効。設定したMapGD地方IDでのみパーツが有効になります(SEQ16039)
	int8_t LimitedMapRegionId2_02A;

	// 名前：地方ID制限3
	// 説明：MapGD地方IDの制限3：「天変地異イベントID」が0の時だけ有効。設定したMapGD地方IDでのみパーツが有効になります(SEQ16039)
	int8_t LimitedMapRegionId3_02B;

	// 名前：予約
	// 説明：予約
	uint8_t reserve_02C[4];

	// 名前：地方制限アセットID
	// 説明：MapGD地方IDで有効なアセット指定：AssetId：AEG123_456_9999→123456
	int32_t LimitedMapRegionAssetId_030;

	// 名前：地方制限アセットパーツID
	// 説明：MapGD地方IDで有効なアセット指定：PartsNo：AEG123_456_9999→9999
	int32_t LimitedMapRegioAssetPartsNo_034;

	// 名前：地方制限アセットID範囲指定Min
	// 説明：MapGD地方IDで有効なアセット指定：アセットID範囲指定Min
	int32_t LimitedMapRegioAssetIdRangeMin_038;

	// 名前：地方制限アセットID範囲指定Max
	// 説明：MapGD地方IDで有効なアセット指定：アセットID範囲指定Max
	int32_t LimitedMapRegioAssetIdRangeMax_03C;

} LegacyDistantViewPartsReplaceParam;

#endif
