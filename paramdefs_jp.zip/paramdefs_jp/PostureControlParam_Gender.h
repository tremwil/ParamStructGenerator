/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PostureControlParam_Gender_H
#define _PARAM_PostureControlParam_Gender_H
#include <stdint.h>

// POSTURE_CONTROL_PARAM_GENDER_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _PostureControlParam_Gender {

	// 名前：右肘_内外
	// 説明：右肘_内外
	int16_t a000_rightElbowIO_000;

	// 名前：左肘_内外
	// 説明：左肘_内外
	int16_t a000_leftElbowIO_002;

	// 名前：両足_内外
	// 説明：両足_内外
	int16_t a000_bothLegsIO_004;

	// 名前：右肘_内外
	// 説明：右肘_内外
	int16_t a002_rightElbowIO_006;

	// 名前：左肘_内外
	// 説明：左肘_内外
	int16_t a002_leftElbowIO_008;

	// 名前：両足_内外
	// 説明：両足_内外
	int16_t a002_bothLegsIO_00A;

	// 名前：右肘_内外
	// 説明：右肘_内外
	int16_t a003_rightElbowIO_00C;

	// 名前：左肘_内外
	// 説明：左肘_内外
	int16_t a003_leftElbowIO_00E;

	// 名前：両足_内外
	// 説明：両足_内外
	int16_t a003_bothLegsIO_010;

	// 名前：右肘_内外
	// 説明：右肘_内外
	int16_t a010_rightElbowIO_012;

	// 名前：左肘_内外
	// 説明：左肘_内外
	int16_t a010_leftElbowIO_014;

	// 名前：両足_内外
	// 説明：両足_内外
	int16_t a010_bothLegsIO_016;

	// 名前：右肘_内外
	// 説明：右肘_内外
	int16_t a012_rightElbowIO_018;

	// 名前：左肘_内外
	// 説明：左肘_内外
	int16_t a012_leftElbowIO_01A;

	// 名前：両足_内外
	// 説明：両足_内外
	int16_t a012_bothLegsIO_01C;

	// 名前：右肘_内外
	// 説明：右肘_内外
	int16_t a013_rightElbowIO_01E;

	// 名前：左肘_内外
	// 説明：左肘_内外
	int16_t a013_leftElbowIO_020;

	// 名前：両足_内外
	// 説明：両足_内外
	int16_t a013_bothLegsIO_022;

	// 名前：右肘_内外
	// 説明：右肘_内外
	int16_t a014_rightElbowIO_024;

	// 名前：左肘_内外
	// 説明：左肘_内外
	int16_t a014_leftElbowIO_026;

	// 名前：両足_内外
	// 説明：両足_内外
	int16_t a014_bothLegsIO_028;

	// 名前：右肘_内外
	// 説明：右肘_内外
	int16_t a015_rightElbowIO_02A;

	// 名前：左肘_内外
	// 説明：左肘_内外
	int16_t a015_leftElbowIO_02C;

	// 名前：両足_内外
	// 説明：両足_内外
	int16_t a015_bothLegsIO_02E;

	// 名前：右肘_内外
	// 説明：右肘_内外
	int16_t a016_rightElbowIO_030;

	// 名前：左肘_内外
	// 説明：左肘_内外
	int16_t a016_leftElbowIO_032;

	// 名前：両足_内外
	// 説明：両足_内外
	int16_t a016_bothLegsIO_034;

	// 名前：pad
	uint8_t pad_036[10];

} PostureControlParam_Gender;

#endif
