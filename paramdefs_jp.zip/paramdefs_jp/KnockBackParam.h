/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_KnockBackParam_H
#define _PARAM_KnockBackParam_H
#include <stdint.h>

// KNOCKBACK_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _KnockBackParam {

	// 名前：極小ダメージ_速度維持時間[s]
	// 説明：極小ダメージアニメの時に使用される維持時間を設定
	float damage_Min_ContTime_000;

	// 名前：小ダメージ_速度維持時間[s]
	// 説明：小ダメージアニメの時に使用される維持時間を設定
	float damage_S_ContTime_004;

	// 名前：中ダメージ_速度維持時間[s]
	// 説明：中ダメージアニメの時に使用される維持時間を設定
	float damage_M_ContTime_008;

	// 名前：大ダメージ_速度維持時間[s]
	// 説明：大ダメージアニメの時に使用される維持時間を設定
	float damage_L_ContTime_00C;

	// 名前：小吹っ飛び_速度維持時間[s]
	// 説明：小吹っ飛びダメージアニメの時に使用される維持時間を設定
	float damage_BlowS_ContTime_010;

	// 名前：大吹っ飛び_速度維持時間[s]
	// 説明：大吹っ飛びダメージアニメの時に使用される維持時間を設定
	float damage_BlowM_ContTime_014;

	// 名前：叩きつけ_速度維持時間[s]
	// 説明：叩きつけダメージアニメの時に使用される維持時間を設定
	float damage_Strike_ContTime_018;

	// 名前：打ち上げ_速度維持時間[s]
	// 説明：打ち上げダメージアニメの時に使用される維持時間を設定
	float damage_Uppercut_ContTime_01C;

	// 名前：プッシュ_速度維持時間[s]
	// 説明：プッシュダメージアニメの時に使用される維持時間を設定
	float damage_Push_ContTime_020;

	// 名前：ブレス_速度維持時間[s]
	// 説明：ブレスダメージアニメの時に使用される維持時間を設定
	float damage_Breath_ContTime_024;

	// 名前：ヘッドショット_速度維持時間[s]
	// 説明：ヘッドショットダメージアニメの時に使用される維持時間を設定
	float damage_HeadShot_ContTime_028;

	// 名前：ガード受け小_速度維持時間[s]
	// 説明：ガード受け小アニメの時に使用される維持時間を設定
	float guard_S_ContTime_02C;

	// 名前：ガード受け大_速度維持時間[s]
	// 説明：ガード受け大アニメの時に使用される維持時間を設定
	float guard_L_ContTime_030;

	// 名前：ガード受け特大_速度維持時間[s]
	// 説明：ガード受け特大アニメの時に使用される維持時間を設定
	float guard_LL_ContTime_034;

	// 名前：ガードくずされ_速度維持時間[s]
	// 説明：ガードくずされアニメの時に仕様される維持時間を設定
	float guardBrake_ContTime_038;

	// 名前：極小ダメージ_減速時間[s]
	// 説明：極小ダメージアニメの時に使用される減速時間を設定
	float damage_Min_DecTime_03C;

	// 名前：小ダメージ_減速時間[s]
	// 説明：小ダメージアニメの時に使用される減速時間を設定
	float damage_S_DecTime_040;

	// 名前：中ダメージ_減速時間[s]
	// 説明：中ダメージアニメの時に使用される減速時間を設定
	float damage_M_DecTime_044;

	// 名前：大ダメージ_減速時間[s]
	// 説明：大ダメージアニメの時に使用される減速時間を設定
	float damage_L_DecTime_048;

	// 名前：小吹っ飛び_減速時間[s]
	// 説明：小吹っ飛びダメージアニメの時に使用される減速時間を設定
	float damage_BlowS_DecTime_04C;

	// 名前：大吹っ飛び_減速時間[s]
	// 説明：大吹っ飛びダメージアニメの時に使用される減速時間を設定
	float damage_BlowM_DecTime_050;

	// 名前：叩きつけ_減速時間[s]
	// 説明：叩きつけダメージアニメの時に使用される減速時間を設定
	float damage_Strike_DecTime_054;

	// 名前：打ち上げ_減速時間[s]
	// 説明：打ち上げダメージアニメの時に使用される減速時間を設定
	float damage_Uppercut_DecTime_058;

	// 名前：プッシュ_減速時間[s]
	// 説明：プッシュダメージアニメの時に使用される減速時間を設定
	float damage_Push_DecTime_05C;

	// 名前：ブレス_減速時間[s]
	// 説明：ブレスダメージアニメの時に使用される減速時間を設定
	float damage_Breath_DecTime_060;

	// 名前：ヘッドショット_減速時間[s]
	// 説明：ヘッドショットダメージアニメの時に使用される減速時間を設定
	float damage_HeadShot_DecTime_064;

	// 名前：ガード受け小_減速時間[s]
	// 説明：ガード受け小アニメの時に使用される減速時間を設定
	float guard_S_DecTime_068;

	// 名前：ガード受け大_減速時間[s]
	// 説明：ガード受け大アニメの時に使用される減速時間を設定
	float guard_L_DecTime_06C;

	// 名前：ガード受け特大_減速時間[s]
	// 説明：ガード受け特大アニメの時に使用される減速時間を設定
	float guard_LL_DecTime_070;

	// 名前：ガードくずされ_減速時間[s]
	// 説明：ガードくずされアニメの時に仕様される減速時間を設定
	float guardBrake_DecTime_074;

	// 名前：pading
	uint8_t pad_078[8];

} KnockBackParam;

#endif
