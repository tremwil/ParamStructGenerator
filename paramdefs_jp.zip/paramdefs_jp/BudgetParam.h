/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_BudgetParam_H
#define _PARAM_BudgetParam_H
#include <stdint.h>

// BUDGET_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BudgetParam {

	// 名前：VRAM:ALL
	// 説明：VRAM:ALL(単位はMB)
	float vram_all_000;

	// 名前：VRAM:マップ/オブジェ テクスチャ
	// 説明：VRAM:マップ/オブジェ テクスチャ(単位はMB)
	float vram_mapobj_tex_004;

	// 名前：VRAM:マップ/オブジェ モデル
	// 説明：VRAM:マップ/オブジェ モデル(単位はMB)
	float vram_mapobj_mdl_008;

	// 名前：VRAM:マップ
	// 説明：VRAM:マップ(単位はMB)
	float vram_map_00C;

	// 名前：VRAM:キャラ
	// 説明：VRAM:キャラ(単位はMB)
	float vram_chr_010;

	// 名前：VRAM:パーツ
	// 説明：VRAM:パーツ(単位はMB)
	float vram_parts_014;

	// 名前：VRAM:SFX
	// 説明：VRAM:SFX(単位はMB)
	float vram_sfx_018;

	// 名前：VRAM:キャラ テクスチャ
	// 説明：VRAM:キャラ テクスチャ(単位はMB)
	float vram_chr_tex_01C;

	// 名前：VRAM:キャラ モデル
	// 説明：VRAM:キャラ モデル(単位はMB)
	float vram_chr_mdl_020;

	// 名前：VRAM:パーツ テクスチャ
	// 説明：VRAM:パーツ テクスチャ(単位はMB)
	float vram_parts_tex_024;

	// 名前：VRAM:パーツ モデル
	// 説明：VRAM:パーツ モデル(単位はMB)
	float vram_parts_mdl_028;

	// 名前：VRAM:SFX テクスチャ
	// 説明：VRAM:SFX テクスチャ(単位はMB)
	float vram_sfx_tex_02C;

	// 名前：VRAM:SFX モデル
	// 説明：VRAM:SFX モデル(単位はMB)
	float vram_sfx_mdl_030;

	// 名前：VRAM:Gi
	// 説明：VRAM:Gi(単位はMB)
	float vram_gi_034;

	// 名前：VRAM:メニュー
	// 説明：VRAM:メニュー(単位はMB)
	float vram_menu_tex_038;

	// 名前：VRAM:DECAL_RT
	// 説明：VRAM:DECALレンダーターゲット(単位はMB)
	float vram_decal_rt_03C;

	// 名前：VRAM:DECAL
	// 説明：VRAM:DECAL(単位はMB)
	float vram_decal_040;

	// 名前：予約領域
	uint8_t reserve_0_044[4];

	// 名前：VRAM:その他 テクスチャ
	// 説明：VRAM:その他 モデル(単位はMB)
	float vram_other_tex_048;

	// 名前：VRAM:その他 モデル
	// 説明：VRAM:その他 テクスチャ(単位はMB)
	float vram_other_mdl_04C;

	// 名前：HAVOK:アニメ
	// 説明：HAVOK:アニメ(単位はMB)
	float havok_anim_050;

	// 名前：HAVOK:配置
	// 説明：HAVOK:配置(単位はMB)
	float havok_ins_054;

	// 名前：HAVOK:ヒット
	// 説明：HAVOK:ヒット(単位はMB)
	float havok_hit_058;

	// 名前：VRAM:その他
	// 説明：VRAM:その他(単位はMB)
	float vram_other_05C;

	// 名前：VRAM:合算値
	// 説明：VRAM:合算値(単位はMB)
	float vram_detail_all_060;

	// 名前：VRAM:キャラ&パーツ
	// 説明：VRAM:キャラとパーツ合算値(単位はMB)
	float vram_chr_and_parts_064;

	// 名前：HAVOK:ナビメッシュ
	// 説明：HAVOK:ナビメッシュ(単位はMB)
	float havok_navimesh_068;

	// 名前：予約領域
	// 説明：予約領域
	uint8_t reserve_1_06C[24];

} BudgetParam;

#endif
