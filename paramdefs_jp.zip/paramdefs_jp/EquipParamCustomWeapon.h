/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EquipParamCustomWeapon_H
#define _PARAM_EquipParamCustomWeapon_H
#include <stdint.h>

// EQUIP_PARAM_CUSTOM_WEAPON_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EquipParamCustomWeapon {

	// 名前：武器ベースID
	// 説明：武器ベースID
	int32_t baseWepId_000;

	// 名前：魔石ID
	// 説明：魔石ID
	int32_t gemId_004;

	// 名前：強化値
	// 説明：強化値
	uint8_t reinforceLv_008;

	// 名前：pad
	// 説明：pad
	uint8_t pad_009[7];

} EquipParamCustomWeapon;

#endif
