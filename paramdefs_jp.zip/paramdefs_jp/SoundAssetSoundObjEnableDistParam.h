/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SoundAssetSoundObjEnableDistParam_H
#define _PARAM_SoundAssetSoundObjEnableDistParam_H
#include <stdint.h>

// SOUND_ASSET_SOUND_OBJ_ENABLE_DIST_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SoundAssetSoundObjEnableDistParam {

	// 名前：アセットサウンド音源有効距離設定[m]
	// 説明：アセットサウンド音源有効距離[m](0より小さい:無効)
	float SoundObjEnableDist_000;

} SoundAssetSoundObjEnableDistParam;

#endif
