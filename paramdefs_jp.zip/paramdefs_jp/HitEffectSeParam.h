/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_HitEffectSeParam_H
#define _PARAM_HitEffectSeParam_H
#include <stdint.h>

// HIT_EFFECT_SE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _HitEffectSeParam {

	// 名前：鉄製：斬撃：小
	// 説明：鉄製：斬撃：小
	int32_t Iron_Slash_S_000;

	// 名前：鉄製：斬撃：大
	// 説明：鉄製：斬撃：大
	int32_t Iron_Slash_L_004;

	// 名前：鉄製：斬撃：特大
	// 説明：鉄製：斬撃：特大
	int32_t Iron_Slash_LL_008;

	// 名前：鉄製：刺突：小
	// 説明：鉄製：刺突：小
	int32_t Iron_Thrust_S_00C;

	// 名前：鉄製：刺突：大
	// 説明：鉄製：刺突：大
	int32_t Iron_Thrust_L_010;

	// 名前：鉄製：刺突：特大
	// 説明：鉄製：刺突：特大
	int32_t Iron_Thrust_LL_014;

	// 名前：鉄製：打撃：小
	// 説明：鉄製：打撃：小
	int32_t Iron_Blow_S_018;

	// 名前：鉄製：打撃：大
	// 説明：鉄製：打撃：大
	int32_t Iron_Blow_L_01C;

	// 名前：鉄製：打撃：特大
	// 説明：鉄製：打撃：特大
	int32_t Iron_Blow_LL_020;

	// 名前：炎：斬撃：小
	// 説明：炎：斬撃：小
	int32_t Fire_Slash_S_024;

	// 名前：炎：斬撃：大
	// 説明：炎：斬撃：大
	int32_t Fire_Slash_L_028;

	// 名前：炎：斬撃：特大
	// 説明：炎：斬撃：特大
	int32_t Fire_Slash_LL_02C;

	// 名前：炎：刺突：小
	// 説明：炎：刺突：小
	int32_t Fire_Thrust_S_030;

	// 名前：炎：刺突：大
	// 説明：炎：刺突：大
	int32_t Fire_Thrust_L_034;

	// 名前：炎：刺突：特大
	// 説明：炎：刺突：特大
	int32_t Fire_Thrust_LL_038;

	// 名前：炎：打撃：小
	// 説明：炎：打撃：小
	int32_t Fire_Blow_S_03C;

	// 名前：炎：打撃：大
	// 説明：炎：打撃：大
	int32_t Fire_Blow_L_040;

	// 名前：炎：打撃：特大
	// 説明：炎：打撃：特大
	int32_t Fire_Blow_LL_044;

	// 名前：木製：斬撃：小
	// 説明：木製：斬撃：小
	int32_t Wood_Slash_S_048;

	// 名前：木製：斬撃：大
	// 説明：木製：斬撃：大
	int32_t Wood_Slash_L_04C;

	// 名前：木製：斬撃：特大
	// 説明：木製：斬撃：特大
	int32_t Wood_Slash_LL_050;

	// 名前：木製：刺突：小
	// 説明：木製：刺突：小
	int32_t Wood_Thrust_S_054;

	// 名前：木製：刺突：大
	// 説明：木製：刺突：大
	int32_t Wood_Thrust_L_058;

	// 名前：木製：刺突：特大
	// 説明：木製：刺突：特大
	int32_t Wood_Thrust_LL_05C;

	// 名前：木製：打撃：小
	// 説明：木製：打撃：小
	int32_t Wood_Blow_S_060;

	// 名前：木製：打撃：大
	// 説明：木製：打撃：大
	int32_t Wood_Blow_L_064;

	// 名前：木製：打撃：特大
	// 説明：木製：打撃：特大
	int32_t Wood_Blow_LL_068;

	// 名前：肉：斬撃：小
	// 説明：肉：斬撃：小
	int32_t Body_Slash_S_06C;

	// 名前：肉：斬撃：大
	// 説明：肉：斬撃：大
	int32_t Body_Slash_L_070;

	// 名前：肉：斬撃：特大
	// 説明：肉：斬撃：特大
	int32_t Body_Slash_LL_074;

	// 名前：肉：刺突：小
	// 説明：肉：刺突：小
	int32_t Body_Thrust_S_078;

	// 名前：肉：刺突：大
	// 説明：肉：刺突：大
	int32_t Body_Thrust_L_07C;

	// 名前：肉：刺突：特大
	// 説明：肉：刺突：特大
	int32_t Body_Thrust_LL_080;

	// 名前：肉：打撃：小
	// 説明：肉：打撃：小
	int32_t Body_Blow_S_084;

	// 名前：肉：打撃：大
	// 説明：肉：打撃：大
	int32_t Body_Blow_L_088;

	// 名前：肉：打撃：特大
	// 説明：肉：打撃：特大
	int32_t Body_Blow_LL_08C;

	// 名前：蝕：斬撃：小
	// 説明：蝕：斬撃：小
	int32_t Eclipse_Slash_S_090;

	// 名前：蝕：斬撃：大
	// 説明：蝕：斬撃：大
	int32_t Eclipse_Slash_L_094;

	// 名前：蝕：斬撃：特大
	// 説明：蝕：斬撃：特大
	int32_t Eclipse_Slash_LL_098;

	// 名前：蝕：刺突：小
	// 説明：蝕：刺突：小
	int32_t Eclipse_Thrust_S_09C;

	// 名前：蝕：刺突：大
	// 説明：蝕：刺突：大
	int32_t Eclipse_Thrust_L_0A0;

	// 名前：蝕：刺突：特大
	// 説明：蝕：刺突：特大
	int32_t Eclipse_Thrust_LL_0A4;

	// 名前：蝕：打撃：小
	// 説明：蝕：打撃：小
	int32_t Eclipse_Blow_S_0A8;

	// 名前：蝕：打撃：大
	// 説明：蝕：打撃：大
	int32_t Eclipse_Blow_L_0AC;

	// 名前：蝕：打撃：特大
	// 説明：蝕：打撃：特大
	int32_t Eclipse_Blow_LL_0B0;

	// 名前：エネルギー：斬撃：小
	// 説明：エネルギー：斬撃：小
	int32_t Energy_Slash_S_0B4;

	// 名前：エネルギー：斬撃：大
	// 説明：エネルギー：斬撃：大
	int32_t Energy_Slash_L_0B8;

	// 名前：エネルギー：斬撃：特大
	// 説明：エネルギー：斬撃：特大
	int32_t Energy_Slash_LL_0BC;

	// 名前：エネルギー：刺突：小
	// 説明：エネルギー：刺突：小
	int32_t Energy_Thrust_S_0C0;

	// 名前：エネルギー：刺突：大
	// 説明：エネルギー：刺突：大
	int32_t Energy_Thrust_L_0C4;

	// 名前：エネルギー：刺突：特大
	// 説明：エネルギー：刺突：特大
	int32_t Energy_Thrust_LL_0C8;

	// 名前：エネルギー：打撃：小
	// 説明：エネルギー：打撃：小
	int32_t Energy_Blow_S_0CC;

	// 名前：エネルギー：打撃：大
	// 説明：エネルギー：打撃：大
	int32_t Energy_Blow_L_0D0;

	// 名前：エネルギー：打撃：特大
	// 説明：エネルギー：打撃：特大
	int32_t Energy_Blow_LL_0D4;

	// 名前：なし：斬撃：小
	// 説明：なし：斬撃：小
	int32_t None_Slash_S_0D8;

	// 名前：なし：斬撃：大
	// 説明：なし：斬撃：大
	int32_t None_Slash_L_0DC;

	// 名前：なし：斬撃：特大
	// 説明：なし：斬撃：特大
	int32_t None_Slash_LL_0E0;

	// 名前：なし：刺突：小
	// 説明：なし：刺突：小
	int32_t None_Thrust_S_0E4;

	// 名前：なし：刺突：大
	// 説明：なし：刺突：大
	int32_t None_Thrust_L_0E8;

	// 名前：なし：刺突：特大
	// 説明：なし：刺突：特大
	int32_t None_Thrust_LL_0EC;

	// 名前：なし：打撃：小
	// 説明：なし：打撃：小
	int32_t None_Blow_S_0F0;

	// 名前：なし：打撃：大
	// 説明：なし：打撃：大
	int32_t None_Blow_L_0F4;

	// 名前：なし：打撃：特大
	// 説明：なし：打撃：特大
	int32_t None_Blow_LL_0F8;

	// 名前：Dmy1：斬撃：小
	// 説明：Dmy1：斬撃：小
	int32_t Dmy1_Slash_S_0FC;

	// 名前：Dmy1：斬撃：大
	// 説明：Dmy1：斬撃：大
	int32_t Dmy1_Slash_L_100;

	// 名前：Dmy1：斬撃：特大
	// 説明：Dmy1：斬撃：特大
	int32_t Dmy1_Slash_LL_104;

	// 名前：Dmy1：刺突：小
	// 説明：Dmy1：刺突：小
	int32_t Dmy1_Thrust_S_108;

	// 名前：Dmy1：刺突：大
	// 説明：Dmy1：刺突：大
	int32_t Dmy1_Thrust_L_10C;

	// 名前：Dmy1：刺突：特大
	// 説明：Dmy1：刺突：特大
	int32_t Dmy1_Thrust_LL_110;

	// 名前：Dmy1：打撃：小
	// 説明：Dmy1：打撃：小
	int32_t Dmy1_Blow_S_114;

	// 名前：Dmy1：打撃：大
	// 説明：Dmy1：打撃：大
	int32_t Dmy1_Blow_L_118;

	// 名前：Dmy1：打撃：特大
	// 説明：Dmy1：打撃：特大
	int32_t Dmy1_Blow_LL_11C;

	// 名前：Dmy2：斬撃：小
	// 説明：Dmy2：斬撃：小
	int32_t Dmy2_Slash_S_120;

	// 名前：Dmy2：斬撃：大
	// 説明：Dmy2：斬撃：大
	int32_t Dmy2_Slash_L_124;

	// 名前：Dmy2：斬撃：特大
	// 説明：Dmy2：斬撃：特大
	int32_t Dmy2_Slash_LL_128;

	// 名前：Dmy2：刺突：小
	// 説明：Dmy2：刺突：小
	int32_t Dmy2_Thrust_S_12C;

	// 名前：Dmy2：刺突：大
	// 説明：Dmy2：刺突：大
	int32_t Dmy2_Thrust_L_130;

	// 名前：Dmy2：刺突：特大
	// 説明：Dmy2：刺突：特大
	int32_t Dmy2_Thrust_LL_134;

	// 名前：Dmy2：打撃：小
	// 説明：Dmy2：打撃：小
	int32_t Dmy2_Blow_S_138;

	// 名前：Dmy2：打撃：大
	// 説明：Dmy2：打撃：大
	int32_t Dmy2_Blow_L_13C;

	// 名前：Dmy2：打撃：特大
	// 説明：Dmy2：打撃：特大
	int32_t Dmy2_Blow_LL_140;

	// 名前：Dmy3：斬撃：小
	// 説明：Dmy3：斬撃：小
	int32_t Dmy3_Slash_S_144;

	// 名前：Dmy3：斬撃：大
	// 説明：Dmy3：斬撃：大
	int32_t Dmy3_Slash_L_148;

	// 名前：Dmy3：斬撃：特大
	// 説明：Dmy3：斬撃：特大
	int32_t Dmy3_Slash_LL_14C;

	// 名前：Dmy3：刺突：小
	// 説明：Dmy3：刺突：小
	int32_t Dmy3_Thrust_S_150;

	// 名前：Dmy3：刺突：大
	// 説明：Dmy3：刺突：大
	int32_t Dmy3_Thrust_L_154;

	// 名前：Dmy3：刺突：特大
	// 説明：Dmy3：刺突：特大
	int32_t Dmy3_Thrust_LL_158;

	// 名前：Dmy3：打撃：小
	// 説明：Dmy3：打撃：小
	int32_t Dmy3_Blow_S_15C;

	// 名前：Dmy3：打撃：大
	// 説明：Dmy3：打撃：大
	int32_t Dmy3_Blow_L_160;

	// 名前：Dmy3：打撃：特大
	// 説明：Dmy3：打撃：特大
	int32_t Dmy3_Blow_LL_164;

	// 名前：うじ：斬撃：小
	// 説明：うじ：斬撃：小
	int32_t Maggot_Slash_S_168;

	// 名前：うじ：斬撃：大
	// 説明：うじ：斬撃：大
	int32_t Maggot_Slash_L_16C;

	// 名前：うじ：斬撃：特大
	// 説明：うじ：斬撃：特大
	int32_t Maggot_Slash_LL_170;

	// 名前：うじ：刺突：小
	// 説明：うじ：刺突：小
	int32_t Maggot_Thrust_S_174;

	// 名前：うじ：刺突：大
	// 説明：うじ：刺突：大
	int32_t Maggot_Thrust_L_178;

	// 名前：うじ：刺突：特大
	// 説明：うじ：刺突：特大
	int32_t Maggot_Thrust_LL_17C;

	// 名前：うじ：打撃：小
	// 説明：うじ：打撃：小
	int32_t Maggot_Blow_S_180;

	// 名前：うじ：打撃：大
	// 説明：うじ：打撃：大
	int32_t Maggot_Blow_L_184;

	// 名前：うじ：打撃：特大
	// 説明：うじ：打撃：特大
	int32_t Maggot_Blow_LL_188;

	// 名前：蝋：斬撃：小
	// 説明：蝋：斬撃：小
	int32_t Wax_Slash_S_18C;

	// 名前：蝋：斬撃：大
	// 説明：蝋：斬撃：大
	int32_t Wax_Slash_L_190;

	// 名前：蝋：斬撃：特大
	// 説明：蝋：斬撃：特大
	int32_t Wax_Slash_LL_194;

	// 名前：蝋：刺突：小
	// 説明：蝋：刺突：小
	int32_t Wax_Thrust_S_198;

	// 名前：蝋：刺突：大
	// 説明：蝋：刺突：大
	int32_t Wax_Thrust_L_19C;

	// 名前：蝋：刺突：特大
	// 説明：蝋：刺突：特大
	int32_t Wax_Thrust_LL_1A0;

	// 名前：蝋：打撃：小
	// 説明：蝋：打撃：小
	int32_t Wax_Blow_S_1A4;

	// 名前：蝋：打撃：大
	// 説明：蝋：打撃：大
	int32_t Wax_Blow_L_1A8;

	// 名前：蝋：打撃：特大
	// 説明：蝋：打撃：特大
	int32_t Wax_Blow_LL_1AC;

	// 名前：炎上：斬撃：小
	// 説明：炎上：斬撃：小
	int32_t FireFlame_Slash_S_1B0;

	// 名前：炎上：斬撃：大
	// 説明：炎上：斬撃：大
	int32_t FireFlame_Slash_L_1B4;

	// 名前：炎上：斬撃：特大
	// 説明：炎上：斬撃：特大
	int32_t FireFlame_Slash_LL_1B8;

	// 名前：炎上：刺突：小
	// 説明：炎上：刺突：小
	int32_t FireFlame_Thrust_S_1BC;

	// 名前：炎上：刺突：大
	// 説明：炎上：刺突：大
	int32_t FireFlame_Thrust_L_1C0;

	// 名前：炎上：刺突：特大
	// 説明：炎上：刺突：特大
	int32_t FireFlame_Thrust_LL_1C4;

	// 名前：炎上：打撃：小
	// 説明：炎上：打撃：小
	int32_t FireFlame_Blow_S_1C8;

	// 名前：炎上：打撃：大
	// 説明：炎上：打撃：大
	int32_t FireFlame_Blow_L_1CC;

	// 名前：炎上：打撃：特大
	// 説明：炎上：打撃：特大
	int32_t FireFlame_Blow_LL_1D0;

	// 名前：蝕：気体：斬撃：小
	// 説明：蝕：気体：斬撃：小
	int32_t EclipseGas_Slash_S_1D4;

	// 名前：蝕：気体：斬撃：大
	// 説明：蝕：気体：斬撃：大
	int32_t EclipseGas_Slash_L_1D8;

	// 名前：蝕：気体：斬撃：特大
	// 説明：蝕：気体：斬撃：特大
	int32_t EclipseGas_Slash_LL_1DC;

	// 名前：蝕：気体：刺突：小
	// 説明：蝕：気体：刺突：小
	int32_t EclipseGas_Thrust_S_1E0;

	// 名前：蝕：気体：刺突：大
	// 説明：蝕：気体：刺突：大
	int32_t EclipseGas_Thrust_L_1E4;

	// 名前：蝕：気体：刺突：特大
	// 説明：蝕：気体：刺突：特大
	int32_t EclipseGas_Thrust_LL_1E8;

	// 名前：蝕：気体：打撃：小
	// 説明：蝕：気体：打撃：小
	int32_t EclipseGas_Blow_S_1EC;

	// 名前：蝕：気体：打撃：大
	// 説明：蝕：気体：打撃：大
	int32_t EclipseGas_Blow_L_1F0;

	// 名前：蝕：気体：打撃：特大
	// 説明：蝕：気体：打撃：特大
	int32_t EclipseGas_Blow_LL_1F4;

	// 名前：エネルギー（強）：斬撃：小
	// 説明：エネルギー（強）：斬撃：小
	int32_t EnergyStrong_Slash_S_1F8;

	// 名前：エネルギー（強）：斬撃：大
	// 説明：エネルギー（強）：斬撃：大
	int32_t EnergyStrong_Slash_L_1FC;

	// 名前：エネルギー（強）：斬撃：特大
	// 説明：エネルギー（強）：斬撃：特大
	int32_t EnergyStrong_Slash_LL_200;

	// 名前：エネルギー（強）：刺突：小
	// 説明：エネルギー（強）：刺突：小
	int32_t EnergyStrong_Thrust_S_204;

	// 名前：エネルギー（強）：刺突：大
	// 説明：エネルギー（強）：刺突：大
	int32_t EnergyStrong_Thrust_L_208;

	// 名前：エネルギー（強）：刺突：特大
	// 説明：エネルギー（強）：刺突：特大
	int32_t EnergyStrong_Thrust_LL_20C;

	// 名前：エネルギー（強）：打撃：小
	// 説明：エネルギー（強）：打撃：小
	int32_t EnergyStrong_Blow_S_210;

	// 名前：エネルギー（強）：打撃：大
	// 説明：エネルギー（強）：打撃：大
	int32_t EnergyStrong_Blow_L_214;

	// 名前：エネルギー（強）：打撃：特大
	// 説明：エネルギー（強）：打撃：特大
	int32_t EnergyStrong_Blow_LL_218;

	// 名前：予約領域
	// 説明：予約領域
	uint8_t reserve_21C[100];

} HitEffectSeParam;

#endif
