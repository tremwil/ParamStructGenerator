/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_MotionBlurQuality_H
#define _PARAM_Gconfig_MotionBlurQuality_H
#include <stdint.h>

// CS_MOTION_BLUR_QUALITY_DETAIL
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_MotionBlurQuality {

	// 名前：モーションブラー有効
	// 説明：モーションブラー有効
	uint8_t enabled_000;

	// 名前：OMB(オブジェクトモーションブラー)有効
	// 説明：OMB(オブジェクトモーションブラー)有効
	uint8_t ombEnabled_001;

	// 名前：内部で使用するベロシティバッファの解像度を下げる
	// 説明：内部で使用するベロシティバッファの解像度を下げる。高精度ベロシティバッファを使っていない場合は効果ない
	uint8_t forceScaleVelocityBuffer_002;

	// 名前：通常、Reconstructionフィルタで処理されるが、軽い処理にダウングレードする
	// 説明：通常、Reconstructionフィルタで処理されるが、軽い処理にダウングレードする
	uint8_t cheapFilterMode_003;

	// 名前：サンプルカウントにオフセットを与える
	// 説明：サンプルカウントにオフセットを与える※2の倍数に設定して下さい
	int32_t sampleCountBias_004;

	// 名前：再帰ブラー回数にオフセットを与える
	// 説明：再帰ブラー回数にオフセットを与える
	int32_t recurrenceCountBias_008;

	// 名前：ブラー最大長さパラメータに対するスケール値
	// 説明：ブラー最大長さパラメータに対するスケール値
	float blurMaxLengthScale_00C;

} Gconfig_MotionBlurQuality;

#endif
