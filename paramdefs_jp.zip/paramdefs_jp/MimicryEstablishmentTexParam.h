/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MimicryEstablishmentTexParam_H
#define _PARAM_MimicryEstablishmentTexParam_H
#include <stdint.h>

// MIMICRY_ESTABLISHMENT_TEX_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MimicryEstablishmentTexParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：R
	// 説明：変換前の地図画像のカラー情報（R）。RGB値が一致したピクセルとこのパラメータが紐づく
	uint8_t srcR_004;

	// 名前：G
	// 説明：変換前の地図画像のカラー情報（G）。RGB値が一致したピクセルとこのパラメータが紐づく
	uint8_t srcG_005;

	// 名前：B
	// 説明：変換前の地図画像のカラー情報（B）。RGB値が一致したピクセルとこのパラメータが紐づく
	uint8_t srcB_006;

	// 名前：パッド
	// 説明：パッド。一応「画像色情報（A）」用で空けておく
	uint8_t pad1_007[1];

	// 名前：マップ別擬態確率パラメータID
	// 説明：マップ別擬態確率パラメータID(-1:設定なし(デフォルト値))。地域はMapStudioと合わせてある
	int32_t mimicryEstablishmentParamId_008;

	// 名前：パッド2
	uint8_t pad2_00C[4];

} MimicryEstablishmentTexParam;

#endif
