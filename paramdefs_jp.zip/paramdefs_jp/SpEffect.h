/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SpEffect_H
#define _PARAM_SpEffect_H
#include <stdint.h>

// SP_EFFECT_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SpEffect {

	// 名前：アイコンID
	// 説明：アイコンID(-1の時は、アイコン必要なし)
	int32_t iconId_000;

	// 名前：発動条件　残りHP比率[%]
	// 説明：残りHPが、maxHPの何%になったら発動するかを設定
	float conditionHp_004;

	// 名前：効果持続時間　時間[s]
	// 説明：変化持続時間　/-1で永続 /0で瞬間1回限り
	float effectEndurance_008;

	// 名前：発動間隔[s]
	// 説明：何秒間隔で発生するのかを設定
	float motionInterval_00C;

	// 名前：最大HP倍率[%]
	// 説明：最大HPに補正をかける
	float maxHpRate_010;

	// 名前：最大MP倍率[%]
	// 説明：最大MPに補正をかける
	float maxMpRate_014;

	// 名前：最大スタミナ倍率[%]
	// 説明：最大SPに補正をかける
	float maxStaminaRate_018;

	// 名前：防御側：斬撃ダメージ倍率
	// 説明：斬撃ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float slashDamageCutRate_01C;

	// 名前：防御側：打撃ダメージ倍率
	// 説明：打撃ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float blowDamageCutRate_020;

	// 名前：防御側：刺突ダメージ倍率
	// 説明：刺突ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float thrustDamageCutRate_024;

	// 名前：防御側：無属性ダメージ倍率
	// 説明：無属性ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float neutralDamageCutRate_028;

	// 名前：防御側：魔法ダメージ倍率
	// 説明：魔法ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float magicDamageCutRate_02C;

	// 名前：防御側：炎ダメージ倍率
	// 説明：炎ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float fireDamageCutRate_030;

	// 名前：防御側：電撃ダメージ倍率
	// 説明：電撃ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float thunderDamageCutRate_034;

	// 名前：攻撃側：物理ダメージ倍率
	// 説明：物理ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float physicsAttackRate_038;

	// 名前：攻撃側：魔法ダメージ倍率
	// 説明：魔法ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float magicAttackRate_03C;

	// 名前：攻撃側：炎ダメージ倍率
	// 説明：炎ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float fireAttackRate_040;

	// 名前：攻撃側：電撃ダメージ倍率
	// 説明：電撃ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float thunderAttackRate_044;

	// 名前：物理攻撃力倍率
	// 説明：物理攻撃力に設定した数値をかけます
	float physicsAttackPowerRate_048;

	// 名前：魔法攻撃力倍率
	// 説明：魔法攻撃力に設定した数値をかけます
	float magicAttackPowerRate_04C;

	// 名前：炎攻撃力倍率
	// 説明：炎攻撃力に設定した数値をかけます
	float fireAttackPowerRate_050;

	// 名前：電撃攻撃力倍率
	// 説明：電撃攻撃力に設定した数値をかけます
	float thunderAttackPowerRate_054;

	// 名前：物理攻撃力[point]
	// 説明：物理攻撃力に設定した数値を加減算する
	int32_t physicsAttackPower_058;

	// 名前：魔法攻撃力[point]
	// 説明：魔法攻撃力に設定した数値を加減算する
	int32_t magicAttackPower_05C;

	// 名前：炎攻撃力[point]
	// 説明：炎攻撃力に設定した数値を加減算する
	int32_t fireAttackPower_060;

	// 名前：電撃攻撃力[point]
	// 説明：電撃攻撃力に設定した数値を加減算する
	int32_t thunderAttackPower_064;

	// 名前：物理防御力倍率
	// 説明：物理防御力に設定した数値をかけます
	float physicsDiffenceRate_068;

	// 名前：魔法防御力倍率
	// 説明：魔法防御力に設定した数値をかけます
	float magicDiffenceRate_06C;

	// 名前：炎防御力倍率
	// 説明：炎防御力に設定した数値をかけます
	float fireDiffenceRate_070;

	// 名前：電撃防御力倍率
	// 説明：電撃防御力に設定した数値をかけます
	float thunderDiffenceRate_074;

	// 名前：物理防御力[point]
	// 説明：物理防御力に設定した数値を加減算する
	int32_t physicsDiffence_078;

	// 名前：魔法防御力[point]
	// 説明：魔法防御力に設定した数値を加減算する
	int32_t magicDiffence_07C;

	// 名前：炎防御力[point]
	// 説明：炎防御力に設定した数値を加減算する
	int32_t fireDiffence_080;

	// 名前：電撃防御力[point]
	// 説明：電撃防御力に設定した数値を加減算する
	int32_t thunderDiffence_084;

	// 名前：隙ダメージ倍率
	// 説明：隙のときのダメージ倍率を、設定した数値に置き換える（ダメージ側に設定）
	float NoGuardDamageRate_088;

	// 名前：スィートスポット倍率
	// 説明：スィートスポットのダメージ計算を指定した数値に差し替える(急所ダメージ補正) -1.0で無効
	float vitalSpotChangeRate_08C;

	// 名前：ノーマルヒット倍率
	// 説明：ノーマルヒットのダメージ計算を指定した数値に差し替える  -1.0で無効
	float normalSpotChangeRate_090;

	// 名前：LookAt位置オフセット[m]
	// 説明：敵がLookAtする際に目標位置をオフセットする。見られる側のしゃがみや騎乗に設定する
	float lookAtTargetPosOffset_094;

	// 名前：行動ID指定枠
	// 説明：特殊効果から行動IDを使ってダメージを与える場合に指定-1で無効
	int32_t behaviorId_098;

	// 名前：HPダメージ量[%]
	// 説明：一度の発動で最大HPの何%分を減算（または加算）するかを設定
	float changeHpRate_09C;

	// 名前：HPダメージ[point]
	// 説明：一度の発動で何ポイント減算（または加算）するかを設定
	int32_t changeHpPoint_0A0;

	// 名前：MPダメージ量[%]
	// 説明：一度の発動で最大MPの何%分を減算（または加算）するかを設定
	float changeMpRate_0A4;

	// 名前：MPダメージ[point]
	// 説明：一度の発動で何ポイント減算（または加算）するかを設定
	int32_t changeMpPoint_0A8;

	// 名前：MP回復速度変化[point]
	// 説明：回復速度を変化させる。回復計算式の基準回復速度、初期回復速度に加減算する。
	int32_t mpRecoverChangeSpeed_0AC;

	// 名前：スタミナダメージ量[%]
	// 説明：一度の発動で最大スタミナの何%分を減算（または加算）するかを設定
	float changeStaminaRate_0B0;

	// 名前：スタミナダメージ[point]
	// 説明：一度の発動で何ポイント減算（または加算）するかを設定
	int32_t changeStaminaPoint_0B4;

	// 名前：スタミナ回復速度変化[point]
	// 説明：回復速度を変化させる。回復計算式の基準回復速度、初期回復速度に加減算する。
	int32_t staminaRecoverChangeSpeed_0B8;

	// 名前：魔法効果時間変化
	// 説明：効果持続時間に0.1秒以上設定されている魔法のみ、効果持続時間に設定されている時間を加減算する
	float magicEffectTimeChange_0BC;

	// 名前：耐久度変化：内部損耗度[point]
	// 説明：内部損耗度に数値分を加減算する
	int32_t insideDurability_0C0;

	// 名前：耐久度変化：最大損耗度変化[point]
	// 説明：耐久度の内部損耗度の最大値に、設定された数値を加算する
	int32_t maxDurability_0C4;

	// 名前：スタミナ攻撃力倍率
	// 説明：スタミナ攻撃力に、倍率をかける(1.0 1倍 0.5 半分）
	float staminaAttackRate_0C8;

	// 名前：毒耐性攻撃力[point]
	// 説明：ヒットした時に、対象の【毒耐性値】に加算する数値
	int32_t poizonAttackPower_0CC;

	// 名前：疫病耐性攻撃力[point]
	// 説明：ヒットした時に、対象の【疫病耐性値】に加算する数値
	int32_t diseaseAttackPower_0D0;

	// 名前：出血耐性攻撃力[point]
	// 説明：ヒットした時に、対象の【出血耐性値】に加算する数値
	int32_t bloodAttackPower_0D4;

	// 名前：呪耐性攻撃力[point]
	// 説明：ヒットした時に、対象の【呪耐性値】に加算する数値
	int32_t curseAttackPower_0D8;

	// 名前：落下ダメージ倍率
	// 説明：落下時のダメージ計算に倍率をかける
	float fallDamageRate_0DC;

	// 名前：取得ソウル倍率
	// 説明：敵を倒した時の取得ソウル量が、指定倍数分上乗せされる
	float soulRate_0E0;

	// 名前：装備重量変化倍率
	// 説明：最大装備重量に、設定された倍率をかける
	float equipWeightChangeRate_0E4;

	// 名前：所持重量変化倍率
	// 説明：最大所持重量に、設定された倍率をかける
	float allItemWeightChangeRate_0E8;

	// 名前：ソウル加算
	// 説明：所持ソウルに、設定値を加算する
	int32_t soul_0EC;

	// 名前：アニメIDオフセット(無効-1)
	// 説明：アニメIDオフセット(無効-1)
	int32_t animIdOffset_0F0;

	// 名前：所持ソウル率
	// 説明：敵周回効果用。設定されているキャラから外にソウルが出て行く時に適用されます。
	float haveSoulRate_0F4;

	// 名前：ターゲット優先度加算分
	// 説明：マルチプレイ時、敵から優先的にターゲットとして狙われるようになる。プライオリティの加算。０がデフォルト。プラス値でよく狙われるようになる。マイナスは、－１まで。
	float targetPriority_0F8;

	// 名前：見られる方：視覚倍率
	// 説明：見つかりやすさを倍率で補正する
	float sightSearchEnemyRate_0FC;

	// 名前：聞かせる方：AI音半径倍率
	// 説明：発するAI音の大きさを倍率で補正する
	float hearingSearchEnemyRate_100;

	// 名前：グラビティ率
	// 説明：グラビティ率
	float grabityRate_104;

	// 名前：毒耐性変化倍率
	// 説明：毒耐性値に設定された倍率をかける
	float registPoizonChangeRate_108;

	// 名前：疫病耐性変化倍率
	// 説明：疫病耐性値に設定された倍率をかける
	float registDiseaseChangeRate_10C;

	// 名前：出血耐性変化倍率
	// 説明：出血耐性値に設定された倍率をかける
	float registBloodChangeRate_110;

	// 名前：呪耐性変化倍率
	// 説明：呪耐性値に設定された倍率をかける
	float registCurseChangeRate_114;

	// 名前：ソウルスティール係数
	// 説明：NPCがソウルスティールで奪われるHPに対する防御力
	float soulStealRate_118;

	// 名前：防御：寿命係数
	float lifeReductionRate_11C;

	// 名前：HP回復量係数
	// 説明：HPが減るときは、効かない。
	float hpRecoverRate_120;

	// 名前：差し替える特殊効果
	// 説明：寿命が尽きた時に追加される特殊効果ID(-1は無視)
	int32_t replaceSpEffectId_124;

	// 名前：周期発生特殊効果
	// 説明：発動周期毎に発生する特殊効果ID(-1は無視)
	int32_t cycleOccurrenceSpEffectId_128;

	// 名前：攻撃発生特殊効果
	// 説明：攻撃Hit時に発生する特殊効果ID(-1は無視)
	int32_t atkOccurrenceSpEffectId_12C;

	// 名前：ガード時はじき防御力アップ倍率
	// 説明：ガード時のはじき防御力補正値
	float guardDefFlickPowerRate_130;

	// 名前：ガード時スタミナカット倍率
	// 説明：ガード時のスタミナカット率補正値
	float guardStaminaCutRate_134;

	// 名前：視線通過：発動時間[ms]
	// 説明：視線通過：発動時間[ms]（邪眼用）
	int16_t rayCastPassedTime_138;

	// 名前：対サブカテゴリパラメータ変化1
	// 説明：対サブカテゴリパラメータ変化1
	uint8_t magicSubCategoryChange1_13A;

	// 名前：対サブカテゴリパラメータ変化2
	// 説明：対サブカテゴリパラメータ変化2
	uint8_t magicSubCategoryChange2_13B;

	// 名前：弓飛距離補正[％]
	// 説明：武器の飛距離補正に加算される補正値
	int16_t bowDistRate_13C;

	// 名前：特殊効果カテゴリ
	// 説明：特殊効果の上書きなどの挙動を決めるカテゴリ
	uint16_t spCategory_13E;

	// 名前：カテゴリ内優先度
	// 説明：同一カテゴリ内での優先度（低い方が優先）
	uint8_t categoryPriority_140;

	// 名前：保存カテゴリ
	// 説明：特殊効果を保存するカテゴリ
	int8_t saveCategory_141;

	// 名前：魔法登録枠変化　魔法スロット
	// 説明：魔法登録枠を指定数増やすことが出来る
	uint8_t changeMagicSlot_142;

	// 名前：奇跡登録枠変化　奇跡スロット
	// 説明：軌跡登録枠を指定数増やすことが出来る
	uint8_t changeMiracleSlot_143;

	// 名前：人間性ダメージ値
	// 説明：人間性値に与えるダメージ値
	int8_t heroPointDamage_144;

	// 名前：はじき防御力_上書き
	// 説明：はじき防御力を上書きする値を設定
	uint8_t defFlickPower_145;

	// 名前：はじき時ダメージ減衰率[%]_上書き
	// 説明：はじき時のダメージ減衰率を上書きする値を設定
	uint8_t flickDamageCutRate_146;

	// 名前：出血ダメージ補正倍率
	// 説明：状態変化タイプ[出血]のPointダメージ、％ダメージの時のみ使用される補正値
	uint8_t bloodDamageRate_147;

	// 名前：DL_ダメージなし（0）
	// 説明：ダメージLv0を差し替えるタイプを指定
	int8_t dmgLv_None_148;

	// 名前：DL_小（1）
	// 説明：ダメージLv1を差し替えるタイプを指定
	int8_t dmgLv_S_149;

	// 名前：DL_中（2）
	// 説明：ダメージLv2を差し替えるタイプを指定
	int8_t dmgLv_M_14A;

	// 名前：DL_大（3）
	// 説明：ダメージLv3を差し替えるタイプを指定
	int8_t dmgLv_L_14B;

	// 名前：DL_吹っ飛び（4）
	// 説明：ダメージLv4を差し替えるタイプを指定
	int8_t dmgLv_BlowM_14C;

	// 名前：DL_プッシュ（5）
	// 説明：ダメージLv5を差し替えるタイプを指定
	int8_t dmgLv_Push_14D;

	// 名前：DL_叩きつけ（6）
	// 説明：ダメージLv6を差し替えるタイプを指定
	int8_t dmgLv_Strike_14E;

	// 名前：DL_小吹っ飛び（7）
	// 説明：ダメージLv7を差し替えるタイプを指定
	int8_t dmgLv_BlowS_14F;

	// 名前：DL_極小（8）
	// 説明：ダメージLv8を差し替えるタイプを指定
	int8_t dmgLv_Min_150;

	// 名前：DL_打ち上げ（9）
	// 説明：ダメージLv9を差し替えるタイプを指定
	int8_t dmgLv_Uppercut_151;

	// 名前：DL_特大吹っ飛び(10)
	// 説明：ダメージLv10を差し替えるタイプを指定
	int8_t dmgLv_BlowLL_152;

	// 名前：DL_ブレス(11)
	// 説明：ダメージLv11を差し替えるタイプを指定
	int8_t dmgLv_Breath_153;

	// 名前：物理属性
	// 説明：特殊効果に設定する物理属性
	uint8_t atkAttribute_154;

	// 名前：特殊属性
	// 説明：特殊効果に設定する特殊属性
	uint8_t spAttribute_155;

	// 名前：状態変化タイプ
	// 説明：状態変化の判定フラグ
	uint16_t stateInfo_156;

	// 名前：対武器パラメータ変化
	// 説明：どの武器に対して効果を発揮するかを指定する。制限無しの場合は敵も含めた全ての攻撃・防御が対象
	uint8_t wepParamChange_158;

	// 名前：移動タイプ
	// 説明：移動タイプ。移動速度を変更する。
	uint8_t moveType_159;

	// 名前：防御：寿命減少タイプ
	uint16_t lifeReductionType_15A;

	// 名前：投げ条件
	// 説明：投げ条件。投げマスクに影響する。
	uint8_t throwCondition_15C;

	// 名前：行動判定IDに加算する条件値
	// 説明：行動判定ＩＤに値を加算する条件値(Def:-1)
	int8_t addBehaviorJudgeId_condition_15D;

	// 名前：冷気ダメージ補正倍率
	// 説明：状態変化タイプ[冷気]のPointダメージ、％ダメージの時のみ使用される補正値
	uint8_t freezeDamageRate_15E;

	// 名前：効果対象：所属　自分
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetSelf_15F: 1;

	// 名前：効果対象：所属　味方
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetFriend_15F: 1;

	// 名前：効果対象：所属　敵
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetEnemy_15F: 1;

	// 名前：効果対象：操作　PC
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetPlayer_15F: 1;

	// 名前：効果対象：操作　AI
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetAI_15F: 1;

	// 名前：効果対象：状態　生存
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetLive_15F: 1;

	// 名前：効果対象：状態　全ゴースト
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetGhost_15F: 1;

	// 名前：睡眠無効
	// 説明：この効果がかかっていると睡眠にかからなくなる
	uint8_t disableSleep_15F: 1;

	// 名前：発狂無効
	// 説明：この効果がかかっていると発狂にかからなくなる
	uint8_t disableMadness_160: 1;

	// 名前：効果対象：攻撃者に発動
	// 説明：ダメージ後に攻撃者に特殊効果を適用（防御側には入れない）
	uint8_t effectTargetAttacker_160: 1;

	// 名前：発動してなくてもアイコン表示
	// 説明：発動待ちの状態でもアイコンを表示する。
	uint8_t dispIconNonactive_160: 1;

	// 名前：リゲインゲージを発生させるか
	// 説明：リゲインゲージを発生させるか
	uint8_t regainGaugeDamage_160: 1;

	// 名前：魔力補正するか？
	// 説明：魔力補正するか？
	uint8_t bAdjustMagicAblity_160: 1;

	// 名前：信仰補正するか？
	// 説明：信仰補正するか？
	uint8_t bAdjustFaithAblity_160: 1;

	// 名前：周回ボーナス用か？
	// 説明：ゲームクリア周回ボーナス用かどうか。
	uint8_t bGameClearBonus_160: 1;

	// 名前：対魔法パラメータ変化
	// 説明：魔法に対して効果を発揮するかしないかを設定する
	uint8_t magParamChange_160: 1;

	// 名前：対奇跡パラメータ変化
	// 説明：奇跡に対して効果を発揮するかしないかを設定する
	uint8_t miracleParamChange_161: 1;

	// 名前：所持ソウルクリアするか
	// 説明：所持ソウルが0になります。
	uint8_t clearSoul_161: 1;

	// 名前：SOSサイン　判定フラグ
	// 説明：チェックが付いている場合、発動時にSOSサイン要求を発行
	uint8_t requestSOS_161: 1;

	// 名前：ブラックSOSサイン　判定フラグ
	// 説明：チェックが付いている場合、発動時にブラックSOSサイン要求を発行
	uint8_t requestBlackSOS_161: 1;

	// 名前：侵入_Aリクエスト　判定フラグ
	// 説明：チェックが付いている場合、発動時に侵入_Aリクエストを発行
	uint8_t requestForceJoinBlackSOS_161: 1;

	// 名前：キック　判定フラグ
	// 説明：チェックが付いている場合、発動時にキック要求を発行
	uint8_t requestKickSession_161: 1;

	// 名前：退出　判定フラグ
	// 説明：チェックが付いている場合、発動時に退出要求を発行
	uint8_t requestLeaveSession_161: 1;

	// 名前：NPCへの侵入　判定フラグ
	// 説明：チェックが付いている場合、発動時にNPCへの侵入要求を発行
	uint8_t requestNpcInveda_161: 1;

	// 名前：成仏不可　判定フラグ
	// 説明：死体状態になれるかどうか。このチェックが付いていると、死亡状態にならない
	uint8_t noDead_162: 1;

	// 名前：最大HPが増減しても、現在HPは影響しないか？
	// 説明：最大HPが増減しても、現在HPは影響しないか？
	uint8_t bCurrHPIndependeMaxHP_162: 1;

	// 名前：腐食無視
	// 説明：【状態変化タイプ】が【腐食】による【耐久度】減少を無視する
	uint8_t corrosionIgnore_162: 1;

	// 名前：視覚索敵カット無視
	// 説明：視覚索敵無効を無視する
	uint8_t sightSearchCutIgnore_162: 1;

	// 名前：聴覚索敵カット無視
	// 説明：聴覚索敵無効を無視する
	uint8_t hearingSearchCutIgnore_162: 1;

	// 名前：アンチマジック無効
	// 説明：アンチマジック範囲でも魔法を使用できる
	uint8_t antiMagicIgnore_162: 1;

	// 名前：偽ターゲット無効_幻聴系
	// 説明：発生した偽ターゲットに引っかからなくなる
	uint8_t fakeTargetIgnore_162: 1;

	// 名前：偽ターゲット無効_人系
	// 説明：発生した人系の偽ターゲットに引っかからなくなる
	uint8_t fakeTargetIgnoreUndead_162: 1;

	// 名前：偽ターゲット無効_獣系
	// 説明：発生した獣系の偽ターゲットに引っかからなくなる
	uint8_t fakeTargetIgnoreAnimal_163: 1;

	// 名前：グラビティ無効
	// 説明：グラビティ効果無効
	uint8_t grabityIgnore_163: 1;

	// 名前：毒無効
	// 説明：この効果がかかっていると毒にかからなくなる
	uint8_t disablePoison_163: 1;

	// 名前：疫病無効
	// 説明：この効果がかかっていると疫病にかからなくなる
	uint8_t disableDisease_163: 1;

	// 名前：出血無効
	// 説明：この効果がかかっていると出血にかからなくなる
	uint8_t disableBlood_163: 1;

	// 名前：呪無効
	// 説明：この効果がかかっていると呪いにかからなくなる
	uint8_t disableCurse_163: 1;

	// 名前：魅了有効
	// 説明：この効果がかかっていると魅了にかかるようになる
	uint8_t enableCharm_163: 1;

	// 名前：寿命延長するか？
	// 説明：TAEによるフラグ設定時に寿命延長するか？
	uint8_t enableLifeTime_163: 1;

	// 名前：筋力補正するか？
	// 説明：筋力補正するか？
	uint8_t bAdjustStrengthAblity_164: 1;

	// 名前：技量補正するか？
	// 説明：技量補正するか？
	uint8_t bAdjustAgilityAblity_164: 1;

	// 名前：篝火回復で消えるか
	// 説明：篝火回復で消えるか
	uint8_t eraseOnBonfireRecover_164: 1;

	// 名前：対投げパラメータ変化
	// 説明：投げ攻撃に対して効果を発揮するかしないかを設定する
	uint8_t throwAttackParamChange_164: 1;

	// 名前：闘技場退出　判定フラグ
	// 説明：チェックが付いている場合、発動時に闘技場退出要求を発行
	uint8_t requestLeaveColiseumSession_164: 1;

	// 名前：寿命延長効果で延長するか？
	// 説明：寿命延長効果が掛かっている時に延長対象になるかどうか
	uint8_t isExtendSpEffectLife_164: 1;

	// 名前：敵を把握しているか？
	// 説明：敵を把握しているか？：[発動条件](邪眼使用者用)
	uint8_t hasTarget_164: 1;

	// 名前：発動時リプランニングするか？
	// 説明：発動時リプランニングするか
	uint8_t replanningOnFire_164: 1;

	// 名前：誓約0
	// 説明：誓約0
	uint8_t vowType0_165: 1;

	// 名前：誓約1
	// 説明：誓約1
	uint8_t vowType1_165: 1;

	// 名前：誓約2
	// 説明：誓約2
	uint8_t vowType2_165: 1;

	// 名前：誓約3
	// 説明：誓約3
	uint8_t vowType3_165: 1;

	// 名前：誓約4
	// 説明：誓約4
	uint8_t vowType4_165: 1;

	// 名前：誓約5
	// 説明：誓約5
	uint8_t vowType5_165: 1;

	// 名前：誓約6
	// 説明：誓約6
	uint8_t vowType6_165: 1;

	// 名前：誓約7
	// 説明：誓約7
	uint8_t vowType7_165: 1;

	// 名前：誓約8
	// 説明：誓約8
	uint8_t vowType8_166: 1;

	// 名前：誓約9
	// 説明：誓約9
	uint8_t vowType9_166: 1;

	// 名前：誓約10
	// 説明：誓約10
	uint8_t vowType10_166: 1;

	// 名前：誓約11
	// 説明：誓約11
	uint8_t vowType11_166: 1;

	// 名前：誓約12
	// 説明：誓約12
	uint8_t vowType12_166: 1;

	// 名前：誓約13
	// 説明：誓約13
	uint8_t vowType13_166: 1;

	// 名前：誓約14
	// 説明：誓約14
	uint8_t vowType14_166: 1;

	// 名前：誓約15
	// 説明：誓約15
	uint8_t vowType15_166: 1;

	// 名前：攻撃側ダメージレベル差し替え
	// 説明：攻撃側のダメージレベルがこの値に指し換わる
	int8_t repAtkDmgLv_167;

	// 名前：見る方：視覚倍率
	// 説明：見つけやすさを倍率で補正する
	float sightSearchRate_168;

	// 名前：効果対象：●敵対
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetOpposeTarget_16C: 1;

	// 名前：効果対象：○味方
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetFriendlyTarget_16C: 1;

	// 名前：効果対象：自分
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetSelfTarget_16C: 1;

	// 名前：効果対象：PC馬
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetPcHorse_16C: 1;

	// 名前：効果対象：PC亡者のみ
	// 説明：この判定にチェックが入っている対象のみ効果を発揮する、デフォルトは×
	uint8_t effectTargetPcDeceased_16C: 1;

	// 名前：寿命短縮効果で短縮するか？
	// 説明：寿命短縮効果が掛かっている時に短縮対象になるかどうか
	uint8_t isContractSpEffectLife_16C: 1;

	// 名前：待ち状態に入ると削除
	// 説明：待ち状態になった瞬間に削除するか？
	uint8_t isWaitModeDelete_16C: 1;

	// 名前：無敵時でも発動するか
	// 説明：状態変化タイプ「無敵時でも発動機能を適応」が掛かっているときのみ、無敵状態でもこの特殊効果からのダメージを適応するか
	uint8_t isIgnoreNoDamage_16C: 1;

	// 名前：チームタイプ変更
	// 説明：指定したチームタイプに上書きする
	int8_t changeTeamType_16D;

	// 名前：ダミポリID
	// 説明：ダミポリID。ダミポリID範囲は0～999.1000,10000の位はカテゴリ番号.
	int16_t dmypolyId_16E;

	// 名前：特殊効果VfxId_０
	// 説明：特殊効果VfxId(-1無効)
	int32_t vfxId_170;

	// 名前：元気玉上限時発動特殊効果Id
	// 説明：元気玉上限時発動特殊効果Id
	int32_t accumuOverFireId_174;

	// 名前：元気玉上限値
	// 説明：元気玉上限値
	int32_t accumuOverVal_178;

	// 名前：元気玉下限時発動特殊効果Id
	// 説明：元気玉下限時発動特殊効果Id
	int32_t accumuUnderFireId_17C;

	// 名前：元気玉下限値
	// 説明：元気玉下限値
	int32_t accumuUnderVal_180;

	// 名前：元気玉蓄積値
	// 説明：元気玉蓄積値
	int32_t accumuVal_184;

	// 名前：見る方：視覚角度（高さ）上書き[deg]
	// 説明：見つけやすさの角度を上書きする
	uint8_t eye_angX_188;

	// 名前：見る方：視覚角度（幅）上書き[deg]
	// 説明：見つけやすさの角度を上書きする
	uint8_t eye_angY_189;

	// 名前：亡者度 変更
	// 説明：この値分亡者度を加算する
	int16_t addDeceasedLv_18A;

	// 名前：特殊効果VfxId_１
	// 説明：特殊効果VfxId１(-1無効)
	int32_t vfxId1_18C;

	// 名前：特殊効果VfxId_２
	// 説明：特殊効果VfxId２(-1無効)
	int32_t vfxId2_190;

	// 名前：特殊効果VfxId_３
	// 説明：特殊効果VfxId３(-1無効)
	int32_t vfxId3_194;

	// 名前：特殊効果VfxId_４
	// 説明：特殊効果VfxId４(-1無効)
	int32_t vfxId4_198;

	// 名前：特殊効果VfxId_５
	// 説明：特殊効果VfxId５(-1無効)
	int32_t vfxId5_19C;

	// 名前：特殊効果VfxId_６
	// 説明：特殊効果VfxId６(-1無効)
	int32_t vfxId6_1A0;

	// 名前：特殊効果VfxId_７
	// 説明：特殊効果VfxId７(-1無効)
	int32_t vfxId7_1A4;

	// 名前：冷気耐性攻撃力[point]
	// 説明：ヒットした時に、対象の【冷気耐性値】に加算する数値
	int32_t freezeAttackPower_1A8;

	// 名前：発生AI音ID
	// 説明：設定された値のAI音パラメータを発生させる
	int32_t AppearAiSoundId_1AC;

	// 名前：追加フットエフェクト識別子
	// 説明：特殊効果時に追加で発生させるフットエフェクトの識別子。XYYZZZのZZZ
	int16_t addFootEffectSfxId_1B0;

	// 名前：技量キャンセル用仮想ステータス
	// 説明：「技量キャンセル」のTAEフラグの終了タイミングを計算する時に、この値を追加して計算する
	int8_t dexterityCancelSystemOnlyAddDexterity_1B2;

	// 名前：チーム攻撃影響力_上書き
	// 説明：対象の【チーム攻撃影響力】の値を、上書きして変更する。デフォルト値（-1）のときは変更しない。
	int8_t teamOffenseEffectivity_1B3;

	// 名前：強靭度 被ダメージ倍率
	// 説明：強靭度版カット率
	float toughnessDamageCutRate_1B4;

	// 名前：特攻Aダメージ倍率補正
	// 説明：特攻Aダメージ倍率に補正をかけます。１が通常。
	float weakDmgRateA_1B8;

	// 名前：特攻Bダメージ倍率補正
	// 説明：特攻Bダメージ倍率に補正をかけます。１が通常。
	float weakDmgRateB_1BC;

	// 名前：特攻Cダメージ倍率補正
	// 説明：特攻Cダメージ倍率に補正をかけます。１が通常。
	float weakDmgRateC_1C0;

	// 名前：特攻Dダメージ倍率補正
	// 説明：特攻Dダメージ倍率に補正をかけます。１が通常。
	float weakDmgRateD_1C4;

	// 名前：特攻Eダメージ倍率補正
	// 説明：特攻Eダメージ倍率に補正をかけます。１が通常。
	float weakDmgRateE_1C8;

	// 名前：特攻Fダメージ倍率補正
	// 説明：特攻Fダメージ倍率に補正をかけます。１が通常。
	float weakDmgRateF_1CC;

	// 名前：防御側：闇ダメージ倍率
	// 説明：闇ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float darkDamageCutRate_1D0;

	// 名前：闇防御力倍率
	// 説明：闇防御力に設定した数値をかけます
	float darkDiffenceRate_1D4;

	// 名前：闇防御力[point]
	// 説明：闇防御力に設定した数値を加減算する
	int32_t darkDiffence_1D8;

	// 名前：攻撃側：闇ダメージ倍率
	// 説明：闇ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float darkAttackRate_1DC;

	// 名前：闇攻撃力倍率
	// 説明：闇攻撃力に設定した数値をかけます
	float darkAttackPowerRate_1E0;

	// 名前：闇攻撃力[point]
	// 説明：闇攻撃力に設定した数値を加減算する
	int32_t darkAttackPower_1E4;

	// 名前：暗闇丸見え半径[m]
	// 説明：暗闇丸見え半径[m]。この距離内にいる場合は暗所でも通常距離で見えるようになります
	float antiDarkSightRadius_1E8;

	// 名前：暗闇丸見えダミポリID
	// 説明：暗闇丸見えダミポリID(-1:マスター)。このダミポリを中心に丸見え領域を作成します
	int32_t antiDarkSightDmypolyId_1EC;

	// 名前：発動条件　残りHP比率が一定以上[%]
	// 説明：指定された値以上のHPを持っている時にしか発動しない
	float conditionHpRate_1F0;

	// 名前：消費スタミナ倍率
	// 説明：行動パラメータの消費スタミナの値にかける倍率
	float consumeStaminaRate_1F4;

	// 名前：アイテムドロップ補正
	// 説明：設定された値が【アイテムドロップ補正】に加算される 
	float itemDropRate_1F8;

	// 名前：毒耐性変化[point]
	// 説明：状態耐性値を増減させる
	int32_t changePoisonResistPoint_1FC;

	// 名前：疫病耐性変化[point]
	// 説明：状態耐性値を増減させる
	int32_t changeDiseaseResistPoint_200;

	// 名前：出血耐性変化[point]
	// 説明：状態耐性値を増減させる
	int32_t changeBloodResistPoint_204;

	// 名前：呪耐性変化[point]
	// 説明：状態耐性値を増減させる
	int32_t changeCurseResistPoint_208;

	// 名前：冷気耐性変化[point]
	// 説明：状態耐性値を増減させる
	int32_t changeFreezeResistPoint_20C;

	// 名前：攻撃側：斬撃ダメージ倍率
	// 説明：斬撃ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float slashAttackRate_210;

	// 名前：攻撃側：打撃ダメージ倍率
	// 説明：打撃ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float blowAttackRate_214;

	// 名前：攻撃側：刺突ダメージ倍率
	// 説明：刺突ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float thrustAttackRate_218;

	// 名前：攻撃側：無属性ダメージ倍率
	// 説明：無属性ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float neutralAttackRate_21C;

	// 名前：斬撃攻撃力倍率
	// 説明：斬撃攻撃力に設定した数値をかけます
	float slashAttackPowerRate_220;

	// 名前：打撃攻撃力倍率
	// 説明：打撃攻撃力に設定した数値をかけます
	float blowAttackPowerRate_224;

	// 名前：刺突攻撃力倍率
	// 説明：刺突攻撃力に設定した数値をかけます
	float thrustAttackPowerRate_228;

	// 名前：無属性攻撃力倍率
	// 説明：無属性攻撃力に設定した数値をかけます
	float neutralAttackPowerRate_22C;

	// 名前：斬撃攻撃力[point]
	// 説明：斬撃攻撃力に設定した数値を加減算する
	int32_t slashAttackPower_230;

	// 名前：打撃攻撃力[point]
	// 説明：打撃攻撃力に設定した数値を加減算する
	int32_t blowAttackPower_234;

	// 名前：刺突攻撃力[point]
	// 説明：刺突攻撃力に設定した数値を加減算する
	int32_t thrustAttackPower_238;

	// 名前：無属性攻撃力[point]
	// 説明：無属性攻撃力に設定した数値を加減算する
	int32_t neutralAttackPower_23C;

	// 名前：筋力補正変化[point]
	// 説明：武器の補正値を加減算する
	int32_t changeStrengthPoint_240;

	// 名前：俊敏補正変化[point]
	// 説明：武器の補正値を加減算する
	int32_t changeAgilityPoint_244;

	// 名前：魔力補正変化[point]
	// 説明：武器の補正値を加減算する
	int32_t changeMagicPoint_248;

	// 名前：信仰補正変化[point]
	// 説明：武器の補正値を加減算する
	int32_t changeFaithPoint_24C;

	// 名前：運補正変化[point]
	// 説明：武器の補正値を加減算する
	int32_t changeLuckPoint_250;

	// 名前：アーツポイント回復 筋力系
	// 説明：アーツポイント筋力を回復させる
	int8_t recoverArtsPoint_Str_254;

	// 名前：アーツポイント回復 技量系
	// 説明：アーツポイント技量を回復させる
	int8_t recoverArtsPoint_Dex_255;

	// 名前：アーツポイント回復 魔法系
	// 説明：アーツポイント魔法を回復させる
	int8_t recoverArtsPoint_Magic_256;

	// 名前：アーツポイント回復 奇跡系
	// 説明：アーツポイント奇跡を回復させる
	int8_t recoverArtsPoint_Miracle_257;

	// 名前：発狂ダメージ補正倍率
	// 説明：状態変化タイプ[発狂]のPointダメージ、％ダメージの時のみ使用される補正値
	uint8_t madnessDamageRate_258;

	// 名前：状態異常攻撃力倍率補正を適応するか
	// 説明：○なら攻撃パラの状態異常攻撃力倍率補正を適応します。
	uint8_t isUseStatusAilmentAtkPowerCorrect_259: 1;

	// 名前：攻撃パラメータの攻撃力倍率補正を適応するか
	// 説明：○なら攻撃パラの攻撃力倍率補正を適応します。
	uint8_t isUseAtkParamAtkPowerCorrect_259: 1;

	// 名前：死亡時に削除しない
	// 説明：○ならキャラが死亡しても削除しません。主に死亡エフェクトに使います。
	uint8_t dontDeleteOnDead_259: 1;

	// 名前：冷気無効
	// 説明：この効果がかかっていると冷気にかからなくなる
	uint8_t disableFreeze_259: 1;

	// 名前：ネット同期しない
	// 説明：ネット同期しない。ローカルに掛けるようになる、という意味ではなく、単にネット送信しない。例えばリモートキャラはローカル発動しないので、その場合何も起こらない。
	uint8_t isDisableNetSync_259: 1;

	// 名前：対呪術パラメータ変化
	// 説明：呪術に対して効果を発揮するかしないかを設定する
	uint8_t shamanParamChange_259: 1;

	// 名前：被索敵状態の通知停止
	// 説明：自軍をターゲットしている通知を停止するかどうか(EventMakerでの判定やバディ小隊で使用)
	uint8_t isStopSearchedNotify_259: 1;

	// 名前：雨遮蔽外の時のみかかる
	// 説明：○なら遮蔽判定されているときは掛からない（×は常に掛かる）
	uint8_t isCheckAboveShadowTest_259: 1;

	// 名前：行動判定IDに加算する加算値
	// 説明：行動判定IDの加算値 ０の場合は行動を切り替えるのではなく、行動しなくなります。
	uint16_t addBehaviorJudgeId_add_25A;

	// 名前：SA値_被ダメージ倍率
	// 説明：SAダメージかかる倍率
	float saReceiveDamageRate_25C;

	// 名前：防御側 プレイヤー 物理ダメージ補正倍率
	// 説明：プレイヤーから受けるダメージ値に対するダメージ補正。
	float defPlayerDmgCorrectRate_Physics_260;

	// 名前：防御側 プレイヤー 魔法ダメージ補正倍率
	// 説明：プレイヤーから受けるダメージ値に対するダメージ補正。
	float defPlayerDmgCorrectRate_Magic_264;

	// 名前：防御側 プレイヤー 炎ダメージ補正倍率
	// 説明：プレイヤーから受けるダメージ値に対するダメージ補正。
	float defPlayerDmgCorrectRate_Fire_268;

	// 名前：防御側 プレイヤー 雷ダメージ補正倍率
	// 説明：プレイヤーから受けるダメージ値に対するダメージ補正。
	float defPlayerDmgCorrectRate_Thunder_26C;

	// 名前：防御側 プレイヤー 闇ダメージ補正倍率
	// 説明：プレイヤーから受けるダメージ値に対するダメージ補正。
	float defPlayerDmgCorrectRate_Dark_270;

	// 名前：防御側 敵 物理ダメージ補正倍率
	// 説明：敵から受けるダメージ値に対するダメージ補正。
	float defEnemyDmgCorrectRate_Physics_274;

	// 名前：防御側 敵 魔法ダメージ補正倍率
	// 説明：敵から受けるダメージ値に対するダメージ補正。
	float defEnemyDmgCorrectRate_Magic_278;

	// 名前：防御側 敵 炎ダメージ補正倍率
	// 説明：敵から受けるダメージ値に対するダメージ補正。
	float defEnemyDmgCorrectRate_Fire_27C;

	// 名前：防御側 敵 雷ダメージ補正倍率
	// 説明：敵から受けるダメージ値に対するダメージ補正。
	float defEnemyDmgCorrectRate_Thunder_280;

	// 名前：防御側 敵 闇ダメージ補正倍率
	// 説明：敵から受けるダメージ値に対するダメージ補正。
	float defEnemyDmgCorrectRate_Dark_284;

	// 名前：防御側 オブジェクトダメージ補正倍率
	// 説明：OBJから受けるダメージ値に対するダメージ補正。
	float defObjDmgCorrectRate_288;

	// 名前：攻撃側 プレイヤー 物理ダメージ補正倍率
	// 説明：プレイヤーに与えるダメージ値に対するダメージ補正。
	float atkPlayerDmgCorrectRate_Physics_28C;

	// 名前：攻撃側 プレイヤー 魔法ダメージ補正倍率
	// 説明：プレイヤーに与えるダメージ値に対するダメージ補正。
	float atkPlayerDmgCorrectRate_Magic_290;

	// 名前：攻撃側 プレイヤー 炎ダメージ補正倍率
	// 説明：プレイヤーに与えるダメージ値に対するダメージ補正。
	float atkPlayerDmgCorrectRate_Fire_294;

	// 名前：攻撃側 プレイヤー 雷ダメージ補正倍率
	// 説明：プレイヤーに与えるダメージ値に対するダメージ補正。
	float atkPlayerDmgCorrectRate_Thunder_298;

	// 名前：攻撃側 プレイヤー 闇ダメージ補正倍率
	// 説明：プレイヤーに与えるダメージ値に対するダメージ補正。
	float atkPlayerDmgCorrectRate_Dark_29C;

	// 名前：攻撃側 敵 物理ダメージ補正倍率
	// 説明：敵に与えるダメージ値に対するダメージ補正。
	float atkEnemyDmgCorrectRate_Physics_2A0;

	// 名前：攻撃側 敵 魔法ダメージ補正倍率
	// 説明：敵に与えるダメージ値に対するダメージ補正。
	float atkEnemyDmgCorrectRate_Magic_2A4;

	// 名前：攻撃側 敵 炎ダメージ補正倍率
	// 説明：敵に与えるダメージ値に対するダメージ補正。
	float atkEnemyDmgCorrectRate_Fire_2A8;

	// 名前：攻撃側 敵 雷ダメージ補正倍率
	// 説明：敵に与えるダメージ値に対するダメージ補正。
	float atkEnemyDmgCorrectRate_Thunder_2AC;

	// 名前：攻撃側 敵 闇ダメージ補正倍率
	// 説明：敵に与えるダメージ値に対するダメージ補正。
	float atkEnemyDmgCorrectRate_Dark_2B0;

	// 名前：冷気耐性変化倍率
	// 説明：冷気耐性値に設定された倍率をかける
	float registFreezeChangeRate_2B4;

	// 名前：発動条件状態変化タイプ1
	// 説明：発動条件状態変化タイプ1
	uint16_t invocationConditionsStateChange1_2B8;

	// 名前：発動条件状態変化タイプ2
	// 説明：発動条件状態変化タイプ2
	uint16_t invocationConditionsStateChange2_2BA;

	// 名前：発動条件状態変化タイプ3
	// 説明：発動条件状態変化タイプ3
	uint16_t invocationConditionsStateChange3_2BC;

	// 名前：聞く方：可聴AI音レベル上書き
	// 説明：どれくらい耳が良いのかを上書きする
	int16_t hearingAiSoundLevel_2BE;

	// 名前：カプセルサイズ倍率
	// 説明：キャラカプセルの高さに掛かる倍率
	float chrProxyHeightRate_2C0;

	// 名前：索敵度加算補正_見る側
	// 説明：索敵度加算補正_見る側
	float addAwarePointCorrectValue_forMe_2C4;

	// 名前：索敵度加算補正_見られる側
	// 説明：索敵度加算補正_見られる側
	float addAwarePointCorrectValue_forTarget_2C8;

	// 名前：見られる方：視覚加算
	// 説明：見つかりやすさを実数で補正する
	float sightSearchEnemyAdd_2CC;

	// 名前：見る方：視覚加算
	// 説明：見つけやすさを実数で補正する
	float sightSearchAdd_2D0;

	// 名前：聞く方：AI音半径加算
	// 説明：AI音の聞こえ具合を実数で補正する
	float hearingSearchAdd_2D4;

	// 名前：聞く方：AI音半径倍率
	// 説明：AI音の聞こえ具合を倍率で補正する
	float hearingSearchRate_2D8;

	// 名前：聞かせる方：AI音半径加算
	// 説明：発するAI音の大きさを実数で補正する
	float hearingSearchEnemyAdd_2DC;

	// 名前：販売価格補正：倍率
	// 説明：販売価格補正：倍率
	float value_Magnification_2E0;

	// 名前：アーツ消費MP倍率
	// 説明：アーツ消費MP倍率[%]
	float artsConsumptionRate_2E4;

	// 名前：魔法消費MP倍率
	// 説明：魔法消費MP倍率[%]
	float magicConsumptionRate_2E8;

	// 名前：呪術消費MP倍率
	// 説明：呪術消費MP倍率[%]
	float shamanConsumptionRate_2EC;

	// 名前：奇跡消費MP倍率
	// 説明：奇跡消費MP倍率[%]
	float miracleConsumptionRate_2F0;

	// 名前：エスト瓶HPダメージ量[%]
	// 説明：一度の発動で最大HPの何%分を加算（または減算）するかを設定
	int32_t changeHpEstusFlaskRate_2F4;

	// 名前：エスト瓶HPダメージ量[point]
	// 説明：一度の発動で何ポイント加算（または減算）するかを設定
	int32_t changeHpEstusFlaskPoint_2F8;

	// 名前：エスト瓶MPダメージ量[%] 
	// 説明：一度の発動で最大MPの何%分を加算（または減算）するかを設定
	int32_t changeMpEstusFlaskRate_2FC;

	// 名前：エスト瓶MPダメージ量[point] 
	// 説明：一度の発動で何ポイント加算（または減算）するかを設定
	int32_t changeMpEstusFlaskPoint_300;

	// 名前：エスト瓶HPダメージ倍率 
	// 説明：HPエスト瓶のダメージ量に対して補正をかける
	float changeHpEstusFlaskCorrectRate_304;

	// 名前：エスト瓶MPダメージ倍率 
	// 説明：MPエスト瓶のダメージ量に対して補正をかける
	float changeMpEstusFlaskCorrectRate_308;

	// 名前：HPドレイン発動特殊効果
	// 説明：状態変化タイプ「HPドレイン」の特殊効果が有効の時に、敵を倒した際に同じ特殊効果の「HPドレイン発動特殊効果」に設定されている特殊効果IDを呼び出す(0：無視)
	int32_t applyIdOnGetSoul_30C;

	// 名前：寿命延長倍率
	// 説明：状態変化タイプ「寿命延長」の延長係数
	float extendLifeRate_310;

	// 名前：寿命短縮倍率
	// 説明：状態変化タイプ「寿命短縮」の短縮係数
	float contractLifeRate_314;

	// 名前：被ダメージ オブジェクト攻撃力倍率
	// 説明：OBJから受けるダメージに対して攻撃力を補正する。（ダメージ補正ではない）
	float defObjectAttackPowerRate_318;

	// 名前：特殊効果消失時にキャラのペイントデカールを削除するグループID
	// 説明：特殊効果が消失した時（寿命/何かに上書きされる/消される…など）に、同じグループIDの特殊効果がかかっていなければペイントデカールを削除する。
	int16_t effectEndDeleteDecalGroupId_31C;

	// 名前：生命力追加値
	// 説明：成長ステータスに値を加える
	int8_t addLifeForceStatus_31E;

	// 名前：精神力追加値
	// 説明：成長ステータスに値を加える
	int8_t addWillpowerStatus_31F;

	// 名前：持久力追加値
	// 説明：成長ステータスに値を加える
	int8_t addEndureStatus_320;

	// 名前：体力追加値
	// 説明：成長ステータスに値を加える
	int8_t addVitalityStatus_321;

	// 名前：筋力追加値
	// 説明：成長ステータスに値を加える
	int8_t addStrengthStatus_322;

	// 名前：技量追加値
	// 説明：成長ステータスに値を加える
	int8_t addDexterityStatus_323;

	// 名前：理力追加値
	// 説明：成長ステータスに値を加える
	int8_t addMagicStatus_324;

	// 名前：信仰追加値
	// 説明：成長ステータスに値を加える
	int8_t addFaithStatus_325;

	// 名前：運追加値
	// 説明：成長ステータスに値を加える
	int8_t addLuckStatus_326;

	// 名前：削除条件ダメージ
	// 説明：特殊効果を削除する条件のダメージ理由
	uint8_t deleteCriteriaDamage_327;

	// 名前：対サブカテゴリパラメータ変化3
	// 説明：対サブカテゴリパラメータ変化3
	uint8_t magicSubCategoryChange3_328;

	// 名前：特殊属性バリエーション値
	// 説明：特殊効果に設定する特殊属性と組み合わせて状態異常SFX,SEなどにバリエーションを持たせるために使用する値です。SEQ16473
	uint8_t spAttributeVariationValue_329;

	// 名前：はじき攻撃力_上書き
	// 説明：はじき攻撃力を上書きする値を設定
	uint8_t atkFlickPower_32A;

	// 名前：濡れる条件の水位設定
	// 説明：TimeAct「どの水位で濡れるか」と組み合わせて特殊効果に掛かるかどうかを判定する
	uint8_t wetConditionDepth_32B;

	// 名前：SA回復速度変化
	// 説明：SA耐久度の回復速度を変化させる
	float changeSaRecoveryVelocity_32C;

	// 名前：リゲイン倍率
	// 説明：リゲイン倍率
	float regainRate_330;

	// 名前：SA攻撃力倍率
	// 説明：SA攻撃力倍率
	float saAttackPowerRate_334;

	// 名前：睡眠耐性攻撃力[point]
	// 説明：ヒットした時に、対象の【睡眠耐性値】に加算する数値
	int32_t sleepAttackPower_338;

	// 名前：発狂耐性攻撃力[point]
	// 説明：ヒットした時に、対象の【発狂耐性値】に加算する数値
	int32_t madnessAttackPower_33C;

	// 名前：睡眠耐性変化倍率
	// 説明：睡眠耐性値に設定された倍率をかける
	float registSleepChangeRate_340;

	// 名前：発狂耐性変化倍率
	// 説明：発狂耐性値に設定された倍率をかける
	float registMadnessChangeRate_344;

	// 名前：睡眠耐性変化[point]
	// 説明：状態耐性値を増減させる
	int32_t changeSleepResistPoint_348;

	// 名前：発狂耐性変化[point]
	// 説明：状態耐性値を増減させる
	int32_t changeMadnessResistPoint_34C;

	// 名前：睡眠ダメージ補正倍率
	// 説明：状態変化タイプ[睡眠]のPointダメージ、％ダメージの時のみ使用される補正値
	uint8_t sleepDamageRate_350;

	// 名前：対部位パラメータ変化
	// 説明：攻撃がヒットした部位によって効果を制限する。ダメージ計算の防御系の項目のみ制限対象となる
	uint8_t applyPartsGroup_351;

	// 名前：ターゲットクリア
	// 説明：特殊効果が掛かっている間ターゲットを認識しない（騎乗ターゲット除く
	uint8_t clearTarget_352: 1;

	// 名前：偽ターゲット無効_亜人系
	// 説明：発生した亜人系の偽ターゲットに引っかからなくなる
	uint8_t fakeTargetIgnoreAjin_352: 1;

	// 名前：偽ターゲット無効_幻影アーツ系
	// 説明：発生した幻影アーツ系の偽ターゲットに引っかからなくなる
	uint8_t fakeTargetIgnoreMirageArts_352: 1;

	// 名前：侵入_Bリクエスト　判定フラグ
	// 説明：チェックが付いている場合、発動時に侵入_Bリクエストを発行
	uint8_t requestForceJoinBlackSOS_B_352: 1;

	// 名前：unk353_4
	uint8_t unk353_4_352: 1;

	// 名前：pad
	uint8_t pad2_352[1];

	// 名前：最大SA加算値[point]
	// 説明：スーパーアーマー値に加算する値
	float changeSuperArmorPoint_353;

	// 名前：SAダメージ量[point]
	// 説明：一度の発動で何ポイント減算（または加算）するかを設定
	float changeSaPoint_357;

	// 名前：巨大敵持ち上げ高さ上書き[m]
	// 説明：巨大敵持ち上げ高さ上書き[m]
	float hugeEnemyPickupHeightOverwrite_35B;

	// 名前：防御側：毒耐性ダメージ倍率
	// 説明：毒耐性ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float poisonDefDamageRate_35F;

	// 名前：防御側：疫病耐性ダメージ倍率
	// 説明：疫病耐性ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float diseaseDefDamageRate_363;

	// 名前：防御側：出血耐性ダメージ倍率
	// 説明：出血耐性ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float bloodDefDamageRate_367;

	// 名前：防御側：呪耐性ダメージ倍率
	// 説明：呪耐性ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float curseDefDamageRate_36B;

	// 名前：防御側：冷気耐性ダメージ倍率
	// 説明：冷気耐性ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float freezeDefDamageRate_36F;

	// 名前：防御側：睡眠耐性ダメージ倍率
	// 説明：睡眠耐性ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float sleepDefDamageRate_373;

	// 名前：防御側：発狂耐性ダメージ倍率
	// 説明：発狂耐性ダメージ倍率：算出したダメージに×○倍で補正をかける。１が通常。
	float madnessDefDamageRate_377;

	// 名前：何があっても帰宅する距離[m]_上書き
	// 説明：何があっても帰宅する距離[m]_上書き
	uint16_t overwrite_maxBackhomeDist_37B;

	// 名前：戦闘しつつ帰宅する距離[m]_上書き
	// 説明：戦闘しつつ帰宅する距離[m]_上書き
	uint16_t overwrite_backhomeDist_37D;

	// 名前：巣に帰るのをあきらめて戦闘する距離[m]_上書き
	// 説明：巣に帰るのをあきらめて戦闘する距離[m]_上書き 
	uint16_t overwrite_backhomeBattleDist_37F;

	// 名前：帰宅時：ターゲットを見ている距離[m]_上書き
	// 説明：帰宅時：ターゲットを見ている距離[m]_上書き
	uint16_t overwrite_BackHome_LookTargetDist_381;

	// 名前：アイテム消費MP倍率
	// 説明：アイテム消費MP倍率
	float goodsConsumptionRate_383;

	// 名前：pad
	uint8_t pad3_387[8];

} SpEffect;

#endif
