/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_FaceParam_H
#define _PARAM_FaceParam_H
#include <stdint.h>

// FACE_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _FaceParam {

	// 名前：顔パーツID
	// 説明：顔パーツID
	uint8_t face_partsId_000;

	// 名前：肌の色(Ｒ)
	// 説明：肌の色(Ｒ)
	uint8_t skin_color_R_001;

	// 名前：肌の色(Ｇ)
	// 説明：肌の色(Ｇ)
	uint8_t skin_color_G_002;

	// 名前：肌の色(Ｂ)
	// 説明：肌の色(Ｂ)
	uint8_t skin_color_B_003;

	// 名前：肌のつや
	// 説明：肌のつや
	uint8_t skin_gloss_004;

	// 名前：毛穴
	// 説明：毛穴
	uint8_t skin_pores_005;

	// 名前：青ひげ
	// 説明：青ひげ
	uint8_t face_beard_006;

	// 名前：くま
	// 説明：くま
	uint8_t face_aroundEye_007;

	// 名前：くまの色(R)
	// 説明：くまの色(R)
	uint8_t face_aroundEyeColor_R_008;

	// 名前：くまの色(G)
	// 説明：くまの色(G)
	uint8_t face_aroundEyeColor_G_009;

	// 名前：くまの色(B)
	// 説明：くまの色(B)
	uint8_t face_aroundEyeColor_B_00A;

	// 名前：チーク
	// 説明：チーク
	uint8_t face_cheek_00B;

	// 名前：チークの色(R)
	// 説明：チークの色(R)
	uint8_t face_cheekColor_R_00C;

	// 名前：チークの色(G)
	// 説明：チークの色(G)
	uint8_t face_cheekColor_G_00D;

	// 名前：チークの色(B)
	// 説明：チークの色(B)
	uint8_t face_cheekColor_B_00E;

	// 名前：アイライン
	// 説明：アイライン
	uint8_t face_eyeLine_00F;

	// 名前：アイラインの色(R)
	// 説明：アイラインの色(R)
	uint8_t face_eyeLineColor_R_010;

	// 名前：アイラインの色(G)
	// 説明：アイラインの色(G)
	uint8_t face_eyeLineColor_G_011;

	// 名前：アイラインの色(B)
	// 説明：アイラインの色(B)
	uint8_t face_eyeLineColor_B_012;

	// 名前：アイシャドウ(下)
	// 説明：アイシャドウ(下)
	uint8_t face_eyeShadowDown_013;

	// 名前：アイシャドウ(下)の色(R)
	// 説明：アイシャドウ(下)の色(R)
	uint8_t face_eyeShadowDownColor_R_014;

	// 名前：アイシャドウ(下)の色(G)
	// 説明：アイシャドウ(下)の色(G)
	uint8_t face_eyeShadowDownColor_G_015;

	// 名前：アイシャドウ(下)の色(B)
	// 説明：アイシャドウ(下)の色(B)
	uint8_t face_eyeShadowDownColor_B_016;

	// 名前：アイシャドウ(上)
	// 説明：アイシャドウ(上)
	uint8_t face_eyeShadowUp_017;

	// 名前：アイシャドウ(上)の色(R)
	// 説明：アイシャドウ(上)の色(R)
	uint8_t face_eyeShadowUpColor_R_018;

	// 名前：アイシャドウ(上)の色(G)
	// 説明：アイシャドウ(上)の色(G)
	uint8_t face_eyeShadowUpColor_G_019;

	// 名前：アイシャドウ(上)の色(B)
	// 説明：アイシャドウ(上)の色(B)
	uint8_t face_eyeShadowUpColor_B_01A;

	// 名前：口紅
	// 説明：口紅
	uint8_t face_lip_01B;

	// 名前：口紅の色(R)
	// 説明：口紅の色(R)
	uint8_t face_lipColor_R_01C;

	// 名前：口紅の色(G)
	// 説明：口紅の色(G)
	uint8_t face_lipColor_G_01D;

	// 名前：口紅の色(B)
	// 説明：口紅の色(B)
	uint8_t face_lipColor_B_01E;

	// 名前：体毛の濃さ
	// 説明：体毛の濃さ
	uint8_t body_hair_01F;

	// 名前：体毛の色(R)
	// 説明：体毛の色(R)
	uint8_t body_hairColor_R_020;

	// 名前：体毛の色(G)
	// 説明：体毛の色(G)
	uint8_t body_hairColor_G_021;

	// 名前：体毛の色(B)
	// 説明：体毛の色(B)
	uint8_t body_hairColor_B_022;

	// 名前：眼球パーツID
	// 説明：眼球パーツID
	uint8_t eye_partsId_023;

	// 名前：虹彩の色(Ｒ)
	// 説明：右目の虹彩の色(Ｒ)
	uint8_t eyeR_irisColor_R_024;

	// 名前：虹彩の色(Ｇ)
	// 説明：右目の虹彩の色(Ｇ)
	uint8_t eyeR_irisColor_G_025;

	// 名前：虹彩の色(Ｂ)
	// 説明：右目の虹彩の色(Ｂ)
	uint8_t eyeR_irisColor_B_026;

	// 名前：虹彩の大きさ
	// 説明：右目の虹彩の大きさ
	uint8_t eyeR_irisScale_027;

	// 名前：水晶体の濁り
	// 説明：右目の水晶体の濁り
	uint8_t eyeR_cataract_028;

	// 名前：水晶体の濁りの色(Ｒ)
	// 説明：右目の水晶体の濁りの色(Ｒ)
	uint8_t eyeR_cataractColor_R_029;

	// 名前：水晶体の濁りの色(Ｇ)
	// 説明：右目の水晶体の濁りの色(Ｇ)
	uint8_t eyeR_cataractColor_G_02A;

	// 名前：水晶体の濁りの色(Ｂ)
	// 説明：右目の水晶体の濁りの色(Ｂ)
	uint8_t eyeR_cataractColor_B_02B;

	// 名前：白目の色(Ｒ)
	// 説明：右目の白目の色(Ｒ)
	uint8_t eyeR_scleraColor_R_02C;

	// 名前：白目の色(G)
	// 説明：右目の白目の色(G)
	uint8_t eyeR_scleraColor_G_02D;

	// 名前：白目の色(B)
	// 説明：右目の白目の色(B)
	uint8_t eyeR_scleraColor_B_02E;

	// 名前：虹彩の位置
	// 説明：右目の虹彩の位置
	uint8_t eyeR_irisDistance_02F;

	// 名前：虹彩の色(Ｒ)
	// 説明：左目の虹彩の色(Ｒ)
	uint8_t eyeL_irisColor_R_030;

	// 名前：虹彩の色(Ｇ)
	// 説明：左目の虹彩の色(Ｇ)
	uint8_t eyeL_irisColor_G_031;

	// 名前：虹彩の色(Ｂ)
	// 説明：左目の虹彩の色(Ｂ)
	uint8_t eyeL_irisColor_B_032;

	// 名前：虹彩の大きさ
	// 説明：左目の虹彩の大きさ
	uint8_t eyeL_irisScale_033;

	// 名前：水晶体の濁り
	// 説明：左目の水晶体の濁り
	uint8_t eyeL_cataract_034;

	// 名前：水晶体の濁りの色(Ｒ)
	// 説明：左目の水晶体の濁りの色(Ｒ)
	uint8_t eyeL_cataractColor_R_035;

	// 名前：水晶体の濁りの色(Ｇ)
	// 説明：左目の水晶体の濁りの色(Ｇ)
	uint8_t eyeL_cataractColor_G_036;

	// 名前：水晶体の濁りの色(Ｂ)
	// 説明：左目の水晶体の濁りの色(Ｂ)
	uint8_t eyeL_cataractColor_B_037;

	// 名前：白目の色(Ｒ)
	// 説明：左目の白目の色(Ｒ)
	uint8_t eyeL_scleraColor_R_038;

	// 名前：白目の色(G)
	// 説明：左目の白目の色(G)
	uint8_t eyeL_scleraColor_G_039;

	// 名前：白目の色(B)
	// 説明：左目の白目の色(B)
	uint8_t eyeL_scleraColor_B_03A;

	// 名前：虹彩の位置
	// 説明：左目の虹彩の位置
	uint8_t eyeL_irisDistance_03B;

	// 名前：髪パーツID
	// 説明：髪パーツID
	uint8_t hair_partsId_03C;

	// 名前：髪の色(Ｒ)
	// 説明：髪の色(Ｒ)
	uint8_t hair_color_R_03D;

	// 名前：髪の色(Ｇ)
	// 説明：髪の色(Ｇ)
	uint8_t hair_color_G_03E;

	// 名前：髪の色(Ｂ)
	// 説明：髪の色(Ｂ)
	uint8_t hair_color_B_03F;

	// 名前：光沢
	// 説明：髪の光沢
	uint8_t hair_shininess_040;

	// 名前：根元の黒さ
	// 説明：髪の根元の黒さ
	uint8_t hair_rootBlack_041;

	// 名前：白髪の量
	// 説明：髪の白髪の量
	uint8_t hair_whiteDensity_042;

	// 名前：髭パーツID
	// 説明：髭パーツID
	uint8_t beard_partsId_043;

	// 名前：髭の色(Ｒ)
	// 説明：髭の色(Ｒ)
	uint8_t beard_color_R_044;

	// 名前：髭の色(Ｇ)
	// 説明：髭の色(Ｇ)
	uint8_t beard_color_G_045;

	// 名前：髭の色(Ｂ)
	// 説明：髭の色(Ｂ)
	uint8_t beard_color_B_046;

	// 名前：光沢
	// 説明：髭の光沢
	uint8_t beard_shininess_047;

	// 名前：根元の黒さ
	// 説明：髭の根元の黒さ
	uint8_t beard_rootBlack_048;

	// 名前：白髪の量
	// 説明：髭の白髪の量
	uint8_t beard_whiteDensity_049;

	// 名前：眉パーツID
	// 説明：眉パーツID
	uint8_t eyebrow_partsId_04A;

	// 名前：眉の色(Ｒ)
	// 説明：眉の色(Ｒ)
	uint8_t eyebrow_color_R_04B;

	// 名前：眉の色(Ｇ)
	// 説明：眉の色(Ｇ)
	uint8_t eyebrow_color_G_04C;

	// 名前：眉の色(Ｂ)
	// 説明：眉の色(Ｂ)
	uint8_t eyebrow_color_B_04D;

	// 名前：光沢
	// 説明：眉の光沢
	uint8_t eyebrow_shininess_04E;

	// 名前：根元の黒さ
	// 説明：眉の根元の黒さ
	uint8_t eyebrow_rootBlack_04F;

	// 名前：白髪の量
	// 説明：眉の白髪の量
	uint8_t eyebrow_whiteDensity_050;

	// 名前：まつげパーツID
	// 説明：まつげパーツID
	uint8_t eyelash_partsId_051;

	// 名前：まつげの色(Ｒ)
	// 説明：まつげの色(Ｒ)
	uint8_t eyelash_color_R_052;

	// 名前：まつげの色(Ｇ)
	// 説明：まつげの色(Ｇ)
	uint8_t eyelash_color_G_053;

	// 名前：まつげの色(Ｂ)
	// 説明：まつげの色(Ｂ)
	uint8_t eyelash_color_B_054;

	// 名前：装飾パーツID
	// 説明：装飾パーツID
	uint8_t accessories_partsId_055;

	// 名前：装飾の色(Ｒ)
	// 説明：装飾の色(Ｒ)
	uint8_t accessories_color_R_056;

	// 名前：装飾の色(Ｇ)
	// 説明：装飾の色(Ｇ)
	uint8_t accessories_color_G_057;

	// 名前：装飾の色(Ｂ)
	// 説明：装飾の色(Ｂ)
	uint8_t accessories_color_B_058;

	// 名前：デカールパーツID
	// 説明：デカールパーツID
	uint8_t decal_partsId_059;

	// 名前：デカール位置(x)
	// 説明：デカール位置(x)
	uint8_t decal_posX_05A;

	// 名前：デカール位置(y)
	// 説明：デカール位置(y)
	uint8_t decal_posY_05B;

	// 名前：デカール角度
	// 説明：デカール角度
	uint8_t decal_angle_05C;

	// 名前：デカールスケール
	// 説明：デカールスケール
	uint8_t decal_scale_05D;

	// 名前：デカールの色(Ｒ)
	// 説明：デカールの色(Ｒ)
	uint8_t decal_color_R_05E;

	// 名前：デカールの色(Ｇ)
	// 説明：デカールの色(Ｇ)
	uint8_t decal_color_G_05F;

	// 名前：デカールの色(Ｂ)
	// 説明：デカールの色(Ｂ)
	uint8_t decal_color_B_060;

	// 名前：デカールのつや
	// 説明：デカールのつや
	uint8_t decal_gloss_061;

	// 名前：デカールの反転
	// 説明：デカールの反転
	uint8_t decal_mirror_062;

	// 名前：キャラ体型頭部スケール
	// 説明：キャラ体型頭部スケール
	uint8_t chrBodyScaleHead_063;

	// 名前：キャラ体型胸部スケール
	// 説明：キャラ体型胸部スケール
	uint8_t chrBodyScaleBreast_064;

	// 名前：キャラ体型腹部スケール
	// 説明：キャラ体型腹部スケール
	uint8_t chrBodyScaleAbdomen_065;

	// 名前：キャラ体型右腕部スケール
	// 説明：キャラ体型右腕部スケール
	uint8_t chrBodyScaleRArm_066;

	// 名前：キャラ体型右脚部スケール
	// 説明：キャラ体型右脚部スケール
	uint8_t chrBodyScaleRLeg_067;

	// 名前：キャラ体型左腕部スケール
	// 説明：キャラ体型左腕部スケール
	uint8_t chrBodyScaleLArm_068;

	// 名前：キャラ体型左脚部スケール
	// 説明：キャラ体型左脚部スケール
	uint8_t chrBodyScaleLLeg_069;

	// 名前：火傷跡
	// 説明：火傷跡
	uint8_t burn_scar_06A;

	// 名前：眼球パーツID
	// 説明：眼球パーツIDを上書きするか
	uint8_t override_eye_partsId_06B: 1;

	// 名前：虹彩の色
	// 説明：虹彩の色を上書きするか
	uint8_t override_eye_irisColor_06B: 1;

	// 名前：水晶体の濁り
	// 説明：水晶体の濁りを上書きするか
	uint8_t override_eye_cataract_06B: 1;

	// 名前：水晶体の濁り色
	// 説明：水晶体の濁り色を上書きするか
	uint8_t override_eye_cataractColor_06B: 1;

	// 名前：白目の色
	// 説明：白目の色を上書きするか
	uint8_t override_eye_scleraColor_06B: 1;

	// 名前：火傷跡
	// 説明：火傷跡を上書きするか
	uint8_t override_burn_scar_06B: 1;

	// 名前：pad2
	uint8_t pad2_06B: 2;

	// 名前：pad
	uint8_t pad_06C[5];

	// 名前：年齢
	// 説明：年齢
	uint8_t age_071;

	// 名前：性別
	// 説明：性別
	uint8_t gender_072;

	// 名前：誇張（モデル）
	// 説明：誇張（モデル）
	uint8_t caricatureGeometry_073;

	// 名前：誇張（テクスチャ）
	// 説明：誇張（テクスチャ）
	uint8_t caricatureTexture_074;

	// 名前：顔作成ジオメトリデータ00
	// 説明：顔作成ジオメトリデータ00
	uint8_t faceGeoData00_075;

	// 名前：顔作成ジオメトリデータ01
	// 説明：顔作成ジオメトリデータ01
	uint8_t faceGeoData01_076;

	// 名前：顔作成ジオメトリデータ02
	// 説明：顔作成ジオメトリデータ02
	uint8_t faceGeoData02_077;

	// 名前：顔作成ジオメトリデータ03
	// 説明：顔作成ジオメトリデータ03
	uint8_t faceGeoData03_078;

	// 名前：顔作成ジオメトリデータ04
	// 説明：顔作成ジオメトリデータ04
	uint8_t faceGeoData04_079;

	// 名前：顔作成ジオメトリデータ05
	// 説明：顔作成ジオメトリデータ05
	uint8_t faceGeoData05_07A;

	// 名前：顔作成ジオメトリデータ06
	// 説明：顔作成ジオメトリデータ06
	uint8_t faceGeoData06_07B;

	// 名前：顔作成ジオメトリデータ07
	// 説明：顔作成ジオメトリデータ07
	uint8_t faceGeoData07_07C;

	// 名前：顔作成ジオメトリデータ08
	// 説明：顔作成ジオメトリデータ08
	uint8_t faceGeoData08_07D;

	// 名前：顔作成ジオメトリデータ09
	// 説明：顔作成ジオメトリデータ09
	uint8_t faceGeoData09_07E;

	// 名前：顔作成ジオメトリデータ10
	// 説明：顔作成ジオメトリデータ10
	uint8_t faceGeoData10_07F;

	// 名前：顔作成ジオメトリデータ11
	// 説明：顔作成ジオメトリデータ11
	uint8_t faceGeoData11_080;

	// 名前：顔作成ジオメトリデータ12
	// 説明：顔作成ジオメトリデータ12
	uint8_t faceGeoData12_081;

	// 名前：顔作成ジオメトリデータ13
	// 説明：顔作成ジオメトリデータ13
	uint8_t faceGeoData13_082;

	// 名前：顔作成ジオメトリデータ14
	// 説明：顔作成ジオメトリデータ14
	uint8_t faceGeoData14_083;

	// 名前：顔作成ジオメトリデータ15
	// 説明：顔作成ジオメトリデータ15
	uint8_t faceGeoData15_084;

	// 名前：顔作成ジオメトリデータ16
	// 説明：顔作成ジオメトリデータ16
	uint8_t faceGeoData16_085;

	// 名前：顔作成ジオメトリデータ17
	// 説明：顔作成ジオメトリデータ17
	uint8_t faceGeoData17_086;

	// 名前：顔作成ジオメトリデータ18
	// 説明：顔作成ジオメトリデータ18
	uint8_t faceGeoData18_087;

	// 名前：顔作成ジオメトリデータ19
	// 説明：顔作成ジオメトリデータ19
	uint8_t faceGeoData19_088;

	// 名前：顔作成ジオメトリデータ20
	// 説明：顔作成ジオメトリデータ20
	uint8_t faceGeoData20_089;

	// 名前：顔作成ジオメトリデータ21
	// 説明：顔作成ジオメトリデータ21
	uint8_t faceGeoData21_08A;

	// 名前：顔作成ジオメトリデータ22
	// 説明：顔作成ジオメトリデータ22
	uint8_t faceGeoData22_08B;

	// 名前：顔作成ジオメトリデータ23
	// 説明：顔作成ジオメトリデータ23
	uint8_t faceGeoData23_08C;

	// 名前：顔作成ジオメトリデータ24
	// 説明：顔作成ジオメトリデータ24
	uint8_t faceGeoData24_08D;

	// 名前：顔作成ジオメトリデータ25
	// 説明：顔作成ジオメトリデータ25
	uint8_t faceGeoData25_08E;

	// 名前：顔作成ジオメトリデータ26
	// 説明：顔作成ジオメトリデータ26
	uint8_t faceGeoData26_08F;

	// 名前：顔作成ジオメトリデータ27
	// 説明：顔作成ジオメトリデータ27
	uint8_t faceGeoData27_090;

	// 名前：顔作成ジオメトリデータ28
	// 説明：顔作成ジオメトリデータ28
	uint8_t faceGeoData28_091;

	// 名前：顔作成ジオメトリデータ29
	// 説明：顔作成ジオメトリデータ29
	uint8_t faceGeoData29_092;

	// 名前：顔作成ジオメトリデータ30
	// 説明：顔作成ジオメトリデータ30
	uint8_t faceGeoData30_093;

	// 名前：顔作成ジオメトリデータ31
	// 説明：顔作成ジオメトリデータ31
	uint8_t faceGeoData31_094;

	// 名前：顔作成ジオメトリデータ32
	// 説明：顔作成ジオメトリデータ32
	uint8_t faceGeoData32_095;

	// 名前：顔作成ジオメトリデータ33
	// 説明：顔作成ジオメトリデータ33
	uint8_t faceGeoData33_096;

	// 名前：顔作成ジオメトリデータ34
	// 説明：顔作成ジオメトリデータ34
	uint8_t faceGeoData34_097;

	// 名前：顔作成ジオメトリデータ35
	// 説明：顔作成ジオメトリデータ35
	uint8_t faceGeoData35_098;

	// 名前：顔作成ジオメトリデータ36
	// 説明：顔作成ジオメトリデータ36
	uint8_t faceGeoData36_099;

	// 名前：顔作成ジオメトリデータ37
	// 説明：顔作成ジオメトリデータ37
	uint8_t faceGeoData37_09A;

	// 名前：顔作成ジオメトリデータ38
	// 説明：顔作成ジオメトリデータ38
	uint8_t faceGeoData38_09B;

	// 名前：顔作成ジオメトリデータ39
	// 説明：顔作成ジオメトリデータ39
	uint8_t faceGeoData39_09C;

	// 名前：顔作成ジオメトリデータ40
	// 説明：顔作成ジオメトリデータ40
	uint8_t faceGeoData40_09D;

	// 名前：顔作成ジオメトリデータ41
	// 説明：顔作成ジオメトリデータ41
	uint8_t faceGeoData41_09E;

	// 名前：顔作成ジオメトリデータ42
	// 説明：顔作成ジオメトリデータ42
	uint8_t faceGeoData42_09F;

	// 名前：顔作成ジオメトリデータ43
	// 説明：顔作成ジオメトリデータ43
	uint8_t faceGeoData43_0A0;

	// 名前：顔作成ジオメトリデータ44
	// 説明：顔作成ジオメトリデータ44
	uint8_t faceGeoData44_0A1;

	// 名前：顔作成ジオメトリデータ45
	// 説明：顔作成ジオメトリデータ45
	uint8_t faceGeoData45_0A2;

	// 名前：顔作成ジオメトリデータ46
	// 説明：顔作成ジオメトリデータ46
	uint8_t faceGeoData46_0A3;

	// 名前：顔作成ジオメトリデータ47
	// 説明：顔作成ジオメトリデータ47
	uint8_t faceGeoData47_0A4;

	// 名前：顔作成ジオメトリデータ48
	// 説明：顔作成ジオメトリデータ48
	uint8_t faceGeoData48_0A5;

	// 名前：顔作成ジオメトリデータ49
	// 説明：顔作成ジオメトリデータ49
	uint8_t faceGeoData49_0A6;

	// 名前：顔作成ジオメトリデータ50
	// 説明：顔作成ジオメトリデータ50
	uint8_t faceGeoData50_0A7;

	// 名前：顔作成ジオメトリデータ51
	// 説明：顔作成ジオメトリデータ51
	uint8_t faceGeoData51_0A8;

	// 名前：顔作成ジオメトリデータ52
	// 説明：顔作成ジオメトリデータ52
	uint8_t faceGeoData52_0A9;

	// 名前：顔作成ジオメトリデータ53
	// 説明：顔作成ジオメトリデータ53
	uint8_t faceGeoData53_0AA;

	// 名前：顔作成ジオメトリデータ54
	// 説明：顔作成ジオメトリデータ54
	uint8_t faceGeoData54_0AB;

	// 名前：顔作成ジオメトリデータ55
	// 説明：顔作成ジオメトリデータ55
	uint8_t faceGeoData55_0AC;

	// 名前：顔作成ジオメトリデータ56
	// 説明：顔作成ジオメトリデータ56
	uint8_t faceGeoData56_0AD;

	// 名前：顔作成ジオメトリデータ57
	// 説明：顔作成ジオメトリデータ57
	uint8_t faceGeoData57_0AE;

	// 名前：顔作成ジオメトリデータ58
	// 説明：顔作成ジオメトリデータ58
	uint8_t faceGeoData58_0AF;

	// 名前：顔作成ジオメトリデータ59
	// 説明：顔作成ジオメトリデータ59
	uint8_t faceGeoData59_0B0;

	// 名前：顔作成ジオメトリデータ60
	// 説明：顔作成ジオメトリデータ60
	uint8_t faceGeoData60_0B1;

	// 名前：顔作成テクスチャデータ00
	// 説明：顔作成テクスチャデータ00
	uint8_t faceTexData00_0B2;

	// 名前：顔作成テクスチャデータ01
	// 説明：顔作成テクスチャデータ01
	uint8_t faceTexData01_0B3;

	// 名前：顔作成テクスチャデータ02
	// 説明：顔作成テクスチャデータ02
	uint8_t faceTexData02_0B4;

	// 名前：顔作成テクスチャデータ03
	// 説明：顔作成テクスチャデータ03
	uint8_t faceTexData03_0B5;

	// 名前：顔作成テクスチャデータ04
	// 説明：顔作成テクスチャデータ04
	uint8_t faceTexData04_0B6;

	// 名前：顔作成テクスチャデータ05
	// 説明：顔作成テクスチャデータ05
	uint8_t faceTexData05_0B7;

	// 名前：顔作成テクスチャデータ06
	// 説明：顔作成テクスチャデータ06
	uint8_t faceTexData06_0B8;

	// 名前：顔作成テクスチャデータ07
	// 説明：顔作成テクスチャデータ07
	uint8_t faceTexData07_0B9;

	// 名前：顔作成テクスチャデータ08
	// 説明：顔作成テクスチャデータ08
	uint8_t faceTexData08_0BA;

	// 名前：顔作成テクスチャデータ09
	// 説明：顔作成テクスチャデータ09
	uint8_t faceTexData09_0BB;

	// 名前：顔作成テクスチャデータ10
	// 説明：顔作成テクスチャデータ10
	uint8_t faceTexData10_0BC;

	// 名前：顔作成テクスチャデータ11
	// 説明：顔作成テクスチャデータ11
	uint8_t faceTexData11_0BD;

	// 名前：顔作成テクスチャデータ12
	// 説明：顔作成テクスチャデータ12
	uint8_t faceTexData12_0BE;

	// 名前：顔作成テクスチャデータ13
	// 説明：顔作成テクスチャデータ13
	uint8_t faceTexData13_0BF;

	// 名前：顔作成テクスチャデータ14
	// 説明：顔作成テクスチャデータ14
	uint8_t faceTexData14_0C0;

	// 名前：顔作成テクスチャデータ15
	// 説明：顔作成テクスチャデータ15
	uint8_t faceTexData15_0C1;

	// 名前：顔作成テクスチャデータ16
	// 説明：顔作成テクスチャデータ16
	uint8_t faceTexData16_0C2;

	// 名前：顔作成テクスチャデータ17
	// 説明：顔作成テクスチャデータ17
	uint8_t faceTexData17_0C3;

	// 名前：顔作成テクスチャデータ18
	// 説明：顔作成テクスチャデータ18
	uint8_t faceTexData18_0C4;

	// 名前：顔作成テクスチャデータ19
	// 説明：顔作成テクスチャデータ19
	uint8_t faceTexData19_0C5;

	// 名前：顔作成テクスチャデータ20
	// 説明：顔作成テクスチャデータ20
	uint8_t faceTexData20_0C6;

	// 名前：顔作成テクスチャデータ21
	// 説明：顔作成テクスチャデータ21
	uint8_t faceTexData21_0C7;

	// 名前：顔作成テクスチャデータ22
	// 説明：顔作成テクスチャデータ22
	uint8_t faceTexData22_0C8;

	// 名前：顔作成テクスチャデータ23
	// 説明：顔作成テクスチャデータ23
	uint8_t faceTexData23_0C9;

	// 名前：顔作成テクスチャデータ24
	// 説明：顔作成テクスチャデータ24
	uint8_t faceTexData24_0CA;

	// 名前：顔作成テクスチャデータ25
	// 説明：顔作成テクスチャデータ25
	uint8_t faceTexData25_0CB;

	// 名前：顔作成テクスチャデータ26
	// 説明：顔作成テクスチャデータ26
	uint8_t faceTexData26_0CC;

	// 名前：顔作成テクスチャデータ27
	// 説明：顔作成テクスチャデータ27
	uint8_t faceTexData27_0CD;

	// 名前：顔作成テクスチャデータ28
	// 説明：顔作成テクスチャデータ28
	uint8_t faceTexData28_0CE;

	// 名前：顔作成テクスチャデータ29
	// 説明：顔作成テクスチャデータ29
	uint8_t faceTexData29_0CF;

	// 名前：顔作成テクスチャデータ30
	// 説明：顔作成テクスチャデータ30
	uint8_t faceTexData30_0D0;

	// 名前：顔作成テクスチャデータ31
	// 説明：顔作成テクスチャデータ31
	uint8_t faceTexData31_0D1;

	// 名前：顔作成テクスチャデータ32
	// 説明：顔作成テクスチャデータ32
	uint8_t faceTexData32_0D2;

	// 名前：顔作成テクスチャデータ33
	// 説明：顔作成テクスチャデータ33
	uint8_t faceTexData33_0D3;

	// 名前：顔作成テクスチャデータ34
	// 説明：顔作成テクスチャデータ34
	uint8_t faceTexData34_0D4;

	// 名前：顔作成テクスチャデータ35
	// 説明：顔作成テクスチャデータ35
	uint8_t faceTexData35_0D5;

	// 名前：顔作成ジオメトリ非対称データ00
	// 説明：顔作成ジオメトリ非対称データ00
	uint8_t faceGeoAsymData00_0D6;

	// 名前：顔作成ジオメトリ非対称データ01
	// 説明：顔作成ジオメトリ非対称データ01
	uint8_t faceGeoAsymData01_0D7;

	// 名前：顔作成ジオメトリ非対称データ02
	// 説明：顔作成ジオメトリ非対称データ02
	uint8_t faceGeoAsymData02_0D8;

	// 名前：顔作成ジオメトリ非対称データ03
	// 説明：顔作成ジオメトリ非対称データ03
	uint8_t faceGeoAsymData03_0D9;

	// 名前：顔作成ジオメトリ非対称データ04
	// 説明：顔作成ジオメトリ非対称データ04
	uint8_t faceGeoAsymData04_0DA;

	// 名前：顔作成ジオメトリ非対称データ05
	// 説明：顔作成ジオメトリ非対称データ05
	uint8_t faceGeoAsymData05_0DB;

	// 名前：顔作成ジオメトリ非対称データ06
	// 説明：顔作成ジオメトリ非対称データ06
	uint8_t faceGeoAsymData06_0DC;

	// 名前：顔作成ジオメトリ非対称データ07
	// 説明：顔作成ジオメトリ非対称データ07
	uint8_t faceGeoAsymData07_0DD;

	// 名前：顔作成ジオメトリ非対称データ08
	// 説明：顔作成ジオメトリ非対称データ08
	uint8_t faceGeoAsymData08_0DE;

	// 名前：顔作成ジオメトリ非対称データ09
	// 説明：顔作成ジオメトリ非対称データ09
	uint8_t faceGeoAsymData09_0DF;

	// 名前：顔作成ジオメトリ非対称データ10
	// 説明：顔作成ジオメトリ非対称データ10
	uint8_t faceGeoAsymData10_0E0;

	// 名前：顔作成ジオメトリ非対称データ11
	// 説明：顔作成ジオメトリ非対称データ11
	uint8_t faceGeoAsymData11_0E1;

	// 名前：顔作成ジオメトリ非対称データ12
	// 説明：顔作成ジオメトリ非対称データ12
	uint8_t faceGeoAsymData12_0E2;

	// 名前：顔作成ジオメトリ非対称データ13
	// 説明：顔作成ジオメトリ非対称データ13
	uint8_t faceGeoAsymData13_0E3;

	// 名前：顔作成ジオメトリ非対称データ14
	// 説明：顔作成ジオメトリ非対称データ14
	uint8_t faceGeoAsymData14_0E4;

	// 名前：顔作成ジオメトリ非対称データ15
	// 説明：顔作成ジオメトリ非対称データ15
	uint8_t faceGeoAsymData15_0E5;

	// 名前：顔作成ジオメトリ非対称データ16
	// 説明：顔作成ジオメトリ非対称データ16
	uint8_t faceGeoAsymData16_0E6;

	// 名前：顔作成ジオメトリ非対称データ17
	// 説明：顔作成ジオメトリ非対称データ17
	uint8_t faceGeoAsymData17_0E7;

	// 名前：顔作成ジオメトリ非対称データ18
	// 説明：顔作成ジオメトリ非対称データ18
	uint8_t faceGeoAsymData18_0E8;

	// 名前：顔作成ジオメトリ非対称データ19
	// 説明：顔作成ジオメトリ非対称データ19
	uint8_t faceGeoAsymData19_0E9;

	// 名前：顔作成ジオメトリ非対称データ20
	// 説明：顔作成ジオメトリ非対称データ20
	uint8_t faceGeoAsymData20_0EA;

	// 名前：顔作成ジオメトリ非対称データ21
	// 説明：顔作成ジオメトリ非対称データ21
	uint8_t faceGeoAsymData21_0EB;

	// 名前：顔作成ジオメトリ非対称データ22
	// 説明：顔作成ジオメトリ非対称データ22
	uint8_t faceGeoAsymData22_0EC;

	// 名前：顔作成ジオメトリ非対称データ23
	// 説明：顔作成ジオメトリ非対称データ23
	uint8_t faceGeoAsymData23_0ED;

	// 名前：顔作成ジオメトリ非対称データ24
	// 説明：顔作成ジオメトリ非対称データ24
	uint8_t faceGeoAsymData24_0EE;

	// 名前：顔作成ジオメトリ非対称データ25
	// 説明：顔作成ジオメトリ非対称データ25
	uint8_t faceGeoAsymData25_0EF;

} FaceParam;

#endif
