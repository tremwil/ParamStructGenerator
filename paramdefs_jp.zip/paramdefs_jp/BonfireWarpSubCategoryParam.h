/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_BonfireWarpSubCategoryParam_H
#define _PARAM_BonfireWarpSubCategoryParam_H
#include <stdint.h>

// BONFIRE_WARP_SUB_CATEGORY_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BonfireWarpSubCategoryParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：テキストID
	// 説明：サブカテゴリの表示名テキストID[MenuText]
	int32_t textId_004;

	// 名前：篝火ワープタブID
	// 説明：篝火ワープタブID。このサブカテゴリが所属するタブのID
	uint16_t tabId_008;

	// 名前：篝火ワープタブソートID
	// 説明：篝火ワープタブソートID。タブの中サブカテゴリの表示順
	uint16_t sortId_00A;

	// 名前：pad
	uint8_t pad_00C[4];

} BonfireWarpSubCategoryParam;

#endif
