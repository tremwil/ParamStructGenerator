/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AtkParam_H
#define _PARAM_AtkParam_H
#include <stdint.h>

// ATK_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AtkParam {

	// 名前：あたり0 半径
	// 説明：球、カプセルの半径
	float hit0_Radius_000;

	// 名前：あたり1 半径
	// 説明：球、カプセルの半径
	float hit1_Radius_004;

	// 名前：あたり2 半径
	// 説明：球、カプセルの半径
	float hit2_Radius_008;

	// 名前：あたり3 半径
	// 説明：球、カプセルの半径
	float hit3_Radius_00C;

	// 名前：ノックバック距離[m]
	// 説明：ノックバック距離[m]
	float knockbackDist_010;

	// 名前：ヒットストップ時間[s]
	// 説明：ヒットストップの停止時間[s]
	float hitStopTime_014;

	// 名前：特殊効果0
	// 説明：特殊効果パラメータで作成したＩＤを入れる
	int32_t spEffectId0_018;

	// 名前：特殊効果1
	// 説明：特殊効果パラメータで作成したＩＤを入れる
	int32_t spEffectId1_01C;

	// 名前：特殊効果2
	// 説明：特殊効果パラメータで作成したＩＤを入れる
	int32_t spEffectId2_020;

	// 名前：特殊効果3
	// 説明：特殊効果パラメータで作成したＩＤを入れる
	int32_t spEffectId3_024;

	// 名前：特殊効果4
	// 説明：特殊効果パラメータで作成したＩＤを入れる
	int32_t spEffectId4_028;

	// 名前：あたり0 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit0_DmyPoly1_02C;

	// 名前：あたり1 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit1_DmyPoly1_02E;

	// 名前：あたり2 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit2_DmyPoly1_030;

	// 名前：あたり3 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit3_DmyPoly1_032;

	// 名前：あたり0 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit0_DmyPoly2_034;

	// 名前：あたり1 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit1_DmyPoly2_036;

	// 名前：あたり2 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit2_DmyPoly2_038;

	// 名前：あたり3 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit3_DmyPoly2_03A;

	// 名前：吹き飛ばし補正値
	// 説明：吹き飛ばす時の補正値
	uint16_t blowingCorrection_03C;

	// 名前：物理攻撃力補正値
	// 説明：PCのみ。物理攻撃力基本値に掛ける倍率
	uint16_t atkPhysCorrection_03E;

	// 名前：魔法攻撃力補正値
	// 説明：PCのみ。魔法攻撃力に掛ける倍率（弓の場合は、飛び道具を補正）
	uint16_t atkMagCorrection_040;

	// 名前：炎攻撃力補正値
	// 説明：PCのみ。炎攻撃力に掛ける倍率（弓の場合は、飛び道具を補正）
	uint16_t atkFireCorrection_042;

	// 名前：電撃攻撃力補正値
	// 説明：PCのみ。電撃攻撃力に掛ける倍率（弓の場合は、飛び道具を補正）
	uint16_t atkThunCorrection_044;

	// 名前：スタミナ攻撃力補正値
	// 説明：PCのみ。スタミナ攻撃力に掛ける倍率
	uint16_t atkStamCorrection_046;

	// 名前：はじき攻撃力補正値
	// 説明：PCのみ。1のみ
	uint16_t guardAtkRateCorrection_048;

	// 名前：はじき防御力補正値
	// 説明：PCのみ。攻撃のはじかれ基本値に掛ける倍率
	uint16_t guardBreakCorrection_04A;

	// 名前：投げ抜け攻撃力補正値
	// 説明：投げ抜け攻撃に対する武器補正値
	uint16_t atkThrowEscapeCorrection_04C;

	// 名前：サブカテゴリ1
	// 説明：サブカテゴリ1
	uint8_t subCategory1_04E;

	// 名前：サブカテゴリ2
	// 説明：サブカテゴリ2
	uint8_t subCategory2_04F;

	// 名前：物理攻撃力
	// 説明：NPCのみ。物理攻撃の基本ダメージ
	uint16_t atkPhys_050;

	// 名前：魔法攻撃力
	// 説明：NPCのみ。魔法攻撃の追加ダメージ
	uint16_t atkMag_052;

	// 名前：炎攻撃力
	// 説明：NPCのみ。炎攻撃の追加ダメージ
	uint16_t atkFire_054;

	// 名前：電撃攻撃力
	// 説明：NPCのみ。電撃攻撃の追加ダメージ
	uint16_t atkThun_056;

	// 名前：スタミナ攻撃力
	// 説明：NPCのみ。敵（プレイヤー）のスタミナに対するダメージ量
	uint16_t atkStam_058;

	// 名前：はじき攻撃力
	// 説明：NPCのみ。はじき値
	uint16_t guardAtkRate_05A;

	// 名前：はじき防御力
	// 説明：NPCのみ。攻撃がはじかれるかどうかの判定に利用する値
	uint16_t guardBreakRate_05C;

	// 名前：pad
	uint8_t pad6_05E[1];

	// 名前：茂みにダメージ可
	// 説明：「茂みダメージで壊れるか」ONのアセットに対してダメージ計算をするか？を設定します。〇：計算する、×：計算しない(つまりダメージをあたえることはできない)【GR】SEQ20617 
	uint8_t isEnableCalcDamageForBushesObj_05F;

	// 名前：投げ抜け攻撃力
	// 説明：投げ抜け攻撃力
	uint16_t atkThrowEscape_060;

	// 名前：オブジェ攻撃力
	// 説明：ＯＢＪに対する攻撃力
	uint16_t atkObj_062;

	// 名前：ガード時スタミナカット率補正
	// 説明：武器パラメータ、ＮＰＣパラメータに設定されている【ガード時スタミナカット率】を補正する
	int16_t guardStaminaCutRate_064;

	// 名前：ガード倍率
	// 説明：ＮＰＣ、武器パラメータで設定してあるガード性能を一律で補正を掛ける0で、1倍／100で、2倍／－100で、0　にパラメータが増減するようにするガード倍率　=　（ガード倍率/100　+　1）
	int16_t guardRate_066;

	// 名前：投げタイプID
	// 説明：投げパラメータと紐付けされているID
	uint16_t throwTypeId_068;

	// 名前：あたり0 部位
	// 説明：あたり部位
	uint8_t hit0_hitType_06A;

	// 名前：あたり1 部位
	// 説明：あたり部位
	uint8_t hit1_hitType_06B;

	// 名前：あたり2 部位
	// 説明：あたり部位
	uint8_t hit2_hitType_06C;

	// 名前：あたり3 部位
	// 説明：あたり部位
	uint8_t hit3_hitType_06D;

	// 名前：あたり0 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti0_Priority_06E;

	// 名前：あたり1 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti1_Priority_06F;

	// 名前：あたり2 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti2_Priority_070;

	// 名前：あたり3 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti3_Priority_071;

	// 名前：ダメージレベル
	// 説明：攻撃したとき、敵にどのダメージモーションを再生するか？を決める.
	uint8_t dmgLevel_072;

	// 名前：マップあたり参照
	// 説明：攻撃あたりが、どのマップあたりを見るか？を設定
	uint8_t mapHitType_073;

	// 名前：ガードカット率無効化倍率
	// 説明：ガードカット率無効化倍率（－100～100）　→0のとき通常／－100で完全無効化／100で相手の防御効果倍増 　→－50とすれば、100％カットの盾が、50％カットになります 
	int8_t guardCutCancelRate_074;

	// 名前：物理属性
	// 説明：攻撃に設定する物理属性
	uint8_t atkAttribute_075;

	// 名前：特殊属性
	// 説明：攻撃に設定する特殊属性
	uint8_t spAttribute_076;

	// 名前：攻撃属性[SFX/SE]
	// 説明：攻撃時のSFX/SEを指定(属性、材質、サイズで1セット)
	uint8_t atkType_077;

	// 名前：攻撃材質[SFX/SE]
	// 説明：攻撃時のSFX/SEを指定(属性、材質、サイズで1セット)
	uint8_t atkMaterial_078;

	// 名前：ガード判定位置
	// 説明：ガード判定位置
	uint8_t guardRangeType_079;

	// 名前：防御材質1[SE]
	// 説明：ガード時のSEに使用1
	uint16_t defSeMaterial1_07A;

	// 名前：あたり発生源
	// 説明：攻撃あたりのダミポリＩＤをどこから取ってくるか？を指定する
	uint8_t hitSourceType_07C;

	// 名前：投げ
	// 説明：投げ情報に用いるフラグ
	uint8_t throwFlag_07D;

	// 名前：ガード不可フラグ
	// 説明：1の場合、ガード側のガードを無視して、ダメージレベルを入れる
	uint8_t disableGuard_07E: 1;

	// 名前：スタミナ減らない
	// 説明：スタミナ攻撃力による「崩され判定」は行うが、実際にスタミナは減らさない
	uint8_t disableStaminaAttack_07E: 1;

	// 名前：ヒット時特殊効果無効
	// 説明：攻撃ヒットしたときの特殊効果を無効にします。SCEバグ対策
	uint8_t disableHitSpEffect_07E: 1;

	// 名前：AIに空振り通知しない
	// 説明：AIに空振り通知しない
	uint8_t IgnoreNotifyMissSwingForAI_07E: 1;

	// 名前：ＨＩＴ時にＳＦＸを何度も出すか
	// 説明：敵専用：壁Hit時のSFXが連続で発生するか
	uint8_t repeatHitSfx_07E: 1;

	// 名前：矢攻撃か
	// 説明：部位ダメージ判定に使用する。
	uint8_t isArrowAtk_07E: 1;

	// 名前：霊体攻撃か
	// 説明：霊体ダメージ判定に使用。
	uint8_t isGhostAtk_07E: 1;

	// 名前：無敵を貫通するか
	// 説明：ステップ等の無敵効果を無視します、TAEの完全無敵は無視できません。
	uint8_t isDisableNoDamage_07E: 1;

	// 名前：攻撃強度[SFX]
	// 説明：攻撃強度[SFX]
	int8_t atkPow_forSfx_07F;

	// 名前：攻撃方向[SFX]
	// 説明：攻撃方向[SFX]
	int8_t atkDir_forSfx_080;

	// 名前：対象：●敵対
	// 説明：対象：●敵対
	uint8_t opposeTarget_081: 1;

	// 名前：対象：○味方
	// 説明：対象：○味方
	uint8_t friendlyTarget_081: 1;

	// 名前：対象：自分
	// 説明：対象：自分
	uint8_t selfTarget_081: 1;

	// 名前：扉貫通チェックを行うか
	// 説明：扉貫通チェックを行うかどうか。○の場合は扉越しの対象を攻撃できるかどうかの判定を行います。
	uint8_t isCheckDoorPenetration_081: 1;

	// 名前：騎乗特攻か
	// 説明：騎乗中の騎乗特攻対象に攻撃を当てた場合、SAダメージに倍率補正が掛かる
	uint8_t isVsRideAtk_081: 1;

	// 名前：武器攻撃でも加算攻撃力を参照するか
	// 説明：武器攻撃でも加算攻撃力を参照するか
	uint8_t isAddBaseAtk_081: 1;

	// 名前：脅威度通知対象除外か
	// 説明：脅威度通知対象除外か
	uint8_t excludeThreatLvNotify_081: 1;

	// 名前：pad1
	uint8_t pad1_081: 1;

	// 名前：Behavior用識別値1
	// 説明：Behavior用識別値：特大ダメージ遷移
	uint8_t atkBehaviorId_082;

	// 名前：攻撃強度[SE]
	// 説明：攻撃強度[SE]
	int8_t atkPow_forSe_083;

	// 名前：SA攻撃力
	// 説明：NPCのみ。SAブレイク計算式に利用すする値
	float atkSuperArmor_084;

	// 名前：デカールID1（直接指定）
	// 説明：デカールID1（直接指定）
	int32_t decalId1_088;

	// 名前：デカールID2（直接指定）
	// 説明：デカールID2（直接指定）
	int32_t decalId2_08C;

	// 名前：発生時AI音ID
	// 説明：攻撃発生時に発生させるAI音のID
	int32_t AppearAiSoundId_090;

	// 名前：ヒット時AI音ID
	// 説明：ヒット時に発生させるAI音のID
	int32_t HitAiSoundId_094;

	// 名前：ヒット時振動効果(-1無効)
	// 説明：ヒット時の振動ID（-1無効）。次の3つのどれにも当てはまらない時の振動IDとなる
	int32_t HitRumbleId_098;

	// 名前：先端ヒット時振動ID
	// 説明：先端にヒットした時のヒット時振動ID（-1無効）
	int32_t HitRumbleIdByNormal_09C;

	// 名前：真ん中ヒット時振動ID
	// 説明：真ん中にヒットした時のヒット時振動ID（-1無効）
	int32_t HitRumbleIdByMiddle_0A0;

	// 名前：根本ヒット時振動ID
	// 説明：根本にヒットした時のヒット時振動ID（-1無効）
	int32_t HitRumbleIdByRoot_0A4;

	// 名前：剣閃SfxID_０
	// 説明：剣閃SfxID_０(-1無効)
	int32_t traceSfxId0_0A8;

	// 名前：根元剣閃ダミポリID_０
	// 説明：剣閃根元ダミポリID_０(-1無効)
	int32_t traceDmyIdHead0_0AC;

	// 名前：剣先剣閃ダミポリID_０
	// 説明：剣閃剣先ダミポリID_０
	int32_t traceDmyIdTail0_0B0;

	// 名前：剣閃SfxID_１
	// 説明：剣閃SfxID_１(-1無効)
	int32_t traceSfxId1_0B4;

	// 名前：根元剣閃ダミポリID_１
	// 説明：剣閃根元ダミポリID_１(-1無効)
	int32_t traceDmyIdHead1_0B8;

	// 名前：剣先剣閃ダミポリID_１
	// 説明：剣閃剣先ダミポリID_１
	int32_t traceDmyIdTail1_0BC;

	// 名前：剣閃SfxID_２
	// 説明：剣閃SfxID_２(-1無効)
	int32_t traceSfxId2_0C0;

	// 名前：根元剣閃ダミポリID_２
	// 説明：剣閃根元ダミポリID_２(-1無効)
	int32_t traceDmyIdHead2_0C4;

	// 名前：剣先剣閃ダミポリID_２
	// 説明：剣閃剣先ダミポリID_２
	int32_t traceDmyIdTail2_0C8;

	// 名前：剣閃SfxID_３
	// 説明：剣閃SfxID_３(-1無効)
	int32_t traceSfxId3_0CC;

	// 名前：根元剣閃ダミポリID_３
	// 説明：剣閃根元ダミポリID_３(-1無効)
	int32_t traceDmyIdHead3_0D0;

	// 名前：剣先剣閃ダミポリID_３
	// 説明：剣閃剣先ダミポリID_３
	int32_t traceDmyIdTail3_0D4;

	// 名前：剣閃SfxID_４
	// 説明：剣閃SfxID_４(-1無効)
	int32_t traceSfxId4_0D8;

	// 名前：根元剣閃ダミポリID_４
	// 説明：剣閃根元ダミポリID_４(-1無効)
	int32_t traceDmyIdHead4_0DC;

	// 名前：剣先剣閃ダミポリID_４
	// 説明：剣閃剣先ダミポリID_４
	int32_t traceDmyIdTail4_0E0;

	// 名前：剣閃SfxID_５
	// 説明：剣閃SfxID_５(-1無効)
	int32_t traceSfxId5_0E4;

	// 名前：根元剣閃ダミポリID_５
	// 説明：剣閃根元ダミポリID_５(-1無効)
	int32_t traceDmyIdHead5_0E8;

	// 名前：剣先剣閃ダミポリID_５
	// 説明：剣閃剣先ダミポリID_５
	int32_t traceDmyIdTail5_0EC;

	// 名前：剣閃SfxID_６
	// 説明：剣閃SfxID_６(-1無効)
	int32_t traceSfxId6_0F0;

	// 名前：根元剣閃ダミポリID_６
	// 説明：剣閃根元ダミポリID_６(-1無効)
	int32_t traceDmyIdHead6_0F4;

	// 名前：剣先剣閃ダミポリID_６
	// 説明：剣閃剣先ダミポリID_６
	int32_t traceDmyIdTail6_0F8;

	// 名前：剣閃SfxID_７
	// 説明：剣閃SfxID_７(-1無効)
	int32_t traceSfxId7_0FC;

	// 名前：根元剣閃ダミポリID_７
	// 説明：剣閃根元ダミポリID_７(-1無効)
	int32_t traceDmyIdHead7_100;

	// 名前：剣先剣閃ダミポリID_７
	// 説明：剣閃剣先ダミポリID_７
	int32_t traceDmyIdTail7_104;

	// 名前：あたり4 半径
	// 説明：球、カプセルの半径
	float hit4_Radius_108;

	// 名前：あたり5 半径
	// 説明：球、カプセルの半径
	float hit5_Radius_10C;

	// 名前：あたり6 半径
	// 説明：球、カプセルの半径
	float hit6_Radius_110;

	// 名前：あたり7 半径
	// 説明：球、カプセルの半径
	float hit7_Radius_114;

	// 名前：あたり8 半径
	// 説明：球、カプセルの半径
	float hit8_Radius_118;

	// 名前：あたり9 半径
	// 説明：球、カプセルの半径
	float hit9_Radius_11C;

	// 名前：あたり10 半径
	// 説明：球、カプセルの半径
	float hit10_Radius_120;

	// 名前：あたり11 半径
	// 説明：球、カプセルの半径
	float hit11_Radius_124;

	// 名前：あたり12 半径
	// 説明：球、カプセルの半径
	float hit12_Radius_128;

	// 名前：あたり13 半径
	// 説明：球、カプセルの半径
	float hit13_Radius_12C;

	// 名前：あたり14 半径
	// 説明：球、カプセルの半径
	float hit14_Radius_130;

	// 名前：あたり15 半径
	// 説明：球、カプセルの半径
	float hit15_Radius_134;

	// 名前：あたり4 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit4_DmyPoly1_138;

	// 名前：あたり5 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit5_DmyPoly1_13A;

	// 名前：あたり6 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit6_DmyPoly1_13C;

	// 名前：あたり7 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit7_DmyPoly1_13E;

	// 名前：あたり8ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit8_DmyPoly1_140;

	// 名前：あたり9 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit9_DmyPoly1_142;

	// 名前：あたり10 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit10_DmyPoly1_144;

	// 名前：あたり11 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit11_DmyPoly1_146;

	// 名前：あたり12 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit12_DmyPoly1_148;

	// 名前：あたり13ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit13_DmyPoly1_14A;

	// 名前：あたり14 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit14_DmyPoly1_14C;

	// 名前：あたり15 ダミポリ1
	// 説明：球、カプセル位置のダミポリ
	int16_t hit15_DmyPoly1_14E;

	// 名前：あたり4 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit4_DmyPoly2_150;

	// 名前：あたり5ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit5_DmyPoly2_152;

	// 名前：あたり6ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit6_DmyPoly2_154;

	// 名前：あたり7ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit7_DmyPoly2_156;

	// 名前：あたり8 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit8_DmyPoly2_158;

	// 名前：あたり9ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit9_DmyPoly2_15A;

	// 名前：あたり10 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit10_DmyPoly2_15C;

	// 名前：あたり11 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit11_DmyPoly2_15E;

	// 名前：あたり12 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit12_DmyPoly2_160;

	// 名前：あたり13 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit13_DmyPoly2_162;

	// 名前：あたり14 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit14_DmyPoly2_164;

	// 名前：あたり15 ダミポリ2
	// 説明：カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit15_DmyPoly2_166;

	// 名前：あたり4 部位
	// 説明：あたり部位
	uint8_t hit4_hitType_168;

	// 名前：あたり5 部位
	// 説明：あたり部位
	uint8_t hit5_hitType_169;

	// 名前：あたり6 部位
	// 説明：あたり部位
	uint8_t hit6_hitType_16A;

	// 名前：あたり7 部位
	// 説明：あたり部位
	uint8_t hit7_hitType_16B;

	// 名前：あたり8 部位
	// 説明：あたり部位
	uint8_t hit8_hitType_16C;

	// 名前：あたり9 部位
	// 説明：あたり部位
	uint8_t hit9_hitType_16D;

	// 名前：あたり10 部位
	// 説明：あたり部位
	uint8_t hit10_hitType_16E;

	// 名前：あたり11 部位
	// 説明：あたり部位
	uint8_t hit11_hitType_16F;

	// 名前：あたり12 部位
	// 説明：あたり部位
	uint8_t hit12_hitType_170;

	// 名前：あたり13 部位
	// 説明：あたり部位
	uint8_t hit13_hitType_171;

	// 名前：あたり14 部位
	// 説明：あたり部位
	uint8_t hit14_hitType_172;

	// 名前：あたり15 部位
	// 説明：あたり部位
	uint8_t hit15_hitType_173;

	// 名前：あたり4 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti4_Priority_174;

	// 名前：あたり5 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti5_Priority_175;

	// 名前：あたり6 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti6_Priority_176;

	// 名前：あたり7 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti7_Priority_177;

	// 名前：あたり8 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti8_Priority_178;

	// 名前：あたり9 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti9_Priority_179;

	// 名前：あたり10 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti10_Priority_17A;

	// 名前：あたり11 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti11_Priority_17B;

	// 名前：あたり12 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti12_Priority_17C;

	// 名前：あたり13 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti13_Priority_17D;

	// 名前：あたり14 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti14_Priority_17E;

	// 名前：あたり15 優先順位
	// 説明：優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti15_Priority_17F;

	// 名前：防御材質1[SFX]
	// 説明：ガード時のSFXに使用.1
	uint16_t defSfxMaterial1_180;

	// 名前：防御材質2[SE]
	// 説明：ガード時のSEに使用2
	uint16_t defSeMaterial2_182;

	// 名前：防御材質2[SFX]
	// 説明：ガード時のSFXに使用.2
	uint16_t defSfxMaterial2_184;

	// 名前：闇攻撃力補正値
	// 説明：PCのみ。闇攻撃力に掛ける倍率（弓の場合は、飛び道具を補正）
	uint16_t atkDarkCorrection_186;

	// 名前：闇攻撃力
	// 説明：NPCのみ。闇攻撃の追加ダメージ
	uint16_t atkDark_188;

	// 名前：pad
	// 説明：pad
	uint8_t pad5_18A: 1;

	// 名前：攻撃接触パリィ判定無効
	// 説明：新パリィ制御を無効化するかどうかのフラグです。攻撃側のダメージが、防御側でパリィ状態のキャラに接触した場合にパリィされたと判定する処理。
	uint8_t isDisableParry_18A: 1;

	// 名前：両手持ち時攻撃力ボーナス無効か
	// 説明：両手時の成長ステータス1.5倍適応を使わないようにする
	uint8_t isDisableBothHandsAtkBonus_18A: 1;

	// 名前：限定無敵（空中のみ）で無効化されるか
	// 説明：「無敵を貫通するか」が◯の場合、この設定は無視されます
	uint8_t isInvalidatedByNoDamageInAir_18A: 1;

	// 名前：pad1
	uint8_t pad2_18A: 4;

	// 名前：ダメージレベル 対プレイヤー
	// 説明：プレイヤーに対するダメージレベル。“0(デフォルト)”であれば使わない。“0(デフォルト)”以外の値域の意味は、《ダメージレベル》と同じ。
	int8_t dmgLevel_vsPlayer_18B;

	// 名前：状態異常攻撃力倍率補正
	// 説明：特殊効果の状態異常攻撃力に対して、倍率補正を行う。
	uint16_t statusAilmentAtkPowerCorrectRate_18C;

	// 名前：特殊効果攻撃力倍率補正（攻撃力ポイント）
	// 説明：特殊効果の～～攻撃力[point]に対して、倍率補正を行う。
	uint16_t spEffectAtkPowerCorrectRate_byPoint_18E;

	// 名前：特殊効果攻撃力倍率補正（攻撃力倍率）
	// 説明：特殊効果の～～攻撃力倍率に対して、倍率補正を行う。
	uint16_t spEffectAtkPowerCorrectRate_byRate_190;

	// 名前：特殊効果攻撃力倍率補正（最終攻撃力倍率）
	// 説明：特殊効果の攻撃側：～～ダメージ倍率に対して、倍率補正を行う。
	uint16_t spEffectAtkPowerCorrectRate_byDmg_192;

	// 名前：Behavior用識別値2
	// 説明：Behavior用識別値：特定の時だけダメージモーションを再生する 
	uint8_t atkBehaviorId_2_194;

	// 名前：投げダメージ属性
	// 説明：攻撃判定の投げダメージの属性。対応する特殊効果がかかるようになる。攻撃のATK_PATAM_THROWFLAG_TYPEが「2：投げ」の場合にのみ、機能を発揮する
	uint8_t throwDamageAttribute_195;

	// 名前：特殊効果状態異常補正（攻撃力ポイント）
	// 説明：特殊効果の「状態異常攻撃力倍率補正を適応するか」に対して、倍率補正を行う。
	uint16_t statusAilmentAtkPowerCorrectRate_byPoint_196;

	// 名前：攻撃属性補正ID上書き
	// 説明：攻撃属性を補正するパラメータのID上書き用
	int32_t overwriteAttackElementCorrectId_198;

	// 名前：デカール識別子1
	// 説明：デカール識別子1(3桁)
	int16_t decalBaseId1_19C;

	// 名前：デカール識別子2
	// 説明：デカール識別子2(3桁)
	int16_t decalBaseId2_19E;

	// 名前：武器リゲイン量補正値
	// 説明：武器リゲイン量補正値
	uint16_t wepRegainHpScale_1A0;

	// 名前：攻撃リゲイン量
	// 説明：攻撃リゲイン量
	uint16_t atkRegainHp_1A2;

	// 名前：リゲイン可能時間補正倍率
	// 説明：リゲイン可能時間補正倍率
	float regainableTimeScale_1A4;

	// 名前：リゲイン可能率補正倍率
	// 説明：リゲイン可能率補正倍率
	float regainableHpRateScale_1A8;

	// 名前：同一攻撃判定ID
	// 説明：同一攻撃判定ID
	int8_t regainableSlotId_1AC;

	// 名前：特殊属性バリエーション値
	// 説明：「特殊属性」と組み合わせて特殊属性によって発生するSFX、SEにバリエーションを持たせるための値(SEQ16473)
	uint8_t spAttributeVariationValue_1AD;

	// 名前：パリィ成立条件の正面角度オフセット
	// 説明：パリィ成立条件の【崩される側】の正面角度オフセット
	int16_t parryForwardOffset_1AE;

	// 名前：SA攻撃力補正値
	// 説明：PCのみ。武器に設定された【基本値】にかける補正値
	float atkSuperArmorCorrection_1B0;

	// 名前：防御材質バリエーション値
	// 説明：ガード時に使用される「防御材質1or2」と組み合わせてダメージSFX、SEのバリエーションを持たせるための値。(SEQ16473)
	uint8_t defSfxMaterialVariationValue_1B4;

	// 名前：pad
	uint8_t pad4_1B5[19];

} AtkParam;

#endif
