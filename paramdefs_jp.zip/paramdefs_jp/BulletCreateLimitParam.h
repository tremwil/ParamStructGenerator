/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_BulletCreateLimitParam_H
#define _PARAM_BulletCreateLimitParam_H
#include <stdint.h>

// BULLET_CREATE_LIMIT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BulletCreateLimitParam {

	// 名前：グループ内上限弾数
	// 説明：同一グループ内での作成上限数
	uint8_t limitNum_byGroup_000;

	// 名前：オーナー毎に制限するか
	// 説明：オーナー毎に制限するか
	uint8_t isLimitEachOwner_001: 1;

	// 名前：パディング
	// 説明：pad2
	uint8_t pad2_001: 7;

	// 名前：パディング
	// 説明：pad3
	uint8_t pad_002[30];

} BulletCreateLimitParam;

#endif
