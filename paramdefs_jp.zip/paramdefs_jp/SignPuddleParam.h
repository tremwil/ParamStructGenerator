/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SignPuddleParam_H
#define _PARAM_SignPuddleParam_H
#include <stdint.h>

// SIGN_PUDDLE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SignPuddleParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：簡易マッチエリアID
	// 説明：属している簡易マッチエリアのID
	int32_t matchAreaId_004;

	// 名前：pad1
	uint8_t pad1_008[24];

} SignPuddleParam;

#endif
