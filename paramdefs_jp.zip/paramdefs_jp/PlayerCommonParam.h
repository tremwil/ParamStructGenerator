/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PlayerCommonParam_H
#define _PARAM_PlayerCommonParam_H
#include <stdint.h>

// PLAYER_COMMON_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _PlayerCommonParam {

	// 名前：プレイヤーの自動フットエフェクトのSFX識別子[3桁]
	// 説明：自動フットエフェクトのSFXIDに使われる識別子です。XYYZZZのZZZにあたります。
	int32_t playerFootEffect_bySFX_000;

	// 名前：精密射撃時プレイヤー非表示フェード時間
	// 説明：精密射撃時にプレイヤーを非表示にするときのフェード時間です。単位は秒
	float snipeModeDrawAlpha_FadeTime_004;

	// 名前：プレイヤー強靭度 回復時間補正値
	// 説明：プレイヤーの強靭度回復時間の計算に使われる補正値です。
	float toughnessRecoverCorrection_008;

	// 名前：魔法記憶スロット初期値
	// 説明：魔法記憶スロット初期値
	uint8_t baseMagicSlotSize_00C;

	// 名前：タリスマン装備スロット初期値
	// 説明：タリスマン装備スロット初期値
	uint8_t baseAccSlotNum_00D;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved02_00E[2];

	// 名前：ドロップアイテム取得アニメーションID
	// 説明：ドロップアイテムを拾った時のアニメーションID
	int32_t animeID_DropItemPick_010;

	// 名前：プレイヤー耐性値回復量_睡眠[point/s]
	// 説明：プレイヤー耐性値回復量_睡眠[point/s]
	float resistRecoverPoint_Sleep_Player_014;

	// 名前：フレア上書き誘導性能[deg/s]
	// 説明：フレア上書き誘導性能[deg/s](-1:上書きなし)
	int32_t flareOverrideHomingAngle_018;

	// 名前：フレア上書き誘導停止距離[m]
	// 説明：フレア上書き誘導停止距離[m](-1:上書きなし)
	float flareOverrideHomingStopRange_01C;

	// 名前：ネムリアイテム取得時のアニメーションID
	// 説明：ネムリアイテム取得時のアニメーションID
	int32_t animeID_SleepCollectorItemPick_020;

	// 名前：武器属性解禁イベントフラグベースID
	// 説明：武器属性解禁イベントフラグベースID
	uint32_t unlockEventFlagBaseId_forWepAttr_024;

	// 名前：システム経由大ルーン発動用特殊効果ID
	// 説明：システムからの大ルーン発動の際に呼び出す特殊効果Id
	int32_t systemEnchant_BigRune_028;

	// 名前：ステータス不足 基本攻撃力低下量
	// 説明：ステータス不足 基本攻撃力低下量
	float lowStatus_AtkPowDown_02C;

	// 名前：ステータス不足 スタミナ消費倍率
	// 説明：ステータス不足 スタミナ消費倍率
	float lowStatus_ConsumeStaminaRate_030;

	// 名前：ステータス不足 弾き攻撃力
	// 説明：ステータス不足 弾き攻撃力
	int16_t lowStatus_AtkGuardBreak_034;

	// 名前：盾ステータス補正 判定ステータス最大値
	// 説明：盾の性能のステータス補正値を計算するときに使う、性能が上昇する最大ステータス値
	int16_t guardStatusCorrect_MaxStatusVal_036;

	// 名前：武器属性解禁イベントフラグステップ数
	// 説明：ベースIDから武器属性IDごとにどのぐらい間隔を空けるか。武器属性解禁イベントフラグID＝《武器属性解禁イベントフラグベースID》＋武器属性ID×《武器属性解禁イベントフラグステップ数》
	uint16_t unlockEventFlagStepNum_forWepAttr_038;

	// 名前：因果応報_反撃までの被ダメージ回数
	// 説明：因果応報_反撃までの被ダメージ回数
	uint16_t retributionMagic_damageCountNum_03A;

	// 名前：因果応報_反撃までの被ダメージ回数存続時間[s]
	// 説明：因果応報_反撃までの被ダメージ回数存続時間[s]
	uint16_t retributionMagic_damageCountRemainTime_03C;

	// 名前：因果応報_反撃魔法ダミポリID
	// 説明：因果応報_反撃魔法ダミポリID
	uint16_t retributionMagic_burstDmypolyId_03E;

	// 名前：因果応報_反撃魔法パラムID
	// 説明：因果応報_反撃魔法パラムID
	int32_t retributionMagic_burstMagicParamId_040;

	// 名前：騎乗精密射撃カメラオフセット高さ
	// 説明：騎乗精密射撃カメラオフセット高さ
	float chrAimCam_rideOffsetHeight_044;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved23_048[4];

	// 名前：矢筒の吸着ダミポリID
	// 説明：矢筒の吸着ダミポリID
	int32_t arrowCaseWepBindDmypolyId_04C;

	// 名前：ボルト筒の吸着ダミポリID
	// 説明：ボルト筒の吸着ダミポリID（ただしボルト筒単独の場合は矢筒のダミポリIDが使われる）
	int32_t boltPouchWepBindDmypolyId_050;

	// 名前：マルチ時クライアント瓶補正倍率
	// 説明：マルチ時クライアント瓶補正倍率(0.5指定で所持数半分に)
	float estusFlaskAllocateRate_054;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved38_058[2];

	// 名前：プレイヤー正面から見てキックを出せる角度
	// 説明：プレイヤー正面から見てキックを出せる角度
	uint8_t kickAcceptanceDeg_05A;

	// 名前：NPCプレイヤー用アナログ重量比率_軽量
	// 説明：NPCプレイヤー用アナログ重量比率[%]。軽量。
	uint8_t npcPlayerAnalogWeightRate_Light_05B;

	// 名前：NPCプレイヤー用アナログ重量比率_中量
	// 説明：NPCプレイヤー用アナログ重量比率[%]。中量。
	uint8_t npcPlayerAnalogWeightRate_Normal_05C;

	// 名前：NPCプレイヤー用アナログ重量比率_重量
	// 説明：NPCプレイヤー用アナログ重量比率[%]。重量。
	uint8_t npcPlayerAnalogWeightRate_Heavy_05D;

	// 名前：NPCプレイヤー用アナログ重量比率_重量過多
	// 説明：NPCプレイヤー用アナログ重量比率[%]。重量過多。
	uint8_t npcPlayerAnalogWeightRate_WeightOver_05E;

	// 名前：NPCプレイヤー用アナログ重量比率_超軽量
	// 説明：NPCプレイヤー用アナログ重量比率[%]。超軽量。
	uint8_t npcPlayerAnalogWeightRate_SuperLight_05F;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved45_060[4];

	// 名前：周回補正特殊効果基準ID
	// 説明：周回補正のためにかける特殊効果の基準ID
	int32_t clearCountCorrectBaseSpEffectId_064;

	// 名前：矢、ボルトのモデルIdオフセット
	// 説明：矢、ボルトモデルを表示する際に、スロット１に装備された場合のモデルIDに加えるオフセット。（モデルId+オフセット値）
	int32_t arrowBoltModelIdOffset_068;

	// 名前：矢、ボルトの残量によるモデルマスクの残数閾値_1段階[%]
	// 説明：矢、ボルトモデルを表示する際に、本数による表示マスクをかけるときの閾値の１段階判定値[%]。（この値より多ければ１段階表示）
	int8_t arrowBoltRemainingNumModelMaskThreshold1_06C;

	// 名前：矢、ボルトの残量によるモデルマスクの残数閾値_2段階[%]
	// 説明：矢、ボルトモデルを表示する際に、本数による表示マスクをかけるときの閾値の２段階判定値[%]。（この値より多ければ２段階表示）
	int8_t arrowBoltRemainingNumModelMaskThreshold2_06D;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved27_06E[2];

	// 名前：プレイヤー耐性値回復量_毒[point/s]
	// 説明：プレイヤー耐性値回復量_毒[point/s]
	float resistRecoverPoint_Poision_Player_070;

	// 名前：プレイヤー耐性値回復量_疫病[point/s]
	// 説明：プレイヤー耐性値回復量_疫病[point/s]
	float resistRecoverPoint_Desease_Player_074;

	// 名前：プレイヤー耐性値回復量_出血[point/s]
	// 説明：プレイヤー耐性値回復量_出血[point/s]
	float resistRecoverPoint_Blood_Player_078;

	// 名前：プレイヤー耐性値回復量_呪い[point/s]
	// 説明：プレイヤー耐性値回復量_呪い[point/s]
	float resistRecoverPoint_Curse_Player_07C;

	// 名前：プレイヤー耐性値回復量_冷気[point/s]
	// 説明：プレイヤー耐性値回復量_冷気[point/s]
	float resistRecoverPoint_Freeze_Player_080;

	// 名前：敵耐性値回復量_毒[point/s]
	// 説明：敵耐性値回復量_毒[point/s]
	float resistRecoverPoint_Poision_Enemy_084;

	// 名前：敵耐性値回復量_疫病[point/s]
	// 説明：敵耐性値回復量_疫病[point/s]
	float resistRecoverPoint_Desease_Enemy_088;

	// 名前：敵耐性値回復量_出血[point/s]
	// 説明：敵耐性値回復量_出血[point/s]
	float resistRecoverPoint_Blood_Enemy_08C;

	// 名前：敵耐性値回復量_呪い[point/s]
	// 説明：敵耐性値回復量_呪い[point/s]
	float resistRecoverPoint_Curse_Enemy_090;

	// 名前：敵耐性値回復量_冷気[point/s]
	// 説明：敵耐性値回復量_冷気[point/s]
	float resistRecoverPoint_Freeze_Enemy_094;

	// 名前：左手両手持ちリクエストのボタン長押し時間[s]
	// 説明：左手両手持ちするときのボタン入力時間
	float requestTimeLeftBothHand_098;

	// 名前：プレイヤー耐性値回復量_発狂[point/s]
	// 説明：プレイヤー耐性値回復量_発狂[point/s]
	float resistRecoverPoint_Madness_Player_09C;

	// 名前：素材アイテム取得アニメーションID
	// 説明：素材アイテムを拾った時のアニメーションID
	int32_t animeID_MaterialItemPick_0A0;

	// 名前：黄衣HPエスト瓶補正倍率 
	// 説明：黄衣HPエスト瓶補正倍率 
	float hpEstusFlaskAllocateRateForYellowMonk_0A4;

	// 名前：黄衣HPエスト瓶オフセット
	// 説明：黄衣HPエスト瓶オフセット
	int32_t hpEstusFlaskAllocateOffsetForYellowMonk_0A8;

	// 名前：黄衣MPエスト瓶補正倍率
	// 説明：黄衣MPエスト瓶補正倍率
	float mpEstusFlaskAllocateRateForYellowMonk_0AC;

	// 名前：黄衣MPエスト瓶オフセット
	// 説明：黄衣MPエスト瓶オフセット
	int32_t mpEstusFlaskAllocateOffsetForYellowMonk_0B0;

	// 名前：敵耐性値回復量_睡眠[point/s]
	// 説明：敵耐性値回復量_睡眠[point/s]
	float resistRecoverPoint_Sleep_Enemy_0B4;

	// 名前：敵耐性値回復量_発狂[point/s]
	// 説明：敵耐性値回復量_発狂[point/s]
	float resistRecoverPoint_Madness_Enemy_0B8;

	// 名前：状態異常_即死_即死アイテムID
	// 説明：状態異常_即死_即死アイテムID
	int32_t resistCurseItemId_0BC;

	// 名前：状態異常_即死_即死アイテム最大数
	// 説明：状態異常_即死_即死アイテム最大数
	uint8_t resistCurseItemMaxNum_0C0;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved_123_0C1[3];

	// 名前：状態異常_即死_即死アイテム所持特殊効果ベースID
	// 説明：状態異常_即死_即死アイテム所持特殊効果ベースID
	int32_t resistCurseItemSpEffectBaseId_0C4;

	// 名前：状態異常_即死_即死時アイテム抽選ID_マップ用
	// 説明：状態異常_即死_即死時アイテム抽選ID_マップ用
	int32_t resistCurseItemLotParamId_map_0C8;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved41_0CC[52];

} PlayerCommonParam;

#endif
