/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SoundCutsceneParam_H
#define _PARAM_SoundCutsceneParam_H
#include <stdint.h>

// SOUND_CUTSCENE_PARAM_ST
// Data Version: 5
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SoundCutsceneParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：カットシーン中のリバーブタイプ
	// 説明：カットシーン中に適応するリバーブタイプを指定します
	uint8_t ReverbType_004;

	// 名前：pad0
	uint8_t pad0_005[3];

	// 名前：カットシーン開始時通常BGM挙動
	// 説明：カットシーン開始時通常BGM挙動を指定します
	int16_t BgmBehaviorTypeOnStart_008;

	// 名前：カットシーン開始時ワンショットBGM挙動
	// 説明：カットシーン開始時ワンショットBGM挙動を指定します
	int16_t OneShotBgmBehaviorOnStart_00A;

	// 名前：カットシーン終了時にポストするSEID（カテゴリ：p)指定(-1:ポストしない)
	// 説明：カットシーン終了時にポストするSEID（カテゴリ：p)指定(-1:ポストしない)
	int32_t PostPlaySeId_00C;

	// 名前：カットシーン終了時にポストするSEID_スキップ時（カテゴリ：p)指定(-1:ポストしない)
	// 説明：カットシーン終了時にポストするSEID_スキップ時用（カテゴリ：p)指定(-1:ポストしない)
	int32_t PostPlaySeIdForSkip_010;

	// 名前：入場直後ミュート解除するカットシーン描画時間[秒](0より小さい：描画時間で解除しない)
	// 説明：入場直後のミュート解除するカットシーン描画時間[秒](0より小さい：描画時間で解除しない)
	float EnterMapMuteStopTimeOnDrawCutscene_014;

	// 名前：リザーブ
	// 説明：リザーブ
	uint8_t reserved_018[8];

} SoundCutsceneParam;

#endif
