/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_LoadBalancerDrawDistScaleParam_H
#define _PARAM_LoadBalancerDrawDistScaleParam_H
#include <stdint.h>

// LOAD_BALANCER_DRAW_DIST_SCALE_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _LoadBalancerDrawDistScaleParam {

	// 名前：Lv00
	// 説明：Lv00 描画距離スケール
	float Lv00_000;

	// 名前：Lv01
	// 説明：Lv01 描画距離スケール
	float Lv01_004;

	// 名前：Lv02
	// 説明：Lv02 描画距離スケール
	float Lv02_008;

	// 名前：Lv03
	// 説明：Lv03 描画距離スケール
	float Lv03_00C;

	// 名前：Lv04
	// 説明：Lv04 描画距離スケール
	float Lv04_010;

	// 名前：Lv05
	// 説明：Lv05 描画距離スケール
	float Lv05_014;

	// 名前：Lv06
	// 説明：Lv06 描画距離スケール
	float Lv06_018;

	// 名前：Lv07
	// 説明：Lv07 描画距離スケール
	float Lv07_01C;

	// 名前：Lv08
	// 説明：Lv08 描画距離スケール
	float Lv08_020;

	// 名前：Lv09
	// 説明：Lv09 描画距離スケール
	float Lv09_024;

	// 名前：Lv10
	// 説明：Lv10 描画距離スケール
	float Lv10_028;

	// 名前：Lv11
	// 説明：Lv11 描画距離スケール
	float Lv11_02C;

	// 名前：Lv12
	// 説明：Lv12 描画距離スケール
	float Lv12_030;

	// 名前：Lv13
	// 説明：Lv13 描画距離スケール
	float Lv13_034;

	// 名前：Lv14
	// 説明：Lv14 描画距離スケール
	float Lv14_038;

	// 名前：Lv15
	// 説明：Lv15 描画距離スケール
	float Lv15_03C;

	// 名前：Lv16
	// 説明：Lv16 描画距離スケール
	float Lv16_040;

	// 名前：Lv17
	// 説明：Lv17 描画距離スケール
	float Lv17_044;

	// 名前：Lv18
	// 説明：Lv18 描画距離スケール
	float Lv18_048;

	// 名前：Lv19
	// 説明：Lv19 描画距離スケール
	float Lv19_04C;

	// 名前：Lv20
	// 説明：Lv20 描画距離スケール
	float Lv20_050;

	// 名前：予備
	// 説明：予備
	uint8_t reserve_054[44];

} LoadBalancerDrawDistScaleParam;

#endif
