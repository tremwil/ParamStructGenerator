/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_BonfireWarpParam_H
#define _PARAM_BonfireWarpParam_H
#include <stdint.h>

// BONFIRE_WARP_PARAM_ST
// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BonfireWarpParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：イベントフラグID
	// 説明：解除条件イベントフラグID
	uint32_t eventflagId_004;

	// 名前：篝火エンティティID
	// 説明：篝火エンティティID
	uint32_t bonfireEntityId_008;

	// 名前：パッド
	// 説明：パディング。削除した旧作由来データが定義されてた場所
	uint8_t pad4_00C[2];

	// 名前：ソートID
	// 説明：篝火ワープサブカテゴリソートID。同じサブカテゴリ内の並び順（昇順）を指定する
	uint16_t bonfireSubCategorySortId_00E;

	// 名前：ワープ禁止アイコンID
	// 説明：ワープ禁止時のアイコンID
	uint16_t forbiddenIconId_010;

	// 名前：表示ズームステップ
	// 説明：篝火を表示するズームステップ（一番ズームアウトした状態が0、ズームするごとに+1）。「《表示ズームステップ》≦ 現在のズームステップ 」のときに表示される。デフォルトは 0（常に表示）
	uint8_t dispMinZoomStep_012;

	// 名前：選択可能ズームステップ
	// 説明：篝火を選択及びスナップ可能なズームステップ（一番ズームアウトした状態が0、ズームするごとに+1）。「《選択可能ズームステップ》≦ 現在の拡大段階 」のときに選択及びスナップ可能。デフォルトは 0（常に選択・スナップ可能）
	uint8_t selectMinZoomStep_013;

	// 名前：サブカテゴリID
	// 説明：篝火ワープサブカテゴリパラメータID(-1:無効)。どのサブカテゴリに属するかを設定する。無効なら篝火一覧に表示されない
	int32_t bonfireSubCategoryId_014;

	// 名前：クリア済イベントフラグID
	// 説明：クリア済みイベントフラグID(0:常にクリア済み扱い)
	uint32_t clearedEventFlagId_018;

	// 名前：アイコンID
	// 説明：アイコンID
	uint16_t iconId_01C;

	// 名前：表示設定M00
	// 説明：M00で表示するか
	uint8_t dispMask00_01E: 1;

	// 名前：表示設定M01
	// 説明：M01で表示するか
	uint8_t dispMask01_01E: 1;

	// 名前：パッド
	// 説明：pad1:6
	uint8_t pad1_01E: 6;

	// 名前：パッド
	// 説明：pad2
	uint8_t pad2_01F[1];

	// 名前：エリア番号
	// 説明：mAA_BB_CC_DD の AA 部分
	uint8_t areaNo_020;

	// 名前：グリッドX番号
	// 説明：mAA_BB_CC_DD の BB 部分
	uint8_t gridXNo_021;

	// 名前：グリッドZ番号
	// 説明：mAA_BB_CC_DD の CC 部分
	uint8_t gridZNo_022;

	// 名前：パディング
	// 説明：pad3
	uint8_t pad3_023[1];

	// 名前：X座標
	// 説明：X座標
	float posX_024;

	// 名前：Y座標
	// 説明：Y座標（使っていない）
	float posY_028;

	// 名前：Z座標
	// 説明：Z座標
	float posZ_02C;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-1)なら、何も表示しない
	int32_t textId1_030;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(0)なら、On扱いされる
	uint32_t textEnableFlagId1_034;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(0)なら、Off扱いされる
	uint32_t textDisableFlagId1_038;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-2)なら、何も表示しない
	int32_t textId2_03C;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(1)なら、On扱いされる
	uint32_t textEnableFlagId2_040;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(1)なら、Off扱いされる
	uint32_t textDisableFlagId2_044;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-3)なら、何も表示しない
	int32_t textId3_048;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(2)なら、On扱いされる
	uint32_t textEnableFlagId3_04C;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(2)なら、Off扱いされる
	uint32_t textDisableFlagId3_050;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-4)なら、何も表示しない
	int32_t textId4_054;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(3)なら、On扱いされる
	uint32_t textEnableFlagId4_058;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(3)なら、Off扱いされる
	uint32_t textDisableFlagId4_05C;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-5)なら、何も表示しない
	int32_t textId5_060;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(4)なら、On扱いされる
	uint32_t textEnableFlagId5_064;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(4)なら、Off扱いされる
	uint32_t textDisableFlagId5_068;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-6)なら、何も表示しない
	int32_t textId6_06C;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(5)なら、On扱いされる
	uint32_t textEnableFlagId6_070;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(5)なら、Off扱いされる
	uint32_t textDisableFlagId6_074;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-7)なら、何も表示しない
	int32_t textId7_078;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(6)なら、On扱いされる
	uint32_t textEnableFlagId7_07C;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(6)なら、Off扱いされる
	uint32_t textDisableFlagId7_080;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-8)なら、何も表示しない
	int32_t textId8_084;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(7)なら、On扱いされる
	uint32_t textEnableFlagId8_088;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(7)なら、Off扱いされる
	uint32_t textDisableFlagId8_08C;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType1_090;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType2_091;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType3_092;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType4_093;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType5_094;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType6_095;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType7_096;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType8_097;

	// 名前：点火前SFXダミポリID0
	// 説明：篝火点火前にSFXを出すダミポリID
	int32_t noIgnitionSfxDmypolyId_0_098;

	// 名前：点火前SFXID0
	// 説明：篝火点火前に出すSFXID。点火したら消える。-1の場合はSFXを出さない。
	int32_t noIgnitionSfxId_0_09C;

	// 名前：点火前SFXダミポリID1
	// 説明：篝火点火前にSFXを出すダミポリID
	int32_t noIgnitionSfxDmypolyId_1_0A0;

	// 名前：点火前SFXID1
	// 説明：篝火点火前に出すSFXID。点火したら消える。-1の場合はSFXを出さない。
	int32_t noIgnitionSfxId_1_0A4;

	// 名前：unkA8
	int32_t unkA8_0A8;

	// 名前：unkAC
	int32_t unkAC_0AC;

	// 名前：unkB0
	int32_t unkB0_0B0;

	// 名前：unkB4
	int32_t unkB4_0B4;

	// 名前：unkB8
	int32_t unkB8_0B8;

	// 名前：unkBC
	int32_t unkBC_0BC;

	// 名前：unkC0
	int32_t unkC0_0C0;

	// 名前：unkC4
	int32_t unkC4_0C4;

	// 名前：unkC8
	int32_t unkC8_0C8;

	// 名前：unkCC
	int32_t unkCC_0CC;

	// 名前：unkD0
	int32_t unkD0_0D0;

	// 名前：unkD4
	int32_t unkD4_0D4;

	// 名前：unkD8
	int32_t unkD8_0D8;

	// 名前：unkDC
	int32_t unkDC_0DC;

	// 名前：unkE0
	int32_t unkE0_0E0;

	// 名前：unkE4
	int32_t unkE4_0E4;

	// 名前：unkE8
	int32_t unkE8_0E8;

} BonfireWarpParam;

#endif
