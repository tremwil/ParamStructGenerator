/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PerformanceCheckParam_H
#define _PARAM_PerformanceCheckParam_H
#include <stdint.h>

// PERFORMANCE_CHECK_PARAM
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 202
typedef struct _PerformanceCheckParam {

	// 名前：報告先_職種タグ
	// 説明：報告先_職種タグ
	uint8_t workTag_000;

	// 名前：報告先_カテゴリタグ
	// 説明：報告先_カテゴリタグ
	uint8_t categoryTag_001;

	// 名前：比較記号
	// 説明：比較記号
	uint8_t compareType_002;

	// 名前：予約1
	// 説明：予約1
	uint8_t dummy1_003[1];

	// 名前：比較数値
	// 説明：比較数値
	float compareValue_004;

	// 名前：予約2
	// 説明：予約2
	uint8_t dummy2_008[8];

	// 名前：報告先_userタグ
	// 説明：報告先_パフォーマンス人物タグ
	wchar_t userTag_010[16];

} PerformanceCheckParam;

#endif
