/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_HitMtrlParam_H
#define _PARAM_HitMtrlParam_H
#include <stdint.h>

// HIT_MTRL_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _HitMtrlParam {

	// 名前：音半径倍率
	// 説明：1倍のときは普通。0にすると音半径が0になる（SEとSFXは無関係のゲーム的なパラメータ）
	float aiVolumeRate_000;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果0
	// 説明：キャラがヒットマテリアルを踏んだ時に、設定した特殊効果0が発揮される
	int32_t spEffectIdOnHit0_004;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果1
	// 説明：キャラがヒットマテリアルを踏んだ時に、設定した特殊効果1が発揮される
	int32_t spEffectIdOnHit1_008;

	// 名前：フットエフェクトの高さタイプ
	// 説明：フットエフェクトを発生させる高さ
	uint8_t footEffectHeightType_00C: 2;

	// 名前：フットエフェクトの向きタイプ
	// 説明：フットエフェクトの発生向き
	uint8_t footEffectDirType_00C: 2;

	// 名前：地面の高さタイプ
	// 説明：水面などアイテムを浮かせるとき用
	uint8_t floorHeightType_00C: 2;

	// 名前：落下ダメージ無効か
	// 説明：落下ダメージを受けない床の場合に 1 を設定する
	uint8_t disableFallDamage_00C: 1;

	// 名前：サウンド反響用硬い材質か？
	// 説明：サウンド反響用 硬い材質か？(0:やわらかい,1:かたい)
	uint8_t isHardnessForSoundReverb_00C: 1;

	// 名前：材質の固さタイプ
	// 説明：材質の固さ。剛体のソフトコンタクト処理に使用。
	uint8_t hardnessType_00D;

	// 名前：pad
	// 説明：pad
	uint8_t pad2_00E[6];

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果0　2周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果0　2周目
	int32_t spEffectIdOnHit0_ClearCount_2_014;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果0　3周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果0　3周目
	int32_t spEffectIdOnHit0_ClearCount_3_018;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果0　4周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果0　4周目
	int32_t spEffectIdOnHit0_ClearCount_4_01C;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果0　5周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果0　5周目
	int32_t spEffectIdOnHit0_ClearCount_5_020;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果0　6周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果0　6周目
	int32_t spEffectIdOnHit0_ClearCount_6_024;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果0　7周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果0　7周目
	int32_t spEffectIdOnHit0_ClearCount_7_028;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果0　8周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果0　8周目
	int32_t spEffectIdOnHit0_ClearCount_8_02C;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果1　2周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果1　2周目
	int32_t spEffectIdOnHit1_ClearCount_2_030;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果1　3周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果1　3周目
	int32_t spEffectIdOnHit1_ClearCount_3_034;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果1　4周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果1　4周目
	int32_t spEffectIdOnHit1_ClearCount_4_038;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果1　5周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果1　5周目
	int32_t spEffectIdOnHit1_ClearCount_5_03C;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果1　6周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果1　6周目
	int32_t spEffectIdOnHit1_ClearCount_6_040;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果1　7周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果1　7周目
	int32_t spEffectIdOnHit1_ClearCount_7_044;

	// 名前：ヒットマテリアルを踏んだ時にかかる特殊効果1　8周目
	// 説明：ヒットマテリアルを踏んだ時にかかる特殊効果1　8周目
	int32_t spEffectIdOnHit1_ClearCount_8_048;

	// 名前：ヒットマテリアル差し替え(雨)
	// 説明：天候(雨)によるヒットマテリアル変更先ID(-1：変更を行なわない)
	int16_t replaceMateiralId_Rain_04C;

	// 名前：pad
	// 説明：pad
	uint8_t pad4_04E[2];

	// 名前：濡れ特殊効果ID_00
	// 説明：濡れ用特殊効果00
	int32_t spEffectId_forWet00_050;

	// 名前：濡れ特殊効果ID_01
	// 説明：濡れ用特殊効果01
	int32_t spEffectId_forWet01_054;

	// 名前：濡れ特殊効果ID_02
	// 説明：濡れ用特殊効果02
	int32_t spEffectId_forWet02_058;

	// 名前：濡れ特殊効果ID_03
	// 説明：濡れ用特殊効果03
	int32_t spEffectId_forWet03_05C;

	// 名前：濡れ特殊効果ID_04
	// 説明：濡れ用特殊効果04
	int32_t spEffectId_forWet04_060;

} HitMtrlParam;

#endif
