/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MenuCommonParam_H
#define _PARAM_MenuCommonParam_H
#include <stdint.h>

// MENU_COMMON_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MenuCommonParam {

	// 名前：ソロプレイ死亡時フェードアウト開始時間[秒]
	// 説明：ソロプレイ死亡時で「YOU DIED」表示後、何秒経過したらフェードアウトを開始するか
	float soloPlayDeath_ToFadeOutTime_000;

	// 名前：ホワイト、ブラックゴースト死亡時フェードアウト開始時間[秒]
	// 説明：ホワイト、ブラックゴースト死亡時で「YOU DIED」表示後、何秒経過したらフェードアウトを開始するか
	float partyGhostDeath_ToFadeOutTime_004;

	// 名前：プレイヤー最大HPの上限
	// 説明：HPゲージ表示の際に、リソースで用意されたゲージの長さの何％を使うかを算出するために使われます。
	int32_t playerMaxHpLimit_008;

	// 名前：プレイヤー最大MPの上限
	// 説明：MPゲージ表示の際に、リソースで用意されたゲージの長さの何％を使うかを算出するために使われます。
	int32_t playerMaxMpLimit_00C;

	// 名前：プレイヤー最大SPの上限
	// 説明：SPゲージ表示の際に、リソースで用意されたゲージの長さの何％を使うかを算出するために使われます。
	int32_t playerMaxSpLimit_010;

	// 名前：アクションパネル切り替え判定_プレイヤー速度[m/sec]
	// 説明：アクションパネル切り替え可能なプレイヤーの速度。この速度以下なら切り替え可能
	float actionPanelChangeThreshold_Vel_014;

	// 名前：アクションパネル切り替え判定_プレイヤー速度判定時間[sec]
	// 説明：アクションパネル切り替え可能なプレイヤーの速度を出すための考慮時間。この時間の平均速度を使う(システム的に最大４秒)
	float actionPanelChangeThreshold_PassTime_018;

	// 名前：キーガイドアイコンの上下位置
	// 説明：キーガイドアイコンの上下位置(+:上, -:下)
	int32_t kgIconVspace_01C;

	// 名前：カーソルの選択半径[px]
	// 説明：カーソル位置がこの半径以内にあれば選択していることになる
	float worldMapCursorSelectRadius_020;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved8_024[4];

	// 名前：デカールオフセット（左右）
	// 説明：デカールの表示位置オフセット左右方向
	int32_t decalPosOffsetX_028;

	// 名前：デカールオフセット（上下）
	// 説明：デカールの表示位置オフセット上下方向
	int32_t decalPosOffsetY_02C;

	// 名前：見つかりそうFE：Searchアイコンの表示時間[秒]
	// 説明：見つかりそうFEのSearchアイコンがフェードインし始めてから、フェードアウトされ始めるまでの秒数
	float targetStateSearchDurationTime_030;

	// 名前：見つかりそうFE：Battleアイコンの表示時間[秒]
	// 説明：見つかりそうFEのBattleアイコンがフェードインし始めてから、フェードアウトされ始めるまでの秒数
	float targetStateBattleDurationTime_034;

	// 名前：カーソルの移動スピード[px/sec]
	// 説明：スムーズに移動するときの移動スピード
	float worldMapCursorSpeed_038;

	// 名前：カーソルの１回目の移動距離[px]
	// 説明：最初の入力のときに、カッと一度だけ移動する距離
	float worldMapCursorFirstDistance_03C;

	// 名前：カーソルの1回目の移動の遅延時間[sec]
	// 説明：最初の入力のときに、カッと一度だけ移動するときにかかる時間
	float worldMapCursorFirstDelay_040;

	// 名前：カーソルの移動までのウェイト[sec]
	// 説明：入力してから、スムーズに移動するまでの待機時間
	float worldMapCursorWaitTime_044;

	// 名前：カーソルのスナップ半径[px]
	// 説明：この半径よりも近くにカーソルを移動すると吸着を開始する（スナップモード用）
	float worldMapCursorSnapRadius_048;

	// 名前：カーソルのスナップ時間[sec]
	// 説明：吸着を開始して、完了するまでにかかる時間
	float worldMapCursorSnapTime_04C;

	// 名前：アイテム取得ログ：１行の表示時間[sec]
	// 説明：１行分のログを追加してフェードアウトするまでの時間。行ごとにタイマーがある
	float itemGetLogAliveTime_050;

	// 名前：プレイヤー最大SA（体幹値）の上限
	// 説明：SAゲージ表示の際に、リソースで用意されたゲージの長さの何％を使うかを算出するために使われます。
	int32_t playerMaxSaLimit_054;

	// 名前：地下地図切り替え可能イベントフラグID
	// 説明：地下地図に切り替え可能かを管理するイベントフラグIDを指定する。このイベントフラグIDがONのときに、地下地図への切り替えが可能になる
	uint32_t worldMap_IsChangeableLayerEventFlagId_058;

	// 名前：踏破範囲の追加解禁距離[m]
	// 説明：プレイヤーを中心として4方向へ拡張する距離(m)。この範囲を踏破したことにする
	float worldMap_TravelMargin_05C;

	// 名前：スクロール前後の待機時間[sec]
	// 説明：運営告知の長い文章をスクロールする前後に待機する秒数。例えば3秒なら前と後ろとで合計6秒待機する
	float systemAnnounceScrollBufferTime_060;

	// 名前：スクロールする速度[px/sec]
	// 説明：運営告知の長い文章をスクロールするときのスクロール速度（ピクセル/秒）。画面サイズに依存しない。メニュー全体を1920x1080として考える
	int32_t systemAnnounceScrollSpeed_064;

	// 名前：スクロールしないときの表示時間[sec]
	// 説明：運営告知のスクロールを必要としない短い文章だったときに表示する秒数
	float systemAnnounceNoScrollWaitTime_068;

	// 名前：スクロールする回数
	// 説明：運営告知の長い文章をスクロールするときに繰り返す回数
	uint8_t systemAnnounceScrollCount_06C;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved17_06D[3];

	// 名前：表示距離_メモマーカー[m]
	// 説明：コンパスに表示するメモマーカーの表示距離[m]。この距離よりも近いものは表示される
	float compassMemoDispDistance_070;

	// 名前：表示距離_篝火[m]
	// 説明：コンパスに表示する篝火の表示距離[m]。この距離よりも近いものは表示される
	float compassBonfireDispDistance_074;

	// 名前：目的地マーカーのゴール判定距離[m]
	// 説明：目的地マーカーのゴール判定距離[m]。この距離よりも近付いたときに目的地マーカーは消える
	float markerGoalThreshold_078;

	// 名前：彩度・明度スライダーの移動量[%/sec]
	// 説明：カラーコントロールの彩度・明度スライダーの移動量[%/sec]。それぞれの値を0%～100%としたときに1秒で移動する最大量。アナログスティックで操作するため、入力値で割合になる
	float svSliderStep_07C;

	// 名前：OPムービー前のウェイト[sec]
	// 説明：OPムービー再生前のウェイト時間。＞SEQ 15261
	float preOpeningMovie_WaitSec_080;

	// 名前：キーガイドアイコンのスケール[%]
	// 説明：キーガイドアイコンのスケール値。100%がテクスチャサイズそのまま
	float kgIconScale_084;

	// 名前：パッド操作一覧用のキーガイドアイコンのスケール[%]
	// 説明：パッド操作一覧用のキーガイドアイコンのスケール値。100%がテクスチャサイズそのまま
	float kgIconScale_forTable_088;

	// 名前：パッド操作一覧用のキーガイドアイコンの上下位置
	// 説明：パッド操作一覧用のキーガイドアイコンの上下位置(+:上, -:下)
	int32_t kgIconVspace_forTable_08C;

	// 名前：キーコンフィグ用のキーガイドアイコンのスケール[%]
	// 説明：キーコンフィグ用のキーガイドアイコンのスケール値。100%がテクスチャサイズそのまま
	float kgIconScale_forConfig_090;

	// 名前：キーコンフィグ用のキーガイドアイコンの上下位置
	// 説明：キーコンフィグ用のキーガイドアイコンの上下位置(+:上, -:下)
	int32_t kgIconVspace_forConfig_094;

	// 名前：未探索マスク_探索済み範囲[m]
	// 説明：未探索マスクを探索済みにする範囲[m]（半径）。プレイヤーを中心とした円形を探索済みとする
	float worldMap_SearchRadius_098;

	// 名前：トースト表示時間[sec]
	// 説明：チュートリアル（トースト通知）の表示時間[sec]。この時間が経過したら自動的に閉じられる
	float tutorialDisplayTime_09C;

	// 名前：表示距離_協力/救援ゲスト側：ホスト
	// 説明：コンパスに表示する他プレイヤー（味方ホスト）の表示距離[m]。この距離以上離れているとコンパスに表示される
	float compassFriendHostInnerDistance_0A0;

	// 名前：表示距離_敵対ゲスト側：ホスト
	// 説明：コンパスに表示する他プレイヤー（敵ホスト）の表示距離[m]。この距離以上離れているとコンパスに表示される
	float compassEnemyHostInnerDistance_0A4;

	// 名前：表示距離_ホスト/協力/救援ホスト側：協力/救援ゲスト
	// 説明：コンパスに表示する他プレイヤー（味方ゲスト）の表示距離[m]。この距離以上離れているとコンパスに表示される
	float compassFriendGuestInnerDistance_0A8;

	// 名前：カットシーンのキーガイド表示時間[秒]
	// 説明：カットシーンスキップの事前入力があってからキーガイドを表示し続ける時間。キーガイドを表示中しかスキップ入力は受け付けないため、スキップ入力受付時間とも言える
	float cutsceneKeyGuideAliveTime_0AC;

	// 名前：HPゲージ：常に表示する割合[%]
	// 説明：[HUD:Auto設定]HP割合。HP割合がこの数値以下なら、HPゲージを常に表示する。割合と現在値はOR条件（どちらかを満たせば表示）
	float autoHideHpThresholdRatio_0B0;

	// 名前：HPゲージ：常に表示する現在値
	// 説明：[HUD:Auto設定]HP現在値。HP現在値がこの数値以下なら、HPゲージを常に表示する。割合と現在値はOR条件（どちらかを満たせば表示）
	int32_t autoHideHpThresholdValue_0B4;

	// 名前：MPゲージ：常に表示する割合[%]
	// 説明：[HUD:Auto設定]MP割合。MP割合がこの数値以下なら、MPゲージを常に表示する。割合と現在値はOR条件（どちらかを満たせば表示）
	float autoHideMpThresholdRatio_0B8;

	// 名前：MPゲージ：常に表示する現在値
	// 説明：[HUD:Auto設定]MP現在値。MP現在値がこの数値以下なら、MPゲージを常に表示する。割合と現在値はOR条件（どちらかを満たせば表示）
	int32_t autoHideMpThresholdValue_0BC;

	// 名前：SPゲージ：常に表示する割合[%]
	// 説明：[HUD:Auto設定]SP割合。SP割合がこの数値以下なら、SPゲージを常に表示する。割合と現在値はOR条件（どちらかを満たせば表示）
	float autoHideSpThresholdRatio_0C0;

	// 名前：SPゲージ：常に表示する現在値
	// 説明：[HUD:Auto設定]SP現在値。SP現在値がこの数値以下なら、SPゲージを常に表示する。割合と現在値はOR条件（どちらかを満たせば表示）
	int32_t autoHideSpThresholdValue_0C4;

	// 名前：ズームアニメーション時間[秒]
	// 説明：世界地図：ズームアニメーションをする時間[秒]
	float worldMapZoomAnimationTime_0C8;

	// 名前：最小アイコン表示倍率
	// 説明：世界地図：ズームステップ0のときの地図ポイントアイコンの表示倍率(0.0～1.0)。ズームステップ2のときに等倍(1.0)。そこから拡大率に合わせてアイコン倍率も補間される
	float worldMapIconScaleMin_0CC;

	// 名前：地図ポイント単位踏破範囲解禁時の追加解禁距離[m]
	// 説明：世界地図：地図ポイント単位踏破範囲解禁時の追加解禁距離[m]。遠見台など地図ポイントが解禁されたときに踏破範囲を解禁する。地図ポイントを中心に4方向に追加で拡張する距離
	float worldMap_TravelMargin_Point_0D0;

	// 名前：表示可能領域（左端）
	// 説明：敵HPゲージの中心座標がどこまで左端にいけるか。中心座標なのでゲージ本体のサイズも含む
	uint16_t enemyTagSafeLeft_0D4;

	// 名前：表示可能領域（右端）
	// 説明：敵HPゲージの中心座標がどこまで右端にいけるか。中心座標なのでゲージ本体のサイズも含む
	uint16_t enemyTagSafeRight_0D6;

	// 名前：表示可能領域（上端）
	// 説明：敵HPゲージの中心座標がどこまで上端にいけるか。中心座標なのでゲージ本体のサイズも含む
	uint16_t enemyTagSafeTop_0D8;

	// 名前：表示可能領域（下端）
	// 説明：敵HPゲージの中心座標がどこまで下端にいけるか。中心座標なのでゲージ本体のサイズも含む
	uint16_t enemyTagSafeBottom_0DA;

	// 名前：表示回復量の閾値
	// 説明：回復時にPC馬HPゲージを表示するかの閾値。「一度に一定値以上増加したらHPバーを表示する」の”一定値”
	uint32_t pcHorseHpRecoverDispThreshold_0DC;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved33_0E0[32];

} MenuCommonParam;

#endif
