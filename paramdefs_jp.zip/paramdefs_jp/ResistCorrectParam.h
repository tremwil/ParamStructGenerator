/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ResistCorrectParam_H
#define _PARAM_ResistCorrectParam_H
#include <stdint.h>

// RESIST_CORRECT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ResistCorrectParam {

	// 名前：1回目発動後加算pt
	// 説明：状態異常が1回発動した後に耐性値に加算される値
	float addPoint1_000;

	// 名前：2回目発動後加算pt
	// 説明：状態異常が2回発動した後に耐性値に加算される値
	float addPoint2_004;

	// 名前：3回目発動後加算pt
	// 説明：状態異常が3回発動した後に耐性値に加算される値
	float addPoint3_008;

	// 名前：4回目発動後加算pt
	// 説明：状態異常が4回発動した後に耐性値に加算される値
	float addPoint4_00C;

	// 名前：5回目発動後加算pt
	// 説明：状態異常が5回発動した後に耐性値に加算される値
	float addPoint5_010;

	// 名前：1回目発動後倍率
	// 説明：状態異常が1回発動した後に耐性値に掛かる倍率
	float addRate1_014;

	// 名前：2回目発動後倍率
	// 説明：状態異常が2回発動した後に耐性値に掛かる倍率
	float addRate2_018;

	// 名前：3回目発動後倍率
	// 説明：状態異常が3回発動した後に耐性値に掛かる倍率
	float addRate3_01C;

	// 名前：4回目発動後倍率
	// 説明：状態異常が4回発動した後に耐性値に掛かる倍率
	float addRate4_020;

	// 名前：5回目発動後倍率
	// 説明：状態異常が5回発動した後に耐性値に掛かる倍率
	float addRate5_024;

} ResistCorrectParam;

#endif
