/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_NpcThinkParam_H
#define _PARAM_NpcThinkParam_H
#include <stdint.h>

// NPC_THINK_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _NpcThinkParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：ロジックスクリプトID
	// 説明：スクリプトで作成したロジックのIDを設定します。
	int32_t logicId_004;

	// 名前：戦闘ゴールID
	// 説明：戦闘ゴールID
	int32_t battleGoalID_008;

	// 名前：索敵視覚_距離[m]
	// 説明：索敵視覚による索敵範囲.
	uint16_t searchEye_dist_00C;

	// 名前：索敵視覚_角度（幅）[deg]
	// 説明：索敵視覚による索敵範囲.
	uint8_t searchEye_angY_00E;

	// 名前：巨大敵を迂回しないか
	// 説明：巨大敵を迂回しないか
	uint8_t isNoAvoidHugeEnemy_00F: 1;

	// 名前：納刀抜刀するか
	// 説明：納刀抜刀するか
	uint8_t enableWeaponOnOff_00F: 1;

	// 名前：ロックダミポリ(エネミー用)を狙うか
	// 説明：ロックダミポリ(エネミー用)を狙うか
	uint8_t targetAILockDmyPoly_00F: 1;

	// 名前：パディング
	uint8_t pad8_00F: 5;

	// 名前：遠隔攻撃用特殊効果ID
	// 説明：遠隔攻撃用特殊効果ID
	int32_t spEffectId_RangedAttack_010;

	// 名前：索敵Lv1ターゲット忘れる時間[sec]
	// 説明：索敵Lv1ターゲット忘れる時間。
	float searchTargetLv1ForgetTime_014;

	// 名前：索敵Lv2ターゲット忘れる時間[sec]
	// 説明：索敵Lv2ターゲット忘れる時間。
	float searchTargetLv2ForgetTime_018;

	// 名前：敵壁接触時のBackHome時間[sec]
	// 説明：ブロックをさえぎる敵壁に接触したとき、BackToHomeゴールの寿命
	float BackHomeLife_OnHitEneWal_01C;

	// 名前：視覚ターゲット忘れる時間[sec]
	// 説明：視覚ターゲット忘れる時間。
	float SightTargetForgetTime_020;

	// 名前：動けなくなったときに行うEzState番号
	// 説明：破壊可能なオブジェクトによって動きが止まっている場合、自動的に実行する行動。
	int32_t idAttackCannotMove_024;

	// 名前：聴覚_距離[m]
	// 説明：聴覚による索敵範囲.。
	float ear_dist_028;

	// 名前：仲間呼び 応答アクションアニメID
	// 説明：応答する時のアニメID(EzStateAnimID)
	int32_t callHelp_ActionAnimId_02C;

	// 名前：仲間呼び_仲間呼びアクションID
	// 説明：仲間呼ぶときのアクションID(EzStateAnimID)
	int32_t callHelp_CallActionId_030;

	// 名前：視覚_距離[m]
	// 説明：視覚による索敵範囲.
	uint16_t eye_dist_034;

	// 名前：行動時ガード使用するか
	// 説明：行動にガードするか（帰宅時、ターゲットの方を見ている時想定）
	uint8_t isGuard_Act_036;

	// 名前：パディング
	uint8_t pad6_037[1];

	// 名前：聴覚　影響カット距離[m]
	// 説明：音源のサイズを小さくする距離。この距離未満の音が聞こえなくなります。
	uint16_t ear_soundcut_dist_038;

	// 名前：嗅覚_距離[m]
	// 説明：嗅覚による索敵範囲.
	uint16_t nose_dist_03A;

	// 名前：何があっても帰宅する距離[m]
	// 説明：COMMON_SetBattleActLogicの引き数
	uint16_t maxBackhomeDist_03C;

	// 名前：戦闘しつつ帰宅する距離[m]
	// 説明：COMMON_SetBattleActLogicの引き数
	uint16_t backhomeDist_03E;

	// 名前：巣に帰るのをあきらめて戦闘する距離[m]
	// 説明：COMMON_SetBattleActLogicの引き数
	uint16_t backhomeBattleDist_040;

	// 名前：敵を意識しているときの非戦闘行動時間[sec]
	// 説明：COMMON_SetBattleActLogicの引き数
	uint16_t nonBattleActLife_042;

	// 名前：帰宅時：ターゲットを見ている時間[sec]
	// 説明：帰宅時：ターゲットを見ている時間[sec]
	uint16_t BackHome_LookTargetTime_044;

	// 名前：帰宅時：ターゲットを見ている距離[m]
	// 説明：帰宅時：ターゲットを見ている距離[m]
	uint16_t BackHome_LookTargetDist_046;

	// 名前：音ターゲット忘れる時間[sec]
	// 説明：音ターゲット忘れる時間。
	float SoundTargetForgetTime_048;

	// 名前：戦闘開始距離[m]
	uint16_t BattleStartDist_04C;

	// 名前：仲間呼び 自分の仲間グループID
	// 説明：自分の仲間グループID
	uint16_t callHelp_MyPeerId_04E;

	// 名前：仲間呼び 呼ぶ仲間グループID
	// 説明：仲間を呼ぶ対象となる仲間グループID
	uint16_t callHelp_CallPeerId_050;

	// 名前：ダメージ影響率[％]
	// 説明：ダメージ影響率取得(ターゲットシステム評価情報)
	uint16_t targetSys_DmgEffectRate_052;

	// 名前：チーム攻撃影響力[0-100]
	// 説明：チーム内の同時攻撃人数を決めるための値。値を大きくすると、同時に攻撃参加できる人数が少なくなる。
	uint8_t TeamAttackEffectivity_054;

	// 名前：視覚_角度（高さ）[deg]
	// 説明：視覚による索敵範囲.
	uint8_t eye_angX_055;

	// 名前：視覚_角度（幅）[deg]
	// 説明：視覚による索敵範囲.
	uint8_t eye_angY_056;

	// 名前：暗闇影響しない
	// 説明：警戒視覚_距離、戦闘開始距離が暗闇による影響を受けないようにするか
	uint8_t disableDark_057;

	// 名前：キャラバンでの役割
	// 説明：キャラバンでの役割
	uint8_t caravanRole_058;

	// 名前：仲間呼び_ターゲットとの最低距離[m]
	// 説明：この値より近い場合は仲間呼びできない.
	uint8_t callHelp_CallValidMinDistTarget_059;

	// 名前：仲間呼び_仲間を呼ぶ有効距離[m]
	// 説明：この値より仲間が遠い場合は呼ばない。
	uint8_t callHelp_CallValidRange_05A;

	// 名前：仲間呼び 応答してから忘れる時間[sec]
	// 説明：応答する時間
	uint8_t callHelp_ForgetTimeByArrival_05B;

	// 名前：応答時の待機最小時間[ssm=>ss．mSec]
	// 説明：応答ゴールの最初の待機ゴールでの最小時間[101=>10．1sec]
	uint8_t callHelp_MinWaitTime_05C;

	// 名前：応答時の待機最大時間[ssm=>ss．mSec]
	// 説明：応答ゴールの最初の待機ゴールでの最大時間[101=>10．1sec]
	uint8_t callHelp_MaxWaitTime_05D;

	// 名前：ゴールアクション：警戒状態/通常音
	// 説明：ゴールアクション：ターゲットが通常音の感知により警戒状態になった
	uint8_t goalAction_ToCaution_05E;

	// 名前：聴覚_可聴AI音レベル
	// 説明：どれくらい耳が良いのか
	uint8_t ear_listenLevel_05F;

	// 名前：仲間呼び 応答後の行動タイプ
	// 説明：応答後、目標位置までの行動タイプ
	uint8_t callHelp_ReplyBehaviorType_060;

	// 名前：パス移動しない
	// 説明：パス移動命令が来てもパスを辿らずに直接移動するか
	uint8_t disablePathMove_061;

	// 名前：視線による到着判定をスキップするか？
	// 説明：視線による到着判定をスキップするか？Onにすると、視線が通っていなくても、到着判定を行う。
	uint8_t skipArrivalVisibleCheck_062;

	// 名前：取巻き役になるか？
	// 説明：思考属性：ＯＮにすると取巻き役を演じます。
	uint8_t thinkAttr_doAdmirer_063;

	// 名前：フラグ「崖」通れるか？
	// 説明：ノード「崖」を通過できるか？(def:1)
	uint8_t enableNaviFlg_Edge_064: 1;

	// 名前：フラグ「広い」通れるか？
	// 説明：ノード「広い」を通過できるか？(def:1)
	uint8_t enableNaviFlg_LargeSpace_064: 1;

	// 名前：フラグ「梯子」通れるか？
	// 説明：ノード「梯子」を通過できるか？(def:0)
	uint8_t enableNaviFlg_Ladder_064: 1;

	// 名前：フラグ「穴」通れるか？
	// 説明：ノード「穴」を通過できるか？(def:0)
	uint8_t enableNaviFlg_Hole_064: 1;

	// 名前：フラグ「扉」通れるか？
	// 説明：ノード「扉」を通過できるか？(def:0)
	uint8_t enableNaviFlg_Door_064: 1;

	// 名前：フラグ「壁中」通れるか？
	// 説明：ノード「壁中」を通過できるか？(def:0)
	uint8_t enableNaviFlg_InSideWall_064: 1;

	// 名前：フラグ「溶岩」通れるか？
	// 説明：ノード「溶岩」を通過できるか？(def:0)
	uint8_t enableNaviFlg_Lava_064: 1;

	// 名前：フラグ「崖」通れるか？（通常／警戒状態）
	// 説明：通常／警戒状態でノード「崖」を通過できるか？(def:1)
	uint8_t enableNaviFlg_Edge_Ordinary_064: 1;

	// 名前：ほんとに予約
	// 説明：フラグが新しく必要になったらここにいれます（NotPadding)
	uint8_t enableNaviFlg_reserve1_065[3];

	// 名前：索敵Lv0→Lv1の閾値
	// 説明：索敵Lv0→Lv1の閾値
	int32_t searchThreshold_Lv0toLv1_068;

	// 名前：索敵Lv1→Lv2の閾値
	// 説明：索敵Lv1→Lv2の閾値
	int32_t searchThreshold_Lv1toLv2_06C;

	// 名前：小隊反応遅延時間[sec]
	// 説明：小隊反応遅延時間[sec]
	float platoonReplyTime_070;

	// 名前：小隊反応追加ランダム時間[sec]
	// 説明：小隊反応追加ランダム時間[sec]
	float platoonReplyAddRandomTime_074;

	// 名前：索敵視覚_角度(高さ)[deg]
	// 説明：索敵視覚_角度(高さ)[deg]
	uint8_t searchEye_angX_078;

	// 名前：戦闘視界を上書きするか？
	// 説明：戦闘視界を上書きするか
	uint8_t isUpdateBattleSight_079;

	// 名前：戦闘視覚_上書き距離[m]
	// 説明：戦闘視覚_上書き距離[m]
	uint16_t battleEye_updateDist_07A;

	// 名前：戦闘視覚_上書き角度(高さ)[deg]
	// 説明：戦闘視覚_上書き角度(高さ)[deg]
	uint8_t battleEye_updateAngX_07C;

	// 名前：戦闘視覚_上書き角度(幅)[deg]
	// 説明：戦闘視覚_上書き角度(幅)[deg]
	uint8_t battleEye_updateAngY_07D;

	// 名前：パディング
	uint8_t pad4_07E[16];

	// 名前：視覚_発生距離[m]
	// 説明：キャラの中心からこの距離後ろが視角開始位置になる
	uint16_t eye_BackOffsetDist_08E;

	// 名前：視覚_カット距離[m]
	// 説明：視角発生位置からこの距離は認識しない
	uint16_t eye_BeginDist_090;

	// 名前：パス検索失敗/帰巣限界時の行動種別
	// 説明：パス検索失敗時、代替パスの終点に到達した際/帰巣限界距離まで到達した際に行うデフォルトの行動種別
	uint8_t actTypeOnFailedPath_092;

	// 名前：ゴールアクション：警戒状態/重要音
	// 説明：ゴールアクション：ターゲットが重要音の感知により警戒状態になった
	uint8_t goalAction_ToCautionImportant_093;

	// 名前：遠隔攻撃用持ち替えアニメID
	// 説明：AI攻撃パラメータの参照ID
	int32_t shiftAnimeId_RangedAttack_094;

	// 名前：パス検索失敗時の挙動（非戦闘中）
	// 説明：ターゲット【なし】時に、現在地点を巣に書き換えた後に取る行動 
	uint8_t actTypeOnNonBtlFailedPath_098;

	// 名前：バディAI
	// 説明：バディ用の思考か
	uint8_t isBuddyAI_099;

	// 名前：ゴールアクション：索敵Lv1
	// 説明：ゴールアクション：ターゲットが索敵Lv1になった
	uint8_t goalAction_ToSearchLv1_09A;

	// 名前：ゴールアクション：索敵Lv2
	// 説明：ゴールアクション：ターゲットが索敵Lv2になった
	uint8_t goalAction_ToSearchLv2_09B;

	// 名前：エッジ「ジャンプ」使うか（非戦闘状態）
	// 説明：ジャンプ用ユーザーエッジを飛び越えて移動するか(非戦闘状態)
	uint8_t enableJumpMove_09C;

	// 名前：回避移動しない
	// 説明：他のキャラクターを回避しながら移動しようとする挙動(ローカルステアリング)をオフにするか？
	uint8_t disableLocalSteering_09D;

	// 名前：ゴールアクション：記憶ターゲット状態
	// 説明：ゴールアクション：ターゲットを見失った
	uint8_t goalAction_ToDisappear_09E;

	// 名前：ゴールアクション：通常状態開始
	// 説明：通常状態に遷移したときのアクション
	uint8_t changeStateAction_ToNormal_09F;

	// 名前：記憶ターゲット忘れる時間[sec]
	// 説明：記憶ターゲット忘れる時間。
	float MemoryTargetForgetTime_0A0;

	// 名前：遠隔攻撃アニメID
	// 説明：遠隔攻撃する際にエネミーが出す攻撃IDを指定するパラメータ
	int32_t rangedAttackId_0A4;

	// 名前：エッジ「飛び降り」使うか（非戦闘状態）
	// 説明：AIが非戦闘状態で、飛び降りエッジを通行できるようにする
	uint8_t useFall_onNormalCaution_0A8;

	// 名前：エッジ「飛び降り」使うか（戦闘状態）
	// 説明：AIが戦闘状態で、飛び降りエッジを通行できるようにする 
	uint8_t useFall_onSearchBattle_0A9;

	// 名前：エッジ「ジャンプ」使うか（戦闘状態）
	// 説明：ジャンプ用ユーザーエッジを飛び越えて移動するか(戦闘状態)
	uint8_t enableJumpMove_onBattle_0AA;

	// 名前：帰巣限界でハマった時の挙動
	// 説明：帰巣限界でハマった時の挙動
	uint8_t backToHomeStuckAct_0AB;

	// 名前：パディング
	// 説明：pad
	uint8_t pad3_0AC[4];

	// 名前：振る舞いID1
	// 説明：聴くことのできる音ターゲットの振る舞いIDに対応
	int32_t soundBehaviorId01_0B0;

	// 名前：振る舞いID2
	// 説明：聴くことのできる音ターゲットの振る舞いIDに対応
	int32_t soundBehaviorId02_0B4;

	// 名前：振る舞いID3
	// 説明：聴くことのできる音ターゲットの振る舞いIDに対応
	int32_t soundBehaviorId03_0B8;

	// 名前：振る舞いID4
	// 説明：聴くことのできる音ターゲットの振る舞いIDに対応
	int32_t soundBehaviorId04_0BC;

	// 名前：振る舞いID5
	// 説明：聴くことのできる音ターゲットの振る舞いIDに対応
	int32_t soundBehaviorId05_0C0;

	// 名前：振る舞いID6
	// 説明：聴くことのできる音ターゲットの振る舞いIDに対応
	int32_t soundBehaviorId06_0C4;

	// 名前：振る舞いID7
	// 説明：聴くことのできる音ターゲットの振る舞いIDに対応
	int32_t soundBehaviorId07_0C8;

	// 名前：振る舞いID8
	// 説明：聴くことのできる音ターゲットの振る舞いIDに対応
	int32_t soundBehaviorId08_0CC;

	// 名前：納刀時特殊効果ID
	// 説明：納刀時特殊効果ID
	int32_t weaponOffSpecialEffectId_0D0;

	// 名前：抜刀時特殊効果ID
	// 説明：抜刀時特殊効果ID
	int32_t weaponOnSpecialEffectId_0D4;

	// 名前：納刀アニメID
	// 説明：納刀アニメID
	int32_t weaponOffAnimId_0D8;

	// 名前：抜刀アニメID
	// 説明：抜刀アニメID
	int32_t weaponOnAnimId_0DC;

	// 名前：驚くアニメID
	// 説明：驚くアニメID
	int32_t surpriseAnimId_0E0;

} NpcThinkParam;

#endif
