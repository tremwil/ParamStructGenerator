/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_DecalParam_H
#define _PARAM_DecalParam_H
#include <stdint.h>

// DECAL_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _DecalParam {

	// 名前：テクスチャID
	// 説明：テクスチャID
	int32_t textureId_000;

	// 名前：ダミポリID
	// 説明：デカール発生基準のダミポリID。TAEで指定している場合はTAEの値になる
	int32_t dmypolyId_004;

	// 名前：基準角度オフセット_上下[deg]
	// 説明：基準角度オフセット_上下[deg]
	float pitchAngle_008;

	// 名前：基準角度オフセット_左右[deg]
	// 説明：基準角度オフセット_左右[deg]
	float yawAngle_00C;

	// 名前：貼り付け開始距離[m]
	// 説明：貼り付け開始距離[m]
	float nearDistance_010;

	// 名前：貼り付け終了距離[m]
	// 説明：貼り付け終了距離[m]
	float farDistance_014;

	// 名前：開始距離での大きさ[m]
	// 説明：開始距離での大きさ[m]
	float nearSize_018;

	// 名前：終了距離での大きさ[m]
	// 説明：終了距離での大きさ[m]
	float farSize_01C;

	// 名前：監視特殊効果ID
	// 説明：監視特殊効果ID。任意の特殊効果IDを入れた場合、その特殊効果がかかっていないとデカールを発生しなくなる。
	int32_t maskSpeffectId_020;

	// 名前：パディング
	// 説明：パディング
	uint32_t pad_10_024: 4;

	// 名前：材質によるテクスチャ差し替え
	// 説明：攻撃のヒットで発生させるときに1で防御材質によってテクスチャを変える。新しいテクスチャID=血材質ID*10000000+元のテクスチャID
	uint32_t replaceTextureId_byMaterial_024: 1;

	// 名前：ダミポリ検索場所
	// 説明：ダミポリ検索場所 0:本体 1:左手武器 2:右手武器
	uint32_t dmypolyCategory_024: 2;

	// 名前：パディング
	// 説明：パディング
	uint32_t pad_05_024: 4;

	// 名前：デファード
	// 説明：1でデファードデカールとして機能する
	uint32_t useDeferredDecal_025: 1;

	// 名前：ペイント
	// 説明：1でペイントデカールとして機能する
	uint32_t usePaintDecal_025: 1;

	// 名前：流血表現
	// 説明：オプションの流血表現の影響を受けるか、マイルドでIDが+1000される、非表示だと貼り付けない
	uint32_t bloodTypeEnable_025: 1;

	// 名前：ノーマル成分を使用するか
	// 説明：ノーマル成分を使用するなら1（ノーマルとシャイニネスのテクスチャ統合対応）
	uint32_t bUseNormal_025: 1;

	// 名前：パディング
	// 説明：パディング
	uint32_t pad_08_025: 1;

	// 名前：パディング
	// 説明：パディング
	uint32_t pad_09_026: 1;

	// 名前：POMを有効にするか
	// 説明：POMを有効にするか
	uint32_t usePom_026: 1;

	// 名前：エミッシブを更新するか
	// 説明：エミッシブを更新するか
	uint32_t useEmissive_026: 1;

	// 名前：垂直に貼り付けるか
	// 説明：垂直に貼り付けるか
	uint32_t putVertical_026: 1;

	// 名前：ランダムスケール最小値[％]
	// 説明：ランダムスケール最小値[％]
	int16_t randomSizeMin_026;

	// 名前：ランダムスケール最大値[％]
	// 説明：ランダムスケール最大値[％]
	int16_t randomSizeMax_028;

	// 名前：ランダム角度_ひねり最小値[deg]
	// 説明：ランダム角度_ひねり最小値[deg]
	float randomRollMin_02A;

	// 名前：ランダム角度_ひねり最大値[deg]
	// 説明：ランダム角度_ひねり最大値[deg]
	float randomRollMax_02E;

	// 名前：ランダム角度_上下最小値[deg]
	// 説明：ランダム角度_上下最小値[deg]
	float randomPitchMin_032;

	// 名前：ランダム角度_上下最大値[deg]
	// 説明：ランダム角度_上下最大値[deg]
	float randomPitchMax_036;

	// 名前：ランダム角度_左右最小値[deg]
	// 説明：ランダム角度_左右最小値[deg]
	float randomYawMin_03A;

	// 名前：ランダム角度_左右最大値[deg]
	// 説明：ランダム角度_左右最大値[deg]
	float randomYawMax_03E;

	// 名前：POM高さスケール
	// 説明：POM高さスケール
	float pomHightScale_042;

	// 名前：POM最小サンプル数
	// 説明：POM最小サンプル数
	uint8_t pomSampleMin_046;

	// 名前：POM最大サンプル数
	// 説明：POM最大サンプル数
	uint8_t pomSampleMax_047;

	// 名前：ブレンドモード
	// 説明：ブレンドモード
	int8_t blendMode_048;

	// 名前：デカールを飛ばす基準座標
	// 説明：デカールを飛ばす方向を決定する基準座標
	int8_t appearDirType_049;

	// 名前：エミッシブ 開始値
	// 説明：エミッシブ 開始値
	float emissiveValueBegin_04A;

	// 名前：エミッシブ 終了値
	// 説明：エミッシブ 終了値
	float emissiveValueEnd_04E;

	// 名前：エミッシブ 更新時間(秒)
	// 説明：開始値～終了値の補間時間
	float emissiveTime_052;

	// 名前：補間するか？
	// 説明：TAEのデカル発生でバーを伸ばしてる時間発生させるか？
	uint8_t bIntpEnable_056;

	// 名前：パディング
	// 説明：パディング
	uint8_t pad_01_057[3];

	// 名前：補間間隔[m]
	// 説明：補間有効時にTAEのバーの間で発生したデカルを補間する距離
	float intpIntervalDist_05A;

	// 名前：補間開始時のテクスチャID
	// 説明：補間開始時のテクスチャID（-1でテクスチャIDと同じ値を使う）
	int32_t beginIntpTextureId_05E;

	// 名前：補間終了時のテクスチャID
	// 説明：補間終了時のテクスチャテクスチャID（-1でテクスチャIDと同じ値を使う）
	int32_t endIntpTextureId_062;

	// 名前：デカールが貼られた時に出すSFXID
	// 説明：デカールが貼られた時に出すSFXID（-1で何も出さない）
	int32_t appearSfxId_066;

	// 名前：SFXのオフセット位置
	// 説明：SFX発生位置のオフセット距離
	float appearSfxOffsetPos_06A;

	// 名前：マスクテクスチャID
	// 説明：マスクテクスチャID（-1でテクスチャIDを見る）
	int32_t maskTextureId_06E;

	// 名前：アルベドテクスチャID
	// 説明：アルベドテクスチャID（-1でテクスチャIDを見る）
	int32_t diffuseTextureId_072;

	// 名前：リフレクテクスチャID
	// 説明：リフレクタンステクスチャID（-1でテクスチャIDを見る）
	int32_t reflecTextureId_076;

	// 名前：マスクの強さ
	// 説明：マスクの強さ（現状、デファードデカールでのみ有効）
	float maskScale_07A;

	// 名前：ノーマルテクスチャID
	// 説明：ノーマルテクスチャID（-1でテクスチャIDを見る）
	int32_t normalTextureId_07E;

	// 名前：ハイトテクスチャID
	// 説明：ハイトテクスチャID（-1でテクスチャIDを見る）
	int32_t heightTextureId_082;

	// 名前：エミッシブテクスチャID
	// 説明：エミッシブテクスチャID（-1でテクスチャIDを見る）
	int32_t emissiveTextureId_086;

	// 名前：アルベドカラー：R
	// 説明：アルベドの色：R
	uint8_t diffuseColorR_08A;

	// 名前：アルベドカラー：G
	// 説明：アルベドの色：G
	uint8_t diffuseColorG_08B;

	// 名前：アルベドカラー：B
	// 説明：アルベドの色：B
	uint8_t diffuseColorB_08C;

	// 名前：パディング
	// 説明：パディング
	uint8_t pad_03_08D[1];

	// 名前：リフレクカラー：R
	// 説明：リフレクの色：R
	uint8_t reflecColorR_08E;

	// 名前：リフレクカラー：G
	// 説明：リフレクの色：G
	uint8_t reflecColorG_08F;

	// 名前：リフレクカラー：B
	// 説明：リフレクの色：B
	uint8_t reflecColorB_090;

	// 名前：寿命が有効か
	// 説明：寿命が有効か
	uint8_t bLifeEnable_091;

	// 名前：シャイニネスの強さ
	// 説明：シャイニネスの強さ
	float siniScale_092;

	// 名前：寿命[秒]
	// 説明：寿命[秒]（デカールが貼られてからの時間、フェードイン時間は関係ない）
	float lifeTimeSec_096;

	// 名前：フェードアウト時間[秒]
	// 説明：フェードアウト時間[秒]
	float fadeOutTimeSec_09A;

	// 名前：優先度
	// 説明：この値が大きいほど残りやすい（-1は消滅しない）
	int16_t priority_09E;

	// 名前：近くにデカールがあれば間引くか
	// 説明：近くにデカールがあれば間引くかどうか
	uint8_t bDistThinOutEnable_0A0;

	// 名前：ランダムパターンを固定化する
	// 説明：「はい」にすると、各バリエーション数が0以外のテクスチャについてランダムに決めた一つのバリエーション番号が適用されるようになります。0以外の各バリエーション数は同じ値に揃える必要があります。
	uint8_t bAlignedTexRandomVariationEnable_0A1;

	// 名前：この距離以内なら間引き候補
	// 説明：この距離以内にデカールがあれば間引き候補
	float distThinOutCheckDist_0A2;

	// 名前：方向の差がこの角度[度]以内なら間引き候補
	// 説明：デカールの方向の差がこの角度以内なら間引き候補
	float distThinOutCheckAngleDeg_0A6;

	// 名前：条件を満たした数がこの数以上なら間引く
	// 説明：距離、角度がこの数以上なら間引く
	uint8_t distThinOutMaxNum_0AA;

	// 名前：直近何個まで間引きチェックするか
	// 説明：間引き候補を直近何個まで調べるか
	uint8_t distThinOutCheckNum_0AB;

	// 名前：発生するまでの遅延フレーム[フレーム（30FPS換算）]
	// 説明：デカールを貼り付けようとしてからこのフレーム後に実際に貼り付けられる
	int16_t delayAppearFrame_0AC;

	// 名前：アルベド・バリエーション数
	// 説明：アルベドテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Diffuse_0AE: 4;

	// 名前：マスク・バリエーション数
	// 説明：マスクテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Mask_0AF: 4;

	// 名前：リフレク・バリエーション数
	// 説明：リフレクテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Reflec_0AF: 4;

	// 名前：パディング
	uint32_t pad_12_0B0: 4;

	// 名前：ノーマル・バリエーション数
	// 説明：ノーマルテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Normal_0B0: 4;

	// 名前：ハイト・バリエーション数
	// 説明：ハイトテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Height_0B1: 4;

	// 名前：エミッシブ・バリエーション数
	// 説明：エミッシブテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Emissive_0B1: 4;

	// 名前：パディング
	// 説明：パディング
	uint32_t pad_11_0B2: 4;

	// 名前：フェードイン時間[秒]
	// 説明：フェードイン時間[秒]
	float fadeInTimeSec_0B2;

	// 名前：間引き:重複乗算値
	// 説明：デカールサイズにこの値を乗算した範囲で重複かを判定する
	float thinOutOverlapMultiRadius_0B6;

	// 名前：間引き:近隣加算距離[m]
	// 説明：デカールサイズにこの距離[m]を加算した範囲で近隣かを判定する
	float thinOutNeighborAddRadius_0BA;

	// 名前：間引き:重複限界数
	// 説明：重複可能な限界数
	uint32_t thinOutOverlapLimitNum_0BE;

	// 名前：間引き:近隣限界数
	// 説明：近隣可能な限界数
	uint32_t thinOutNeighborLimitNum_0C2;

	// 名前：間引きモード
	// 説明：間引きモード
	int8_t thinOutMode_0C6;

	// 名前：エミッシブカラー：R
	// 説明：エミッシブの色：R
	uint8_t emissiveColorR_0C7;

	// 名前：エミッシブカラー：G
	// 説明：エミッシブの色：G
	uint8_t emissiveColorG_0C8;

	// 名前：エミッシブカラー：B
	// 説明：エミッシブの色：B
	uint8_t emissiveColorB_0C9;

	// 名前：SFX発生上限角度
	// 説明：SFX発生上限角度
	float maxDecalSfxCreatableSlopeAngleDeg_0CA;

	// 名前：パディング
	// 説明：パディング
	uint8_t pad_02_0CE[40];

} DecalParam;

#endif
