/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_ReflectionQuality_H
#define _PARAM_Gconfig_ReflectionQuality_H
#include <stdint.h>

// CS_REFLECTION_QUALITY_DETAIL
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_ReflectionQuality {

	// 名前：反射有効
	// 説明：反射有効
	uint8_t enabled_000;

	// 名前：ローカルライト有効
	// 説明：ローカルライト有効
	uint8_t localLightEnabled_001;

	// 名前：ローカルライト強制有効
	// 説明：ローカルライト強制有効
	uint8_t localLightForceEnabled_002;

	// 名前：dmy
	uint8_t dmy_003[1];

	// 名前：解像度スケール
	// 説明：解像度スケール
	uint32_t resolutionDivider_004;

	// 名前：SSR有効
	// 説明：SSR有効
	uint8_t ssrEnabled_008;

	// 名前：ガウスぼかしの許可
	// 説明：ガウスぼかしの許可
	uint8_t ssrGaussianBlurEnabled_009;

	// 名前：dmy
	uint8_t dmy2_00A[2];

	// 名前：計算距離スケール
	// 説明：計算距離スケール
	float ssrDepthRejectThresholdScale_00C;

	// 名前：レイトレースステップ係数（SSRパラメータに乗算）
	// 説明：レイトレースステップ係数（SSRパラメータに乗算）
	float ssrRayTraceStepScale_010;

	// 名前：フェード角度バイアス。小さくすると高品質
	// 説明：フェード角度バイアス。小さくすると高品質
	float ssrFadeToViewerBias_014;

	// 名前：フレネルリジェクトバイアス。小さくすると高品質
	// 説明：フレネルリジェクトバイアス。小さくすると高品質
	float ssrFresnelRejectBias_018;

} Gconfig_ReflectionQuality;

#endif
