/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_GestureParam_H
#define _PARAM_GestureParam_H
#include <stdint.h>

// GESTURE_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GestureParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：参照アイテムID
	// 説明：参照アイテムID。各メニューでのジェスチャのテキストID、アイコンID、ソートIDを持ってくるのに使用される。装備品パラメータの道具IDを登録します
	int32_t itemId_004;

	// 名前：メッセージ添付用アニメID
	// 説明：メッセージ添付用アニメID。メッセージ添付時のアニメIDを指定します
	int32_t msgAnimId_008;

	// 名前：騎乗中使用禁止か
	// 説明：騎乗中使用禁止か(デフォルト:×)。○なら騎乗中に使用できない
	uint8_t cannotUseRiding_00C: 1;

	// 名前：予約領域
	uint8_t pad2_00C: 7;

	// 名前：予約領域
	uint8_t pad1_00D[3];

} GestureParam;

#endif
