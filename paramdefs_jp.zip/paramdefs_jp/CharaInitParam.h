/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CharaInitParam_H
#define _PARAM_CharaInitParam_H
#include <stdint.h>

// CHARACTER_INIT_PARAM
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CharaInitParam {

	// 名前：ＭＰ回復速度基本値[s]
	// 説明：ＭＰが、1ポイント回復するまでの時間（小数点第一位）
	float baseRec_mp_000;

	// 名前：スタミナ回復速度基本値[s]
	// 説明：スタミナが、1ポイント回復するまでの時間（小数点第一位）
	float baseRec_sp_004;

	// 名前：落下ダメージ軽減補正[%]
	// 説明：他のキャラクターに上からのしかかれたときに、クッションとなりえるダメージ軽減量（％）（小数点第一位）
	float red_Falldam_008;

	// 名前：初期ソウル
	// 説明：初期に所持しているソウル量
	int32_t soul_00C;

	// 名前：右手武器スロット1
	// 説明：装備品パラメータの武器ＩＤ(右手スロット１)
	int32_t equip_Wep_Right_010;

	// 名前：右手武器スロット2
	// 説明：装備品パラメータの武器ＩＤ(右手スロット２)
	int32_t equip_Subwep_Right_014;

	// 名前：左手武器スロット1
	// 説明：装備品パラメータの武器ＩＤ(左手スロット１)
	int32_t equip_Wep_Left_018;

	// 名前：左手武器スロット2
	// 説明：装備品パラメータの武器ＩＤ(左手スロット２)
	int32_t equip_Subwep_Left_01C;

	// 名前：頭防具
	// 説明：装備品パラメータの防具ＩＤ(頭防具)
	int32_t equip_Helm_020;

	// 名前：胴体防具
	// 説明：装備品パラメータの防具ＩＤ(胴体防具)
	int32_t equip_Armer_024;

	// 名前：腕防具
	// 説明：装備品パラメータの防具ＩＤ(腕防具)
	int32_t equip_Gaunt_028;

	// 名前：脚防具
	// 説明：装備品パラメータの防具ＩＤ(脚防具)
	int32_t equip_Leg_02C;

	// 名前：矢
	// 説明：装備品パラメータの武器ＩＤ(矢)
	int32_t equip_Arrow_030;

	// 名前：ボルト
	// 説明：装備品パラメータの武器ＩＤ(ボルト)
	int32_t equip_Bolt_034;

	// 名前：予備矢
	// 説明：装備品パラメータの武器ＩＤ(矢予備)
	int32_t equip_SubArrow_038;

	// 名前：予備ボルト
	// 説明：装備品パラメータの武器ＩＤ(ボルト予備)
	int32_t equip_SubBolt_03C;

	// 名前：装飾品1
	// 説明：装備品パラメータの装飾品ＩＤ01
	int32_t equip_Accessory01_040;

	// 名前：装飾品2
	// 説明：装備品パラメータの装飾品ＩＤ02
	int32_t equip_Accessory02_044;

	// 名前：装飾品3
	// 説明：装備品パラメータの装飾品ＩＤ03
	int32_t equip_Accessory03_048;

	// 名前：装飾品4
	// 説明：装備品パラメータの装飾品ＩＤ04
	int32_t equip_Accessory04_04C;

	// 名前：pad
	// 説明：pad
	uint8_t pad8_050[4];

	// 名前：エリクサー用素材ID1
	// 説明：エリクサー用素材ID1
	int32_t elixir_material00_054;

	// 名前：エリクサー用素材ID2
	// 説明：エリクサー用素材ID2
	int32_t elixir_material01_058;

	// 名前：エリクサー用素材ID3
	// 説明：エリクサー用素材ID3
	int32_t elixir_material02_05C;

	// 名前：魔法・奇跡1
	// 説明：初期配置の魔法・奇跡ID01
	int32_t equip_Spell_01_060;

	// 名前：魔法・奇跡2
	// 説明：初期配置の魔法・奇跡ID02
	int32_t equip_Spell_02_064;

	// 名前：魔法・奇跡3
	// 説明：初期配置の魔法・奇跡ID03
	int32_t equip_Spell_03_068;

	// 名前：魔法・奇跡4
	// 説明：初期配置の魔法・奇跡ID04
	int32_t equip_Spell_04_06C;

	// 名前：魔法・奇跡5
	// 説明：初期配置の魔法・奇跡ID05
	int32_t equip_Spell_05_070;

	// 名前：魔法・奇跡6
	// 説明：初期配置の魔法・奇跡ID06
	int32_t equip_Spell_06_074;

	// 名前：魔法・奇跡7
	// 説明：初期配置の魔法・奇跡ID07
	int32_t equip_Spell_07_078;

	// 名前：アイテム01
	// 説明：初期所持のアイテムID01
	int32_t item_01_07C;

	// 名前：アイテム02
	// 説明：初期所持のアイテムID02
	int32_t item_02_080;

	// 名前：アイテム03
	// 説明：初期所持のアイテムID03
	int32_t item_03_084;

	// 名前：アイテム04
	// 説明：初期所持のアイテムID04
	int32_t item_04_088;

	// 名前：アイテム05
	// 説明：初期所持のアイテムID05
	int32_t item_05_08C;

	// 名前：アイテム06
	// 説明：初期所持のアイテムID06
	int32_t item_06_090;

	// 名前：アイテム07
	// 説明：初期所持のアイテムID07
	int32_t item_07_094;

	// 名前：アイテム08
	// 説明：初期所持のアイテムID08
	int32_t item_08_098;

	// 名前：アイテム09
	// 説明：初期所持のアイテムID09
	int32_t item_09_09C;

	// 名前：アイテム10
	// 説明：初期所持のアイテムID10
	int32_t item_10_0A0;

	// 名前：フェイスジェンパラメータID
	// 説明：NPCプレイヤーで使用するフェイスジェンパラメータID。通常プレイヤーでは使用しません。
	int32_t npcPlayerFaceGenId_0A4;

	// 名前：NPCプレイヤーの思考ID
	// 説明：NPCプレイヤーで使用するNPC思考パラメータID。通常プレイヤーでは使用しません。
	int32_t npcPlayerThinkId_0A8;

	// 名前：ＨＰ基本値
	// 説明：ＨＰの基本値（実際は、計算式で補正される）
	uint16_t baseHp_0AC;

	// 名前：ＭＰ基本値
	// 説明：ＭＰの基本値（実際は、計算式で補正される）
	uint16_t baseMp_0AE;

	// 名前：スタミナ基本値
	// 説明：スタミナの基本値（実際は、計算式で補正される）
	uint16_t baseSp_0B0;

	// 名前：矢の所持数
	// 説明：矢の初期所持数
	uint16_t arrowNum_0B2;

	// 名前：ボルトの所持数
	// 説明：ボルトの初期所持数
	uint16_t boltNum_0B4;

	// 名前：予備矢の所持数
	// 説明：矢の初期所持数
	uint16_t subArrowNum_0B6;

	// 名前：予備ボルトの所持数
	// 説明：ボルトの初期所持数
	uint16_t subBoltNum_0B8;

	// 名前：pad
	uint8_t pad4_0BA[6];

	// 名前：ソウルLv
	// 説明：初期Lv
	int16_t soulLv_0C0;

	// 名前：体力
	// 説明：体力の基本値
	uint8_t baseVit_0C2;

	// 名前：精神
	// 説明：精神の基本値
	uint8_t baseWil_0C3;

	// 名前：頑強
	// 説明：頑強の基本値
	uint8_t baseEnd_0C4;

	// 名前：筋力
	// 説明：筋力の基本値
	uint8_t baseStr_0C5;

	// 名前：俊敏
	// 説明：俊敏の基本値
	uint8_t baseDex_0C6;

	// 名前：魔力
	// 説明：魔力の基本値
	uint8_t baseMag_0C7;

	// 名前：信仰
	// 説明：信仰の基本値
	uint8_t baseFai_0C8;

	// 名前：運
	// 説明：運の基本値
	uint8_t baseLuc_0C9;

	// 名前：人間性
	// 説明：人間性の基本値
	uint8_t baseHeroPoint_0CA;

	// 名前：耐久力
	// 説明：耐久力の基本値
	uint8_t baseDurability_0CB;

	// 名前：アイテム01の所持数
	// 説明：初期所持のアイテム個数01
	uint8_t itemNum_01_0CC;

	// 名前：アイテム02の所持数
	// 説明：初期所持のアイテム個数02
	uint8_t itemNum_02_0CD;

	// 名前：アイテム03の所持数
	// 説明：初期所持のアイテム個数03
	uint8_t itemNum_03_0CE;

	// 名前：アイテム個数04
	// 説明：初期所持のアイテム個数04
	uint8_t itemNum_04_0CF;

	// 名前：アイテム個数05
	// 説明：初期所持のアイテム個数05
	uint8_t itemNum_05_0D0;

	// 名前：アイテム個数06
	// 説明：初期所持のアイテム個数06
	uint8_t itemNum_06_0D1;

	// 名前：アイテム個数07
	// 説明：初期所持のアイテム個数07
	uint8_t itemNum_07_0D2;

	// 名前：アイテム個数08
	// 説明：初期所持のアイテム個数08
	uint8_t itemNum_08_0D3;

	// 名前：アイテム個数09
	// 説明：初期所持のアイテム個数09
	uint8_t itemNum_09_0D4;

	// 名前：アイテム個数10
	// 説明：初期所持のアイテム個数10
	uint8_t itemNum_10_0D5;

	// 名前：pad
	uint8_t pad5_0D6[5];

	// 名前：ジェスチャーID0
	// 説明：ジェスチャー0番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId0_0DB;

	// 名前：ジェスチャーID1
	// 説明：ジェスチャー1番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId1_0DC;

	// 名前：ジェスチャーID2
	// 説明：ジェスチャー2番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId2_0DD;

	// 名前：ジェスチャーID3
	// 説明：ジェスチャー3番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId3_0DE;

	// 名前：ジェスチャーID4
	// 説明：ジェスチャー4番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId4_0DF;

	// 名前：ジェスチャーID5
	// 説明：ジェスチャー5番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId5_0E0;

	// 名前：ジェスチャーID6
	// 説明：ジェスチャー6番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId6_0E1;

	// 名前：NPCプレイヤーのNPCタイプ
	// 説明：NPCプレイヤーで使用するNPCタイプ。通常プレイヤーでは使用しません。
	uint8_t npcPlayerType_0E2;

	// 名前：NPCプレイヤーの描画タイプ
	// 説明：NPCプレイヤーで使用する描画タイプ。通常プレイヤーでは使用しません。
	int8_t npcPlayerDrawType_0E3;

	// 名前：NPCプレイヤーの性別
	// 説明：NPCプレイヤーで使用する性別です。通常プレイヤーには反映しません。
	uint8_t npcPlayerSex_0E4;

	// 名前：誓約
	// 説明：誓約タイプ(なし：0)
	uint8_t vowType_0E5: 4;

	// 名前：送受信対象か
	// 説明：送受信対象か（コピーNPC用）
	uint8_t isSyncTarget_0E5: 1;

	// 名前：pad
	uint8_t pad_0E5: 3;

	// 名前：pad
	uint8_t pad6_0E6[2];

	// 名前：右手武器スロット1装備タイプ
	// 説明：右手武器スロット１のパラメータ参照先
	uint8_t wepParamType_Right1_0E8;

	// 名前：右手武器スロット2装備タイプ
	// 説明：右手武器スロット２のパラメータ参照先
	uint8_t wepParamType_Right2_0E9;

	// 名前：右手武器スロット3装備タイプ
	// 説明：右手武器スロット３のパラメータ参照先
	uint8_t wepParamType_Right3_0EA;

	// 名前：左手武器スロット1装備タイプ
	// 説明：左手武器スロット１のパラメータ参照先
	uint8_t wepParamType_Left1_0EB;

	// 名前：左手武器スロット2装備タイプ
	// 説明：左手武器スロット２のパラメータ参照先
	uint8_t wepParamType_Left2_0EC;

	// 名前：左手武器スロット3装備タイプ
	// 説明：左手武器スロット３のパラメータ参照先
	uint8_t wepParamType_Left3_0ED;

	// 名前：pad
	uint8_t pad2_0EE[26];

	// 名前：右手武器スロット3
	// 説明：装備品パラメータの武器ＩＤ(右手スロット３)
	int32_t equip_Subwep_Right3_108;

	// 名前：左手武器スロット3
	// 説明：装備品パラメータの武器ＩＤ(左手スロット３)
	int32_t equip_Subwep_Left3_10C;

	// 名前：pad
	uint8_t pad3_110[4];

	// 名前：第二アイテム01
	// 説明：第二ショートカット初期所持のアイテムID01
	int32_t secondaryItem_01_114;

	// 名前：第二アイテム02
	// 説明：第二ショートカット初期所持のアイテムID02
	int32_t secondaryItem_02_118;

	// 名前：第二アイテム03
	// 説明：第二ショートカット初期所持のアイテムID03
	int32_t secondaryItem_03_11C;

	// 名前：第二アイテム04
	// 説明：第二ショートカット初期所持のアイテムID04
	int32_t secondaryItem_04_120;

	// 名前：第二アイテム05
	// 説明：第二ショートカット初期所持のアイテムID05
	int32_t secondaryItem_05_124;

	// 名前：第二アイテム06
	// 説明：第二ショートカット初期所持のアイテムID06
	int32_t secondaryItem_06_128;

	// 名前：第二アイテム01の所持数
	// 説明：第二ショートカット初期所持のアイテム個数01
	uint8_t secondaryItemNum_01_12C;

	// 名前：第二アイテム02の所持数
	// 説明：第二ショートカット初期所持のアイテム個数02
	uint8_t secondaryItemNum_02_12D;

	// 名前：第二アイテム03の所持数
	// 説明：第二ショートカット初期所持のアイテム個数03
	uint8_t secondaryItemNum_03_12E;

	// 名前：第二アイテム04の所持数
	// 説明：第二ショートカット初期所持のアイテム個数04
	uint8_t secondaryItemNum_04_12F;

	// 名前：第二アイテム05の所持数
	// 説明：第二ショートカット初期所持のアイテム個数05
	uint8_t secondaryItemNum_05_130;

	// 名前：第二アイテム06の所持数
	// 説明：第二ショートカット初期所持のアイテム個数06
	uint8_t secondaryItemNum_06_131;

	// 名前：HPエスト瓶 所持限界数
	// 説明：HPエスト瓶 所持限界数
	int8_t HpEstMax_132;

	// 名前：MPエスト瓶 所持限界数
	// 説明：MPエスト瓶 所持限界数
	int8_t MpEstMax_133;

	// 名前：pad
	uint8_t pad7_134[5];

	// 名前：声タイプ
	// 説明：声タイプ
	uint8_t voiceType_139;

	// 名前：予約領域
	// 説明：予約領域
	uint8_t reserve_13A[6];

} CharaInitParam;

#endif
