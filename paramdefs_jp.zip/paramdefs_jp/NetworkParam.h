/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_NetworkParam_H
#define _PARAM_NetworkParam_H
#include <stdint.h>

// NETWORK_PARAM_ST
// Data Version: 10
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _NetworkParam {

	// 名前：サイン高さオフセット[m]
	float signVerticalOffset_000;

	// 名前：サイン位置補正最大距離[m]
	float maxSignPosCorrectionRange_004;

	// 名前：召喚希望タイムアウト時間[秒]
	float summonTimeoutTime_008;

	// 名前：予約
	uint8_t pad_00C[4];

	// 名前：サイン溜まり登録中メッセージ表示間隔[秒]
	float signPuddleActiveMessageIntervalSec_010;

	// 名前：キーガイド垂直範囲[m]
	float keyGuideHeight_014;

	// 名前：召喚サイン再取得待機時間(過疎時)[秒]
	float reloadSignIntervalTime1_018;

	// 名前：召喚サイン再取得待機時間[秒]
	float reloadSignIntervalTime2_01C;

	// 名前：召喚サイン所持可能数上限(全体)
	// 説明：本当はu8くらいで十分
	uint32_t reloadSignTotalCount_020;

	// 名前：召喚サイン所持可能数上限(セル)
	// 説明：本当はu8くらいで十分
	uint32_t reloadSignCellCount_024;

	// 名前：召喚サイン更新待機時間[秒]
	float updateSignIntervalTime_028;

	// 名前：召喚サイン間描画排他水平範囲[m]
	float basicExclusiveRange_02C;

	// 名前：召喚サイン間描画排他垂直範囲[m]
	float basicExclusiveHeight_030;

	// 名前：召喚サインキャラモデル描画待機時間[秒]
	float previewChrWaitingTime_034;

	// 名前：召喚サインPC間描画距離[m]
	float signVisibleRange_038;

	// 名前：召喚サイン取得セル範囲(水平)
	// 説明：本当はu8くらいで十分
	uint32_t cellGroupHorizontalRange_03C;

	// 名前：召喚サイン取得セル範囲(上方向)
	// 説明：本当はu8くらいで十分
	uint32_t cellGroupTopRange_040;

	// 名前：召喚サイン取得セル範囲(下方向)
	// 説明：本当はu8くらいで十分
	uint32_t cellGroupBottomRange_044;

	// 名前：白霊サイン表示制限時間下限倍率
	float minWhitePhantomLimitTimeScale_048;

	// 名前：小霊サイン表示制限時間下限倍率
	float minSmallPhantomLimitTimeScale_04C;

	// 名前：白霊サインキーワード延長倍率
	float whiteKeywordLimitTimeScale_050;

	// 名前：小霊サインキーワード延長倍率
	float smallKeywordLimitTimeScale_054;

	// 名前：闇霊サインキーワード延長倍率
	float blackKeywordLimitTimeScale_058;

	// 名前：竜霊サインキーワード延長倍率
	float dragonKeywordLimitTimeScale_05C;

	// 名前：サイン取得上限
	// 説明：本当はu8くらいで十分
	uint32_t singGetMax_060;

	// 名前：サインダウンロードスパン
	float signDownloadSpan_064;

	// 名前：サインアップロードスパン
	float signUpdateSpan_068;

	// 名前：予約
	uint8_t signPad_06C[4];

	// 名前：乱入先取得数
	uint32_t maxBreakInTargetListCount_070;

	// 名前：乱入リクエスト間隔[秒]
	float breakInRequestIntervalTimeSec_074;

	// 名前：乱入リクエストタイムアウト時間[秒]
	float breakInRequestTimeOutSec_078;

	// 名前：予約
	uint8_t pad_07C[4];

	// 名前：キーガイド水平範囲[m]
	float keyGuideRange_080;

	// 名前：キーガイド垂直範囲[m]
	float keyGuideHeight_084;

	// 名前：血文字取得数(全体)
	// 説明：本当はu8くらいで十分
	uint32_t reloadSignTotalCount_088;

	// 名前：血文字取得数(セル、新順)
	// 説明：本当はu8くらいで十分
	uint32_t reloadNewSignCellCount_08C;

	// 名前：血文字取得数(セル、ランダム )
	// 説明：本当はu8くらいで十分
	uint32_t reloadRandomSignCellCount_090;

	// 名前：血文字所持可能数上限(全体)
	// 説明：本当はu16くらいで十分
	uint32_t maxSignTotalCount_094;

	// 名前：血文字所持可能数上限(セル)
	// 説明：本当はu8くらいで十分
	uint32_t maxSignCellCount_098;

	// 名前：血文字間描画排他水平範囲[m]
	float basicExclusiveRange_09C;

	// 名前：血文字間描画排他垂直範囲[m]
	float basicExclusiveHeight_0A0;

	// 名前：血文字PC間描画距離[m]
	float signVisibleRange_0A4;

	// 名前：書いた血文字履歴件数上限
	// 説明：本当はu8くらいで十分
	uint32_t maxWriteSignCount_0A8;

	// 名前：読んだ血文字履歴件数上限
	// 説明：本当はu8くらいで十分
	uint32_t maxReadSignCount_0AC;

	// 名前：血文字再取得待機時間[秒]
	float reloadSignIntervalTime_0B0;

	// 名前：血文字取得セル範囲(水平)
	// 説明：本当はu8くらいで十分
	uint32_t cellGroupHorizontalRange_0B4;

	// 名前：血文字取得セル範囲(上方向)
	// 説明：本当はu8くらいで十分
	uint32_t cellGroupTopRange_0B8;

	// 名前：血文字取得セル範囲(下方向)
	// 説明：本当はu8くらいで十分
	uint32_t cellGroupBottomRange_0BC;

	// 名前：血文字データ保持期間上限[秒]
	// 説明：本当はu16くらいで十分
	uint32_t lifeTime_0C0;

	// 名前：血文字ダウンロード間隔
	float downloadSpan_0C4;

	// 名前：血文字評価数ダウンロード間隔
	float downloadEvaluationSpan_0C8;

	// 名前：予約
	uint8_t pad_0CC[4];

	// 名前：血痕位置と幻影開始位置間の許容距離[m]
	// 説明：血痕位置と幻影開始位置の間の距離がこの値より離れている場合はサーバの登録を行わない
	float deadingGhostStartPosThreshold_0D0;

	// 名前：キーガイド垂直範囲[m]
	float keyGuideHeight_0D4;

	// 名前：プレイヤー血痕キーガイド水平範囲[m]
	float keyGuideRangePlayer_0D8;

	// 名前：プレイヤー血痕キーガイド垂直範囲[m]
	float keyGuideHeightPlayer_0DC;

	// 名前：血痕取得数(全体)
	// 説明：本当はu8くらいで十分
	uint32_t reloadSignTotalCount_0E0;

	// 名前：血痕取得数(セル)
	// 説明：本当はu8くらいで十分
	uint32_t reloadSignCellCount_0E4;

	// 名前：血痕所持可能数上限(全体)
	// 説明：本当はu16くらいで十分
	uint32_t maxSignTotalCount_0E8;

	// 名前：血痕所持可能数上限(セル)
	// 説明：本当はu8くらいで十分
	uint32_t maxSignCellCount_0EC;

	// 名前：血痕再取得待機時間[秒]
	float reloadSignIntervalTime_0F0;

	// 名前：血痕PC間描画距離[m]
	float signVisibleRange_0F4;

	// 名前：血痕間描画排他水平範囲[m]
	float basicExclusiveRange_0F8;

	// 名前：血痕間描画排他垂直範囲[m]
	float basicExclusiveHeight_0FC;

	// 名前：血痕取得セル範囲(水平)
	// 説明：本当はu8くらいで十分
	uint32_t cellGroupHorizontalRange_100;

	// 名前：血痕取得セル範囲(上方向)
	// 説明：本当はu8くらいで十分
	uint32_t cellGroupTopRange_104;

	// 名前：血痕取得セル範囲(下方向)
	// 説明：本当はu8くらいで十分
	uint32_t cellGroupBottomRange_108;

	// 名前：血痕データ保持期間上限[秒]
	// 説明：本当はu16くらいで十分
	uint32_t lifeTime_10C;

	// 名前：死亡幻影記録合計時間[秒]
	float recordDeadingGhostTotalTime_110;

	// 名前：死亡幻影の最低記録時間[秒]
	// 説明：この記録時間未満の死亡幻影はサーバの登録を行わない
	float recordDeadingGhostMinTime_114;

	// 名前：血痕ダウンロード間隔
	float downloadSpan_118;

	// 名前：石化血痕描画制限距離[m]
	// 説明：オープンフィールド用。石像生成時にPC～生成位置間の距離がこの値以上ならば生成できる
	float statueCreatableDistance_11C;

	// 名前：幻影取得数(全体)
	// 説明：本当はu8くらいで十分
	uint32_t reloadGhostTotalCount_120;

	// 名前：幻影取得数(セル)
	// 説明：本当はu8くらいで十分
	uint32_t reloadGhostCellCount_124;

	// 名前：幻影所持可能数上限(全体)
	// 説明：本当はu16くらいで十分
	uint32_t maxGhostTotalCount_128;

	// 名前：敵対PCリプレイ記録開始距離[m]
	float distanceOfBeginRecordVersus_12C;

	// 名前：敵対PCリプレイ記録終了距離[m]
	float distanceOfEndRecordVersus_130;

	// 名前：徘徊幻影アップロード間隔[秒]
	float updateWanderGhostIntervalTime_134;

	// 名前：対戦幻影アップロード間隔[秒]
	float updateVersusGhostIntervalTime_138;

	// 名前：幻影記録時間[秒]
	float recordWanderingGhostTime_13C;

	// 名前：徘徊幻影の最低記録時間[秒]
	// 説明：この記録時間未満の徘徊幻影はサーバの登録を行わない
	float recordWanderingGhostMinTime_140;

	// 名前：篝火幻影アップロード間隔[秒]
	float updateBonfireGhostIntervalTime_144;

	// 名前：幻影再生距離（視野内）[秒]
	float replayGhostRangeOnView_148;

	// 名前：幻影再生距離（視野外）[秒]
	float replayGhostRangeOutView_14C;

	// 名前：篝火幻影再生時間[秒]
	float replayBonfireGhostTime_150;

	// 名前：篝火幻影配置最小距離[秒]
	// 説明：篝火からこの距離未満の場所には篝火幻影を配置しない
	float minBonfireGhostValidRange_154;

	// 名前：篝火幻影配置最大距離[秒]
	// 説明：篝火からこの距離以上の場所には篝火幻影を配置しない
	float maxBonfireGhostValidRange_158;

	// 名前：幻影再生間隔下限[秒]
	float minReplayIntervalTime_15C;

	// 名前：幻影再生間隔上限[秒]
	float maxReplayIntervalTime_160;

	// 名前：幻影定期取得間隔[秒]
	float reloadGhostIntervalTime_164;

	// 名前：幻影取得セル範囲(水平)
	// 説明：本当はu8くらいで十分
	uint32_t cellGroupHorizontalRange_168;

	// 名前：幻影取得セル範囲(上方向)
	// 説明：本当はu8くらいで十分
	uint32_t cellGroupTopRange_16C;

	// 名前：幻影篝火モードファントムパラメータID(コードネーム)
	// 説明：コードネーム一致のときに使われる幻影篝火モードファントムパラメータID
	int32_t replayBonfirePhantomParamIdForCodename_170;

	// 名前：幻影篝火モード再生適用距離
	float replayBonfireModeRange_174;

	// 名前：幻影篝火モードファントムパラメータID
	// 説明：幻影篝火モードファントムパラメータID
	int32_t replayBonfirePhantomParamId_178;

	// 名前：予約
	uint8_t ghostpad_17C[4];

	// 名前：指輪検索間隔[秒]
	float reloadVisitListCoolTime_180;

	// 名前：救援青霊出現数上限
	// 説明：本当はu8くらいで十分
	uint32_t maxCoopBlueSummonCount_184;

	// 名前：鐘守灰霊出現数上限
	// 説明：本当はu8くらいで十分
	uint32_t maxBellGuardSummonCount_188;

	// 名前：指輪検索先取得数
	uint32_t maxVisitListCount_18C;

	// 名前：救援青霊リロード時間　最小[sec]
	float reloadSearch_CoopBlue_Min_190;

	// 名前：救援青霊リロード時間　最大[sec]
	float reloadSearch_CoopBlue_Max_194;

	// 名前：鐘守リロード時間　最小[sec]
	float reloadSearch_BellGuard_Min_198;

	// 名前：鐘守リロード時間　最大[sec]
	float reloadSearch_BellGuard_Max_19C;

	// 名前：ネズミの王リロード時間　最小[sec]
	float reloadSearch_RatKing_Min_1A0;

	// 名前：ネズミの王リロード時間　最大[sec]
	float reloadSearch_RatKing_Max_1A4;

	// 名前：予約
	uint8_t visitpad00_1A8[8];

	// 名前：SRTT上限[ミリ秒]
	float srttMaxLimit_1B0;

	// 名前：SRTT上限(安定時)[ミリ秒]
	float srttMeanLimit_1B4;

	// 名前：RTT平均偏差上限[ミリ秒]
	float srttMeanDeviationLimit_1B8;

	// 名前：闇霊制限時間加速時間[秒]
	float darkPhantomLimitBoostTime_1BC;

	// 名前：闇霊制限時間加速時倍率
	float darkPhantomLimitBoostScale_1C0;

	// 名前：マルチプレイ無効化寿命
	float multiplayDisableLifeTime_1C4;

	// 名前：深淵霊マルチプレイ回数
	// 説明：深淵エリアで、深淵霊がホストに入ってこれる回数
	uint8_t abyssMultiplayLimit_1C8;

	// 名前：霊体がワープするまでの最低時間[秒]
	uint8_t phantomWarpMinimumTime_1C9;

	// 名前：黒水晶使用後に帰還するまでのディレイ時間[秒]
	uint8_t phantomReturnDelayTime_1CA;

	// 名前：切断待ちのタイムアウト時間
	uint8_t terminateTimeoutTime_1CB;

	// 名前：LAN抜きによるペナルティ加算値
	uint16_t penaltyPointLanDisconnect_1CC;

	// 名前：サインアウトによるペナルティ加算値
	uint16_t penaltyPointSignout_1CE;

	// 名前：電源断によるペナルティ加算値
	uint16_t penaltyPointReboot_1D0;

	// 名前：ペナルティが発動するペナルティ値
	uint16_t penaltyPointBeginPenalize_1D2;

	// 名前：「線の理」の販売制限時間[秒]
	float penaltyForgiveItemLimitTime_1D4;

	// 名前：全域検索率：救援青霊[0-100]
	// 説明：全域から侵入対象を検索する割合（％）
	uint8_t allAreaSearchRate_CoopBlue_1D8;

	// 名前：全域検索率：報復青霊[0-100]
	// 説明：全域から侵入対象を検索する割合（％）
	uint8_t allAreaSearchRate_VsBlue_1D9;

	// 名前：全域検索率：鐘守灰霊[0-100]
	// 説明：全域から侵入対象を検索する割合（％）
	uint8_t allAreaSearchRate_BellGuard_1DA;

	// 名前：血文字評価時のHP回復割合[0-100]
	uint8_t bloodMessageEvalHealRate_1DB;

	// 名前：小金霊成功帰還ホスト報酬ID
	uint32_t smallGoldSuccessHostRewardId_1DC;

	// 名前：ドア付近プレイ領域無効化距離[m]
	// 説明：マルチプレイ領域を区切る黒扉の周辺を、システム的に無効なプレイ領域（-1）にします。その際、無効領域を黒扉のOBJのバウンディングボックスの薄い方を、このパラメータで太らせます。
	float doorInvalidPlayAreaExtents_1E0;

	// 名前：サイン最大同時表示数
	uint8_t signDisplayMax_1E4;

	// 名前：血痕最大同時表示数
	uint8_t bloodStainDisplayMax_1E5;

	// 名前：血文字最大同時表示数
	uint8_t bloodMessageDisplayMax_1E6;

	// 名前：予約
	uint8_t pad00_1E7[9];

	// 名前：予約
	uint8_t pad10_1F0[32];

	// 名前：召喚メッセージが表示間隔[秒]
	float summonMessageInterval_210;

	// 名前：ホスト定期更新リクエスト間隔[秒]
	float hostRegisterUpdateTime_214;

	// 名前：ホストのゲスト参加待ちタイムアウト時間[秒]
	float hostTimeOutTime_218;

	// 名前：ゲストのホストからの認証待ちタイムアウト時間[秒]
	float guestUpdateTime_21C;

	// 名前：ゲストPlayNo同期待ちタイムアウト時間[秒]
	float guestPlayerNoTimeOutTime_220;

	// 名前：ホストPlayNo同期待ちタイムアウト時間[秒]
	float hostPlayerNoTimeOutTime_224;

	// 名前：RequestSearchQuickMatchのlimit値
	// 説明：本当はu8くらいで十分
	uint32_t requestSearchQuickMatchLimit_228;

	// 名前：アバター戦検索時の最大人数(未使用)
	// 説明：本当はu8くらいで十分
	uint32_t AvatarMatchSearchMax_22C;

	// 名前：バトルロイヤル戦検索時の最少人数(未使用)
	// 説明：本当はu8くらいで十分
	uint32_t BattleRoyalMatchSearchMin_230;

	// 名前：バトルロイヤル戦検索時の最大人数(未使用)
	// 説明：本当はu8くらいで十分
	uint32_t BattleRoyalMatchSearchMax_234;

	// 名前：予約
	uint8_t pad11_238[8];

	// 名前：訪問対象者リスト取得最大値
	// 説明：本当はu8くらいで十分
	uint32_t VisitorListMax_240;

	// 名前：訪問待ちタイムアウト
	float VisitorTimeOutTime_244;

	// 名前：訪問者リストダウンロード間隔[秒]
	float DownloadSpan_248;

	// 名前：訪問先検索メッセージ表示間隔[秒]
	// 説明：訪問ゲストが訪問先を探してる間に出すメッセージの表示間隔[秒]
	float VisitorGuestRequestMessageIntervalSec_24C;

	// 名前：徘徊幻影寿命
	// 説明：徘徊幻影寿命
	float wanderGhostIntervalLifeTime_250;

	// 名前：予約
	// 説明：予約
	uint8_t pad13_254[12];

	// 名前：黄衣の翁待ちタイムアウト
	float YellowMonkTimeOutTime_260;

	// 名前：黄衣の翁リストダウンロード間隔
	float YellowMonkDownloadSpan_264;

	// 名前：黄衣の翁全体フロータイムアウト
	float YellowMonkOverallFlowTimeOutTime_268;

	// 名前：予約
	uint8_t pad14_26C[4];

	// 名前：予約
	uint8_t pad14_270[8];

} NetworkParam;

#endif
