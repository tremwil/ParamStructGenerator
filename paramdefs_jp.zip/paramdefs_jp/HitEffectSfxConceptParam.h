/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_HitEffectSfxConceptParam_H
#define _PARAM_HitEffectSfxConceptParam_H
#include <stdint.h>

// HIT_EFFECT_SFX_CONCEPT_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _HitEffectSfxConceptParam {

	// 名前：鉄製：概念１
	// 説明：鉄製：概念１
	int16_t atkIron_1_000;

	// 名前：鉄製：概念２
	// 説明：鉄製：概念２
	int16_t atkIron_2_002;

	// 名前：革製：概念１
	// 説明：革：概念１
	int16_t atkLeather_1_004;

	// 名前：革製：概念２
	// 説明：革：概念２
	int16_t atkLeather_2_006;

	// 名前：木製：概念１
	// 説明：木製：概念１
	int16_t atkWood_1_008;

	// 名前：木製：概念２
	// 説明：木製：概念２
	int16_t atkWood_2_00A;

	// 名前：肉：概念１
	// 説明：肉：概念１
	int16_t atkBody_1_00C;

	// 名前：肉：概念２
	// 説明：肉：概念２
	int16_t atkBody_2_00E;

	// 名前：石製：概念１
	// 説明：蝕：概念１
	int16_t atkStone_1_010;

	// 名前：石製：概念２
	// 説明：蝕：概念２
	int16_t atkStone_2_012;

	// 名前：pad
	uint8_t pad_014[4];

	// 名前：なし：概念１
	// 説明：なし：概念１
	int16_t atkNone_1_018;

	// 名前：なし：概念２
	// 説明：なし：概念２
	int16_t atkNone_2_01A;

	// 名前：予約領域
	uint8_t reserve_01C[52];

} HitEffectSfxConceptParam;

#endif
