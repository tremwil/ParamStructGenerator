/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_BuddyStoneParam_H
#define _PARAM_BuddyStoneParam_H
#include <stdint.h>

// BUDDY_STONE_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BuddyStoneParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：会話キャラエンティティID
	// 説明：会話から参照する時の外部キーとして使う。
	uint32_t talkChrEntityId_004;

	// 名前：撃破対象リストエンティティID
	// 説明：この石碑から召喚した際に、バディの撃破対象になるキャラ/グループのエンティティID
	uint32_t eliminateTargetEntityId_008;

	// 名前：召喚済みイベントフラグID
	// 説明：一度石碑から召喚した際に立つフラグID。このフラグが立っていると、石碑が召喚不可になる。
	uint32_t summonedEventFlagId_00C;

	// 名前：スペシャルか
	// 説明：石碑がSP石碑か汎用石碑か？を区別するbool。
	uint8_t isSpecial_010: 1;

	// 名前：パディング
	uint8_t pad1_010: 7;

	// 名前：パディング
	uint8_t pad2_011[3];

	// 名前：バディID
	// 説明：バディパラメータのID。「スペシャルか」が○の場合、このバディIDが召喚される。
	int32_t buddyId_014;

	// 名前：ドーピング用特殊効果ID
	// 説明：バディ召喚時に、バディにかかる特殊効果ID。
	int32_t dopingSpEffectId_018;

	// 名前：バディ起動距離[m]
	// 説明：撃破対象のキャラがこの範囲に1体でも居れば、その石碑でバディ召喚が可能になる
	uint16_t activateRange_01C;

	// 名前：バディ帰巣距離上書き[m]
	// 説明：バディの帰巣距離を上書きできる
	int16_t overwriteReturnRange_01E;

	// 名前：起動範囲上書き領域エンティティID
	// 説明：バディを召喚できる範囲を、指定エンティティIDの領域で上書きできる
	uint32_t overwriteActivateRegionEntityId_020;

	// 名前：警告範囲上書き領域エンティティID
	// 説明：警告領域エンティティID
	uint32_t warnRegionEntityId_024;

	// 名前：パディング
	uint8_t pad3_028[24];

} BuddyStoneParam;

#endif
