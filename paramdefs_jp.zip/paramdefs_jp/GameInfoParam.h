/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_GameInfoParam_H
#define _PARAM_GameInfoParam_H
#include <stdint.h>

// GAME_INFO_PARAM
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GameInfoParam {

	// 名前：タイトルのMsgID
	// 説明：タイトル名
	int32_t titleMsgId_000;

	// 名前：内容のMsgID
	// 説明：内容
	int32_t contentMsgId_004;

	// 名前：価格
	// 説明：価格
	int32_t value_008;

	// 名前：ソートID
	// 説明：ソートID
	int32_t sortId_00C;

	// 名前：アクションID
	// 説明：販売状況を判断するアクションIDです。
	int32_t eventId_010;

	// 名前：パディング
	// 説明：パディング
	uint8_t Pad_014[12];

} GameInfoParam;

#endif
