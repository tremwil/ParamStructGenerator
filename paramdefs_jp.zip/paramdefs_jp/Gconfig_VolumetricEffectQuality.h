/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_VolumetricEffectQuality_H
#define _PARAM_Gconfig_VolumetricEffectQuality_H
#include <stdint.h>

// CS_VOLUMETRIC_EFFECT_QUALITY_DETAIL
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_VolumetricEffectQuality {

	// 名前：フォグ有効
	// 説明：フォグ有効
	uint8_t fogEnabled_000;

	// 名前：フォグシャドウ許可
	// 説明：フォグシャドウ許可
	uint8_t fogShadowEnabled_001;

	// 名前：dmy
	// 説明：dmy
	uint8_t dmy_002[2];

	// 名前：シャドウのサンプルカウントオフセット。
	// 説明：シャドウのサンプルカウントオフセット。
	int32_t fogShadowSampleCountBias_004;

	// 名前：ローカルライト計算距離スケール (0にするとローカルライト計算をしない)
	// 説明：ローカルライト計算距離スケール (0にするとローカルライト計算をしない)
	float fogLocalLightDistScale_008;

	// 名前：フォグボリュームサイズスケーラ
	// 説明：フォグボリュームサイズスケーラ
	uint32_t fogVolueSizeScaler_00C;

	// 名前：フォグボリュームサイズ除算
	// 説明：フォグボリュームサイズ除算
	uint32_t fogVolueSizeDivider_010;

	// 名前：フォグボリューム奥行きスライススケーラ
	// 説明：フォグボリューム奥行きスライススケーラ
	uint32_t fogVolumeDepthScaler_014;

	// 名前：フォグボリューム奥行きスライス除算
	// 説明：フォグボリューム奥行きスライス除算
	uint32_t fogVolumeDepthDivider_018;

	// 名前：配置式フォグボリューム有効
	// 説明：配置式フォグボリューム有効
	uint8_t fogVolumeEnabled_01C;

	// 名前：アップスケール種別
	// 説明：アップスケール時の手法種別
	uint8_t fogVolumeUpScaleType_01D;

	// 名前：バイラテラル時のみ行われるエッジ補正レベル
	// 説明：バイラテラル時のみ行われるエッジ補正レベル(0:無効,1:1/2x1/2解像度でのエッジ再描画許可,2:1/2x1/2+1x1解像度でパラメータ削減ありのエッジ再描画許可,3:1/2x1/2+1x1解像度でのエッジ再描画許可)
	uint8_t fogVolumeEdgeCorrectionLevel_01E;

	// 名前：レイマーチング時のサンプリング数のオフセット
	// 説明：レイマーチング時のサンプリング数のオフセット
	int8_t fogVolumeRayMarcingSampleCountOffset_01F;

	// 名前：シャドウ許可
	// 説明：シャドウ許可(領域に影が落ちる、領域内の密度変化による陰影処理を指す)
	uint8_t fogVolumeShadowEnabled_020;

	// 名前：シャドウ許可時に設定にかかわらず領域に強制的に影を落とす
	// 説明：シャドウ許可時に設定にかかわらず領域に強制的に影を落とす(陰影処理は影響をうけない)
	uint8_t fogVolumeForceShadowing_021;

	// 名前：フォグボリュームのアップスケール処理解像度
	uint8_t fogVolumeResolution_022;

	// 名前：pad
	uint8_t pad2_023[1];

} Gconfig_VolumetricEffectQuality;

#endif
