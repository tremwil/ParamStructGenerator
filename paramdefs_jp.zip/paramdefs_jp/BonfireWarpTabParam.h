/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_BonfireWarpTabParam_H
#define _PARAM_BonfireWarpTabParam_H
#include <stdint.h>

// BONFIRE_WARP_TAB_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BonfireWarpTabParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：テキストID
	// 説明：タブの表示名テキストID[MenuText]
	int32_t textId_004;

	// 名前：ソートID
	// 説明：タブの表示順ソートID。照準で左から並ぶ
	int32_t sortId_008;

	// 名前：アイコンID
	// 説明：タブのアイコンID。メニューリソース準拠
	uint16_t iconId_00C;

	// 名前：パッド
	uint8_t pad_00E[2];

} BonfireWarpTabParam;

#endif
