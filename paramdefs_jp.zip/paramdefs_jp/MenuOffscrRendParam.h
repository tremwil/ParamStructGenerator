/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MenuOffscrRendParam_H
#define _PARAM_MenuOffscrRendParam_H
#include <stdint.h>

// MENU_OFFSCR_REND_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MenuOffscrRendParam {

	// 名前：カメラ注視点X
	// 説明：カメラ注視点X
	float camAtPosX_000;

	// 名前：カメラ注視点Y
	// 説明：カメラ注視点Y
	float camAtPosY_004;

	// 名前：カメラ注視点Z
	// 説明：カメラ注視点Z
	float camAtPosZ_008;

	// 名前：カメラ距離
	// 説明：カメラ距離
	float camDist_00C;

	// 名前：カメラ向きX
	// 説明：カメラ向きX
	float camRotX_010;

	// 名前：カメラ向きY
	// 説明：カメラ向きY
	float camRotY_014;

	// 名前：カメラ画角
	// 説明：カメラ画角
	float camFov_018;

	// 名前：カメラ操作時最短距離
	// 説明：カメラ操作時最短距離
	float camDistMin_01C;

	// 名前：カメラ操作時最長距離
	// 説明：カメラ操作時最長距離
	float camDistMax_020;

	// 名前：カメラ操作時最小向き
	// 説明：カメラ操作時最小向き
	float camRotXMin_024;

	// 名前：カメラ操作時最大向き
	// 説明：カメラ操作時最大向き
	float camRotXMax_028;

	// 名前：GparamID
	// 説明：GparamID
	uint32_t GparamID_02C;

	// 名前：環境マップテクスチャID
	// 説明：環境マップテクスチャID。N:\GR\data\Other\SysEnvTex\GILM????_rem.dds の数字4桁に対応しています。
	uint32_t envTexId_030;

	// 名前：GparamID(PS4用)
	// 説明：GparamID(PS4用)
	uint32_t Grapm_ID_forPS4_034;

	// 名前：GparamID(XboxOne用)
	// 説明：GparamID(XboxOne用)
	uint32_t Grapm_ID_forXB1_038;

	// 名前：予約
	// 説明：予約
	uint8_t pad_03C[4];

} MenuOffscrRendParam;

#endif
