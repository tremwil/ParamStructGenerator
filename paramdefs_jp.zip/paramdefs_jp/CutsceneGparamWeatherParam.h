/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CutsceneGparamWeatherParam_H
#define _PARAM_CutsceneGparamWeatherParam_H
#include <stdint.h>

// CUTSCENE_GPARAM_WEATHER_PARAM_ST
// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CutsceneGparamWeatherParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：デバッグパラメータか
	// 説明：○をつけたパラメータは全パッケージから除外します（デバッグ用なので）
	uint8_t disableParam_Debug_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 6;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：晴れ
	// 説明：晴れ
	int16_t DstWeather_Sunny_004;

	// 名前：快晴
	// 説明：快晴
	int16_t DstWeather_ClearSky_006;

	// 名前：薄曇り
	// 説明：薄曇り
	int16_t DstWeather_WeakCloudy_008;

	// 名前：曇り
	// 説明：曇り
	int16_t DstWeather_Cloud_00A;

	// 名前：雨
	// 説明：雨
	int16_t DstWeather_Rain_00C;

	// 名前：豪雨
	// 説明：豪雨
	int16_t DstWeather_HeavyRain_00E;

	// 名前：嵐
	// 説明：嵐
	int16_t DstWeather_Storm_010;

	// 名前：嵐（守護者の末裔との戦闘用）
	// 説明：嵐（守護者の末裔との戦闘用）
	int16_t DstWeather_StormForBattle_012;

	// 名前：雪
	// 説明：雪
	int16_t DstWeather_Snow_014;

	// 名前：大雪
	// 説明：大雪
	int16_t DstWeather_HeavySnow_016;

	// 名前：霧
	// 説明：霧
	int16_t DstWeather_Fog_018;

	// 名前：濃霧
	// 説明：濃霧
	int16_t DstWeather_HeavyFog_01A;

	// 名前：砂嵐
	// 説明：砂嵐
	int16_t DstWeather_SandStorm_01C;

	// 名前：濃霧（雨）
	// 説明：濃霧（雨）
	int16_t DstWeather_HeavyFogRain_01E;

	// 名前：再生終了時のインゲーム天候指定(未使用、無効)
	// 説明：再生終了時のインゲーム天候指定(空白または「無効」の場合は何も行われない。)
	int16_t PostPlayIngameWeather_020;

	// 名前：屋内屋外指定
	// 説明：屋内にすると「天候パラメータ.xlsm」の「天候SfxId(屋外)」と「風SfxId(屋外)」で指定されたSFXがカットシーン内で無効になります。
	uint8_t IndoorOutdoorType_022;

	// 名前：インゲームの天候SFX引き継ぐか？_晴れ
	// 説明：インゲームの天候SFX引き継ぐか？_晴れ
	uint8_t TakeOverDstWeather_Sunny_023;

	// 名前：インゲームの天候SFX引き継ぐか？_快晴
	// 説明：インゲームの天候SFX引き継ぐか？_快晴
	uint8_t TakeOverDstWeather_ClearSky_024;

	// 名前：インゲームの天候SFX引き継ぐか？_薄曇り
	// 説明：インゲームの天候SFX引き継ぐか？_薄曇り
	uint8_t TakeOverDstWeather_WeakCloudy_025;

	// 名前：インゲームの天候SFX引き継ぐか？_曇り
	// 説明：インゲームの天候SFX引き継ぐか？_曇り
	uint8_t TakeOverDstWeather_Cloud_026;

	// 名前：インゲームの天候SFX引き継ぐか？_雨
	// 説明：インゲームの天候SFX引き継ぐか？_雨
	uint8_t TakeOverDstWeather_Rain_027;

	// 名前：インゲームの天候SFX引き継ぐか？_豪雨
	// 説明：インゲームの天候SFX引き継ぐか？_豪雨
	uint8_t TakeOverDstWeather_HeavyRain_028;

	// 名前：インゲームの天候SFX引き継ぐか？_嵐
	// 説明：インゲームの天候SFX引き継ぐか？_嵐
	uint8_t TakeOverDstWeather_Storm_029;

	// 名前：インゲームの天候SFX引き継ぐか？_嵐（守護者の末裔との戦闘用）
	// 説明：インゲームの天候SFX引き継ぐか？_嵐（守護者の末裔との戦闘用）
	uint8_t TakeOverDstWeather_StormForBattle_02A;

	// 名前：インゲームの天候SFX引き継ぐか？_雪
	// 説明：インゲームの天候SFX引き継ぐか？_雪
	uint8_t TakeOverDstWeather_Snow_02B;

	// 名前：インゲームの天候SFX引き継ぐか？_大雪
	// 説明：インゲームの天候SFX引き継ぐか？_大雪
	uint8_t TakeOverDstWeather_HeavySnow_02C;

	// 名前：インゲームの天候SFX引き継ぐか？_霧
	// 説明：インゲームの天候SFX引き継ぐか？_霧
	uint8_t TakeOverDstWeather_Fog_02D;

	// 名前：インゲームの天候SFX引き継ぐか？_濃霧
	// 説明：インゲームの天候SFX引き継ぐか？_濃霧
	uint8_t TakeOverDstWeather_HeavyFog_02E;

	// 名前：インゲームの天候SFX引き継ぐか？_砂嵐
	// 説明：インゲームの天候SFX引き継ぐか？_砂嵐
	uint8_t TakeOverDstWeather_SandStorm_02F;

	// 名前：インゲームの天候SFX引き継ぐか？_濃霧（雨）
	// 説明：インゲームの天候SFX引き継ぐか？_濃霧（雨）
	uint8_t TakeOverDstWeather_HeavyFogRain_030;

	// 名前：reserved
	// 説明：reserved
	uint8_t reserved_031[7];

	// 名前：吹雪
	// 説明：吹雪
	int16_t DstWeather_Snowstorm_038;

	// 名前：嵐（雷）
	// 説明：予備天候2
	int16_t DstWeather_LightningStorm_03A;

	// 名前：雪特殊(予備3)
	// 説明：予備天候3
	int16_t DstWeather_Reserved3_03C;

	// 名前：予備天候4
	// 説明：予備天候4
	int16_t DstWeather_Reserved4_03E;

	// 名前：予備天候5
	// 説明：予備天候5
	int16_t DstWeather_Reserved5_040;

	// 名前：予備天候6
	// 説明：予備天候6
	int16_t DstWeather_Reserved6_042;

	// 名前：予備天候7
	// 説明：予備天候7
	int16_t DstWeather_Reserved7_044;

	// 名前：予備天候8
	// 説明：予備天候8
	int16_t DstWeather_Reserved8_046;

	// 名前：インゲームの天候SFX引き継ぐか？_吹雪
	// 説明：インゲームの天候SFX引き継ぐか？_吹雪
	uint8_t TakeOverDstWeather_Snowstorm_048;

	// 名前：インゲームの天候SFX引き継ぐか？_嵐（雷）
	// 説明：インゲームの天候SFX引き継ぐか？_嵐（雷）
	uint8_t TakeOverDstWeather_LightningStorm_049;

	// 名前：インゲームの天候SFX引き継ぐか？_雪特殊(予備3)
	// 説明：インゲームの天候SFX引き継ぐか？_予備天候3
	uint8_t TakeOverDstWeather_Reserved3_04A;

	// 名前：インゲームの天候SFX引き継ぐか？_予備天候4
	// 説明：インゲームの天候SFX引き継ぐか？_予備天候4
	uint8_t TakeOverDstWeather_Reserved4_04B;

	// 名前：インゲームの天候SFX引き継ぐか？_予備天候5
	// 説明：インゲームの天候SFX引き継ぐか？_予備天候5
	uint8_t TakeOverDstWeather_Reserved5_04C;

	// 名前：インゲームの天候SFX引き継ぐか？_予備天候6
	// 説明：インゲームの天候SFX引き継ぐか？_予備天候6
	uint8_t TakeOverDstWeather_Reserved6_04D;

	// 名前：インゲームの天候SFX引き継ぐか？_予備天候7
	// 説明：インゲームの天候SFX引き継ぐか？_予備天候7
	uint8_t TakeOverDstWeather_Reserved7_04E;

	// 名前：インゲームの天候SFX引き継ぐか？_予備天候8
	// 説明：インゲームの天候SFX引き継ぐか？_予備天候8
	uint8_t TakeOverDstWeather_Reserved8_04F;

	// 名前：天候GparamにMapGD地方IDを適用するか？
	// 説明：カットシーン天候Gparamにインゲーム同様MapGD地方IDによる変化を適用するか？(【GR】SEQ30194)
	uint8_t IsEnableApplyMapGdRegionIdForGparam_050;

	// 名前：reserved1
	// 説明：reserved1 ver4->5 64->96へ増量
	uint8_t reserved2_051[1];

	// 名前：天候GparamMapGD用地方ID上書き
	// 説明：カットシーン天候Gparamに使用されるIDを上書きする(-1：上書きなし。カットシーン再生時のMapGD地方IDが使用される)。「天候GparamにMapGD地方IDを適用するか？」が×の場合は参照されない
	int16_t OverrideMapGdRegionId_052;

	// 名前：reserved1
	// 説明：reserved1 ver4->5 64->96へ増量
	uint8_t reserved1_054[12];

} CutsceneGparamWeatherParam;

#endif
