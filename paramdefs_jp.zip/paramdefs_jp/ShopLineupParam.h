/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ShopLineupParam_H
#define _PARAM_ShopLineupParam_H
#include <stdint.h>

// SHOP_LINEUP_PARAM
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ShopLineupParam {

	// 名前：装備ID
	// 説明：販売している装備品のID
	int32_t equipId_000;

	// 名前：価格
	// 説明：上書きする販売価格(-1:上書きしない)
	int32_t value_004;

	// 名前：購入に必要な素材ID
	// 説明：購入に必要な素材ID(-1:なし)
	int32_t mtrlId_008;

	// 名前：個数保持イベントフラグ
	// 説明：個数を保持してあるイベントフラグ値
	uint32_t eventFlag_forStock_00C;

	// 名前：販売解禁イベントフラグ
	// 説明：販売解禁イベントフラグ
	uint32_t eventFlag_forRelease_010;

	// 名前：販売個数
	// 説明：販売個数
	int16_t sellQuantity_014;

	// 名前：パディング
	uint8_t pad3_016[1];

	// 名前：装備タイプ
	// 説明：販売している装備品の種類
	uint8_t equipType_017;

	// 名前：価格タイプ
	// 説明：価格の種類。販売価格を上書きするときだけ適用される
	uint8_t costType_018;

	// 名前：パディング
	uint8_t pad1_019[1];

	// 名前：販売セット数
	// 説明：販売セット数。1回の購入で手に入る個数（デフォルト: 1）
	uint16_t setNum_01A;

	// 名前：加算
	// 説明：装備品の販売価格に対する補正（加算）。装備品パラの販売価格×倍率＋加算
	int32_t value_Add_01C;

	// 名前：倍率
	// 説明：装備品の販売価格に対する補正（倍率）。装備品パラの販売価格×倍率＋加算
	float value_Magnification_020;

	// 名前：アイコンID
	// 説明：メニュー表示用_アイコンID(-1:上書きしない)
	int32_t iconId_024;

	// 名前：テキストID
	// 説明：メニュー表示用_テキストID(-1:上書きしない)
	int32_t nameMsgId_028;

	// 名前：メニュータイトルテキストID
	// 説明：ショップのメニュータイトルのテキストID(-1:上書きしない)。ショップを起動するときに渡されたパラID範囲の中で最初に見つかったパラのこの値が参照されます
	int32_t menuTitleMsgId_02C;

	// 名前：メニューアイコンID
	// 説明：ショップのメニューアイコンID(-1:上書きしない)。ショップを起動するときに渡されたパラID範囲の中で最初に見つかったパラのこの値が参照されます
	int16_t menuIconId_030;

	// 名前：パディング
	uint8_t pad2_032[2];

} ShopLineupParam;

#endif
