/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AssetGeometryParam_H
#define _PARAM_AssetGeometryParam_H
#include <stdint.h>

// ASSET_GEOMETORY_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AssetGeometryParam {

	// 名前：サウンドのバンクID
	// 説明：サウンドのバンクID(-1:バンクなし, それ以外:指定したIDのバンク)
	int32_t soundBankId_000;

	// 名前：破壊音SEID
	// 説明：破壊音SEID(9桁) -1：assetIdから生成
	int32_t soundBreakSEId_004;

	// 名前：描画パラメータ参照ID
	// 説明：描画パラメータ参照ID。パーツ描画パラメータ.xlsmの参照IDです。
	int32_t refDrawParamId_008;

	// 名前：静的アセットヒット構築設定
	// 説明：静的アセットのヒット構築タイプを設定します。動的アセットでは無視されます。
	int8_t hitCreateType_00C;

	// 名前：アセット挙動タイプ
	// 説明：動的(すべてのアセット機能が使用可能)、静的(旧マップ扱いの機能制限された軽いアセット)、部分静的(部分破壊アセット)
	uint8_t behaviorType_00D;

	// 名前：衝突判定タイプ
	// 説明：衝突判定タイプ。アセットが何と当たるかが設定できます。
	uint8_t collisionType_00E;

	// 名前：雨遮断設定
	// 説明：雨遮断のタイプです。SFXと濡れ表現の遮断設定が行えます
	uint8_t rainBlockingType_00F;

	// 名前：HP
	// 説明：破壊までの耐久力(-1:破壊不可)
	int16_t hp_010;

	// 名前：防御力
	// 説明：この値以下の攻撃力はダメージなし
	uint16_t defense_012;

	// 名前：破壊後強制停止時間
	// 説明：破壊されてから剛体を強制的に停止するまでの時間（0で強制停止しない）
	float breakStopTime_014;

	// 名前：破壊時SFXID
	// 説明：破壊時のSFXID(-1:デフォルト(810030))
	int32_t breakSfxId_018;

	// 名前：破壊時SFXダミポリID
	// 説明：破壊時SFXの発生位置ダミポリID(-1：配置位置）
	int32_t breakSfxCpId_01C;

	// 名前：破壊後着地時SFX識別子
	// 説明：破壊された後、最初に着地した際に再生するオブジェ材質依存SFXの識別子(-1:発生しない)
	int32_t breakLandingSfxId_020;

	// 名前：破壊時 弾発生 行動パラメータID
	// 説明：破壊時[弾]の行動パラメータ(-1:発生しない)。周回によるオフセットの仕様があるので注意。(【GR】SEQ35556 )
	int32_t breakBulletBehaviorId_024;

	// 名前：破壊時 弾発生 ダミポリID
	// 説明：破壊時[弾]の発生位置ダミポリID(-1:配置位置)
	int32_t breakBulletCpId_028;

	// 名前：破片非表示 待機時間(秒)
	// 説明：破片非表示 待機時間(秒)
	float FragmentInvisibleWaitTime_02C;

	// 名前：破片非表示 時間(秒)
	// 説明：破片を非表示にさせる時間(秒)
	float FragmentInvisibleTime_030;

	// 名前：破壊時発生AI音ID
	// 説明：破壊時に発生させるAI音ID
	int32_t BreakAiSoundID_034;

	// 名前：破壊時_アイテム抽選種別
	// 説明：破壊時に抽選したアイテムの入手方法を決めるタイプ
	int8_t breakItemLotType_038;

	// 名前：アニメ破壊ID最大値
	// 説明：アニメ破壊IDが0番から何番までか
	uint8_t animBreakIdMax_039;

	// 名前：破壊時 弾発生 属性ダメージ条件
	// 説明：アセット破壊時に最後に受けたダメージがこの設定の条件を満たしていれば弾丸を生成する
	int8_t breakBulletAttributeDamageType_03A;

	// 名前：プレイヤ衝突で壊れるか
	// 説明：プレイヤが接触したときに壊れ(0:ない, 1:る)
	uint8_t isBreakByPlayerCollide_03B: 1;

	// 名前：敵キャラ衝突で壊れるか
	// 説明：敵キャラが接触したときに壊れ(0:ない, 1:る)
	uint8_t isBreakByEnemyCollide_03B: 1;

	// 名前：キャラが乗ったら壊れるか
	// 説明：キャラが乗ったら壊れるか(0:壊れるない 1:壊れる)
	uint8_t isBreak_ByChrRide_03B: 1;

	// 名前：初期出現用破壊禁止
	// 説明：プレイヤの初期出現で壊れ(0:る, 1:ない)
	uint8_t isDisableBreakForFirstAppear_03B: 1;

	// 名前：アニメ破壊か
	// 説明：アニメ破壊か(0:物理破壊, 1:アニメ破壊)
	uint8_t isAnimBreak_03B: 1;

	// 名前：ダメージを遮蔽するか
	// 説明：ダメージを受けたときに、そのダメージを反対側に通さないかどうか　(0:通す, 1:通さない)
	uint8_t isDamageCover_03B: 1;

	// 名前：攻撃を弾くか
	// 説明：攻撃を弾くか(0:弾かない, 1:弾く)
	uint8_t isAttackBacklash_03B: 1;

	// 名前：リザーブ2
	uint8_t Reserve_2_03B: 1;

	// 名前：ハシゴか
	// 説明：ハシゴか(0:ちがう, 1:そう)
	uint8_t isLadder_03C: 1;

	// 名前：移動オブジェか
	// 説明：移動オブジェか。マルチ時の移動処理の分岐に使われるフラグです(0:ちがう, 1:そう)
	uint8_t isMoveObj_03C: 1;

	// 名前：天球扱いか
	// 説明：天球扱いの処理(プレイヤー追従など)が行われます(0:ちがう, 1:そう)
	uint8_t isSkydomeFlag_03C: 1;

	// 名前：ポリ劇中アニメを停止するか
	// 説明：ポリ劇中アニメを停止するか(0:しない, 1:する)
	uint8_t isAnimPauseOnRemoPlay_03C: 1;

	// 名前：燃焼するか
	// 説明：燃焼するか(0:しない, 1:する)
	uint8_t isBurn_03C: 1;

	// 名前：再収集時変化があるか
	// 説明：このフラグが○なら、配置単位で再度収集するアセットでは「再収集時_***」のパラメータが使われます
	uint8_t isEnableRepick_03C: 1;

	// 名前：収集時破壊か
	// 説明：×なら収集時にアニメ再生、○なら収集時に破壊（差し替えなど含めた全ての場合において破壊）
	uint8_t isBreakOnPickUp_03C: 1;

	// 名前：巨大敵衝突で壊れるか
	// 説明：巨大敵が接触したときに壊れ(0:ない, 1:る)
	uint8_t isBreakByHugeenemyCollide_03C: 1;

	// 名前：破壊前ナビメッシュフラグ
	// 説明：破壊前のアセットから設定されるナビメッシュフラグ
	uint8_t navimeshFlag_03D;

	// 名前：燃焼 弾発生間隔(フレーム)
	// 説明：延焼用の弾を発生する間隔(フレーム)
	uint16_t burnBulletInterval_03E;

	// 名前：クロス更新距離(m)
	// 説明：havokClothの更新を行なうカメラからの距離(0:必ず更新する)
	float clothUpdateDist_040;

	// 名前：ランタイム生成アセットの寿命(秒)
	// 説明：ランタイム生成アセットが生成後に消滅するまでの時間 (0:消滅しない)
	float lifeTime_forRuntimeCreate_044;

	// 名前：プレイヤー接触時SE ID
	// 説明：自分が操作するローカルプレイヤーが触れた際に再生するSEのID(-1:再生しない)
	int32_t contactSeId_048;

	// 名前：再収集時_アニメオフセット
	// 説明：「再収集時変化があるか」が○のアセットは配置単位で再収集時、この値でオフセットしたアニメIDで未収集/収集済のアニメを再生
	int32_t repickAnimIdOffset_04C;

	// 名前：風係数(破壊前)
	// 説明：風係数(破壊前)
	float windEffectRate_0_050;

	// 名前：風係数(破壊後)
	// 説明：風係数(破壊後)
	float windEffectRate_1_054;

	// 名前：風影響タイプ(破壊前)
	// 説明：風影響タイプ(破壊前)
	uint8_t windEffectType_0_058;

	// 名前：風影響タイプ(破壊後)
	// 説明：風影響タイプ(破壊後)
	uint8_t windEffectType_1_059;

	// 名前：上書き材質ID
	// 説明：アセットの材質ID上書き設定(-1：モデルの材質IDを上書きしない 0以上：材質ID上書き)　はしご上ではこの設定でのみ材質IDが反映されます
	int16_t overrideMaterialId_05A;

	// 名前：自動生成時の高さオフセット(m)
	// 説明：マップに自動生成時にレイキャストが当たったところからどれぐらい浮かせるかの高さオフセット[m]
	float autoCreateOffsetHeight_05C;

	// 名前：燃焼時間(秒)
	// 説明：燃焼時間(秒)(0で燃え続ける)
	float burnTime_060;

	// 名前：燃焼 破壊判定進行度
	// 説明：破壊状態に切り替わる燃焼度の閾値
	float burnBraekRate_064;

	// 名前：燃焼 SFXID：0
	// 説明：燃焼時のSFXID：0 (-1：SFXなし)
	int32_t burnSfxId_068;

	// 名前：燃焼 SFXID：1
	// 説明：燃焼時のSFXID：1 (-1：SFXなし)
	int32_t burnSfxId_1_06C;

	// 名前：燃焼 SFXID：2
	// 説明：燃焼時のSFXID：2 (-1：SFXなし)
	int32_t burnSfxId_2_070;

	// 名前：燃焼 SFXID：3
	// 説明：燃焼時のSFXID：3 (-1：SFXなし)
	int32_t burnSfxId_3_074;

	// 名前：燃焼 SFX発生遅延 開始時間(秒)：0
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin_078;

	// 名前：燃焼 SFX発生遅延 開始時間(秒)：1
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin_1_07C;

	// 名前：燃焼 SFX発生遅延 開始時間(秒)：2
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin_2_080;

	// 名前：燃焼 SFX発生遅延 開始時間(秒)：3
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin_3_084;

	// 名前：燃焼 SFX発生遅延 終了時間(秒)：0
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax_088;

	// 名前：燃焼 SFX発生遅延 終了時間(秒)：1
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax_1_08C;

	// 名前：燃焼 SFX発生遅延 終了時間(秒)：2
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax_2_090;

	// 名前：燃焼 SFX発生遅延 終了時間(秒)：3
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax_3_094;

	// 名前：燃焼 弾発生 行動パラメータ：0
	// 説明：燃焼時の弾発生行動パラメータ：0(-1:発生しない)
	int32_t burnBulletBehaviorId_098;

	// 名前：燃焼 弾発生 行動パラメータ：1
	// 説明：燃焼時の弾発生行動パラメータ：1(-1:発生しない)
	int32_t burnBulletBehaviorId_1_09C;

	// 名前：燃焼 弾発生 行動パラメータ：2
	// 説明：燃焼時の弾発生行動パラメータ：2(-1:発生しない)
	int32_t burnBulletBehaviorId_2_0A0;

	// 名前：燃焼 弾発生 行動パラメータ：3
	// 説明：燃焼時の弾発生行動パラメータ：3(-1:発生しない)
	int32_t burnBulletBehaviorId_3_0A4;

	// 名前：燃焼 弾発生遅延時間(秒)
	// 説明：延焼用の弾発生を遅らせる時間(秒)
	float burnBulletDelayTime_0A8;

	// 名前：ペイントデカールターゲットサイズ
	// 説明：ペイントデカールターゲットサイズ 0：デカール無効 (0～4096 ２のべき乗 0, 2, 4, 8, … 2048 のみ有効)
	uint16_t paintDecalTargetTextureSize_0AC;

	// 名前：破壊後ナビメッシュフラグ
	// 説明：破壊後のアセットから設定されるナビメッシュフラグ
	uint8_t navimeshFlag_after_0AE;

	// 名前：カメラ接近時描画
	// 説明：カメラ接近時の描画設定。【GR】SEQ07529
	int8_t camNearBehaviorType_0AF;

	// 名前：破壊時_アイテム抽選ID_マップ用
	// 説明：破壊時に抽選させるアイテム抽選ID_マップ用　-1：抽選しない
	int32_t breakItemLotParamId_0B0;

	// 名前：収集時_アクションボタンID
	// 説明：収集で出すアクションボタンID　-1：収集機能は無効
	int32_t pickUpActionButtonParamId_0B4;

	// 名前：収集時_アイテム抽選ID_マップ用
	// 説明：収集時に抽選させるアイテム抽選ID_マップ用　-1：収集機能は無効
	int32_t pickUpItemLotParamId_0B8;

	// 名前：自動描画グループ_裏面チェック
	// 説明：自動描画グループ_裏面チェック
	uint8_t autoDrawGroupBackFaceCheck_0BC;

	// 名前：自動描画グループ_遮蔽
	// 説明：自動描画グループ_遮蔽
	uint8_t autoDrawGroupDepthWrite_0BD;

	// 名前：自動描画グループ_影テスト
	// 説明：自動描画グループ_影テスト
	uint8_t autoDrawGroupShadowTest_0BE;

	// 名前：デバッグ_許容地面高さチェック
	// 説明：デバッグ_許容地面高さチェック 詳細はSEQ07876参照
	uint8_t debug_isHeightCheckEnable_0BF;

	// 名前：床下ナビメッシュ切り抜き対象外
	// 説明：床（地面）のヒットより低い位置に配置された場合、床下ナビメッシュ削除対象から外すかを設定すること ツールから参照
	uint8_t hitCarverCancelAreaFlag_0C0;

	// 名前：ナビメッシュ結合制御
	// 説明：設定されたアセットが、ナビメッシュビルド時に、ヒットパーツの結合対象から除外される
	uint8_t assetNavimeshNoCombine_0C1;

	// 名前：ナビメッシュフラグ適用先
	// 説明：アセットから設定されるナビメッシュフラグの適用先
	uint8_t navimeshFlagApply_0C2;

	// 名前：破壊後ナビメッシュフラグ適用先
	// 説明：破壊後のアセットから設定されるナビメッシュフラグの適用先
	uint8_t navimeshFlagApply_after_0C3;

	// 名前：自動描画グループ_合格ピクセル
	// 説明：自動描画グループ_合格ピクセル（0.0～1.0に設定することで撮影時に拡大される）
	float autoDrawGroupPassPixelNum_0C4;

	// 名前：収集時_差し替えフラグ条件
	// 説明：このイベントフラグがONの時は後続の差し替えのIDを使う　0：常に差し替えない
	uint32_t pickUpReplacementEventFlag_0C8;

	// 名前：収集時_差し替えアニメオフセット
	// 説明：「収集時_差し替えフラグ条件」がONの時、この値でオフセットしたアニメIDで未収集/収集済のアニメを再生
	int32_t pickUpReplacementAnimIdOffset_0CC;

	// 名前：収集時_差し替えアクションボタンID
	// 説明：「収集時_差し替えフラグ条件」がONの時、このアクションボタンIDが使われる
	int32_t pickUpReplacementActionButtonParamId_0D0;

	// 名前：収集時_差し替えアイテム抽選ID_マップ用
	// 説明：「収集時_差し替えフラグ条件」がONの時、このアイテム抽選ID_マップ用が使われる
	int32_t pickUpReplacementItemLotParamId_0D4;

	// 名前：地面を這う弾丸の着弾時の挙動
	// 説明：追従タイプ「衝突しても地面を這う」の弾丸がアセットに衝突した際、着弾地点に沿う方向に曲げるか？の挙動
	uint8_t slidingBulletHitType_0D8;

	// 名前：茂みダメージで壊れるか
	// 説明：◯のアセットは、 「茂みにダメージ可」◯  かつ 「オブジェ攻撃力 ＞ 防御力」の攻撃のみ、ダメージが通るようになります【GR】SEQ20617
	uint8_t isBushesForDamage_0D9;

	// 名前：弾丸貫通タイプ
	// 説明：弾丸がヒットして着弾するか？を決める時に、どの弾丸パラを参照するか？を決める値。
	uint8_t penetrationBulletType_0DA;

	// 名前：リザーブ3
	uint8_t Reserve_3_0DB[1];

	// 名前：リザーブ4
	uint8_t Reserve_4_0DC[4];

	// 名前：破壊音ダミポリID
	// 説明：破壊音を再生する場所のダミポリID (-1:配置位置)
	int32_t soundBreakSECpId_0E0;

	// 名前：デバッグ_許容地面高さ_最小[m]
	// 説明：デバッグ_許容地面高さ_最小[m] 詳細はSEQ07876参照　最大より小さい必要あり
	float debug_HeightCheckCapacityMin_0E4;

	// 名前：デバッグ_許容地面高さ_最大[m]
	// 説明：デバッグ_許容地面高さ_最大[m] 詳細はSEQ07876参照　最小より大きい必要あり
	float debug_HeightCheckCapacityMax_0E8;

	// 名前：再収集時_アクションボタンID
	// 説明：「再収集時変化があるか」が○のアセットは配置単位で再収集時、このアクションボタンIDが使われる
	int32_t repickActionButtonParamId_0EC;

	// 名前：再収集時_アイテム抽選ID_マップ用
	// 説明：「再収集時変化があるか」が○のアセットは配置単位で再収集時、このアイテム抽選ID_マップ用が使われる
	int32_t repickItemLotParamId_0F0;

	// 名前：再収集時_差し替えアニメオフセット
	// 説明：「再収集時変化があるか」が○のアセットは配置単位で再収集時、「収集時_差し替えアニメオフセット」の代わりにこのパラメータを使う
	int32_t repickReplacementAnimIdOffset_0F4;

	// 名前：再収集時_差し替えアクションボタンID
	// 説明：「再収集時変化があるか」が○のアセットは配置単位で再収集時、「収集時_差し替えアクションボタンID」の代わりにこのパラメータを使う
	int32_t repickReplacementActionButtonParamId_0F8;

	// 名前：再収集時_差し替えアイテム抽選ID_マップ用
	// 説明：「再収集時変化があるか」が○のアセットは配置単位で再収集時、「収集時_差し替えアイテム抽選ID_マップ用」の代わりにこのパラメータを使う
	int32_t repickReplacementItemLotParamId_0FC;

	// 名前：ナビメッシュ地形内判定無効化
	// 説明：これが設定されたAssetはCarverを作らない
	uint8_t noGenerateCarver_100;

	// 名前：破壊後に巨大敵に当たらない
	// 説明：破壊後のヒットフィルタを衝突判定タイプ巨大敵に当たらない（静○動○）相当のもので上書きする
	uint8_t noHitHugeAfterBreak_101;

	// 名前：破壊を同期するか
	// 説明：これが×の場合は初期同期,マップアクティベート同期,インゲーム中のアセット破壊同期を行わないようにし、リモートPCの攻撃が当たらなくなる
	uint8_t isEnabledBreakSync_102: 1;

	// 名前：再収集時_非表示
	// 説明：配置単位で再収集時にアイテム抽選的に取れなければアセットを非表示にします
	uint8_t isHiddenOnRepick_102: 1;

	// 名前：マルチ中のみ有効か(動的のみ)
	// 説明：マルチ中のみ有効か。動的アセットのみ有効。(詳細：SEQ15087)
	uint8_t isCreateMultiPlayOnly_102: 1;

	// 名前：弾丸の着弾SFXを発生しない
	// 説明：○の場合、当たった弾丸が貫通しようと着弾しようと着弾SFXは発生しない
	uint8_t isDisableBulletHitSfx_102: 1;

	// 名前：サイン／血文字作成可能か(アセット破壊前) 
	// 説明：アセット上にいるときサイン/血文字の作成可能かを設定する(破壊前)〇：可能、×：不可能(詳細：SEQ122568)
	uint8_t isEnableSignPreBreak_102: 1;

	// 名前：サイン／血文字作成可能か(アセット破壊後) 
	// 説明：アセット上にいるときサイン/血文字の作成可能かを設定する(破壊後)〇：可能、×：不可能(詳細：SEQ122568)
	uint8_t isEnableSignPostBreak_102: 1;

	// 名前：リザーブ1
	uint8_t Reserve_1_102: 2;

	// 名前：召喚禁止/侵入禁止領域生成（ダミポリ）
	// 説明：召喚禁止/侵入禁止領域生成（ダミポリ）
	uint8_t generateMultiForbiddenRegion_103;

	// 名前：常駐SEID0
	// 説明：アセットに常駐させるサウンドID0(9桁) (-1:常駐なし)
	int32_t residentSeId0_104;

	// 名前：常駐SEID1
	// 説明：アセットに常駐させるサウンドID1(9桁) (-1:常駐なし)
	int32_t residentSeId1_108;

	// 名前：常駐SEID2
	// 説明：アセットに常駐させるサウンドID2(9桁) (-1:常駐なし)
	int32_t residentSeId2_10C;

	// 名前：常駐SEID3
	// 説明：アセットに常駐させるサウンドID3(9桁) (-1:常駐なし)
	int32_t residentSeId3_110;

	// 名前：常駐SEダミポリID0
	// 説明：常駐サウンドをアタッチするダミポリID0 (-1:配置位置)
	int16_t residentSeDmypolyId0_114;

	// 名前：常駐SEダミポリID1
	// 説明：常駐サウンドをアタッチするダミポリID1 (-1:配置位置)
	int16_t residentSeDmypolyId1_116;

	// 名前：常駐SEダミポリID2
	// 説明：常駐サウンドをアタッチするダミポリID2 (-1:配置位置)
	int16_t residentSeDmypolyId2_118;

	// 名前：常駐SEダミポリID3
	// 説明：常駐サウンドをアタッチするダミポリID3 (-1:配置位置)
	int16_t residentSeDmypolyId3_11A;

	// 名前：オープン_XB1除外割合
	// 説明：オープン_XB1除外割合【GR】SEQ25310
	uint8_t excludeActivateRatio_Xboxone_Grid_11C;

	// 名前：レガシー_XB1除外割合
	// 説明：レガシー_XB1除外割合【GR】SEQ25310
	uint8_t excludeActivateRatio_Xboxone_Legacy_11D;

	// 名前：オープン_PS4除外割合
	// 説明：オープン_PS4除外割合【GR】SEQ25310
	uint8_t excludeActivateRatio_PS4_Grid_11E;

	// 名前：レガシー_PS4除外割合
	// 説明：レガシー_PS4除外割合【GR】SEQ25310
	uint8_t excludeActivateRatio_PS4_Legacy_11F;

	// 名前：リザーブ0
	// 説明：リザーブ0
	uint8_t Reserve_0_120[32];

} AssetGeometryParam;

#endif
