/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_LoadBalancerNewDrawDistScaleParam_H
#define _PARAM_LoadBalancerNewDrawDistScaleParam_H
#include <stdint.h>

// LOAD_BALANCER_NEW_DRAW_DIST_SCALE_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _LoadBalancerNewDrawDistScaleParam {

	// 名前：発動レベル(開始)
	// 説明：描画距離スケール発動レベル(開始)
	uint8_t DrawDist_LvBegin_000;

	// 名前：発動レベル(終了)
	// 説明：描画距離スケール発動レベル(修了)
	uint8_t DrawDist_LvEnd_001;

	// 名前：予備
	// 説明：予備
	uint8_t reserve0_002[2];

	// 名前：スケール（開始）
	// 説明：描画距離スケール（開始）
	float DrawDist_ScaleBegin_004;

	// 名前：スケール（終了）
	// 説明：描画距離スケール（修了）
	float DrawDist_ScaleEnd_008;

	// 名前：発動レベル(開始)
	// 説明：影描画距離スケール発動レベル(開始)
	uint8_t ShadwDrawDist_LvBegin_00C;

	// 名前：発動レベル(終了)
	// 説明：影描画距離スケール発動レベル(修了)
	uint8_t ShadwDrawDist_LvEnd_00D;

	// 名前：予備
	// 説明：予備
	uint8_t reserve1_00E[2];

	// 名前：スケール（開始）
	// 説明：影描画距離スケール（開始）
	float ShadwDrawDist_ScaleBegin_010;

	// 名前：スケール（終了）
	// 説明：影描画距離スケール（修了）
	float ShadwDrawDist_ScaleEnd_014;

	// 名前：予備
	// 説明：予備
	uint8_t reserve2_018[24];

} LoadBalancerNewDrawDistScaleParam;

#endif
