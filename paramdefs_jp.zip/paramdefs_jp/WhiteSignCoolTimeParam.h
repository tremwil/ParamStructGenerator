/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WhiteSignCoolTimeParam_H
#define _PARAM_WhiteSignCoolTimeParam_H
#include <stdint.h>

// WHITE_SIGN_COOL_TIME_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WhiteSignCoolTimeParam {

	// 名前：制限時間（通常・指なし）
	// 説明：制限時間[sec]（通常・干からびた指無）
	float limitationTime_Normal_000;

	// 名前：制限時間（通常・指あり）
	// 説明：制限時間[sec]（通常・干からびた指有）
	float limitationTime_NormalDriedFinger_004;

	// 名前：制限時間（マップ守護・指なし）
	// 説明：制限時間[sec]（マップ守護・干からびた指無）
	float limitationTime_Guardian_008;

	// 名前：制限時間（マップ守護・指あり）
	// 説明：制限時間[sec]（マップ守護・干からびた指有）
	float limitationTime_GuardianDriedFinger_00C;

} WhiteSignCoolTimeParam;

#endif
