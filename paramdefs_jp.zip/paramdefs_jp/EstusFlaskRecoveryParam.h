/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EstusFlaskRecoveryParam_H
#define _PARAM_EstusFlaskRecoveryParam_H
#include <stdint.h>

// ESTUS_FLASK_RECOVERY_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EstusFlaskRecoveryParam {

	// 名前：ホスト
	// 説明：ホストのエスト回復数
	uint8_t host_000;

	// 名前：侵入経路_オーブ_なし
	// 説明：侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_None_001;

	// 名前：侵入経路_オーブ_太陽
	// 説明：侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_Umbasa_002;

	// 名前：侵入経路_オーブ_バーサーカー
	// 説明：侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_Berserker_003;

	// 名前：侵入経路_オーブ_罪人
	// 説明：侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_Sinners_004;

	// 名前：侵入経路_サイン_なし
	// 説明：侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_None_005;

	// 名前：侵入経路_サイン_太陽
	// 説明：侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_Umbasa_006;

	// 名前：侵入経路_サイン_バーサーカー
	// 説明：侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_Berserker_007;

	// 名前：侵入経路_サイン_罪人
	// 説明：侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_Sinners_008;

	// 名前：侵入経路_指輪_罪人
	// 説明：侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Sinners_009;

	// 名前：侵入経路_指輪_ボス守(ロザリア)
	// 説明：侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Rosalia_00A;

	// 名前：侵入経路_指輪_マップ守(森)
	// 説明：侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Forest_00B;

	// 名前：協力経路_サイン_なし
	// 説明：協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_None_00C;

	// 名前：協力経路_サイン_太陽
	// 説明：協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_Umbasa_00D;

	// 名前：協力経路_サイン_バーサーカー
	// 説明：協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_Berserker_00E;

	// 名前：協力経路_サイン_罪人
	// 説明：協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_Sinners_00F;

	// 名前：協力経路_指輪 _赤狩り
	// 説明：協力経路が指輪の勢力のエスト回復数
	uint8_t coopRing_RedHunter_010;

	// 名前：侵入経路_指輪_マップ守(アノール)
	// 説明：侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Anor_011;

	// 名前：回復数パラメータ差し替え率
	// 説明：回復数パラメータ差し替え率
	uint16_t paramReplaceRate_012;

	// 名前：回復数パラメータ差し替え先ID
	// 説明：回復数パラメータ差し替え先ID
	int32_t paramReplaceId_014;

	// 名前：pad
	uint8_t pad_018[8];

} EstusFlaskRecoveryParam;

#endif
