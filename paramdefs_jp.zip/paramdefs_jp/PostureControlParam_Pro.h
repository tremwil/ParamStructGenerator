/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_PostureControlParam_Pro_H
#define _PARAM_PostureControlParam_Pro_H
#include <stdint.h>

// POSTURE_CONTROL_PARAM_PRO_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _PostureControlParam_Pro {

	// 名前：右腕_内外
	// 説明：右腕_内外
	int16_t a000_rightArmIO_000;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a000_rightArmFB_002;

	// 名前：左腕_内外
	// 説明：左腕_内外
	int16_t a000_leftArmIO_004;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a000_leftArmFB_006;

	// 名前：右腕_内外
	// 説明：右腕_内外
	int16_t a002_rightArmIO_008;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a002_rightArmFB_00A;

	// 名前：左腕_内外
	// 説明：左腕_内外
	int16_t a002_leftArmIO_00C;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a002_leftArmFB_00E;

	// 名前：右腕_内外
	// 説明：右腕_内外
	int16_t a003_rightArmIO_010;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a003_rightArmFB_012;

	// 名前：左腕_内外
	// 説明：左腕_内外
	int16_t a003_leftArmIO_014;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a003_leftArmFB_016;

	// 名前：右腕_内外
	// 説明：右腕_内外
	int16_t a010_rightArmIO_018;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a010_rightArmFB_01A;

	// 名前：左腕_内外
	// 説明：左腕_内外
	int16_t a010_leftArmIO_01C;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a010_leftArmFB_01E;

	// 名前：右腕_内外
	// 説明：右腕_内外
	int16_t a012_rightArmIO_020;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a012_rightArmFB_022;

	// 名前：左腕_内外
	// 説明：左腕_内外
	int16_t a012_leftArmIO_024;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a012_leftArmFB_026;

	// 名前：右腕_内外
	// 説明：右腕_内外
	int16_t a013_rightArmIO_028;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a013_rightArmFB_02A;

	// 名前：左腕_内外
	// 説明：左腕_内外
	int16_t a013_leftArmIO_02C;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a013_leftArmFB_02E;

	// 名前：右腕_内外
	// 説明：右腕_内外
	int16_t a014_rightArmIO_030;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a014_rightArmFB_032;

	// 名前：左腕_内外
	// 説明：左腕_内外
	int16_t a014_leftArmIO_034;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a014_leftArmFB_036;

	// 名前：右腕_内外
	// 説明：右腕_内外
	int16_t a015_rightArmIO_038;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a015_rightArmFB_03A;

	// 名前：左腕_内外
	// 説明：左腕_内外
	int16_t a015_leftArmIO_03C;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a015_leftArmFB_03E;

	// 名前：右腕_内外
	// 説明：右腕_内外
	int16_t a016_rightArmIO_040;

	// 名前：右腕_前後
	// 説明：右腕_前後
	int16_t a016_rightArmFB_042;

	// 名前：左腕_内外
	// 説明：左腕_内外
	int16_t a016_leftArmIO_044;

	// 名前：左腕_前後
	// 説明：左腕_前後
	int16_t a016_leftArmFB_046;

	// 名前：pad
	uint8_t pad_048[8];

} PostureControlParam_Pro;

#endif
