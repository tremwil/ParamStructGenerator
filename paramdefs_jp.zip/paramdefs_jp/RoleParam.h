/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_RoleParam_H
#define _PARAM_RoleParam_H
#include <stdint.h>

// ROLE_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _RoleParam {

	// 名前：チームタイプ
	// 説明：チームタイプ
	uint8_t teamType_000;

	// 名前：pad10
	uint8_t pad10_001[3];

	// 名前：ファントムパラメータID(誓約ランク0)
	// 説明：誓約ランクが0のときのファントムパラメータID
	int32_t phantomParamId_004;

	// 名前：常駐特殊効果0
	// 説明：常駐特殊効果0
	int32_t spEffectID0_008;

	// 名前：常駐特殊効果1
	// 説明：常駐特殊効果1
	int32_t spEffectID1_00C;

	// 名前：常駐特殊効果2
	// 説明：常駐特殊効果2
	int32_t spEffectID2_010;

	// 名前：常駐特殊効果3
	// 説明：常駐特殊効果3
	int32_t spEffectID3_014;

	// 名前：常駐特殊効果4
	// 説明：常駐特殊効果4
	int32_t spEffectID4_018;

	// 名前：常駐特殊効果5
	// 説明：常駐特殊効果5
	int32_t spEffectID5_01C;

	// 名前：常駐特殊効果6
	// 説明：常駐特殊効果6
	int32_t spEffectID6_020;

	// 名前：常駐特殊効果7
	// 説明：常駐特殊効果7
	int32_t spEffectID7_024;

	// 名前：常駐特殊効果8
	// 説明：常駐特殊効果8
	int32_t spEffectID8_028;

	// 名前：常駐特殊効果9
	// 説明：常駐特殊効果9
	int32_t spEffectID9_02C;

	// 名前：SOSサインSFX ID
	// 説明：他の人が出したSOSサインSFX ID
	int32_t sosSignSfxId_030;

	// 名前：自分が出したSOSサインSFX ID
	// 説明：自分が出したSOSサインSFX ID
	int32_t mySosSignSfxId_034;

	// 名前：召喚された時のアニメID(プレイヤ)
	// 説明：プレイヤが召喚されてゲーム開始するときに再生するアニメID
	int32_t summonStartAnimId_038;

	// 名前：報酬アイテム抽選ID_マップ用
	// 説明：獲得報酬のアイテム抽選パラメータID_マップ用(-1で無し)
	int32_t itemlotParamId_03C;

	// 名前：ボイスチャットグループ
	// 説明：ボイスチャットグループ
	uint8_t voiceChatGroup_040;

	// 名前：ロール名テキストカラー
	// 説明：ネットワークPCのFEに表示するロール名テキストの色
	uint8_t roleNameColor_041;

	// 名前：pad1
	uint8_t pad1_042[2];

	// 名前：ロール名テキストID
	// 説明：ネットワークPCのFEに表示するロール名のテキストID
	int32_t roleNameId_044;

	// 名前：脅威度
	// 説明：脅威度
	uint32_t threatLv_048;

	// 名前：ファントムパラメータID(誓約ランク1)
	// 説明：誓約ランクが1のときのファントムパラメータID
	int32_t phantomParamId_vowRank1_04C;

	// 名前：ファントムパラメータID(誓約ランク2)
	// 説明：誓約ランクが2のときのファントムパラメータID
	int32_t phantomParamId_vowRank2_050;

	// 名前：ファントムパラメータID(誓約ランク3)
	// 説明：誓約ランクが3のときのファントムパラメータID
	int32_t phantomParamId_vowRank3_054;

	// 名前：SFX用特殊効果ID(誓約ランク0)
	// 説明：誓約ランク0のときのSFX用特殊効果ID
	int32_t spEffectID_vowRank0_058;

	// 名前：SFX用特殊効果ID(誓約ランク1)
	// 説明：誓約ランク1のときのSFX用特殊効果ID
	int32_t spEffectID_vowRank1_05C;

	// 名前：SFX用特殊効果ID(誓約ランク2)
	// 説明：誓約ランク2のときのSFX用特殊効果ID
	int32_t spEffectID_vowRank2_060;

	// 名前：SFX用特殊効果ID(誓約ランク3)
	// 説明：誓約ランク3のときのSFX用特殊効果ID
	int32_t spEffectID_vowRank3_064;

	// 名前：サイン幻影用のファントムID
	// 説明：マルチプレイ誓約霊体用　サイン幻影用のファントムID指定
	int32_t signPhantomId_068;

	// 名前：召喚された時のアニメID(プレイヤ以外)
	// 説明：プレイヤ以外が召喚されてゲーム開始するときに再生するアニメID
	int32_t nonPlayerSummonStartAnimId_06C;

	// 名前：pad2
	uint8_t pad2_070[16];

} RoleParam;

#endif
