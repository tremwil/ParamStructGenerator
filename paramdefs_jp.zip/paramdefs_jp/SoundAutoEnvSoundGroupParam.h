/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SoundAutoEnvSoundGroupParam_H
#define _PARAM_SoundAutoEnvSoundGroupParam_H
#include <stdint.h>

// SOUND_AUTO_ENV_SOUND_GROUP_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SoundAutoEnvSoundGroupParam {

	// 名前：サウンドNo
	// 説明：再生するサウンドNo (サウンドタイプはa固定)
	int32_t SoundNo_000;

	// 名前：判定拡張距離
	// 説明：再生判定領域の拡張距離
	float ExpandRange_004;

	// 名前：音源追従スピード
	// 説明：実音源の目標位置への追従速度(固定速度)
	float FollowSpeed_008;

	// 名前：音源追従率
	// 説明：実音源の目標位置への追従速度(差分割合)
	float FollowRate_00C;

} SoundAutoEnvSoundGroupParam;

#endif
