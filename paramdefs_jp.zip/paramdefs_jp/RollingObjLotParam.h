/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_RollingObjLotParam_H
#define _PARAM_RollingObjLotParam_H
#include <stdint.h>

// ROLLING_OBJ_LOT_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _RollingObjLotParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：AssetId_0
	// 説明：AssetId_0 (-1：無視)
	int32_t AssetId_0_004;

	// 名前：AssetId_1
	// 説明：AssetId_1 (-1：無視)
	int32_t AssetId_1_008;

	// 名前：AssetId_2
	// 説明：AssetId_2 (-1：無視)
	int32_t AssetId_2_00C;

	// 名前：AssetId_3
	// 説明：AssetId_3 (-1：無視)
	int32_t AssetId_3_010;

	// 名前：AssetId_4
	// 説明：AssetId_4 (-1：無視)
	int32_t AssetId_4_014;

	// 名前：AssetId_5
	// 説明：AssetId_5 (-1：無視)
	int32_t AssetId_5_018;

	// 名前：AssetId_6
	// 説明：AssetId_6 (-1：無視) 
	int32_t AssetId_6_01C;

	// 名前：AssetId_7
	// 説明：AssetId_7 (-1：無視)
	int32_t AssetId_7_020;

	// 名前：出現ウェイト_0
	// 説明：出現の比率ポイント(ウェイト)_0: 0だと無視
	uint8_t CreateWeight_0_024;

	// 名前：出現ウェイト_1
	// 説明：出現の比率ポイント(ウェイト)_1
	uint8_t CreateWeight_1_025;

	// 名前：出現ウェイト_2
	// 説明：出現の比率ポイント(ウェイト)_2
	uint8_t CreateWeight_2_026;

	// 名前：出現ウェイト_3
	// 説明：出現の比率ポイント(ウェイト)_3
	uint8_t CreateWeight_3_027;

	// 名前：出現ウェイト_4
	// 説明：出現の比率ポイント(ウェイト)_4
	uint8_t CreateWeight_4_028;

	// 名前：出現ウェイト_5
	// 説明：出現の比率ポイント(ウェイト)_5
	uint8_t CreateWeight_5_029;

	// 名前：出現ウェイト_6
	// 説明：出現の比率ポイント(ウェイト)_6
	uint8_t CreateWeight_6_02A;

	// 名前：出現ウェイト_7
	// 説明：出現の比率ポイント(ウェイト)_7
	uint8_t CreateWeight_7_02B;

	// 名前：リザーブ
	// 説明：リザーブ
	uint8_t Reserve_0_02C[20];

} RollingObjLotParam;

#endif
