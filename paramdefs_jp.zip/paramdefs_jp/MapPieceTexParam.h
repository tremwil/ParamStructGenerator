/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MapPieceTexParam_H
#define _PARAM_MapPieceTexParam_H
#include <stdint.h>

// MAP_PIECE_TEX_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MapPieceTexParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：R
	// 説明：変換前の地図画像のカラー情報（R）。RGB値が一致したピクセルとこのパラメータが紐づく
	uint8_t srcR_004;

	// 名前：G
	// 説明：変換前の地図画像のカラー情報（G）。RGB値が一致したピクセルとこのパラメータが紐づく
	uint8_t srcG_005;

	// 名前：B
	// 説明：変換前の地図画像のカラー情報（B）。RGB値が一致したピクセルとこのパラメータが紐づく
	uint8_t srcB_006;

	// 名前：パッド
	// 説明：パッド。一応「画像色情報（A）」用で空けておく
	uint8_t pad1_007[1];

	// 名前：マップ名ID_セーブデータ表示用
	// 説明：セーブデータ表示用のマップ名ID[PlaceName](0:無効値)
	int32_t saveMapNameId_008;

	// 名前：マルチプレイエリアID
	// 説明：マルチプレイエリアID(-1:無効値)
	int32_t multiPlayAreaId_00C;

} MapPieceTexParam;

#endif
