/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SpEffectVfx_H
#define _PARAM_SpEffectVfx_H
#include <stdint.h>

// SP_EFFECT_VFX_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SpEffectVfx {

	// 名前：効果中SfxID
	// 説明：効果中SfxID(-1：無効)
	int32_t midstSfxId_000;

	// 名前：効果中SeID
	// 説明：効果中SeID(-1：無効)
	int32_t midstSeId_004;

	// 名前：発動時SfxID
	// 説明：発動時SfxID(-1：無効)
	int32_t initSfxId_008;

	// 名前：発動時SeID
	// 説明：発動時SeID(-1：無効)
	int32_t initSeId_00C;

	// 名前：解除時SfxID
	// 説明：解除時SfxID(-1：無効)
	int32_t finishSfxId_010;

	// 名前：解除時SeID
	// 説明：解除時SeID(-1：無効)
	int32_t finishSeId_014;

	// 名前：姿隠し開始距離[m]
	// 説明：カムフラージュ開始距離です
	float camouflageBeginDist_018;

	// 名前：姿隠し終了距離[m]
	// 説明：カムフラージュ終了距離です
	float camouflageEndDist_01C;

	// 名前：変身防具ID
	// 説明：変身防具ID(-1：なし)
	int32_t transformProtectorId_020;

	// 名前：効果中ダミポリID
	// 説明：効果中ダミポリID(-1：ルート)
	int16_t midstDmyId_024;

	// 名前：発動時ダミポリID
	// 説明：発動時ダミポリID(-1：ルート)
	int16_t initDmyId_026;

	// 名前：解除時ダミポリID
	// 説明：解除時ダミポリID(-1：ルート)
	int16_t finishDmyId_028;

	// 名前：エフェクトタイプ
	// 説明：エフェクトタイプ
	uint8_t effectType_02A;

	// 名前：武器エンチャント用ソウルパラムID
	// 説明：武器エンチャント用ソウルパラムID(-1：なし).適用されるファントムパラムを変更します。
	uint8_t soulParamIdForWepEnchant_02B;

	// 名前：VFX再生カテゴリ
	// 説明：重複効果によるエフェクト再生を制御します
	uint8_t playCategory_02C;

	// 名前：カテゴリ内優先度
	// 説明：カテゴリ一致した場合の再生優先度を設定(低い方が優先)
	uint8_t playPriority_02D;

	// 名前：大型用エフェクトがあるか
	// 説明：大型用エフェクトがあるか
	uint8_t existEffectForLarge_02E: 1;

	// 名前：ソウル体用エフェクトがあるか
	// 説明：ソウル体用エフェクトがあるか
	uint8_t existEffectForSoul_02E: 1;

	// 名前：姿隠し時にエフェクトを非表示にするか
	// 説明：姿隠し時にエフェクトを非表示にするか
	uint8_t effectInvisibleAtCamouflage_02E: 1;

	// 名前：姿隠しするか
	// 説明：姿隠しするか
	uint8_t useCamouflage_02E: 1;

	// 名前：姿隠し時に味方でも非表示か
	// 説明：姿隠し時に味方でも非表示か
	uint8_t invisibleAtFriendCamouflage_02E: 1;

	// 名前：姿隠し時にフットエフェクトを消すか
	// 説明：姿隠し時にフットエフェクトを消すか
	uint8_t isHideFootEffect_forCamouflage_02E: 1;

	// 名前：半透明の姿隠しか
	// 説明：半透明の姿隠しか
	uint8_t halfCamouflage_02E: 1;

	// 名前：変身防具IDが全身用か
	// 説明：変身防具IDが全身用か
	uint8_t isFullBodyTransformProtectorId_02E: 1;

	// 名前：武器エンチャント用インビジブルウェポンか
	// 説明：武器エンチャント用インビジブルウェポンか(0:武器表示, 1:武器非表示)
	uint8_t isInvisibleWeapon_02F: 1;

	// 名前：サイレンスか
	// 説明：サイレンスか(0:ちがう, 1:そう)
	uint8_t isSilence_02F: 1;

	// 名前：全身か（効果中）
	// 説明：効果中SFXを装備用全身ダミポリを使用するか。1の時に胴:190,頭:191,手:192,脚:193からSFXを再生する
	uint8_t isMidstFullbody_02F: 1;

	// 名前：全身か（発動時）
	// 説明：発動中SFXを装備用全身ダミポリを使用するか。1の時に胴:190,頭:191,手:192,脚:193からSFXを再生する
	uint8_t isInitFullbody_02F: 1;

	// 名前：全身か（解除時）
	// 説明：解除時SFXを装備用全身ダミポリを使用するか。1の時に胴:190,頭:191,手:192,脚:193からSFXを再生する
	uint8_t isFinishFullbody_02F: 1;

	// 名前：死体時でも表示を行うか
	// 説明：○の場合、死体時でもVFXが表示されるようになります。
	uint8_t isVisibleDeadChr_02F: 1;

	// 名前：エンチャントSFXサイズオフセット適応か
	// 説明：武器パラの「エンチャントSfxサイズ」に従ってSfxIdをオフセットするか
	uint8_t isUseOffsetEnchantSfxSize_02F: 1;

	// 名前：パディング
	// 説明：パディング
	uint8_t pad_1_02F: 1;

	// 名前：デカールID1
	// 説明：デカールID1(-1：無効)
	int32_t decalId1_030;

	// 名前：デカールID2
	// 説明：デカールID2(-1：無効)
	int32_t decalId2_034;

	// 名前：フットエフェクト優先度
	// 説明：フットエフェクトオフセットの優先度(低いほうが優先)
	uint8_t footEffectPriority_038;

	// 名前：フットエフェクトオフセット
	// 説明：この特殊効果がかかっている場合にフットエフェクトIDにオフセットする量
	uint8_t footEffectOffset_039;

	// 名前：剣閃SFXIDオフセットタイプ
	// 説明：剣閃SFXIDにかけるオフセット値です。エンチャントと剣の軌跡エフェクトに使われる
	uint8_t traceSfxIdOffsetType_03A;

	// 名前：プレイヤー見た目強制上書き
	// 説明：キャラクターの見た目を強制的に生者/亡者にできる機能
	uint8_t forceDeceasedType_03B;

	// 名前：エンチャント時根元ダミポリID＿０
	// 説明：エンチャント時の根元に発生させるダミポリID
	int32_t enchantStartDmyId_0_03C;

	// 名前：エンチャント時剣先ダミポリID＿０
	// 説明：エンチャント時の剣先に発生させるダミポリID。-1指定で自動的に連番になってるところまで出す。
	int32_t enchantEndDmyId_0_040;

	// 名前：エンチャント時根元ダミポリID＿１
	// 説明：エンチャント時の根元に発生させるダミポリID
	int32_t enchantStartDmyId_1_044;

	// 名前：エンチャント時剣先ダミポリID＿１
	// 説明：エンチャント時の剣先に発生させるダミポリID。-1指定で自動的に連番になってるところまで出す。
	int32_t enchantEndDmyId_1_048;

	// 名前：エンチャント時根元ダミポリID＿２
	// 説明：エンチャント時の根元に発生させるダミポリID
	int32_t enchantStartDmyId_2_04C;

	// 名前：エンチャント時剣先ダミポリID＿２
	// 説明：エンチャント時の剣先に発生させるダミポリID。-1指定で自動的に連番になってるところまで出す。
	int32_t enchantEndDmyId_2_050;

	// 名前：エンチャント時根元ダミポリID＿３
	// 説明：エンチャント時の根元に発生させるダミポリID
	int32_t enchantStartDmyId_3_054;

	// 名前：エンチャント時剣先ダミポリID＿３
	// 説明：エンチャント時の剣先に発生させるダミポリID。-1指定で自動的に連番になってるところまで出す。
	int32_t enchantEndDmyId_3_058;

	// 名前：エンチャント時根元ダミポリID＿４
	// 説明：エンチャント時の根元に発生させるダミポリID
	int32_t enchantStartDmyId_4_05C;

	// 名前：エンチャント時剣先ダミポリID＿４
	// 説明：エンチャント時の剣先に発生させるダミポリID。-1指定で自動的に連番になってるところまで出す。
	int32_t enchantEndDmyId_4_060;

	// 名前：エンチャント時根元ダミポリID＿５
	// 説明：エンチャント時の根元に発生させるダミポリID
	int32_t enchantStartDmyId_5_064;

	// 名前：エンチャント時剣先ダミポリID＿５
	// 説明：エンチャント時の剣先に発生させるダミポリID。-1指定で自動的に連番になってるところまで出す。
	int32_t enchantEndDmyId_5_068;

	// 名前：エンチャント時根元ダミポリID＿６
	// 説明：エンチャント時の根元に発生させるダミポリID
	int32_t enchantStartDmyId_6_06C;

	// 名前：エンチャント時剣先ダミポリID＿６
	// 説明：エンチャント時の剣先に発生させるダミポリID。-1指定で自動的に連番になってるところまで出す。
	int32_t enchantEndDmyId_6_070;

	// 名前：エンチャント時根元ダミポリID＿７
	// 説明：エンチャント時の根元に発生させるダミポリID
	int32_t enchantStartDmyId_7_074;

	// 名前：エンチャント時剣先ダミポリID＿７
	// 説明：エンチャント時の剣先に発生させるダミポリID。-1指定で自動的に連番になってるところまで出す。
	int32_t enchantEndDmyId_7_078;

	// 名前：SfxIDオフセットタイプ
	// 説明：SfxIDオフセットタイプ
	uint8_t SfxIdOffsetType_07C;

	// 名前：ファントムパラメータ強制指定
	// 説明：ファントムパラメータの強制上書きタイプ
	uint8_t phantomParamOverwriteType_07D;

	// 名前：姿隠し時最小α値[%]
	// 説明：姿隠し時最小α値[%]
	uint8_t camouflageMinAlpha_07E;

	// 名前：水濡れ効果
	// 説明：ウェットパラメータを参照して水濡れ表現を発生させる
	uint8_t wetAspectType_07F;

	// 名前：ファントムパラメータ上書きID
	// 説明：ファントムパラメータの強制Id
	int32_t phantomParamOverwriteId_080;

	// 名前：マテリアル拡張パラメータID
	// 説明：ID0～99はGSの予約IDです。ID100以降を指定した場合、マテリアル拡張パラメータを参照します（-1：無効値）
	int32_t materialParamId_084;

	// 名前：マテリアルパラメータの初期値
	// 説明：マテリアルパラメータのフェード開始時の値。対象はマテリアルパラメータIDで指定する。マテリアルパラメータIDが -1 なら何もしない
	float materialParamInitValue_088;

	// 名前：マテリアルパラメータの目標値
	// 説明：マテリアルパラメータのフェード終了時の値。対象はマテリアルパラメータIDで指定する。マテリアルパラメータIDが -1 なら何もしない
	float materialParamTargetValue_08C;

	// 名前：マテリアルパラメータ値のフェード時間
	// 説明：マテリアルパラメータ値のフェード時間。この時間かけて徐々に目標値へ行く。マテリアルパラメータIDが -1 なら何もしない
	float materialParamFadeTime_090;

	// 名前：フットデカール材質オフセット強制上書きID 
	// 説明：フットデカールの床材質IDオフセットを強制的に書き換える（-1未使用）
	int16_t footDecalMaterialOffsetOverwriteId_094;

	// 名前：パディング
	// 説明：パディング
	uint8_t pad_096[14];

} SpEffectVfx;

#endif
