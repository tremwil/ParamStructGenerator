/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CalcCorrectGraph_H
#define _PARAM_CalcCorrectGraph_H
#include <stdint.h>

// CACL_CORRECT_GRAPH_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CalcCorrectGraph {

	// 名前：閾値ポイント0
	// 説明：仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal0_000;

	// 名前：閾値ポイント1
	// 説明：仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal1_004;

	// 名前：閾値ポイント2
	// 説明：仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal2_008;

	// 名前：閾値ポイント3
	// 説明：仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal3_00C;

	// 名前：閾値ポイント4
	// 説明：仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal4_010;

	// 名前：閾値係数0
	// 説明：仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal0_014;

	// 名前：閾値係数1
	// 説明：仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal1_018;

	// 名前：閾値係数2
	// 説明：仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal2_01C;

	// 名前：閾値係数3
	// 説明：仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal3_020;

	// 名前：閾値係数4
	// 説明：仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal4_024;

	// 名前：調整係数0
	// 説明：調整係数
	float adjPt_maxGrowVal0_028;

	// 名前：調整係数1
	// 説明：調整係数
	float adjPt_maxGrowVal1_02C;

	// 名前：調整係数2
	// 説明：調整係数
	float adjPt_maxGrowVal2_030;

	// 名前：調整係数3
	// 説明：調整係数
	float adjPt_maxGrowVal3_034;

	// 名前：調整係数4
	// 説明：調整係数
	float adjPt_maxGrowVal4_038;

	// 名前：成長ソウル 初期のグラフの傾きα1
	// 説明：成長ソウル 初期のグラフの傾きα1
	float init_inclination_soul_03C;

	// 名前：成長ソウル 初期のsoul調整α2
	// 説明：成長ソウル 初期のsoul調整α2
	float adjustment_value_040;

	// 名前：成長ソウル 閾値後のグラフの傾きに影響α3
	// 説明：成長ソウル 閾値後のグラフの傾きに影響α3
	float boundry_inclination_soul_044;

	// 名前：成長ソウル 閾値 t
	// 説明：成長ソウル 閾値 t
	float boundry_value_048;

	// 名前：パディング
	uint8_t pad_04C[4];

} CalcCorrectGraph;

#endif
