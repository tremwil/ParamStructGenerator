/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MultiPlayCorrectionParam_H
#define _PARAM_MultiPlayCorrectionParam_H
#include <stdint.h>

// MULTI_PLAY_CORRECTION_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MultiPlayCorrectionParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：協力クライアント1名特殊効果ID
	// 説明：協力クライアント1名特殊効果ID
	int32_t client1SpEffectId_004;

	// 名前：協力クライアント2名特殊効果ID
	// 説明：協力クライアント2名特殊効果ID
	int32_t client2SpEffectId_008;

	// 名前：協力クライアント3名特殊効果ID
	// 説明：協力クライアント3名特殊効果ID
	int32_t client3SpEffectId_00C;

	// 名前：協力人数変動時に上書きするか
	// 説明：協力人数変動時に上書きするか
	uint8_t bOverrideSpEffect_010;

	// 名前：pad
	// 説明：pad
	uint8_t pad3_011[15];

} MultiPlayCorrectionParam;

#endif
