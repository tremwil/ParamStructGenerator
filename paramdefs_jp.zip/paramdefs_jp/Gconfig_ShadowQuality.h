/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_Gconfig_ShadowQuality_H
#define _PARAM_Gconfig_ShadowQuality_H
#include <stdint.h>

// CS_SHADOW_QUALITY_DETAIL
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _Gconfig_ShadowQuality {

	// 名前：シャドウが有効
	// 説明：シャドウが有効
	uint8_t enabled_000;

	// 名前：許可される最大のフィルタ品質
	// 説明：許可される最大のフィルタ品質
	uint8_t maxFilterLevel_001;

	// 名前：dmy
	uint8_t dmy_002[2];

	// 名前：設定されたシャドウマップ解像度のスケーラ
	// 説明：設定されたシャドウマップ解像度のスケーラ
	uint32_t textureSizeScaler_004;

	// 名前：設定されたシャドウマップ解像度を除算
	// 説明：設定されたシャドウマップ解像度を除算
	uint32_t textureSizeDivider_008;

	// 名前：解像度最小
	// 説明：解像度をクランプ
	uint32_t textureMinSize_00C;

	// 名前：解像度最大
	// 説明：解像度をクランプ。カスケード毎の解像度判定になります
	uint32_t textureMaxSize_010;

	// 名前：ブラーカウントバイアス
	// 説明：ブラーカウントバイアス(設定されたカウントのバイアス。0で変更なし)
	int32_t blurCountBias_014;

} Gconfig_ShadowQuality;

#endif
