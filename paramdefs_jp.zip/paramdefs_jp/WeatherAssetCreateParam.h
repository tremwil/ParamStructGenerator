/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WeatherAssetCreateParam_H
#define _PARAM_WeatherAssetCreateParam_H
#include <stdint.h>

// WEATHER_ASSET_CREATE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WeatherAssetCreateParam {

	// 名前：アセットId
	// 説明：生成するアセットIDを指定します。AEG999_999 -> 999999
	uint32_t AssetId_000;

	// 名前：スロット番号
	// 説明：生成制御用の番号です。同一スロットには１個のアセットのみ生成が可能です。重複して生成させたい、させたくない制御ができます。
	uint32_t SlotNo_004;

	// 名前：発生条件
	// 説明：発生の条件のタイプです
	uint8_t CreateConditionType_008;

	// 名前：padding0
	uint8_t padding0_009[3];

	// 名前：遷移元天候
	// 説明：遷移元の天候を指定します。発生条件が「遷移」のときだけ参照されます
	int16_t TransitionSrcWeather_00C;

	// 名前：遷移先天候
	// 説明：遷移先の天候を指定します。発生条件が「遷移」のときだけ参照されます
	int16_t TransitionDstWeather_00E;

	// 名前：経過時間チェック天候
	// 説明：経過時間をチェックする天候を指定します。
	int16_t ElapsedTimeCheckweather_010;

	// 名前：padding1
	uint8_t padding1_012[2];

	// 名前：経過時間[Second]
	// 説明：経過時間を指定します。発生条件が「時間経過」のときだけ参照されます。現実時間[秒]単位で指定します。
	float ElapsedTime_014;

	// 名前：生成遅延時間[Second]
	// 説明：生成が決定してから遅延する時間を指定します。遅延している間は作成したスロットは使用中になります。0以下で即時作成。
	float CreateDelayTime_018;

	// 名前：発生確率[％]
	// 説明：天候遷移、または経過時間の条件を満たした際に発生する確率を指定します
	uint32_t CreateProbability_01C;

	// 名前：寿命[Second]
	// 説明：生成したアセットの寿命を指定します。現実時間[秒]単位で指定します。
	float LifeTime_020;

	// 名前：フェード時間[Second]
	// 説明：フェードイン、フェードアウトに使用される時間[秒]。0以下でフェードなし。
	float FadeTime_024;

	// 名前：生成可能開始時刻[Hour]
	// 説明：生成可能な開始時刻を指定します[0.0 - 24.0]。開始、終了どちらかに-1を入れると無制限(全時間で生成可能)の扱いになります。
	float EnableCreateTimeMin_028;

	// 名前：生成可能終了時刻[Hour]
	// 説明：生成可能な終了時刻を指定します[0.0 - 24.0]。開始、終了どちらかに-1を入れると無制限(全時間で生成可能)の扱いになります。
	float EnableCreateTimeMax_02C;

	// 名前：生成ポイント0
	// 説明：生成ポイント番号を指定します。MapStudioの「天候アセット生成ポイント」の末尾3桁の数値を指定してください。-1だと無効になります
	int16_t CreatePoint0_030;

	// 名前：生成ポイント1
	// 説明：生成ポイント番号を指定します。MapStudioの「天候アセット生成ポイント」の末尾3桁の数値を指定してください。-1だと無効になります
	int16_t CreatePoint1_032;

	// 名前：生成ポイント2
	// 説明：生成ポイント番号を指定します。MapStudioの「天候アセット生成ポイント」の末尾3桁の数値を指定してください。-1だと無効になります
	int16_t CreatePoint2_034;

	// 名前：生成ポイント3
	// 説明：生成ポイント番号を指定します。MapStudioの「天候アセット生成ポイント」の末尾3桁の数値を指定してください。-1だと無効になります
	int16_t CreatePoint3_036;

	// 名前：生成制限ID0
	// 説明：生成制限用のIDです。-1:無制限。「マップデフォルトパラメータ.xlsm」の生成制限IDと一致した場合のみ生成が許可されます(SEQ08921)
	int8_t CreateAssetLimitId0_038;

	// 名前：生成制限ID1
	// 説明：生成制限用のIDです。-1:無制限。「マップデフォルトパラメータ.xlsm」の生成制限IDと一致した場合のみ生成が許可されます(SEQ08921)
	int8_t CreateAssetLimitId1_039;

	// 名前：生成制限ID2
	// 説明：生成制限用のIDです。-1:無制限。「マップデフォルトパラメータ.xlsm」の生成制限IDと一致した場合のみ生成が許可されます(SEQ08921)
	int8_t CreateAssetLimitId2_03A;

	// 名前：生成制限ID3
	// 説明：生成制限用のIDです。-1:無制限。「マップデフォルトパラメータ.xlsm」の生成制限IDと一致した場合のみ生成が許可されます(SEQ08921)
	int8_t CreateAssetLimitId3_03B;

	// 名前：Reserved2
	uint8_t Reserved2_03C[4];

} WeatherAssetCreateParam;

#endif
