/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CameraFadeParam_H
#define _PARAM_CameraFadeParam_H
#include <stdint.h>

// CAMERA_FADE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CameraFadeParam {

	// 名前：透明になりきる距離(m)
	// 説明：Nearフェード最小距離(m) : α = 0になる距離
	float NearMinDist_000;

	// 名前：透明になり始める距離(m)
	// 説明：Nearフェード最大距離(m) : α = MiddelAlphaとなる間の開始距離
	float NearMaxDist_004;

	// 名前：半透明状態になりきる距離(m)
	// 説明：Farフェードの最小距離(m) : α = MiddleAlphaとなる間の終了距離
	float FarMinDist_008;

	// 名前：半透明状態になり始める距離(m)
	// 説明：Farフェードの最大距離(m) : α = 1になる距離
	float FarMaxDist_00C;

	// 名前：半透明状態の濃さ(α値)
	// 説明：中間のα値
	float MiddleAlpha_010;

	// 名前：ダミー
	uint8_t dummy_014[12];

} CameraFadeParam;

#endif
