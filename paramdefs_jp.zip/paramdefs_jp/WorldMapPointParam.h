/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WorldMapPointParam_H
#define _PARAM_WorldMapPointParam_H
#include <stdint.h>

// WORLD_MAP_POINT_PARAM_ST
// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WorldMapPointParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：開放イベントフラグID
	// 説明：開放条件のイベントフラグID
	uint32_t eventFlagId_004;

	// 名前：遠見台発見イベントフラグID
	// 説明：遠見台で発見した際に立てるイベントフラグID
	uint32_t distViewEventFlagId_008;

	// 名前：アイコンID
	// 説明：アイコンID
	uint16_t iconId_00C;

	// 名前：BGM用場所情報（入場領域内）
	// 説明：Bgm場所タイプ
	int16_t bgmPlaceType_00E;

	// 名前：範囲アイコンか
	// 説明：範囲を表すアイコンか。地図に対して等倍になる
	uint8_t isAreaIcon_010: 1;

	// 名前：遠見台目印_座標上書きするか
	// 説明：遠見台目印として使うときに座標を上書きするか
	uint8_t isOverrideDistViewMarkPos_010: 1;

	// 名前：テキストが無いときに表示するか
	// 説明：テキストが無いときにも表示するか。基本的にはテキストがなければポイントは表示しない。このフラグが有効なときにはテキストがなくても表示する
	uint8_t isEnableNoText_010: 1;

	// 名前：パッド3
	uint8_t pad3_010: 5;

	// 名前：遠見台目印上書き_エリア番号
	// 説明：mAA_BB_CC_DD の AA 部分
	uint8_t areaNo_forDistViewMark_011;

	// 名前：遠見台目印上書き_グリッドX番号
	// 説明：mAA_BB_CC_DD の BB 部分
	uint8_t gridXNo_forDistViewMark_012;

	// 名前：遠見台目印上書き_グリッドZ番号
	// 説明：mAA_BB_CC_DD の CC 部分
	uint8_t gridZNo_forDistViewMark_013;

	// 名前：クリア済イベントフラグID
	// 説明：クリア済みイベントフラグID(0:常にクリア済み扱い)
	uint32_t clearedEventFlagId_014;

	// 名前：表示設定M00
	// 説明：M00で表示するか
	uint8_t dispMask00_018: 1;

	// 名前：表示設定M01
	// 説明：M01で表示するか
	uint8_t dispMask01_018: 1;

	// 名前：パッド
	// 説明：pad2_0
	uint8_t pad2_0_018: 6;

	// 名前：パッド
	// 説明：pad2
	uint8_t pad2_019[1];

	// 名前：遠見台発見時アイコンID
	// 説明：遠見台発見時アイコンID
	uint16_t distViewIconId_01A;

	// 名前：アイコン角度[deg]
	// 説明：表示アイコンの回転角度[deg]
	float angle_01C;

	// 名前：エリア番号
	// 説明：mAA_BB_CC_DD の AA 部分
	uint8_t areaNo_020;

	// 名前：グリッドX番号
	// 説明：mAA_BB_CC_DD の BB 部分
	uint8_t gridXNo_021;

	// 名前：グリッドZ番号
	// 説明：mAA_BB_CC_DD の CC 部分
	uint8_t gridZNo_022;

	// 名前：パディング
	// 説明：パディング
	uint8_t pad_023[1];

	// 名前：X座標
	// 説明：X座標
	float posX_024;

	// 名前：Y座標
	// 説明：Y座標（使っていない）
	float posY_028;

	// 名前：Z座標
	// 説明：Z座標
	float posZ_02C;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-1)なら、何も表示しない
	int32_t textId1_030;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(0)なら、On扱いされる
	uint32_t textEnableFlagId1_034;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(0)なら、Off扱いされる
	uint32_t textDisableFlagId1_038;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-2)なら、何も表示しない
	int32_t textId2_03C;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(1)なら、On扱いされる
	uint32_t textEnableFlagId2_040;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(1)なら、Off扱いされる
	uint32_t textDisableFlagId2_044;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-3)なら、何も表示しない
	int32_t textId3_048;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(2)なら、On扱いされる
	uint32_t textEnableFlagId3_04C;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(2)なら、Off扱いされる
	uint32_t textDisableFlagId3_050;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-4)なら、何も表示しない
	int32_t textId4_054;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(3)なら、On扱いされる
	uint32_t textEnableFlagId4_058;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(3)なら、Off扱いされる
	uint32_t textDisableFlagId4_05C;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-5)なら、何も表示しない
	int32_t textId5_060;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(4)なら、On扱いされる
	uint32_t textEnableFlagId5_064;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(4)なら、Off扱いされる
	uint32_t textDisableFlagId5_068;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-6)なら、何も表示しない
	int32_t textId6_06C;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(5)なら、On扱いされる
	uint32_t textEnableFlagId6_070;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(5)なら、Off扱いされる
	uint32_t textDisableFlagId6_074;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-7)なら、何も表示しない
	int32_t textId7_078;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(6)なら、On扱いされる
	uint32_t textEnableFlagId7_07C;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(6)なら、Off扱いされる
	uint32_t textDisableFlagId7_080;

	// 名前：テキストID
	// 説明：表示するテキストID。無効値(-8)なら、何も表示しない
	int32_t textId8_084;

	// 名前：出現イベントフラグID
	// 説明：テキストの表示イベントフラグID。イベントフラグがOnなら表示する。無効なイベントフラグID(7)なら、On扱いされる
	uint32_t textEnableFlagId8_088;

	// 名前：非表示イベントフラグID
	// 説明：テキストの非表示イベントフラグID。イベントフラグがOnなら表示しない。表示イベントフラグIDよりも優先される。無効なイベントフラグID(7)なら、Off扱いされる
	uint32_t textDisableFlagId8_08C;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType1_090;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType2_091;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType3_092;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType4_093;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType5_094;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType6_095;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType7_096;

	// 名前：テキスト種別
	// 説明：テキストの種別(地名,NPC名,...)
	uint8_t textType8_097;

	// 名前：遠見台ID0
	// 説明：遠見台ID
	int32_t distViewId_098;

	// 名前：遠見台目印上書き_X座標
	// 説明：X座標
	float posX_forDistViewMark_09C;

	// 名前：遠見台目印上書きY座標
	// 説明：Y座標
	float posY_forDistViewMark_0A0;

	// 名前：遠見台目印上書きZ座標
	// 説明：Z座標
	float posZ_forDistViewMark_0A4;

	// 名前：遠見台ID1
	// 説明：遠見台ID
	int32_t distViewId1_0A8;

	// 名前：遠見台ID2
	// 説明：遠見台ID
	int32_t distViewId2_0AC;

	// 名前：遠見台ID3
	// 説明：遠見台ID
	int32_t distViewId3_0B0;

	// 名前：表示ズームステップ
	// 説明：地図ポイントを表示するズームステップ（一番ズームアウトした状態が0、ズームするごとに+1）。「《表示ズームステップ》≦ 現在のズームステップ 」のときに表示される。デフォルトは 0（常に表示）
	uint8_t dispMinZoomStep_0B4;

	// 名前：選択可能ズームステップ
	// 説明：地図ポイントを選択可能なズームステップ（一番ズームアウトした状態が0、ズームするごとに+1）。「《選択可能ズームステップ》≦ 現在の拡大段階 」のときに選択可能。デフォルトは 0（常に選択可能）
	uint8_t selectMinZoomStep_0B5;

	// 名前：入場表示形式
	// 説明：入場表示形式。入場時に表示する地図ポイント入場FEの種類
	uint8_t entryFEType_0B6;

	// 名前：パッド
	// 説明：pad3
	uint8_t pad4_0B7[9];

	// 名前：unkC0
	int32_t unkC0_0C0;

	// 名前：unkC4
	int32_t unkC4_0C4;

	// 名前：unkC8
	int32_t unkC8_0C8;

	// 名前：unkCC
	int32_t unkCC_0CC;

	// 名前：unkD0
	int32_t unkD0_0D0;

	// 名前：unkD4
	int32_t unkD4_0D4;

	// 名前：unkD8
	int32_t unkD8_0D8;

	// 名前：unkDC
	int32_t unkDC_0DC;

	// 名前：unkE0
	int32_t unkE0_0E0;

	// 名前：unkE4
	int32_t unkE4_0E4;

	// 名前：unkE8
	int32_t unkE8_0E8;

	// 名前：unkEC
	int32_t unkEC_0EC;

	// 名前：unkF0
	int32_t unkF0_0F0;

	// 名前：unkF4
	int32_t unkF4_0F4;

	// 名前：unkF8
	int32_t unkF8_0F8;

	// 名前：unkFC
	int32_t unkFC_0FC;

} WorldMapPointParam;

#endif
