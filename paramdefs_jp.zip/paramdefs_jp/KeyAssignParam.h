/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_KeyAssignParam_H
#define _PARAM_KeyAssignParam_H
#include <stdint.h>

// KEY_ASSIGN_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _KeyAssignParam {

	// 名前：パッド
	// 説明：パッド（物理キー）
	int32_t padKeyId_000;

	// 名前：キーボード修飾
	// 説明：キーボード修飾キー
	int32_t keyboardModifyKey_004;

	// 名前：キーボード
	// 説明：キーボード（物理キー）
	int32_t keyboardKeyId_008;

	// 名前：マウス修飾
	// 説明：マウス修飾キー
	int32_t mouseModifyKey_00C;

	// 名前：マウス
	// 説明：マウス（物理キー）
	int32_t mouseKeyId_010;

	// 名前：----
	uint8_t reserved_014[12];

} KeyAssignParam;

#endif
