/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EquipParamGoods_H
#define _PARAM_EquipParamGoods_H
#include <stdint.h>

// EQUIP_PARAM_GOODS_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EquipParamGoods {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：呼び出しID0(デフォルト)
	// 説明：アイテムから呼び出されるID0(デフォルト)
	int32_t refId_default_004;

	// 名前：SFXバリエーションID
	// 説明：ＳＦＸのバリエーションを指定（TimeActEditorのＩＤと組み合わせて、ＳＦＸを特定するのに使用する）
	int32_t sfxVariationId_008;

	// 名前：重量[kg]
	// 説明：重量[kg]
	float weight_00C;

	// 名前：基本価格
	// 説明：基本価格
	int32_t basicPrice_010;

	// 名前：売却価格
	// 説明：販売価格
	int32_t sellValue_014;

	// 名前：行動ID
	// 説明：道具を使ったときに発生する効果を設定します
	int32_t behaviorId_018;

	// 名前：差し替えアイテムID
	// 説明：差し替えるときのアイテムID
	int32_t replaceItemId_01C;

	// 名前：ソートID
	// 説明：ソートID(-1:集めない)
	int32_t sortId_020;

	// 名前：表示差し替え先アイテムID
	// 説明：条件付きで表示を別の道具IDに差し替える。ゲームデータ側の道具IDは変わらない
	int32_t appearanceReplaceItemId_024;

	// 名前：YES/NOメッセージID
	// 説明：YesNoダイアログ表示時に使用するメッセージID
	int32_t yesNoDialogMessageId_028;

	// 名前：使用可能条件_状態変化タイプ
	// 説明：設定した状態変化タイプの特殊効果が掛かったときだけ、使用許可する
	uint16_t useEnableSpEffectType_02C;

	// 名前：壺グループID
	// 説明：壺グループIDに0以上が設定されている「消費アイテム」は同じ壺グループIDの「壺」の個数だけ所持可能
	int8_t potGroupId_02E;

	// 名前：PAD
	// 説明：旧(巻物と紐づいた魔法ID)
	uint8_t pad_02F[1];

	// 名前：アイコンID
	// 説明：メニュー用アイコンID
	uint16_t iconId_030;

	// 名前：モデルID
	// 説明：モデルID
	uint16_t modelId_032;

	// 名前：ショップレベル
	// 説明：お店で販売できるレベル
	int16_t shopLv_034;

	// 名前：コンプトロフィーSEQ番号
	// 説明：コンプリート系トロフィのSEQ番号
	int16_t compTrophySedId_036;

	// 名前：トロフィーSEQ番号
	// 説明：トロフィーのSEQ番号
	int16_t trophySeqId_038;

	// 名前：最大所持数
	// 説明：最大所持数
	int16_t maxNum_03A;

	// 名前：消費人間性
	// 説明：消費人間性
	uint8_t consumeHeroPoint_03C;

	// 名前：技量オーバー開始値
	// 説明：技量オーバー開始値
	uint8_t overDexterity_03D;

	// 名前：道具のタイプ
	// 説明：道具の種類
	uint8_t goodsType_03E;

	// 名前：IDカテゴリ
	// 説明：↓のIDのカテゴリ[攻撃、飛び道具、特殊]
	uint8_t refCategory_03F;

	// 名前：特殊効果カテゴリ
	// 説明：スキルや、魔法、アイテムなどで、パラメータが変動する効果（エンチャントウェポンなど）があるので、│定した効果が、「武器攻撃のみをパワーアップする」といった効果に対応できるように行動ごとに設定するバリスタなど、設定の必要のないものは「なし」を設定する

	uint8_t spEffectCategory_040;

	// 名前：pad
	uint8_t pad3_041[1];

	// 名前：道具使用時アニメ
	// 説明：道具を使ったときに再生するアニメを設定します
	uint8_t goodsUseAnim_042;

	// 名前：メニュー開くか
	// 説明：アイテム使用時に開くメニュータイプ
	uint8_t opmeMenuType_043;

	// 名前：使用禁止条件_特殊効果カテゴリ
	// 説明：かかっている特殊効果によって使用可能かを制御する為に指定
	uint8_t useLimitCategory_044;

	// 名前：差し替えカテゴリ
	// 説明：呼び出しIDに加算しる条件カテゴリ
	uint8_t replaceCategory_045;

	// 名前：リザーブ
	uint8_t reserve4_046[2];

	// 名前：生存使用可
	// 説明：生存プレイヤー使用可能か
	uint8_t enable_live_048: 1;

	// 名前：グレイ使用可
	// 説明：グレイゴースト使用可能か
	uint8_t enable_gray_048: 1;

	// 名前：白使用可
	// 説明：ホワイトゴースト使用可能か
	uint8_t enable_white_048: 1;

	// 名前：黒使用可
	// 説明：ブラックゴーストしよう可能か
	uint8_t enable_black_048: 1;

	// 名前：マルチプレイ可
	// 説明：マルチプレイ中に使用可能か？
	uint8_t enable_multi_048: 1;

	// 名前：オフラインで使用不可
	// 説明：オフライン中に使用不可か？
	uint8_t disable_offline_048: 1;

	// 名前：装備可能
	// 説明：装備できるかどうか
	uint8_t isEquip_048: 1;

	// 名前：消耗品か
	// 説明：使用時に消耗するか(所持数が減るか)
	uint8_t isConsume_048: 1;

	// 名前：自動装備するか？
	// 説明：拾った時に自動で装備するか？
	uint8_t isAutoEquip_049: 1;

	// 名前：設置型アイテムか？
	// 説明：設置型アイテムか？
	uint8_t isEstablishment_049: 1;

	// 名前：1個しか持てないか
	// 説明：1個しか持てないアイテムか
	uint8_t isOnlyOne_049: 1;

	// 名前：捨てれるか
	// 説明：アイテムを捨てれるか？TRUE=捨てれる
	uint8_t isDiscard_049: 1;

	// 名前：預けれるか
	// 説明：倉庫に預けれるか
	uint8_t isDeposit_049: 1;

	// 名前：右素手に使えないか
	// 説明：右手武器が素手の場合に使用不可か
	uint8_t isDisableHand_049: 1;

	// 名前：周回時削除するか
	// 説明：周回時削除するか
	uint8_t isRemoveItem_forGameClear_049: 1;

	// 名前：補充アイテムか
	// 説明：補充可能アイテムを判別するのに使用します
	uint8_t isSuppleItem_049: 1;

	// 名前：補充済みアイテムか
	// 説明：補充済みアイテムを判別するのに使用します
	uint8_t isFullSuppleItem_04A: 1;

	// 名前：エンチャントするか？
	// 説明：武器にエンチャントするか？
	uint8_t isEnhance_04A: 1;

	// 名前：修理アイテムか
	// 説明：修理するアイテムか？
	uint8_t isFixItem_04A: 1;

	// 名前：マルチドロップ共有禁止か
	// 説明：マルチドロップ共有禁止か
	uint8_t disableMultiDropShare_04A: 1;

	// 名前：闘技場で使用禁止か
	// 説明：闘技場で使用禁止か
	uint8_t disableUseAtColiseum_04A: 1;

	// 名前：闘技場以外で使用禁止か
	// 説明：闘技場以外で使用禁止か
	uint8_t disableUseAtOutOfColiseum_04A: 1;

	// 名前：早いキャンセル可能か
	// 説明：早いキャンセル可能か
	uint8_t isEnableFastUseItem_04A: 1;

	// 名前：特殊効果を反映するか
	// 説明：（能力値補正など）特殊効果を反映するか
	uint8_t isApplySpecialEffect_04A: 1;

	// 名前：個数増減を同期させるID
	// 説明：アイテムの個数が変更された際に、同じIDを設定したアイテムも一緒に変更を行います。 0：同期しない
	uint8_t syncNumVaryId_04B;

	// 名前：呼び出しID1
	// 説明：アイテムから呼び出されるID1
	int32_t refId_1_04C;

	// 名前：参照仮想武器ID
	// 説明：道具使用時に参照する武器ID
	int32_t refVirtualWepId_050;

	// 名前：ベイグラント時アイテム抽選ID_マップ用
	// 説明：-1：ベイグラントなし 0：抽選なし 1～：抽選あり
	int32_t vagrantItemLotId_054;

	// 名前：ベイグラントボーナス敵ドロップアイテム抽選ID_マップ用
	// 説明：-1：ドロップなし 0：抽選なし 1～：抽選あり
	int32_t vagrantBonusEneDropItemLotId_058;

	// 名前：ベイグラントアイテム敵ドロップアイテム抽選ID_マップ用
	// 説明：-1：ドロップなし 0：抽選なし 1～：抽選あり
	int32_t vagrantItemEneDropItemLotId_05C;

	// 名前：手持ちSFXID
	// 説明：アイテムを使用しようとし、効果が発動するまでのSFXID
	int32_t castSfxId_060;

	// 名前：発動SFXID
	// 説明：アイテムが発動したときのSFXID
	int32_t fireSfxId_064;

	// 名前：効果SFXID
	// 説明：アイテムが発動後、効果中のSFXID
	int32_t effectSfxId_068;

	// 名前：大ルーン発動中使用可
	// 説明：大ルーン発動状態で使用可能か
	uint8_t enable_ActiveBigRune_06C: 1;

	// 名前：篝火ワープアイテムか
	// 説明：TRUEの時に状態変化タイプの「ワープ禁止」がかかっていればそのアイテムを使用不可にする機能を外す
	uint8_t isBonfireWarpItem_06C: 1;

	// 名前：はしご中使用可能か
	// 説明：はしご中に使用可能なアイテムはここにチェックを入れます
	uint8_t enable_Ladder_06C: 1;

	// 名前：マルチプレイ準備中可
	// 説明：セッション確率～初期同期の間でアイテムを使用できるかどうか
	uint8_t isUseMultiPlayPreparation_06C: 1;

	// 名前：まとめて使えるか
	// 説明：まとめて使えるか
	uint8_t canMultiUse_06C: 1;

	// 名前：盾エンチャントか
	// 説明：盾エンチャントか
	uint8_t isShieldEnchant_06C: 1;

	// 名前：ワープ禁止対象か
	// 説明：これがTRUEの時に、状態変化タイプの「ワープ禁止」がかかっていればそのアイテムを使用不可にする 
	uint8_t isWarpProhibited_06C: 1;

	// 名前：切断ペナルティが発生しているときのみ使用可能
	// 説明：クライアント切断ペナルティが発生しているときのみ使用可能なアイテムかどうかを判断できるようにするためのフラグ
	uint8_t isUseMultiPenaltyOnly_06C: 1;

	// 名前：補充タイプ
	// 説明：補充アイテム/補充済みアイテムを補充する際の補充タイプ。
	uint8_t suppleType_06D;

	// 名前：自動補充タイプ
	// 説明：自動補充する/しないの可否およびデフォルト設定をコントロールします
	uint8_t autoReplenishType_06E;

	// 名前：その場に置けるか
	// 説明：アイテムをその場に置けるか？TRUE=置ける
	uint8_t isDrop_06F: 1;

	// 名前：取得ログ表示条件
	// 説明：アイテム取得時にアイテム取得ログに表示するか（未入力: ○）
	uint8_t showLogCondType_06F: 1;

	// 名前：馬呼びアイテムか
	// 説明：馬を召喚するアイテムか？馬が死亡、PCが馬禁止エリアに居る場合は使用不可
	uint8_t isSummonHorse_06F: 1;

	// 名前：取得ダイアログ表示条件
	// 説明：アイテム取得時にアイテム取得ダイアログに表示するか（未入力: newのみ）
	uint8_t showDialogCondType_06F: 2;

	// 名前：ネムリ収集アイテムか
	// 説明：ネムリ収集アイテムか
	uint8_t isSleepCollectionItem_06F: 1;

	// 名前：騎乗中使用可能か
	// 説明：騎乗中使用可能か
	uint8_t enableRiding_06F: 1;

	// 名前：非騎乗中使用禁止か
	// 説明：非騎乗中使用禁止か
	uint8_t disableRiding_06F: 1;

	// 名前：倉庫所持数
	// 説明：倉庫所持数
	int16_t maxRepositoryNum_070;

	// 名前：ソートアイテム種別ID
	// 説明：ソートアイテム種別ID。ソート「アイテム種別順」にて、同じIDは同じグループとしてまとめて表示されます
	uint8_t sortGroupId_072;

	// 名前：攻撃禁止区域で使用できるか
	// 説明：攻撃禁止区域で使用できるか
	uint8_t isUseNoAttackRegion_073: 1;

	// 名前：pad
	// 説明：（旧ログ用アイコン）
	uint8_t pad1_073: 7;

	// 名前：販売価格
	// 説明：販売価格
	int32_t saleValue_074;

	// 名前：レア度
	// 説明：アイテム取得ログで使うレア度
	uint8_t rarity_078;

	// 名前：バディアイテムか
	// 説明：バディアイテム用のアイテム使用制限がかかるかどうか
	uint8_t useLimitSummonBuddy_079;

	// 名前：使用禁止条件_状態変化タイプ
	// 説明：かかっている特殊効果の状態変化タイプによって使用可能かを制御する為に指定
	uint16_t useLimitSpEffectType_07A;

	// 名前：AI使用判断ID
	// 説明：AI使用判断ID
	int32_t aiUseJudgeId_07C;

	// 名前：消費MP
	// 説明：消費MP
	int16_t consumeMP_080;

	// 名前：消費HP
	// 説明：消費HP
	int16_t consumeHP_082;

	// 名前：強化先道具ID
	// 説明：強化先道具ID
	int32_t reinforceGoodsId_084;

	// 名前：強化時素材ID
	// 説明：強化時素材ID
	int32_t reinforceMaterialId_088;

	// 名前：強化価格
	// 説明：強化価格
	int32_t reinforcePrice_08C;

	// 名前：誓約0使用レベル
	// 説明：誓約0使用レベル
	int8_t useLevel_vowType0_090;

	// 名前：誓約1使用レベル
	// 説明：誓約1使用レベル
	int8_t useLevel_vowType1_091;

	// 名前：誓約2使用レベル
	// 説明：誓約2使用レベル
	int8_t useLevel_vowType2_092;

	// 名前：誓約3使用レベル
	// 説明：誓約3使用レベル
	int8_t useLevel_vowType3_093;

	// 名前：誓約4使用レベル
	// 説明：誓約4使用レベル
	int8_t useLevel_vowType4_094;

	// 名前：誓約5使用レベル
	// 説明：誓約5使用レベル
	int8_t useLevel_vowType5_095;

	// 名前：誓約6使用レベル
	// 説明：誓約6使用レベル
	int8_t useLevel_vowType6_096;

	// 名前：誓約7使用レベル
	// 説明：誓約7使用レベル
	int8_t useLevel_vowType7_097;

	// 名前：誓約8使用レベル
	// 説明：誓約8使用レベル
	int8_t useLevel_vowType8_098;

	// 名前：誓約9使用レベル
	// 説明：誓約9使用レベル
	int8_t useLevel_vowType9_099;

	// 名前：誓約10使用レベル
	// 説明：誓約10使用レベル
	int8_t useLevel_vowType10_09A;

	// 名前：誓約11使用レベル
	// 説明：誓約11使用レベル
	int8_t useLevel_vowType11_09B;

	// 名前：誓約12使用レベル
	// 説明：誓約12使用レベル
	int8_t useLevel_vowType12_09C;

	// 名前：誓約13使用レベル
	// 説明：誓約13使用レベル
	int8_t useLevel_vowType13_09D;

	// 名前：誓約14使用レベル
	// 説明：誓約14使用レベル
	int8_t useLevel_vowType14_09E;

	// 名前：誓約15使用レベル
	// 説明：誓約15使用レベル
	int8_t useLevel_vowType15_09F;

	// 名前：使用適正レベル
	// 説明：使用適正レベル
	uint16_t useLevel_0A0;

	// 名前：予約領域
	// 説明：予約領域
	uint8_t reserve5_0A2[2];

	// 名前：アイテム入手チュートリアル判定フラグID
	// 説明：初めてアイテム入手した時のチュートリアル用のイベントフラグID。アイテム入手時にフラグON。
	uint32_t itemGetTutorialFlagId_0A4;

	// 名前：予約領域
	// 説明：予約領域
	uint8_t reserve3_0A8[8];

} EquipParamGoods;

#endif
