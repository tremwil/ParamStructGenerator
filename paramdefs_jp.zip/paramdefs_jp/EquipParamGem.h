/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EquipParamGem_H
#define _PARAM_EquipParamGem_H
#include <stdint.h>

// EQUIP_PARAM_GEM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EquipParamGem {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：アイコンID
	// 説明：メニュー用アイコンID
	uint16_t iconId_004;

	// 名前：魔石ランク
	// 説明：魔石ランク
	int8_t rank_006;

	// 名前：ソートアイテム種別ID
	// 説明：ソートアイテム種別ID。ソート「アイテム種別順」にて、同じIDは同じグループとしてまとめて表示されます
	uint8_t sortGroupId_007;

	// 名前：常駐特殊効果ID00
	// 説明：特殊効果ID00
	int32_t spEffectId0_008;

	// 名前：常駐特殊効果ID01
	// 説明：特殊効果ID01
	int32_t spEffectId1_00C;

	// 名前：常駐特殊効果ID02
	// 説明：特殊効果ID02
	int32_t spEffectId2_010;

	// 名前：アイテム入手チュートリアル判定フラグID
	// 説明：初めてアイテム入手した時のチュートリアル用のイベントフラグID。アイテム入手時にフラグON。
	uint32_t itemGetTutorialFlagId_014;

	// 名前：変化先アーツパラメータID
	// 説明：変化先アーツパラメータのID
	int32_t swordArtsParamId_018;

	// 名前：装着価格
	// 説明：装着価格
	int32_t mountValue_01C;

	// 名前：売却価格
	// 説明：売却価格
	int32_t sellValue_020;

	// 名前：販売価格
	// 説明：販売価格
	int32_t saleValue_024;

	// 名前：ソートID
	// 説明：ソートID(-1:集めない)
	int32_t sortId_028;

	// 名前：コンプトロフィーSEQ番号
	// 説明：コンプリート系トロフィのSEQ番号
	int16_t compTrophySedId_02C;

	// 名前：トロフィーSEQ番号
	// 説明：トロフィーのSEQ番号
	int16_t trophySeqId_02E;

	// 名前：0
	// 説明：設定可能武器属性ID0
	uint8_t configurableWepAttr00_030: 1;

	// 名前：1
	// 説明：設定可能武器属性ID1
	uint8_t configurableWepAttr01_030: 1;

	// 名前：2
	// 説明：設定可能武器属性ID2
	uint8_t configurableWepAttr02_030: 1;

	// 名前：3
	// 説明：設定可能武器属性ID3
	uint8_t configurableWepAttr03_030: 1;

	// 名前：4
	// 説明：設定可能武器属性ID4
	uint8_t configurableWepAttr04_030: 1;

	// 名前：5
	// 説明：設定可能武器属性ID5
	uint8_t configurableWepAttr05_030: 1;

	// 名前：6
	// 説明：設定可能武器属性ID6
	uint8_t configurableWepAttr06_030: 1;

	// 名前：7
	// 説明：設定可能武器属性ID7
	uint8_t configurableWepAttr07_030: 1;

	// 名前：8
	// 説明：設定可能武器属性ID8
	uint8_t configurableWepAttr08_031: 1;

	// 名前：9
	// 説明：設定可能武器属性ID9
	uint8_t configurableWepAttr09_031: 1;

	// 名前：10
	// 説明：設定可能武器属性ID10
	uint8_t configurableWepAttr10_031: 1;

	// 名前：11
	// 説明：設定可能武器属性ID11
	uint8_t configurableWepAttr11_031: 1;

	// 名前：12
	// 説明：設定可能武器属性ID12
	uint8_t configurableWepAttr12_031: 1;

	// 名前：13
	// 説明：設定可能武器属性ID13
	uint8_t configurableWepAttr13_031: 1;

	// 名前：14
	// 説明：設定可能武器属性ID14
	uint8_t configurableWepAttr14_031: 1;

	// 名前：15
	// 説明：設定可能武器属性ID15
	uint8_t configurableWepAttr15_031: 1;

	// 名前：レア度
	// 説明：アイテム取得ログで使うレア度
	uint8_t rarity_032;

	// 名前：16
	// 説明：設定可能武器属性ID16
	uint8_t configurableWepAttr16_033: 1;

	// 名前：17
	// 説明：設定可能武器属性ID17
	uint8_t configurableWepAttr17_033: 1;

	// 名前：18
	// 説明：設定可能武器属性ID18
	uint8_t configurableWepAttr18_033: 1;

	// 名前：19
	// 説明：設定可能武器属性ID19
	uint8_t configurableWepAttr19_033: 1;

	// 名前：20
	// 説明：設定可能武器属性ID20
	uint8_t configurableWepAttr20_033: 1;

	// 名前：21
	// 説明：設定可能武器属性ID21
	uint8_t configurableWepAttr21_033: 1;

	// 名前：22
	// 説明：設定可能武器属性ID22
	uint8_t configurableWepAttr22_033: 1;

	// 名前：23
	// 説明：設定可能武器属性ID23
	uint8_t configurableWepAttr23_033: 1;

	// 名前：捨てれるか
	// 説明：アイテムを捨てれるか？TRUE=捨てれる
	uint8_t isDiscard_034: 1;

	// 名前：その場に置けるか
	// 説明：アイテムをその場に置けるか？TRUE=置ける
	uint8_t isDrop_034: 1;

	// 名前：預けれるか
	// 説明：倉庫に預けれるか
	uint8_t isDeposit_034: 1;

	// 名前：マルチドロップ共有禁止か
	// 説明：マルチドロップ共有禁止か
	uint8_t disableMultiDropShare_034: 1;

	// 名前：取得ダイアログ表示条件
	// 説明：アイテム取得時にアイテム取得ダイアログに表示するか（未入力: newのみ）
	uint8_t showDialogCondType_034: 2;

	// 名前：取得ログ表示条件
	// 説明：アイテム取得時にアイテム取得ログに表示するか（未入力: ○）
	uint8_t showLogCondType_034: 1;

	// 名前：pad
	// 説明：pad
	uint8_t pad_034: 1;

	// 名前：デフォルト武器属性ID
	// 説明：デフォルト武器属性ID。開放されてない武器属性でも装着可能になる
	uint8_t defaultWepAttr_035;

	// 名前：pad2
	// 説明：pad2
	uint8_t pad2_036[2];

	// 名前：短剣
	// 説明：「武器種別：短剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_Dagger_038: 1;

	// 名前：直剣
	// 説明：「武器種別：直剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SwordNormal_038: 1;

	// 名前：大剣
	// 説明：「武器種別：大剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SwordLarge_038: 1;

	// 名前：特大剣
	// 説明：「武器種別：特大剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SwordGigantic_038: 1;

	// 名前：曲剣 
	// 説明：「武器種別：曲剣 」に装着可能か。未入力は×になる
	uint8_t canMountWep_SaberNormal_038: 1;

	// 名前：大曲剣
	// 説明：「武器種別：大曲剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SaberLarge_038: 1;

	// 名前：刀
	// 説明：「武器種別：刀」に装着可能か。未入力は×になる
	uint8_t canMountWep_katana_038: 1;

	// 名前：両刃剣
	// 説明：「武器種別：両刃剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SwordDoubleEdge_038: 1;

	// 名前：刺剣
	// 説明：「武器種別：刺剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SwordPierce_039: 1;

	// 名前：大刺剣
	// 説明：「武器種別：大刺剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_RapierHeavy_039: 1;

	// 名前：斧
	// 説明：「武器種別：斧」に装着可能か。未入力は×になる
	uint8_t canMountWep_AxeNormal_039: 1;

	// 名前：大斧
	// 説明：「武器種別：大斧」に装着可能か。未入力は×になる
	uint8_t canMountWep_AxeLarge_039: 1;

	// 名前：槌
	// 説明：「武器種別：槌」に装着可能か。未入力は×になる
	uint8_t canMountWep_HammerNormal_039: 1;

	// 名前：大槌
	// 説明：「武器種別：大槌」に装着可能か。未入力は×になる
	uint8_t canMountWep_HammerLarge_039: 1;

	// 名前：フレイル
	// 説明：「武器種別：フレイル」に装着可能か。未入力は×になる
	uint8_t canMountWep_Flail_039: 1;

	// 名前：槍
	// 説明：「武器種別：槍」に装着可能か。未入力は×になる
	uint8_t canMountWep_SpearNormal_039: 1;

	// 名前：長槍
	// 説明：「武器種別：長槍」に装着可能か。未入力は×になる
	uint8_t canMountWep_SpearLarge_03A: 1;

	// 名前：大槍
	// 説明：「武器種別：大槍」に装着可能か。未入力は×になる
	uint8_t canMountWep_SpearHeavy_03A: 1;

	// 名前：斧槍
	// 説明：「武器種別：斧槍」に装着可能か。未入力は×になる
	uint8_t canMountWep_SpearAxe_03A: 1;

	// 名前：鎌
	// 説明：「武器種別：鎌」に装着可能か。未入力は×になる
	uint8_t canMountWep_Sickle_03A: 1;

	// 名前：拳
	// 説明：「武器種別：拳」に装着可能か。未入力は×になる
	uint8_t canMountWep_Knuckle_03A: 1;

	// 名前：爪
	// 説明：「武器種別：爪」に装着可能か。未入力は×になる
	uint8_t canMountWep_Claw_03A: 1;

	// 名前：ムチ
	// 説明：「武器種別：ムチ」に装着可能か。未入力は×になる
	uint8_t canMountWep_Whip_03A: 1;

	// 名前：特大斧槌
	// 説明：「武器種別：特大斧槌」に装着可能か。未入力は×になる
	uint8_t canMountWep_AxhammerLarge_03A: 1;

	// 名前：小弓
	// 説明：「武器種別：小弓」に装着可能か。未入力は×になる
	uint8_t canMountWep_BowSmall_03B: 1;

	// 名前：弓
	// 説明：「武器種別：弓」に装着可能か。未入力は×になる
	uint8_t canMountWep_BowNormal_03B: 1;

	// 名前：大弓
	// 説明：「武器種別：大弓」に装着可能か。未入力は×になる
	uint8_t canMountWep_BowLarge_03B: 1;

	// 名前：クロスボウ
	// 説明：「武器種別：クロスボウ」に装着可能か。未入力は×になる
	uint8_t canMountWep_ClossBow_03B: 1;

	// 名前：バリスタ
	// 説明：「武器種別：バリスタ」に装着可能か。未入力は×になる
	uint8_t canMountWep_Ballista_03B: 1;

	// 名前：杖
	// 説明：「武器種別：杖」に装着可能か。未入力は×になる
	uint8_t canMountWep_Staff_03B: 1;

	// 名前：入れ墨
	// 説明：「武器種別：入れ墨」に装着可能か。未入力は×になる
	uint8_t canMountWep_Sorcery_03B: 1;

	// 名前：聖印
	// 説明：「武器種別：聖印」に装着可能か。未入力は×になる
	uint8_t canMountWep_Talisman_03B: 1;

	// 名前：小盾
	// 説明：「武器種別：小盾」に装着可能か。未入力は×になる
	uint8_t canMountWep_ShieldSmall_03C: 1;

	// 名前：中盾
	// 説明：「武器種別：中盾」に装着可能か。未入力は×になる
	uint8_t canMountWep_ShieldNormal_03C: 1;

	// 名前：大盾
	// 説明：「武器種別：大盾」に装着可能か。未入力は×になる
	uint8_t canMountWep_ShieldLarge_03C: 1;

	// 名前：松明
	// 説明：「武器種別：松明」に装着可能か。未入力は×になる
	uint8_t canMountWep_Torch_03C: 1;

	// 名前：予約領域（装着可能な武器種別か）
	// 説明：装着可能な武器種別かの予約領域（全部で64bit分確保）
	uint8_t reserved_canMountWep_03C: 4;

	// 名前：予約領域（装着可能な武器種別か）
	// 説明：装着可能な武器種別かの予約領域（全部で64bit分確保）
	uint8_t reserved2_canMountWep_03D[3];

	// 名前：効果テキストID00
	// 説明：効果テキストID00(Gem_Effect)。ステータスに表示する魔石の効果テキスト
	int32_t spEffectMsgId0_040;

	// 名前：効果テキストID01
	// 説明：効果テキストID01(Gem_Effect)。ステータスに表示する魔石の効果テキスト
	int32_t spEffectMsgId1_044;

	// 名前：攻撃ヒット時特殊効果ID00
	// 説明：攻撃ヒット時用の特殊効果パラメータID
	int32_t spEffectId_forAtk0_048;

	// 名前：攻撃ヒット時特殊効果ID01
	// 説明：攻撃ヒット時用の特殊効果パラメータID
	int32_t spEffectId_forAtk1_04C;

	// 名前：攻撃ヒット時特殊効果ID02
	// 説明：攻撃ヒット時用の特殊効果パラメータID
	int32_t spEffectId_forAtk2_050;

	// 名前：対応武器種別上書きテキストID
	// 説明：対応武器種別上書きテキストID(-1:上書きしない)[MenuText]
	int32_t mountWepTextId_054;

	// 名前：pad6
	uint8_t pad6_058[8];

} EquipParamGem;

#endif
