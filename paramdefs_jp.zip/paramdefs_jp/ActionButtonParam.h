/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ActionButtonParam_H
#define _PARAM_ActionButtonParam_H
#include <stdint.h>

// ACTIONBUTTON_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ActionButtonParam {

	// 名前：範囲タイプ
	// 説明：範囲形状(円柱、角柱、カプセル)
	uint8_t regionType_000;

	// 名前：カテゴリ
	// 説明：カテゴリ。名前の左側の数字は複数のアクションボタンが重なっていた場合の優先度(0に近い程優先表示)。
	uint8_t category_001;

	// 名前：パディング1
	uint8_t padding1_002[2];

	// 名前：ダミポリ1
	// 説明：範囲の底面の中心となるダミポリIDを指定する　ダミポリがない場合 or -1が入力されている場合は、中心座標が基準になる
	int32_t dummyPoly1_004;

	// 名前：ダミポリ2
	// 説明：範囲タイプがカプセルの場合のみ使用　ダミポリ2つで線分を作る追加ダミポリ(カプセル)
	int32_t dummyPoly2_008;

	// 名前：半径
	// 説明：半径(円柱・カプセル)
	float radius_00C;

	// 名前：角度
	// 説明：角度(円柱)
	int32_t angle_010;

	// 名前：奥行き
	// 説明：奥行き(角柱)
	float depth_014;

	// 名前：幅
	// 説明：幅(角柱)
	float width_018;

	// 名前：高さ
	// 説明：高さ(円柱・角柱)
	float height_01C;

	// 名前：底面高さオフセット
	// 説明：底面のY座標をどれだけ上下させるか(円柱・角柱)
	float baseHeightOffset_020;

	// 名前：角度差判定タイプ
	// 説明：角度差判定タイプ(円柱・角柱)
	uint8_t angleCheckType_024;

	// 名前：パディング2
	uint8_t padding2_025[3];

	// 名前：許容角度差
	// 説明：許容角度差(円柱・角柱)
	int32_t allowAngle_028;

	// 名前：アクションスポットダミポリ
	// 説明：アクションスポットの位置となるダミポリIDを指定する ダミポリがない場合 or -1が入力されている場合は、中心座標が基準となる
	int32_t spotDummyPoly_02C;

	// 名前：テキストボックスタイプ
	// 説明：テキストボックスタイプ
	uint8_t textBoxType_030;

	// 名前：パディング3
	uint8_t padding3_031[2];

	// 名前：パディング5
	uint8_t padding5_033: 1;

	// 名前：騎乗時無効か
	// 説明：この項目がYESだと騎乗時にアクションボタンが出なくなり、判定も行われない
	uint8_t isInvalidForRide_033: 1;

	// 名前：騎乗時グレーアウトか
	// 説明：この項目がYESだと騎乗時にアクションボタンがグレーアウトし、判定も行われない
	uint8_t isGrayoutForRide_033: 1;

	// 名前：しゃがみ時無効か
	// 説明：この項目がYESだとしゃがみ時にアクションボタンが出なくなり、判定も行われない
	uint8_t isInvalidForCrouching_033: 1;

	// 名前：しゃがみ時グレーアウトか
	// 説明：この項目がYESだとしゃがみ時にアクションボタンがグレーアウトし、判定も行われない
	uint8_t isGrayoutForCrouching_033: 1;

	// 名前：パディング4
	uint8_t padding4_033: 3;

	// 名前：テキストID
	// 説明：表示するテキストID
	int32_t textId_034;

	// 名前：無効フラグ
	// 説明：このフラグがONだとアクションボタンが出ず、判定も行われない
	uint32_t invalidFlag_038;

	// 名前：グレーアウトフラグ
	// 説明：このフラグがONだとアクションボタンがグレーアウトし、判定も行われない
	uint32_t grayoutFlag_03C;

	// 名前：騎乗時差し替えアクションボタンID
	// 説明：騎乗中はこのアクションボタンIDのパラメータに差し替える（-1：差し替え無し）
	int32_t overrideActionButtonIdForRide_040;

	// 名前：実行後無効時間
	// 説明：実行後無効時間(-値で無限)
	float execInvalidTime_044;

	// 名前：パディング6
	uint8_t padding6_048[28];

} ActionButtonParam;

#endif
