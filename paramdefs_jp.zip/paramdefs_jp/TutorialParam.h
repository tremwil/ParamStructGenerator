/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_TutorialParam_H
#define _PARAM_TutorialParam_H
#include <stdint.h>

// TUTORIAL_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _TutorialParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：表示タイプ
	// 説明：表示するチュートリアルメニューの種類を指定します
	uint8_t menuType_004;

	// 名前：表示タイミング
	// 説明：表示タイミング（デフォルト: 0:"-"）。このメニューを開いたときに、このチュートリアルを表示します。メニューを開いたときに表示しない場合は 0:"-" を指定します
	uint8_t triggerType_005;

	// 名前：表示回数
	// 説明：表示する回数（デフォルト: 0:ゲーム中1回）
	uint8_t repeatType_006;

	// 名前：パディング
	uint8_t pad1_007[1];

	// 名前：イメージID
	// 説明：表示するチュートリアル画像IDを指定します（デフォルト: 0）。画像を表示しない場合は、0 を指定します
	uint16_t imageId_008;

	// 名前：パディング
	uint8_t pad2_00A[2];

	// 名前：表示許可フラグ
	// 説明：表示許可用のイベントフラグID（デフォルト: 0）。このフラグが立つまでは表示されません。常に許可したい場合は 0 を指定します
	uint32_t unlockEventFlagId_00C;

	// 名前：テキストID
	// 説明：チュートリアルに表示するテキストのID[TutorialText.xlsm]。「タイトル」も「本文」もこのテキストIDが使われる
	int32_t textId_010;

	// 名前：最短
	// 説明：最短表示保障時間[秒]。イベントなどから閉じられたとしても、少なくともこの時間は表示してから閉じられるます。トースト専用なのでモーダルでは無視されます
	float displayMinTime_014;

	// 名前：最長
	// 説明：表示時間[秒]。トーストが表示されてからこの時間経過すると自動的に閉じられます。トースト専用なのでモーダルでは無視されます
	float displayTime_018;

	// 名前：パディング
	uint8_t pad3_01C[4];

} TutorialParam;

#endif
