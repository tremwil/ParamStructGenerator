/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SoundChrPhysicsSeParam_H
#define _PARAM_SoundChrPhysicsSeParam_H
#include <stdint.h>

// SOUND_CHR_PHYSICS_SE_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SoundChrPhysicsSeParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：地面接触SEID
	// 説明：死亡後、地面と接触したときに発音するSEID。(-1：無効)。SEIDカテゴリーはc固定
	int32_t ContactLandSeId_004;

	// 名前：地面接触追加SEID(材質用)
	// 説明：死亡後、地面と接触したときに発音する追加SEID(材質用)。(-1：無効)。SEIDカテゴリーはc固定
	int32_t ContactLandAddSeId_008;

	// 名前：地面接触発音回数
	// 説明：死亡後、地面接触時に発音する回数
	int32_t ContactLandPlayNum_00C;

	// 名前：地面接触発音回数を剛体単位でカウントするか？
	// 説明：死亡後地、面接触発音回数を剛体単位でカウントするか？(〇：剛体単位、×：キャラ単位)
	uint8_t IsEnablePlayCountPerRigid_010;

	// 名前：pad
	uint8_t pad_011[3];

	// 名前：地面接触最小力積値
	// 説明：死亡後、地面接触判定に必要な最小力積値
	float ContactLandMinImpuse_014;

	// 名前：地面接触最小速度値
	// 説明：死亡後、地面接触判定に必要な最小速度値
	float ContactLandMinSpeed_018;

	// 名前：Player接触SEID
	// 説明：死亡後、Playerと接触したときに鳴らすSEID。(-1：無効)。SEIDカテゴリーはc固定
	int32_t ContactPlayerSeId_01C;

	// 名前：Player接触最小力積値
	// 説明：死亡後、Player接触判定に必要な最小力積値
	float ContactPlayerMinImpuse_020;

	// 名前：Player接触最小速度値
	// 説明：死亡後、Player接触判定に必要な最小速度値
	float ContactPlayerMinSpeed_024;

	// 名前：接触判定剛体IDX0
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx0_028;

	// 名前：接触判定剛体IDX1
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx1_029;

	// 名前：接触判定剛体IDX2
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx2_02A;

	// 名前：接触判定剛体IDX3
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx3_02B;

	// 名前：接触判定剛体IDX4
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx4_02C;

	// 名前：接触判定剛体IDX5
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx5_02D;

	// 名前：接触判定剛体IDX6
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx6_02E;

	// 名前：接触判定剛体IDX7
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx7_02F;

	// 名前：接触判定剛体IDX8
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx8_030;

	// 名前：接触判定剛体IDX9
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx9_031;

	// 名前：接触判定剛体IDX10
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx10_032;

	// 名前：接触判定剛体IDX11
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx11_033;

	// 名前：接触判定剛体IDX12
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx12_034;

	// 名前：接触判定剛体IDX13
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx13_035;

	// 名前：接触判定剛体IDX14
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx14_036;

	// 名前：接触判定剛体IDX15
	// 説明：接触判定する剛体のINDEXを指定します。SEを付けたい剛体だけ指定します
	int8_t ContactCheckRigidIdx15_037;

} SoundChrPhysicsSeParam;

#endif
