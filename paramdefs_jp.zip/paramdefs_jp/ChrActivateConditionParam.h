/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ChrActivateConditionParam_H
#define _PARAM_ChrActivateConditionParam_H
#include <stdint.h>

// CHR_ACTIVATE_CONDITION_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ChrActivateConditionParam {

	// 名前：出現条件_晴れ
	// 説明：天候が「晴れ」のときに出現するか
	uint8_t weatherSunny_000: 1;

	// 名前：出現条件_快晴
	// 説明：天候が「快晴」のときに出現するか
	uint8_t weatherClearSky_000: 1;

	// 名前：出現条件_薄曇り
	// 説明：天候が「薄曇り」のときに出現するか
	uint8_t weatherWeakCloudy_000: 1;

	// 名前：出現条件_曇り
	// 説明：天候が「曇り」のときに出現するか
	uint8_t weatherCloudy_000: 1;

	// 名前：出現条件_雨
	// 説明：天候が「雨」のときに出現するか
	uint8_t weatherRain_000: 1;

	// 名前：出現条件_豪雨
	// 説明：天候が「豪雨」のときに出現するか
	uint8_t weatherHeavyRain_000: 1;

	// 名前：出現条件_嵐
	// 説明：天候が「嵐」のときに出現するか
	uint8_t weatherStorm_000: 1;

	// 名前：出現条件_嵐（守護者の末裔との戦闘用）
	// 説明：天候が「嵐（守護者の末裔との戦闘用）」のときに出現するか
	uint8_t weatherStormForBattle_000: 1;

	// 名前：出現条件_雪
	// 説明：天候が「雪」のときに出現するか
	uint8_t weatherSnow_001: 1;

	// 名前：出現条件_大雪
	// 説明：天候が「大雪」のときに出現するか
	uint8_t weatherHeavySnow_001: 1;

	// 名前：出現条件_霧
	// 説明：天候が「霧」のときに出現するか
	uint8_t weatherFog_001: 1;

	// 名前：出現条件_濃霧
	// 説明：天候が「濃霧」のときに出現するか
	uint8_t weatherHeavyFog_001: 1;

	// 名前：出現条件_濃霧（雨）
	// 説明：天候が「濃霧（雨）」のときに出現するか
	uint8_t weatherHeavyFogRain_001: 1;

	// 名前：出現条件_砂嵐
	// 説明：天候が「砂嵐」のときに出現するか
	uint8_t weatherSandStorm_001: 1;

	// 名前：pad
	uint8_t pad1_001: 2;

	// 名前：出現開始インゲーム時間_時
	// 説明：出現開始インゲーム時間_時
	uint8_t timeStartHour_002;

	// 名前：出現開始インゲーム時間_分
	// 説明：出現開始インゲーム時間_分
	uint8_t timeStartMin_003;

	// 名前：出現終了インゲーム時間_時
	// 説明：出現終了インゲーム時間_時
	uint8_t timeEndHour_004;

	// 名前：出現終了インゲーム時間_分
	// 説明：出現終了インゲーム時間_分
	uint8_t timeEndMin_005;

	// 名前：pad
	uint8_t pad2_006[2];

} ChrActivateConditionParam;

#endif
