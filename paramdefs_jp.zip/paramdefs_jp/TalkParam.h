/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_TalkParam_H
#define _PARAM_TalkParam_H
#include <stdint.h>

// TALK_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _TalkParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：PC性別が男：メッセージID
	// 説明：PC性別が男：メッセージを指定->メニュー
	int32_t msgId_004;

	// 名前：PC性別が男：ボイスID
	// 説明：PC性別が男：ボイスを指定->サウンド
	int32_t voiceId_008;

	// 名前：特殊効果ID0
	// 説明：特殊効果を指定->キャラ
	int32_t spEffectId0_00C;

	// 名前：モーションID0
	// 説明：モーションを指定->キャラ
	int32_t motionId0_010;

	// 名前：特殊効果ID1
	// 説明：特殊効果を指定->キャラ
	int32_t spEffectId1_014;

	// 名前：モーションID1
	// 説明：モーションを指定->キャラ
	int32_t motionId1_018;

	// 名前：復帰位置
	// 説明：復帰する会話の相対位置->会話
	int32_t returnPos_01C;

	// 名前：リアクションID
	// 説明：復帰時の会話指定->会話
	int32_t reactionId_020;

	// 名前：イベントID
	// 説明：イベントID->イベント
	int32_t eventId_024;

	// 名前：PC性別が女：メッセージ
	// 説明：PC性別が女：メッセージを指定->メニュー
	int32_t msgId_female_028;

	// 名前：PC性別が女：ボイスID
	// 説明：PC性別が女：ボイスを指定->サウンド
	int32_t voiceId_female_02C;

	// 名前：話者：口パク開始時間
	// 説明：話者：口パク開始時間。-1で口パク無し
	int16_t lipSyncStart_030;

	// 名前：話者：口パク継続時間
	// 説明：話者：口パク継続時間。-1で口パクずっと継続
	int16_t lipSyncTime_032;

	// 名前：パディング
	uint8_t pad2_034[4];

	// 名前：ボイス再生タイムアウト時間
	// 説明：ボイス再生タイムアウト時間。-1の場合は「共通_ゲームシステムパラメータ」の「NPC会話ボイス再生タイムアウト時間」でタイムアウト処理を行う。
	float timeout_038;

	// 名前：話者：字幕芝居アニメID
	// 説明：話者：会話中のアニメーションID
	int32_t talkAnimationId_03C;

	// 名前：強制的に字幕を表示するか
	// 説明：強制的に字幕を表示するか。オプションで字幕オフでも字幕を表示する
	uint8_t isForceDisp_040: 1;

	// 名前：パディング
	uint8_t pad3_040: 7;

	// 名前：パディング
	// 説明：パディング
	uint8_t pad1_041[31];

} TalkParam;

#endif
