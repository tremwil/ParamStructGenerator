/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CutSceneTextureLoadParam_H
#define _PARAM_CutSceneTextureLoadParam_H
#include <stdint.h>

// CUTSCENE_TEXTURE_LOAD_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CutSceneTextureLoadParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：デバッグパラメータか
	// 説明：○をつけたパラメータは全パッケージから除外します（デバッグ用なので）
	uint8_t disableParam_Debug_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 6;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：テクスチャ名 00
	// 説明：テクスチャ名 00
	char texName_00_004[16];

	// 名前：テクスチャ名 01
	// 説明：テクスチャ名 01
	char texName_01_014[16];

	// 名前：テクスチャ名 02
	// 説明：テクスチャ名 02
	char texName_02_024[16];

	// 名前：テクスチャ名 03
	// 説明：テクスチャ名 03
	char texName_03_034[16];

	// 名前：テクスチャ名 04
	// 説明：テクスチャ名 04
	char texName_04_044[16];

	// 名前：テクスチャ名 05
	// 説明：テクスチャ名 05
	char texName_05_054[16];

	// 名前：テクスチャ名 06
	// 説明：テクスチャ名 06
	char texName_06_064[16];

	// 名前：テクスチャ名 07
	// 説明：テクスチャ名 07
	char texName_07_074[16];

	// 名前：テクスチャ名 08
	// 説明：テクスチャ名 08
	char texName_08_084[16];

	// 名前：テクスチャ名 09
	// 説明：テクスチャ名 09
	char texName_09_094[16];

	// 名前：テクスチャ名 10
	// 説明：テクスチャ名 10
	char texName_10_0A4[16];

	// 名前：テクスチャ名 11
	// 説明：テクスチャ名 11
	char texName_11_0B4[16];

	// 名前：テクスチャ名 12
	// 説明：テクスチャ名 12
	char texName_12_0C4[16];

	// 名前：テクスチャ名 13
	// 説明：テクスチャ名 13
	char texName_13_0D4[16];

	// 名前：テクスチャ名 14
	// 説明：テクスチャ名 14
	char texName_14_0E4[16];

	// 名前：テクスチャ名 15
	// 説明：テクスチャ名 15
	char texName_15_0F4[16];

} CutSceneTextureLoadParam;

#endif
