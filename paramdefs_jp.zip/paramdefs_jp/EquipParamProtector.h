/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EquipParamProtector_H
#define _PARAM_EquipParamProtector_H
#include <stdint.h>

// EQUIP_PARAM_PROTECTOR_ST
// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EquipParamProtector {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：ソートID
	// 説明：ソートID(プログラム内で強化レベルを加味しているので s32 では７桁が限界)
	int32_t sortId_004;

	// 名前：徘徊装備ID
	// 説明：徘徊ゴースト用の差し替え装備ID.
	uint32_t wanderingEquipId_008;

	// 名前：睡眠耐性
	// 説明：睡眠状態異常へのかかりにくさ
	uint16_t resistSleep_00C;

	// 名前：発狂耐性
	// 説明：発狂状態異常へのかかりにくさ
	uint16_t resistMadness_00E;

	// 名前：SA耐久値
	// 説明：スーパーアーマー耐久力
	float saDurability_010;

	// 名前：強靭度 補正倍率
	// 説明：強靭度の基本値を補正する倍率です
	float toughnessCorrectRate_014;

	// 名前：修理価格
	// 説明：修理基本価格
	int32_t fixPrice_018;

	// 名前：基本価格
	// 説明：基本価格
	int32_t basicPrice_01C;

	// 名前：売却価格
	// 説明：販売価格
	int32_t sellValue_020;

	// 名前：重量[kg]
	// 説明：重量[kg].
	float weight_024;

	// 名前：常駐特殊効果ID1
	// 説明：常駐特殊効果ID1
	int32_t residentSpEffectId_028;

	// 名前：常駐特殊効果ID2
	// 説明：常駐特殊効果ID2
	int32_t residentSpEffectId2_02C;

	// 名前：常駐特殊効果ID3
	// 説明：常駐特殊効果ID3
	int32_t residentSpEffectId3_030;

	// 名前：素材ID
	// 説明：武器強化に必要な素材パラメータID
	int32_t materialSetId_034;

	// 名前：部位ダメージ率
	// 説明：部位ダメージ率
	float partsDamageRate_038;

	// 名前：SA回復時間補正値
	// 説明：スーパーアーマー回復時間の補正値
	float corectSARecover_03C;

	// 名前：派生元
	// 説明：この防具の強化元防具ID
	int32_t originEquipPro_040;

	// 名前：派生元 強化+1
	// 説明：この防具の強化元防具ID1
	int32_t originEquipPro1_044;

	// 名前：派生元 強化+2
	// 説明：この防具の強化元防具ID2
	int32_t originEquipPro2_048;

	// 名前：派生元 強化+3
	// 説明：この防具の強化元防具ID3
	int32_t originEquipPro3_04C;

	// 名前：派生元 強化+4
	// 説明：この防具の強化元防具ID4
	int32_t originEquipPro4_050;

	// 名前：派生元 強化+5
	// 説明：この防具の強化元防具ID5
	int32_t originEquipPro5_054;

	// 名前：派生元 強化+6
	// 説明：この防具の強化元防具ID6
	int32_t originEquipPro6_058;

	// 名前：派生元 強化+7
	// 説明：この防具の強化元防具ID7
	int32_t originEquipPro7_05C;

	// 名前：派生元 強化+8
	// 説明：この防具の強化元防具ID8
	int32_t originEquipPro8_060;

	// 名前：派生元 強化+9
	// 説明：この防具の強化元防具ID9
	int32_t originEquipPro9_064;

	// 名前：派生元 強化+10
	// 説明：この防具の強化元防具ID10
	int32_t originEquipPro10_068;

	// 名前：派生元 強化+11
	// 説明：この防具の強化元防具ID11
	int32_t originEquipPro11_06C;

	// 名前：派生元 強化+12
	// 説明：この防具の強化元防具ID12
	int32_t originEquipPro12_070;

	// 名前：派生元 強化+13
	// 説明：この防具の強化元防具ID13
	int32_t originEquipPro13_074;

	// 名前：派生元 強化+14
	// 説明：この防具の強化元防具ID14
	int32_t originEquipPro14_078;

	// 名前：派生元 強化+15
	// 説明：この防具の強化元防具ID15
	int32_t originEquipPro15_07C;

	// 名前：男横顔拡大スケール
	float faceScaleM_ScaleX_080;

	// 名前：男前顔拡大スケール
	float faceScaleM_ScaleZ_084;

	// 名前：男横顔拡大最大倍率
	float faceScaleM_MaxX_088;

	// 名前：男前顔拡大最大倍率
	float faceScaleM_MaxZ_08C;

	// 名前：女横顔拡大スケール
	float faceScaleF_ScaleX_090;

	// 名前：女前顔拡大スケール
	float faceScaleF_ScaleZ_094;

	// 名前：女横顔拡大最大倍率
	float faceScaleF_MaxX_098;

	// 名前：女前顔拡大最大倍率
	float faceScaleF_MaxZ_09C;

	// 名前：QWCID
	// 説明：QWCのパラメタID
	int32_t qwcId_0A0;

	// 名前：装備モデル番号
	// 説明：装備モデルの番号.
	uint16_t equipModelId_0A4;

	// 名前：男用アイコンID
	// 説明：男用メニューアイコンID.
	uint16_t iconIdM_0A6;

	// 名前：女用アイコンID
	// 説明：女用メニューアイコンID.
	uint16_t iconIdF_0A8;

	// 名前：ノックバックカット率
	// 説明：ノックバックの減少値.
	uint16_t knockBack_0AA;

	// 名前：ノックバック反発率
	// 説明：ノックバックの反発率.
	uint16_t knockbackBounceRate_0AC;

	// 名前：耐久度
	// 説明：初期耐久度.
	uint16_t durability_0AE;

	// 名前：耐久度最大値
	// 説明：新品耐久度.
	uint16_t durabilityMax_0B0;

	// 名前：pad
	uint8_t pad03_0B2[2];

	// 名前：はじき防御力
	// 説明：敵の攻撃のはじき返し判定に利用.
	uint16_t defFlickPower_0B4;

	// 名前：物理防御力
	// 説明：物理攻撃のダメージ防御.
	uint16_t defensePhysics_0B6;

	// 名前：魔法防御力
	// 説明：魔法攻撃のダメージ防御.
	uint16_t defenseMagic_0B8;

	// 名前：炎防御力
	// 説明：炎攻撃のダメージ防御.
	uint16_t defenseFire_0BA;

	// 名前：電撃防御力
	// 説明：電撃攻撃のダメージ防御.
	uint16_t defenseThunder_0BC;

	// 名前：斬撃防御力
	// 説明：攻撃タイプを見て、斬撃属性のときは、防御力を減少させる
	int16_t defenseSlash_0BE;

	// 名前：打撃防御力
	// 説明：攻撃属性を見て、打撃属性のときは、防御力を減少させる.
	int16_t defenseBlow_0C0;

	// 名前：刺突防御力
	// 説明：攻撃属性を見て、打撃属性のときは、防御力を減少させる.
	int16_t defenseThrust_0C2;

	// 名前：毒耐性
	// 説明：毒状態異常へのかかりにくさ
	uint16_t resistPoison_0C4;

	// 名前：疫病耐性
	// 説明：疫病状態異常へのかかりにくさ
	uint16_t resistDisease_0C6;

	// 名前：出血耐性
	// 説明：出血状態異常へのかかりにくさ
	uint16_t resistBlood_0C8;

	// 名前：呪耐性
	// 説明：呪い状態異常へのかかりにくさ
	uint16_t resistCurse_0CA;

	// 名前：強化タイプID
	// 説明：強化タイプID
	int16_t reinforceTypeId_0CC;

	// 名前：トロフィー
	// 説明：トロフィーシステムに関係あるか？
	int16_t trophySGradeId_0CE;

	// 名前：ショップレベル
	// 説明：お店で販売できるレベル
	int16_t shopLv_0D0;

	// 名前：ノックバックパラメータID
	// 説明：ノックバックで使用するパラメータのID
	uint8_t knockbackParamId_0D2;

	// 名前：はじき時ダメージ減衰率[%]
	// 説明：はじき時のダメージ減衰率に使用
	uint8_t flickDamageCutRate_0D3;

	// 名前：装備モデル種別
	// 説明：装備モデルの種別.
	uint8_t equipModelCategory_0D4;

	// 名前：装備モデル性別
	// 説明：装備モデルの性別.
	uint8_t equipModelGender_0D5;

	// 名前：防具カテゴリ
	// 説明：防具のカテゴリ.
	uint8_t protectorCategory_0D6;

	// 名前：レア度
	// 説明：アイテム取得ログで使うレア度
	uint8_t rarity_0D7;

	// 名前：ソートアイテム種別ID
	// 説明：ソートアイテム種別ID。ソート「アイテム種別順」にて、同じIDは同じグループとしてまとめて表示されます
	uint8_t sortGroupId_0D8;

	// 名前：部位ダメージ適用攻撃
	// 説明：部位ダメージ判定を行う攻撃タイプを設定
	uint8_t partsDmgType_0D9;

	// 名前：パディング
	uint8_t pad04_0DA[2];

	// 名前：預けれるか
	// 説明：倉庫に預けれるか
	uint8_t isDeposit_0DC: 1;

	// 名前：頭装備
	// 説明：頭装備か.
	uint8_t headEquip_0DC: 1;

	// 名前：胴装備
	// 説明：胴装備か.
	uint8_t bodyEquip_0DC: 1;

	// 名前：腕装備
	// 説明：腕装備か.
	uint8_t armEquip_0DC: 1;

	// 名前：脚装備
	// 説明：脚装備か.
	uint8_t legEquip_0DC: 1;

	// 名前：顔スケールを使用するか
	// 説明：顔スケールを使用するか
	uint8_t useFaceScale_0DC: 1;

	// 名前：弱点アニメをスキップするか
	// 説明：弱点ダメージアニメ再生をスキップするかどうか。アニメを再生しないだけで「部位ダメージ率」「防御材質」は弱点として扱われます。
	uint8_t isSkipWeakDamageAnim_0DC: 1;

	// 名前：パディング
	uint8_t pad06_0DC: 1;

	// 名前：弱点防御材質バリエーション値
	// 説明：弱点防御材質と組み合わせて状態異常、ダメージSFX,SEのバリエーション分けに使用する値です。SEQ16473
	uint8_t defenseMaterialVariationValue_Weak_0DD;

	// 名前：フットデカール識別子2
	// 説明：自動フットエフェクトのデカールID。床材質も考慮される。防具カテゴリ」が「脚」のときのみ利用される。
	int16_t autoFootEffectDecalBaseId2_0DE;

	// 名前：フットデカール識別子3
	// 説明：自動フットエフェクトのデカールID。床材質も考慮される。防具カテゴリ」が「脚」のときのみ利用される。
	int16_t autoFootEffectDecalBaseId3_0E0;

	// 名前：防御材質バリエーション値
	// 説明：防御材質と組み合わせて状態異常、ダメージSFX,SEのバリエーション分けに使用する値です。SEQ16473
	uint8_t defenseMaterialVariationValue_0E2;

	// 名前：捨てれるか
	// 説明：アイテムを捨てれるか？TRUE=捨てれる
	uint8_t isDiscard_0E3: 1;

	// 名前：その場に置けるか
	// 説明：アイテムをその場に置けるか？TRUE=置ける
	uint8_t isDrop_0E3: 1;

	// 名前：マルチドロップ共有禁止か
	// 説明：マルチドロップ共有禁止か
	uint8_t disableMultiDropShare_0E3: 1;

	// 名前：DLC用シンプルモデルありか
	// 説明：ＤＬＣ用シンプルモデルが存在しているか
	uint8_t simpleModelForDlc_0E3: 1;

	// 名前：取得ログ表示条件
	// 説明：アイテム取得時にアイテム取得ログに表示するか（未入力: ○）
	uint8_t showLogCondType_0E3: 1;

	// 名前：取得ダイアログ表示条件
	// 説明：アイテム取得時にアイテム取得ダイアログに表示するか（未入力: newのみ）
	uint8_t showDialogCondType_0E3: 2;

	// 名前：パディング
	uint8_t pad_0E3: 1;

	// 名前：無属性ダメージ倍率
	// 説明：無属性ダメージ倍率
	float neutralDamageCutRate_0E4;

	// 名前：斬撃ダメージ倍率
	// 説明：斬撃ダメージ倍率
	float slashDamageCutRate_0E8;

	// 名前：打撃ダメージ倍率
	// 説明：打撃ダメージ倍率
	float blowDamageCutRate_0EC;

	// 名前：刺突ダメージ倍率
	// 説明：刺突ダメージ倍率
	float thrustDamageCutRate_0F0;

	// 名前：魔法ダメージ倍率
	// 説明：魔法ダメージ倍率
	float magicDamageCutRate_0F4;

	// 名前：火炎ダメージ倍率
	// 説明：火炎ダメージ倍率
	float fireDamageCutRate_0F8;

	// 名前：電撃ダメージ倍率
	// 説明：電撃ダメージ倍率
	float thunderDamageCutRate_0FC;

	// 名前：防御材質1【SFX】
	// 説明：移動/防御時のSFX用.1
	uint16_t defenseMaterialSfx1_100;

	// 名前：弱点防御材質1【SFX】
	// 説明：弱点部位ダメージ時のSFX用1
	uint16_t defenseMaterialSfx_Weak1_102;

	// 名前：防御材質1【SE】
	// 説明：移動/防御時のSE用.1
	uint16_t defenseMaterial1_104;

	// 名前：弱点防御材質1【SE】
	// 説明：弱点部位ダメージ時のSE用1
	uint16_t defenseMaterial_Weak1_106;

	// 名前：防御材質2【SFX】
	// 説明：移動/防御時のSFX用.2
	uint16_t defenseMaterialSfx2_108;

	// 名前：弱点防御材質2【SFX】
	// 説明：弱点部位ダメージ時のSFX用2
	uint16_t defenseMaterialSfx_Weak2_10A;

	// 名前：足装備材質【SE】
	// 説明：足装備SE用材質。足装備のみ参照される。(【GR】SEQ10061) 「139:なし」の場合は防御材質1【SE】が参照される
	uint16_t footMaterialSe_10C;

	// 名前：弱点防御材質2【SE】
	// 説明：弱点部位ダメージ時のSE用2
	uint16_t defenseMaterial_Weak2_10E;

	// 名前：フットデカール識別子1
	// 説明：自動フットエフェクトのデカールID。床材質も考慮される。防具カテゴリ」が「脚」のときのみ利用される。
	int32_t autoFootEffectDecalBaseId1_110;

	// 名前：強靭度 被ダメージ倍率
	// 説明：強靭度版カット率
	float toughnessDamageCutRate_114;

	// 名前：強靭度 回復時間補正値
	// 説明：強靭度の回復時間用の補正値
	float toughnessRecoverCorrection_118;

	// 名前：闇ダメージ倍率
	// 説明：闇ダメージ倍率
	float darkDamageCutRate_11C;

	// 名前：闇防御力
	// 説明：闇攻撃のダメージ防御.
	uint16_t defenseDark_120;

	// 名前：PAD_元_#48#非表示
	// 説明：元_#48#非表示
	uint8_t invisibleFlag48_122: 1;

	// 名前：PAD_元_#49#非表示
	// 説明：元_#49#非表示
	uint8_t invisibleFlag49_122: 1;

	// 名前：PAD_元_#50#非表示
	// 説明：元_#50#非表示
	uint8_t invisibleFlag50_122: 1;

	// 名前：PAD_元_#51#非表示
	// 説明：元_#51#非表示
	uint8_t invisibleFlag51_122: 1;

	// 名前：PAD_元_#52#非表示
	// 説明：元_#52#非表示
	uint8_t invisibleFlag52_122: 1;

	// 名前：PAD_元_#53#非表示
	// 説明：元_#53#非表示
	uint8_t invisibleFlag53_122: 1;

	// 名前：PAD_元_#54#非表示
	// 説明：元_#54#非表示
	uint8_t invisibleFlag54_122: 1;

	// 名前：PAD_元_#55#非表示
	// 説明：元_#55#非表示
	uint8_t invisibleFlag55_122: 1;

	// 名前：PAD_元_#56#非表示
	// 説明：元_#56#非表示
	uint8_t invisibleFlag56_123: 1;

	// 名前：PAD_元_#57#非表示
	// 説明：元_#57#非表示
	uint8_t invisibleFlag57_123: 1;

	// 名前：PAD_元_#58#非表示
	// 説明：元_#58#非表示
	uint8_t invisibleFlag58_123: 1;

	// 名前：PAD_元_#59#非表示
	// 説明：元_#59#非表示
	uint8_t invisibleFlag59_123: 1;

	// 名前：PAD_元_#60#非表示
	// 説明：元_#60#非表示
	uint8_t invisibleFlag60_123: 1;

	// 名前：PAD_元_#61#非表示
	// 説明：元_#61#非表示
	uint8_t invisibleFlag61_123: 1;

	// 名前：PAD_元_#62#非表示
	// 説明：元_#62#非表示
	uint8_t invisibleFlag62_123: 1;

	// 名前：PAD_元_#63#非表示
	// 説明：元_#63#非表示
	uint8_t invisibleFlag63_123: 1;

	// 名前：PAD_元_#64#非表示
	// 説明：元_#64#非表示
	uint8_t invisibleFlag64_124: 1;

	// 名前：PAD_元_#65#非表示
	// 説明：元_#65#非表示
	uint8_t invisibleFlag65_124: 1;

	// 名前：PAD_元_#66#非表示
	// 説明：元_#66#非表示
	uint8_t invisibleFlag66_124: 1;

	// 名前：PAD_元_#67#非表示
	// 説明：元_#67#非表示
	uint8_t invisibleFlag67_124: 1;

	// 名前：PAD_元_#68#非表示
	// 説明：元_#68#非表示
	uint8_t invisibleFlag68_124: 1;

	// 名前：PAD_元_#69#非表示
	// 説明：元_#69#非表示
	uint8_t invisibleFlag69_124: 1;

	// 名前：PAD_元_#70#非表示
	// 説明：元_#70#非表示
	uint8_t invisibleFlag70_124: 1;

	// 名前：PAD_元_#71#非表示
	// 説明：元_#71#非表示
	uint8_t invisibleFlag71_124: 1;

	// 名前：PAD_元_#72#非表示
	// 説明：元_#72#非表示
	uint8_t invisibleFlag72_125: 1;

	// 名前：PAD_元_#73#非表示
	// 説明：元_#73#非表示
	uint8_t invisibleFlag73_125: 1;

	// 名前：PAD_元_#74#非表示
	// 説明：元_#74#非表示
	uint8_t invisibleFlag74_125: 1;

	// 名前：PAD_元_#75#非表示
	// 説明：元_#75#非表示
	uint8_t invisibleFlag75_125: 1;

	// 名前：PAD_元_#76#非表示
	// 説明：元_#76#非表示
	uint8_t invisibleFlag76_125: 1;

	// 名前：PAD_元_#77#非表示
	// 説明：元_#77#非表示
	uint8_t invisibleFlag77_125: 1;

	// 名前：PAD_元_#78#非表示
	// 説明：元_#78#非表示
	uint8_t invisibleFlag78_125: 1;

	// 名前：PAD_元_#79#非表示
	// 説明：元_#79#非表示
	uint8_t invisibleFlag79_125: 1;

	// 名前：PAD_元_#80#非表示
	// 説明：元_#80#非表示
	uint8_t invisibleFlag80_126: 1;

	// 名前：パディング
	uint8_t padbit_126: 7;

	// 名前：姿勢制御ID(胴)
	// 説明：姿勢制御ID(胴)
	uint8_t postureControlId_127;

	// 名前：pad
	uint8_t pad2_128[4];

	// 名前：販売価格
	// 説明：販売価格
	int32_t saleValue_12C;

	// 名前：冷気耐性
	// 説明：冷気状態異常へのかかりにくさ
	uint16_t resistFreeze_130;

	// 名前：#00#非表示(男女指定)
	// 説明：前髪の先
	uint8_t invisibleFlag_SexVer00_132;

	// 名前：#01#非表示(男女指定)
	// 説明：前髪の根元
	uint8_t invisibleFlag_SexVer01_133;

	// 名前：#02#非表示(男女指定)
	// 説明：もみあげ
	uint8_t invisibleFlag_SexVer02_134;

	// 名前：#03#非表示(男女指定)
	// 説明：頭頂部
	uint8_t invisibleFlag_SexVer03_135;

	// 名前：#04#非表示(男女指定)
	// 説明：頭頂部
	uint8_t invisibleFlag_SexVer04_136;

	// 名前：#05#非表示(男女指定)
	// 説明：後ろ髪
	uint8_t invisibleFlag_SexVer05_137;

	// 名前：#06#非表示(男女指定)
	// 説明：後ろ髪の先
	uint8_t invisibleFlag_SexVer06_138;

	// 名前：#07#非表示(男女指定)
	uint8_t invisibleFlag_SexVer07_139;

	// 名前：#08#非表示(男女指定)
	uint8_t invisibleFlag_SexVer08_13A;

	// 名前：#09#非表示(男女指定)
	uint8_t invisibleFlag_SexVer09_13B;

	// 名前：#10#非表示(男女指定)
	// 説明：襟
	uint8_t invisibleFlag_SexVer10_13C;

	// 名前：#11#非表示(男女指定)
	// 説明：襟回り
	uint8_t invisibleFlag_SexVer11_13D;

	// 名前：#12#非表示(男女指定)
	uint8_t invisibleFlag_SexVer12_13E;

	// 名前：#13#非表示(男女指定)
	uint8_t invisibleFlag_SexVer13_13F;

	// 名前：#14#非表示(男女指定)
	uint8_t invisibleFlag_SexVer14_140;

	// 名前：#15#非表示(男女指定)
	// 説明：頭巾の裾
	uint8_t invisibleFlag_SexVer15_141;

	// 名前：#16#非表示(男女指定)
	uint8_t invisibleFlag_SexVer16_142;

	// 名前：#17#非表示(男女指定)
	uint8_t invisibleFlag_SexVer17_143;

	// 名前：#18#非表示(男女指定)
	uint8_t invisibleFlag_SexVer18_144;

	// 名前：#19#非表示(男女指定)
	uint8_t invisibleFlag_SexVer19_145;

	// 名前：#20#非表示(男女指定)
	// 説明：袖A
	uint8_t invisibleFlag_SexVer20_146;

	// 名前：#21#非表示(男女指定)
	// 説明：袖B
	uint8_t invisibleFlag_SexVer21_147;

	// 名前：#22#非表示(男女指定)
	uint8_t invisibleFlag_SexVer22_148;

	// 名前：#23#非表示(男女指定)
	uint8_t invisibleFlag_SexVer23_149;

	// 名前：#24#非表示(男女指定)
	uint8_t invisibleFlag_SexVer24_14A;

	// 名前：#25#非表示(男女指定)
	// 説明：腕
	uint8_t invisibleFlag_SexVer25_14B;

	// 名前：#26#非表示(男女指定)
	uint8_t invisibleFlag_SexVer26_14C;

	// 名前：#27#非表示(男女指定)
	uint8_t invisibleFlag_SexVer27_14D;

	// 名前：#28#非表示(男女指定)
	uint8_t invisibleFlag_SexVer28_14E;

	// 名前：#29#非表示(男女指定)
	uint8_t invisibleFlag_SexVer29_14F;

	// 名前：#30#非表示(男女指定)
	// 説明：ベルト
	uint8_t invisibleFlag_SexVer30_150;

	// 名前：#31#非表示(男女指定)
	uint8_t invisibleFlag_SexVer31_151;

	// 名前：#32#非表示(男女指定)
	uint8_t invisibleFlag_SexVer32_152;

	// 名前：#33#非表示(男女指定)
	uint8_t invisibleFlag_SexVer33_153;

	// 名前：#34#非表示(男女指定)
	uint8_t invisibleFlag_SexVer34_154;

	// 名前：#35#非表示(男女指定)
	uint8_t invisibleFlag_SexVer35_155;

	// 名前：#36#非表示(男女指定)
	uint8_t invisibleFlag_SexVer36_156;

	// 名前：#37#非表示(男女指定)
	uint8_t invisibleFlag_SexVer37_157;

	// 名前：#38#非表示(男女指定)
	uint8_t invisibleFlag_SexVer38_158;

	// 名前：#39#非表示(男女指定)
	uint8_t invisibleFlag_SexVer39_159;

	// 名前：#40#非表示(男女指定)
	uint8_t invisibleFlag_SexVer40_15A;

	// 名前：#41#非表示(男女指定)
	uint8_t invisibleFlag_SexVer41_15B;

	// 名前：#42#非表示(男女指定)
	uint8_t invisibleFlag_SexVer42_15C;

	// 名前：#43#非表示(男女指定)
	uint8_t invisibleFlag_SexVer43_15D;

	// 名前：#44#非表示(男女指定)
	uint8_t invisibleFlag_SexVer44_15E;

	// 名前：#45#非表示(男女指定)
	uint8_t invisibleFlag_SexVer45_15F;

	// 名前：#46#非表示(男女指定)
	uint8_t invisibleFlag_SexVer46_160;

	// 名前：#47#非表示(男女指定)
	uint8_t invisibleFlag_SexVer47_161;

	// 名前：#48#非表示(男女指定)
	uint8_t invisibleFlag_SexVer48_162;

	// 名前：#49#非表示(男女指定)
	uint8_t invisibleFlag_SexVer49_163;

	// 名前：#50#非表示(男女指定)
	uint8_t invisibleFlag_SexVer50_164;

	// 名前：#51#非表示(男女指定)
	uint8_t invisibleFlag_SexVer51_165;

	// 名前：#52#非表示(男女指定)
	uint8_t invisibleFlag_SexVer52_166;

	// 名前：#53#非表示(男女指定)
	uint8_t invisibleFlag_SexVer53_167;

	// 名前：#54#非表示(男女指定)
	uint8_t invisibleFlag_SexVer54_168;

	// 名前：#55#非表示(男女指定)
	uint8_t invisibleFlag_SexVer55_169;

	// 名前：#56#非表示(男女指定)
	uint8_t invisibleFlag_SexVer56_16A;

	// 名前：#57#非表示(男女指定)
	uint8_t invisibleFlag_SexVer57_16B;

	// 名前：#58#非表示(男女指定)
	uint8_t invisibleFlag_SexVer58_16C;

	// 名前：#59#非表示(男女指定)
	uint8_t invisibleFlag_SexVer59_16D;

	// 名前：#60#非表示(男女指定)
	uint8_t invisibleFlag_SexVer60_16E;

	// 名前：#61#非表示(男女指定)
	uint8_t invisibleFlag_SexVer61_16F;

	// 名前：#62#非表示(男女指定)
	uint8_t invisibleFlag_SexVer62_170;

	// 名前：#63#非表示(男女指定)
	uint8_t invisibleFlag_SexVer63_171;

	// 名前：#64#非表示(男女指定)
	uint8_t invisibleFlag_SexVer64_172;

	// 名前：#65#非表示(男女指定)
	uint8_t invisibleFlag_SexVer65_173;

	// 名前：#66#非表示(男女指定)
	uint8_t invisibleFlag_SexVer66_174;

	// 名前：#67#非表示(男女指定)
	uint8_t invisibleFlag_SexVer67_175;

	// 名前：#68#非表示(男女指定)
	uint8_t invisibleFlag_SexVer68_176;

	// 名前：#69#非表示(男女指定)
	uint8_t invisibleFlag_SexVer69_177;

	// 名前：#70#非表示(男女指定)
	uint8_t invisibleFlag_SexVer70_178;

	// 名前：#71#非表示(男女指定)
	uint8_t invisibleFlag_SexVer71_179;

	// 名前：#72#非表示(男女指定)
	uint8_t invisibleFlag_SexVer72_17A;

	// 名前：#73#非表示(男女指定)
	uint8_t invisibleFlag_SexVer73_17B;

	// 名前：#74#非表示(男女指定)
	uint8_t invisibleFlag_SexVer74_17C;

	// 名前：#75#非表示(男女指定)
	uint8_t invisibleFlag_SexVer75_17D;

	// 名前：#76#非表示(男女指定)
	uint8_t invisibleFlag_SexVer76_17E;

	// 名前：#77#非表示(男女指定)
	uint8_t invisibleFlag_SexVer77_17F;

	// 名前：#78#非表示(男女指定)
	uint8_t invisibleFlag_SexVer78_180;

	// 名前：#79#非表示(男女指定)
	uint8_t invisibleFlag_SexVer79_181;

	// 名前：#80#非表示(男女指定)
	uint8_t invisibleFlag_SexVer80_182;

	// 名前：#81#非表示(男女指定)
	uint8_t invisibleFlag_SexVer81_183;

	// 名前：#82#非表示(男女指定)
	uint8_t invisibleFlag_SexVer82_184;

	// 名前：#83#非表示(男女指定)
	uint8_t invisibleFlag_SexVer83_185;

	// 名前：#84#非表示(男女指定)
	uint8_t invisibleFlag_SexVer84_186;

	// 名前：#85#非表示(男女指定)
	uint8_t invisibleFlag_SexVer85_187;

	// 名前：#86#非表示(男女指定)
	uint8_t invisibleFlag_SexVer86_188;

	// 名前：#87#非表示(男女指定)
	uint8_t invisibleFlag_SexVer87_189;

	// 名前：#88#非表示(男女指定)
	uint8_t invisibleFlag_SexVer88_18A;

	// 名前：#89#非表示(男女指定)
	uint8_t invisibleFlag_SexVer89_18B;

	// 名前：#90#非表示(男女指定)
	uint8_t invisibleFlag_SexVer90_18C;

	// 名前：#91#非表示(男女指定)
	uint8_t invisibleFlag_SexVer91_18D;

	// 名前：#92#非表示(男女指定)
	uint8_t invisibleFlag_SexVer92_18E;

	// 名前：#93#非表示(男女指定)
	uint8_t invisibleFlag_SexVer93_18F;

	// 名前：#94#非表示(男女指定)
	uint8_t invisibleFlag_SexVer94_190;

	// 名前：#95#非表示(男女指定)
	uint8_t invisibleFlag_SexVer95_191;

	// 名前：パディング
	// 説明：パディング
	uint8_t pad404_192[14];

} EquipParamProtector;

#endif
