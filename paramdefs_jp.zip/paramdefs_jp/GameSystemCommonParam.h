/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_GameSystemCommonParam_H
#define _PARAM_GameSystemCommonParam_H
#include <stdint.h>

// GAME_SYSTEM_COMMON_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GameSystemCommonParam {

	// 名前：基本強靭度耐久値回復時間
	// 説明：強靭度回復時間の基本値です。（秒）
	float baseToughnessRecoverTime_000;

	// 名前：キャラのイベント旋回アニメーション（左90°）
	// 説明：「キャラの旋回」イベント用の左90°旋回アニメーションです。
	int32_t chrEventTrun_byLeft90_004;

	// 名前：キャラのイベント旋回アニメーション（右90°）
	// 説明：「キャラの旋回」イベント用の右90°旋回アニメーションです。
	int32_t chrEventTrun_byRight90_008;

	// 名前：キャラのイベント旋回アニメーション（左180°）
	// 説明：「キャラの旋回」イベント用の左180°旋回アニメーションです。
	int32_t chrEventTrun_byLeft180_00C;

	// 名前：キャラのイベント旋回アニメーション（右180°）
	// 説明：「キャラの旋回」イベント用の右180°旋回アニメーションです。
	int32_t chrEventTrun_byRight180_010;

	// 名前：キャラのイベント旋回90°アニメーション開始角度
	// 説明：「キャラの旋回」イベント用の90°旋回アニメーションを適用する角度の開始角度。この角度より小さい角度でイベントが始まった場合は、システム旋回が行われます
	int16_t chrEventTrun_90TurnStartAngle_014;

	// 名前：キャラのイベント旋回180°アニメーション開始角度
	// 説明：「キャラの旋回」イベント用の180°旋回アニメーションを適用する角度の開始角度。
	int16_t chrEventTrun_180TurnStartAngle_016;

	// 名前：ステルス攻撃被ダメージ倍率
	// 説明：ステルス攻撃被ダメージ倍率
	float stealthAtkDamageRate_018;

	// 名前：はじかれ時ガード成功時ダメージカット率
	// 説明：はじかれ時ガード成功時ダメージカット率。最終ダメージに乗算
	float flickDamageCutRateSuccessGurad_01C;

	// 名前：NPC会話のアニメ再生開始する差分角度
	// 説明：NPC会話の会話中モーションのアニメ再生開始する差分角度です。
	float npcTalkAnimBeginDiffAngle_020;

	// 名前：NPC会話のアニメ再生停止する差分角度
	// 説明：NPC会話の会話中モーションのアニメ再生停止する差分角度です。
	float npcTalkAnimEndDiffAngle_024;

	// 名前：ネムリアイテム取得範囲_アクションボタンパラID
	// 説明：ネムリアイテム取得範囲_アクションボタンパラID。TAEフラグ「イベント＞ネムリアイテム登録」で上書きしないときのデフォルト値として使われる。
	int32_t sleepCollectorItemActionButtonParamId_028;

	// 名前：バディアイテム許可_SFX発生間隔[s]
	// 説明：バディアイテム許可_SFX発生間隔[s]
	float allowUseBuddyItem_sfxInterval_02C;

	// 名前：バディアイテム許可_SFX発生PCダミポリID
	// 説明：バディアイテム許可_SFX発生PCダミポリID
	int32_t allowUseBuddyItem_sfxDmyPolyId_030;

	// 名前：バディアイテム許可_SFX発生馬ダミポリID_騎乗時
	// 説明：バディアイテム許可_SFX発生馬ダミポリID_騎乗時
	int32_t allowUseBuddyItem_sfxDmyPolyId_horse_034;

	// 名前：バディアイテム許可_発生SFXID
	// 説明：バディアイテム許可_発生SFXID
	int32_t allowUseBuddyItem_sfxId_038;

	// 名前：バディ召喚中_起動範囲内_SFX発生間隔[s]
	// 説明：バディ召喚中_起動範囲内_SFX発生間隔[s]
	float onBuddySummon_inActivateRange_sfxInterval_03C;

	// 名前：バディ召喚中_起動範囲内_SFX発生PCダミポリID
	// 説明：バディ召喚中_起動範囲内_SFX発生PCダミポリID
	int32_t onBuddySummon_inActivateRange_sfxDmyPolyId_040;

	// 名前：バディ召喚中_起動範囲内_SFX発生馬ダミポリID_騎乗時
	// 説明：バディ召喚中_起動範囲内_SFX発生馬ダミポリID_騎乗時
	int32_t onBuddySummon_inActivateRange_sfxDmyPolyId_horse_044;

	// 名前：バディ召喚中_起動範囲内_発生SFXID
	// 説明：バディ召喚中_起動範囲内_発生SFXID
	int32_t onBuddySummon_inActivateRange_sfxId_048;

	// 名前：バディ召喚中_起動範囲内特殊効果ID_PC用
	// 説明：バディ召喚中_起動範囲内特殊効果ID_PC用
	int32_t onBuddySummon_inActivateRange_spEffectId_pc_04C;

	// 名前：バディ召喚中_警告範囲内特殊効果ID_PC用
	// 説明：バディ召喚中_警告範囲内特殊効果ID_PC用
	int32_t onBuddySummon_inWarnRange_spEffectId_pc_050;

	// 名前：バディ召喚中_バディ帰還時特殊効果ID_PC用
	// 説明：バディ召喚中_バディ帰還時特殊効果ID_PC用
	int32_t onBuddySummon_atBuddyUnsummon_spEffectId_pc_054;

	// 名前：バディ召喚中_警告範囲内特殊効果ID_バディ用
	// 説明：バディ召喚中_警告範囲内特殊効果ID_バディ用
	int32_t onBuddySummon_inWarnRange_spEffectId_buddy_058;

	// 名前：朝のインゲーム時間（時）
	// 説明：朝のインゲーム時間（時）。会話で使用します。
	uint8_t morningIngameHour_05C;

	// 名前：朝のインゲーム時間（分）
	// 説明：朝のインゲーム時間（分）。会話で使用します。
	uint8_t morningIngameMinute_05D;

	// 名前：朝のインゲーム時間（秒）
	// 説明：朝のインゲーム時間（秒）。会話で使用します。
	uint8_t morningIngameSecond_05E;

	// 名前：昼のインゲーム時間（時）
	// 説明：昼のインゲーム時間（時）。会話で使用します。
	uint8_t noonIngameHour_05F;

	// 名前：昼のインゲーム時間（分）
	// 説明：昼のインゲーム時間（分）。会話で使用します。
	uint8_t noonIngameMinute_060;

	// 名前：昼のインゲーム時間（秒）
	// 説明：昼のインゲーム時間（秒）。会話で使用します。
	uint8_t noonIngameSecond_061;

	// 名前：夜のインゲーム時間（時）
	// 説明：夜のインゲーム時間（時）。会話で使用します。
	uint8_t nightIngameHour_062;

	// 名前：夜のインゲーム時間（分）
	// 説明：夜のインゲーム時間（分）。会話で使用します。
	uint8_t nightIngameMinute_063;

	// 名前：夜のインゲーム時間（秒）
	// 説明：夜のインゲーム時間（秒）。会話で使用します。
	uint8_t nightIngameSecond_064;

	// 名前：AI視界倍率_朝_開始時刻(時)
	// 説明：AI視界倍率_朝_開始時刻(時)
	uint8_t aiSightRateStart_Morning_Hour_065;

	// 名前：AI視界倍率_朝_開始時刻(分)
	// 説明：AI視界倍率_朝_開始時刻(分)
	uint8_t aiSightRateStart_Morning_Minute_066;

	// 名前：AI視界倍率_昼_開始時刻(時)
	// 説明：AI視界倍率_昼_開始時刻(時)
	uint8_t aiSightRateStart_Noon_Hour_067;

	// 名前：AI視界倍率_昼_開始時刻(分)
	// 説明：AI視界倍率_昼_開始時刻(分)
	uint8_t aiSightRateStart_Noon_Minute_068;

	// 名前：AI視界倍率_夕_開始時刻(時)
	// 説明：AI視界倍率_夕_開始時刻(時)
	uint8_t aiSightRateStart_Evening_Hour_069;

	// 名前：AI視界倍率_夕_開始時刻(分)
	// 説明：AI視界倍率_夕_開始時刻(分)
	uint8_t aiSightRateStart_Evening_Minute_06A;

	// 名前：AI視界倍率_夜_開始時刻(時)
	// 説明：AI視界倍率_夜_開始時刻(時)
	uint8_t aiSightRateStart_Night_Hour_06B;

	// 名前：AI視界倍率_夜_開始時刻(分)
	// 説明：AI視界倍率_夜_開始時刻(分)
	uint8_t aiSightRateStart_Night_Minute_06C;

	// 名前：AI視界倍率_深夜_開始時刻(時)
	// 説明：AI視界倍率_深夜_開始時刻(時)
	uint8_t aiSightRateStart_Midnight_Hour_06D;

	// 名前：AI視界倍率_深夜_開始時刻(分)
	// 説明：AI視界倍率_深夜_開始時刻(分)
	uint8_t aiSightRateStart_Midnight_Minute_06E;

	// 名前：SA大ダメージヒット演出SFX_発生条件SAダメージ閾値比率[％]
	// 説明：SA大ダメージヒット演出SFX_発生条件SAダメージ閾値比率[％]
	uint8_t saLargeDamageHitSfx_Threshold_06F;

	// 名前：SA大ダメージヒット演出SFX_SFXID
	// 説明：SA大ダメージヒット演出SFX_SFXID
	int32_t saLargeDamageHitSfx_SfxId_070;

	// 名前：安全位置から離れてサインを作成できる距離[m]
	// 説明：PCの最後の安全位置から離れてサインを作成できる距離[m]
	float signCreatableDistFromSafePos_074;

	// 名前：再召喚が発生するホストとゲストの距離[m]
	// 説明：再召喚が発生するホストとゲストの距離[m]
	float guestResummonDist_078;

	// 名前：ゲストがホストから離れそうになってることを通知する距離[m]
	// 説明：ゲストがホストから離れそうになってることを通知する距離[m]。この距離より離れたら通知する。
	float guestLeavingMessageDistMax_07C;

	// 名前：ゲストがホストから離れそうになってることを再通知可能にする距離[m]
	// 説明：ゲストがホストから離れそうになってることを再通知可能にする距離[m]。この距離より近づくまで再通知しない。
	float guestLeavingMessageDistMin_080;

	// 名前：ゲストがホストから離れられる最大距離[m] 
	// 説明：ゲストがホストから離れられる最大距離[m]。この距離より離れた状態で一定時間経過するとセッション脱退する。
	float guestLeaveSessionDist_084;

	// 名前：リトライエリア半径_デフォルト値(m)
	// 説明：リトライエリア半径_デフォルト値(m)。MapStudioのイベントタイプ「リトライポイント」で半径も領域も未設定の場合のデフォルト値として使われる。
	float retryPointAreaRadius_088;

	// 名前：ネムリアイテム取得可能時に発動する特殊効果ID
	// 説明：ネムリアイテム取得可能時に発動する特殊効果ID。TAEフラグ「イベント＞ネムリアイテム登録」で上書きしないときのデフォルト値として使われる。
	int32_t sleepCollectorSpEffectId_08C;

	// 名前：「HP最大以下で回復」特殊効果完了通知特殊効果ID
	// 説明：「HP最大以下で回復」が完了したことを通知する特殊効果のID。主にマルチの同期用に使われる。 
	int32_t recoverBelowMaxHpCompletionNoticeSpEffectId_090;

	// 名前：HPエスト吸収演出SFXID
	// 説明：侵入者撃破時などにHPエスト瓶の使用回数を回復する際の吸収演出SFXID
	int32_t estusFlaskRecovery_AbsorptionProductionSfxId_byHp_094;

	// 名前：MPエスト吸収演出SFXID
	// 説明：侵入者撃破時などにMPエスト瓶の使用回数を回復する際の吸収演出SFXID
	int32_t estusFlaskRecovery_AbsorptionProductionSfxId_byMp_098;

	// 名前：復活特殊効果発動判定用特殊効果ID
	// 説明：復活特殊効果が発動したことを通知する特殊効果のID。主にマルチの同期用に使われる。 
	int32_t respawnSpecialEffectActiveCheckerSpEffectId_09C;

	// 名前：バディ召喚中_起動範囲内特殊効果ID_バディ用
	// 説明：バディ召喚中_起動範囲内特殊効果ID_バディ用
	int32_t onBuddySummon_inActivateRange_spEffectId_buddy_0A0;

	// 名前：エスト吸収SFX再生開始からエスト追加処理を行うまでの時間
	// 説明：エスト吸収SFX再生開始からエスト追加処理を行うまでの時間
	float estusFlaskRecovery_AddEstusTime_0A4;

	// 名前：マルチ時エネミー撃破時取得ソウル補正値_ホスト
	// 説明：マルチプレイで通常敵を撃破した時のホストの取得ソウル量の補正値
	float defeatMultiModeEnemyOfSoulCorrectRate_byHost_0A8;

	// 名前：マルチ時エネミー撃破時取得ソウル補正値_協力霊
	// 説明：マルチプレイで通常敵を撃破した時の協力霊の取得ソウル量の補正値
	float defeatMultiModeEnemyOfSoulCorrectRate_byTeamGhost_0AC;

	// 名前：マルチ時ボス撃破時取得ソウル補正値_ホスト
	// 説明：マルチプレイでボスを撃破した時のホストの取得ソウル量の補正値
	float defeatMultiModeBossOfSoulCorrectRate_byHost_0B0;

	// 名前：マルチ時ボス撃破時取得ソウル補正値_協力霊
	// 説明：マルチプレイでボスを撃破した時の協力霊の取得ソウル量の補正値
	float defeatMultiModeBossOfSoulCorrectRate_byTeamGhost_0B4;

	// 名前：敵キャラのHPゲージが画面上に見切れないようにするためのオフセット
	// 説明：敵のHPゲージが画面上に見切れた時に画面内に収めるオフセット値[pixel]（FullHD基準）
	uint16_t enemyHpGaugeScreenOffset_byUp_0B8;

	// 名前：プレイ領域収集半径
	// 説明：PC周辺のプレイ領域の収集半径
	uint16_t playRegionCollectDist_0BA;

	// 名前：「敵探知」時弾丸発射位置ダミポリID
	// 説明：探知弾丸の発射位置ダミポリID
	uint16_t enemyDetectionSpEffect_ShootBulletDummypolyId_0BC;

	// 名前：大ルーン：グレーターデーモン侵入時付与道具個数
	// 説明：大ルーン：グレーターデーモン侵入時付与道具個数
	uint16_t bigRuneGreaterDemonBreakInGoodsNum_0BE;

	// 名前：大ルーン：グレーターデーモン侵入時付与道具アイテムID
	// 説明：大ルーン：グレーターデーモン侵入時付与道具アイテムID
	int32_t bigRuneGreaterDemonBreakInGoodsId_0C0;

	// 名前：大ジャンプ領域SFXID
	// 説明：騎乗大ジャンプ領域のSFXID
	int32_t rideJumpRegionDefaultSfxId_0C4;

	// 名前：共通_騎乗特攻倍率
	// 説明：騎乗特攻時に補正する倍率
	float saAttackRate_forVsRideAtk_0C8;

	// 名前：ネムリアイテム抽選時に敵側にかかる特殊効果
	// 説明：ネムリアイテム抽選時に敵側にかかる特殊効果
	int32_t enemySpEffectIdAfterSleepCollectorItemLot_0CC;

	// 名前：周回保留時マップUID
	// 説明：周回保留時マップUID、8桁で入力（例…m60_42_36_00 -> 60423600）
	int32_t afterEndingMapUid_0D0;

	// 名前：周回保留時復帰ポイント
	// 説明：周回保留時復帰ポイントのエンティティID
	uint32_t afterEndingReturnPointEntityId_0D4;

	// 名前：「敵探知」時発射弾丸ID_協力指輪_赤狩り
	// 説明：敵の勢力/タイプによって飛ばす弾丸のID(マルチ自動発射でも使う)
	int32_t enemyDetectionSpEffect_BulletId_byCoopRing_RedHunter_0D8;

	// 名前：「敵探知」時発射弾丸ID_侵入オーブ_なし
	// 説明：敵の勢力/タイプによって飛ばす弾丸のID(マルチ自動発射でも使う)
	int32_t enemyDetectionSpEffect_BulletId_byInvadeOrb_None_0DC;

	// 名前：チュートリアル判定用：遠見台にアクセスした時にONにするイベントフラグ
	// 説明：チュートリアル判定用：遠見台にアクセスした時にONにするイベントフラグ
	uint32_t tutorialFlagOnAccessDistView_0E0;

	// 名前：チュートリアル判定用：リトライポイントにアクセスした時にONにするイベントフラグ
	// 説明：チュートリアル判定用：リトライポイントにアクセスした時にONにするイベントフラグ
	uint32_t tutorialFlagOnAccessRetryPoint_0E4;

	// 名前：チュートリアル判定用：集団を倒してグループ報酬が入った時にONにするイベントフラグ
	// 説明：チュートリアル判定用：集団を倒してグループ報酬が入った時にONにするイベントフラグ
	uint32_t tutorialFlagOnGetGroupReward_0E8;

	// 名前：チュートリアル判定用：騎乗大ジャンプポイントに入った時にONにするイベントフラグ
	// 説明：チュートリアル判定用：騎乗大ジャンプポイントに入った時にONにするイベントフラグ
	uint32_t tutorialFlagOnEnterRideJumpRegion_0EC;

	// 名前：チュートリアル判定用：騎乗大ジャンプポイントを○[m]拡張して内外判定
	// 説明：チュートリアル判定用：騎乗大ジャンプポイントを○[m]拡張して内外判定。○[m]の値をここに設定する。
	float tutorialCheckRideJumpRegionExpandRange_0F0;

	// 名前：リトライポイント起動時のPCアニメID
	// 説明：リトライポイント起動時のPCアニメID。-1の場合は再生しない。
	int32_t retryPointActivatedPcAnimId_0F4;

	// 名前：リトライポイント起動時のダイアログ表示の遅延時間[秒]
	// 説明：リトライポイント起動時のダイアログ表示の遅延時間[秒]
	float retryPointActivatedDialogDelayTime_0F8;

	// 名前：リトライポイント起動時のダイアログのテキストID
	// 説明：リトライポイント起動時のダイアログのテキストID。EventText_ForMap.xlsm のテキストを設定する。-1の場合はダイアログを出さない。
	int32_t retryPointActivatedDialogTextId_0FC;

	// 名前：サイン溜まり起動時のPCアニメID
	// 説明：サイン溜まり起動時のPCアニメID。-1の場合は再生しない。
	int32_t signPuddleOpenPcAnimId_100;

	// 名前：サイン溜まり起動時のダイアログ表示の遅延時間[秒]
	// 説明：サイン溜まり起動時のダイアログ表示の遅延時間[秒]
	float signPuddleOpenDialogDelayTime_104;

	// 名前：「死者の活性」特殊効果発動時弾丸ID
	// 説明：「死者の活性」特殊効果が発動したときに発射する弾丸ID
	int32_t activityOfDeadSpEffect_BulletId_108;

	// 名前：「死者の活性」特殊効果発動時弾丸発生位置ダミポリID
	// 説明：「死者の活性」特殊効果が発動したときに弾丸が発生する位置のダミポリID
	int32_t activityOfDeadSpEffect_ShootBulletDummypolyId_10C;

	// 名前：「死者の活性」特殊効果発動時の死体のフェードアウト時間
	// 説明：「死者の活性」特殊効果が発動したときに死体がフェードアウトする際のフェード時間
	float activityOfDeadSpEffect_DeadFadeOutTime_110;

	// 名前：投げ開始時のネットワーク情報による遷移を無視する時間
	// 説明：投げ開始時のネットワーク情報による遷移を無視する時間
	float ignorNetStateSyncTime_ForThrow_114;

	// 名前：マルチプレペナルティ：LAN切断
	// 説明：マルチプレペナルティ：LAN切断
	uint16_t netPenaltyPointLanDisconnect_118;

	// 名前：マルチプレペナルティ：プロフィールサインアウト
	// 説明：マルチプレペナルティ：プロフィールサインアウト
	uint16_t netPenaltyPointProfileSignout_11A;

	// 名前：マルチプレペナルティ：電源断
	// 説明：マルチプレペナルティ：電源断
	uint16_t netPenaltyPointReboot_11C;

	// 名前：マルチプレペナルティ：サスペンド・一時停止
	// 説明：マルチプレペナルティ：サスペンド・一時停止
	uint16_t netPnaltyPointSuspend_11E;

	// 名前：マルチプレペナルティ：理の骨の生成（販売）開始待ち時間
	// 説明：マルチプレペナルティ：理の骨の生成（販売）開始待ち時間(秒)
	float netPenaltyForgiveItemLimitTime_120;

	// 名前：マルチプレペナルティ：ペナルティ判定ポイント
	// 説明：マルチプレペナルティ：ペナルティ判定ポイント
	uint16_t netPenaltyPointThreshold_124;

	// 名前：未操作判定時間
	// 説明：マルチで一定期間操作ない人を退出させるためのもの。単位は秒。
	uint16_t uncontrolledMoveThresholdTime_126;

	// 名前：「敵探知」時発射弾丸ID_敵対NPC/敵キャラ
	// 説明：敵意の探知に失敗したときに敵対NPC/敵キャラに飛ばす弾丸のID
	int32_t enemyDetectionSpEffect_BulletId_byNpcEnemy_128;

	// 名前：「死者の活性ターゲット検索」対象にかける特殊効果ID 
	// 説明：検索した対象にかける特殊効果
	int32_t activityOfDeadTargetSearchSpEffect_OnHitSpEffect_12C;

	// 名前：「死者の活性ターゲット検索」距離 
	// 説明：検索可能最大距離
	float activityOfDeadTargetSearchSpEffect_MaxLength_130;

	// 名前：視界_最低保証距離[倍率換算]
	// 説明：視界_最低保証距離[倍率換算]
	float sightRangeLowerPromiseRate_134;

	// 名前：SA大ダメージヒット演出SFX_発生条件SAダメージ必要最低値[pt]
	// 説明：SA大ダメージヒット演出SFX_発生条件SAダメージ必要最低値[pt]
	int16_t saLargeDamageHitSfx_MinDamage_138;

	// 名前：SA大ダメージヒット演出SFX_発生条件SAダメージ強制発生最低値[pt]
	// 説明：SA大ダメージヒット演出SFX_発生条件SAダメージ強制発生最低値[pt]
	int16_t saLargeDamageHitSfx_ForceDamage_13A;

	// 名前：ソロ侵入最大ポイント
	// 説明：ソロ侵入ポイントの最大値。この値を越えたときにソロで侵入されるようになる
	uint32_t soloBreakInMaxPoint_13C;

	// 名前：NPC会話のボイス再生タイムアウト時間
	// 説明：NPC会話のボイス再生タイムアウト時間。この時間経過してもボイス再生が終わらない場合は次のメッセージへ進む
	float npcTalkTimeOutThreshold_140;

	// 名前：プレイログの送信間隔
	// 説明：アイテム使用ログ などをサーバーへ送信する間隔
	float sendPlayLogIntervalTime_144;

	// 名前：七色石の最大設置数
	// 説明：七色石の最大設置数
	uint8_t item370_MaxSfxNum_148;

	// 名前：キャラディアクティベート中にアクティベート許可する距離[m]
	// 説明：キャラディアクティベート中にアクティベート許可する距離（オープン配置キャラのみ有効）
	uint8_t chrActivateDist_forLeavePC_149;

	// 名前：マルチ弱体化レベル補正係数１
	// 説明：マルチ時ステータス弱体化。ホストのレベル加算補正
	int16_t summonDataCoopMatchingLevelUpperAbs_14A;

	// 名前：マルチ弱体化レベル補正係数２
	// 説明：マルチ時ステータス弱体化。ホストのレベル倍率補正
	int16_t summonDataCoopMatchingLevelUpperRel_14C;

	// 名前：マルチ弱体化最大武器補正係数
	// 説明：マルチ時ステータス弱体化。最大武器強化レベル補正
	int16_t summonDataCoopMatchingWepLevelMul_14E;

	// 名前：バーサーカーサインを拾った時のまたたび効果用弾丸ID
	// 説明：サイン位置に特殊効果用の弾丸を発生させる際の弾丸ID
	int32_t pickUpBerserkerSignSpEffectBulletId_150;

	// 名前：バーサーカーがPC自力殺害に成功演出用特殊効果ID
	// 説明：バーサーカーがPC自力殺害に成功した際に専用の演出を再生する特殊効果
	int32_t succeedBerserkerSelfKillingEffectId_154;

	// 名前：レベルシンク適用判定係数１白
	// 説明：レベルシンク適用するかどうかのソウルレベル係数
	uint8_t machingLevelWhiteSignUpperRel_158;

	// 名前：レベルシンク適用判定係数２白
	// 説明：レベルシンク適用するかどうかのソウルレベル係数
	uint8_t machingLevelWhiteSignUpperAbs_159;

	// 名前：レベルシンク適用判定係数１赤
	// 説明：レベルシンク適用するかどうかのソウルレベル係数
	uint8_t machingLevelRedSignUpperRel_15A;

	// 名前：レベルシンク適用判定係数２赤
	// 説明：レベルシンク適用するかどうかのソウルレベル係数
	uint8_t machingLevelRedSignUpperAbs_15B;

	// 名前：レベルシンク適用判定最大武器強化レベル係数０白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_0_15C;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_1_15D;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_2_15E;

	// 名前：レベルシンク適用判定最大武器強化レベル係数３白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_3_15F;

	// 名前：レベルシンク適用判定最大武器強化レベル係数４白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_4_160;

	// 名前：レベルシンク適用判定最大武器強化レベル係数５白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_5_161;

	// 名前：レベルシンク適用判定最大武器強化レベル係数６白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_6_162;

	// 名前：レベルシンク適用判定最大武器強化レベル係数７白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_7_163;

	// 名前：レベルシンク適用判定最大武器強化レベル係数８白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_8_164;

	// 名前：レベルシンク適用判定最大武器強化レベル係数９白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_9_165;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１０白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_10_166;

	// 名前：レベルシンク適用判定最大武器強化レベル係数０赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_0_167;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_1_168;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_2_169;

	// 名前：レベルシンク適用判定最大武器強化レベル係数３赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_3_16A;

	// 名前：レベルシンク適用判定最大武器強化レベル係数４赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_4_16B;

	// 名前：レベルシンク適用判定最大武器強化レベル係数５赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_5_16C;

	// 名前：レベルシンク適用判定最大武器強化レベル係数６赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_6_16D;

	// 名前：レベルシンク適用判定最大武器強化レベル係数７赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_7_16E;

	// 名前：レベルシンク適用判定最大武器強化レベル係数８赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_8_16F;

	// 名前：レベルシンク適用判定最大武器強化レベル係数９赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_9_170;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１０赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_10_171;

	// 名前：侵入ポイントの自動配置間隔
	// 説明：侵入ポイントの自動配置間隔
	uint8_t autoInvadePoint_generateDist_172;

	// 名前：侵入ポイント自動配置取り消し範囲
	// 説明：侵入ポイント自動配置取り消し範囲
	uint8_t autoInvadePoint_cancelDist_173;

	// 名前：グローバルイベントログの送信間隔
	// 説明：グローバルイベントログ をサーバーへ送信する間隔
	float sendGlobalEventLogIntervalTime_174;

	// 名前：ソロ侵入ポイント加算値_白サイン
	// 説明：ソロ侵入ポイント加算値_白サイン
	uint16_t addSoloBreakInPoint_White_178;

	// 名前：ソロ侵入ポイント加算値_赤サイン
	// 説明：ソロ侵入ポイント加算値_赤サイン
	uint16_t addSoloBreakInPoint_Black_17A;

	// 名前：ソロ侵入ポイント加算値_乱入
	// 説明：ソロ侵入ポイント加算値_乱入
	uint16_t addSoloBreakInPoint_ForceJoin_17C;

	// 名前：ソロ侵入ポイント加算値_マップ守護訪問
	// 説明：ソロ侵入ポイント加算値_マップ守護訪問
	uint16_t addSoloBreakInPoint_VisitorGuardian_17E;

	// 名前：ソロ侵入ポイント加算値_赤狩り訪問
	// 説明：ソロ侵入ポイント加算値_赤狩り訪問
	uint16_t addSoloBreakInPoint_VisitorRedHunter_180;

	// 名前：初期同期PC用の無敵タイマー
	// 説明：初期同期PC用の無敵タイマー
	uint8_t invincibleTimer_forNetPC_initSync_182;

	// 名前：初期同期PC以外用の無敵タイマー
	// 説明：初期同期PC以外用の無敵タイマー
	uint8_t invincibleTimer_forNetPC_183;

	// 名前：【赤狩り】ホストが白扉を通過した際にもらえるソウル率
	// 説明：ホストが白扉を通過した時に赤狩りがもらえるソウル=赤狩りが一つ前のLvから現在Lvになるために必要なソウル*この倍率
	float redHunter_HostBossAreaGetSoulRate_184;

	// 名前：徘徊幻影の痕跡のデカールパラメータID
	// 説明：徘徊幻影が移動中に出す痕跡のデカールパラメータID
	int32_t ghostFootprintDecalParamId_188;

	// 名前：マルチプレイ制限距離外の警告メッセージ表示のカウント時間[秒]
	// 説明：マルチプレイ制限距離外に出たままこのカウント時間経過したらマルチプレイの解散を行う
	float leaveAroundHostWarningTime_18C;

	// 名前：ホスト化コストアイテムID
	// 説明：ホスト化をONにした際に消費するコストアイテムのID
	int32_t hostModeCostItemId_190;

	// 名前：AIジャンプ減速パラメータ
	// 説明：AIジャンプ用減速パラメータ(0.0：等速運動、1.0：最大減速、目標地点で速度0)
	float aIJump_DecelerateParam_194;

	// 名前：バディインスタンス削除保証時間
	// 説明：死亡フラグから実際にインスタンスが消滅するまでの時間
	float buddyDisappearDelaySec_198;

	// 名前：AIジャンプ飛び降り時Y移動量補正率
	// 説明：AIジャンプ飛び降り時Y移動量補正率
	float aIJump_AnimYMoveCorrectRate_onJumpOff_19C;

	// 名前：ステルス視界倍率_ステルス効果無しでしゃがみ
	// 説明：ステルス視界倍率_ステルス効果無しでしゃがみ
	float stealthSystemSightRate_NotInStealthRigid_NotSightHide_StealthMode_1A0;

	// 名前：ステルス視界倍率_ステルスレイ遮蔽地帯で立ち
	// 説明：ステルス視界倍率_ステルスレイ遮蔽地帯で立ち
	float stealthSystemSightRate_NotInStealthRigid_SightHide_NotStealthMode_1A4;

	// 名前：ステルス視界倍率_ステルスレイ遮蔽地帯でしゃがみ
	// 説明：ステルス視界倍率_ステルスレイ遮蔽地帯でしゃがみ
	float stealthSystemSightRate_NotInStealthRigid_SightHide_StealthMode_1A8;

	// 名前：ステルス視界倍率_ステルスヒット内で立ち
	// 説明：ステルス視界倍率_ステルスヒット内で立ち
	float stealthSystemSightRate_InStealthRigid_NotSightHide_NotStealthMode_1AC;

	// 名前：ステルス視界倍率_ステルスヒット内でしゃがみ
	// 説明：ステルス視界倍率_ステルスヒット内でしゃがみ
	float stealthSystemSightRate_InStealthRigid_NotSightHide_StealthMode_1B0;

	// 名前：ステルス視界倍率_ステルスレイ遮蔽地帯＋ステルスヒット内で立ち
	// 説明：ステルス視界倍率_ステルスレイ遮蔽地帯＋ステルスヒット内で立ち
	float stealthSystemSightRate_InStealthRigid_SightHide_NotStealthMode_1B4;

	// 名前：ステルス視界倍率_ステルスレイ遮蔽地帯＋ステルスヒット内でしゃがみ
	// 説明：ステルス視界倍率_ステルスレイ遮蔽地帯＋ステルスヒット内でしゃがみ
	float stealthSystemSightRate_InStealthRigid_SightHide_StealthMode_1B8;

	// 名前：宝死体のデフォルトアクションボタンパラメータID
	// 説明：MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「宝死体」を選択したときのデフォルトアクションボタンパラメータID
	int32_t msbEventGeomTreasureInfo_actionButtonParamId_corpse_1BC;

	// 名前：宝死体のデフォルトアイテム取得時アニメID
	// 説明：MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「宝死体」を選択したときのデフォルトアイテム取得時アニメID
	int32_t msbEventGeomTreasureInfo_itemGetAnimId_corpse_1C0;

	// 名前：宝箱のデフォルトアクションボタンパラメータID
	// 説明：MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「宝箱」を選択したときのデフォルトアクションボタンパラメータID
	int32_t msbEventGeomTreasureInfo_actionButtonParamId_box_1C4;

	// 名前：宝箱のデフォルトアイテム取得時アニメID
	// 説明：MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「宝箱」を選択したときのデフォルトアイテム取得時アニメID
	int32_t msbEventGeomTreasureInfo_itemGetAnimId_box_1C8;

	// 名前：アイテム光のデフォルトアクションボタンパラメータID
	// 説明：MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「アイテム光」を選択したときのデフォルトアクションボタンパラメータID
	int32_t msbEventGeomTreasureInfo_actionButtonParamId_shine_1CC;

	// 名前：アイテム光のデフォルトアイテム取得時アニメID
	// 説明：MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「アイテム光」を選択したときのデフォルトアイテム取得時アニメID
	int32_t msbEventGeomTreasureInfo_itemGetAnimId_shine_1D0;

	// 名前：サイン溜まり：アセットID
	// 説明：サイン溜まりに使うアセット
	int32_t signPuddleAssetId_1D4;

	// 名前：サイン溜まり：サイン出現ダミポリ0
	// 説明：サイン溜まりのサインの表示位置を決定するのに使うダミポリ
	int32_t signPuddleAppearDmypolyId0_1D8;

	// 名前：サイン溜まり：サイン出現ダミポリ1
	// 説明：サイン溜まりのサインの表示位置を決定するのに使うダミポリ
	int32_t signPuddleAppearDmypolyId1_1DC;

	// 名前：サイン溜まり：サイン出現ダミポリ2
	// 説明：サイン溜まりのサインの表示位置を決定するのに使うダミポリ
	int32_t signPuddleAppearDmypolyId2_1E0;

	// 名前：サイン溜まり：サイン出現ダミポリ3
	// 説明：サイン溜まりのサインの表示位置を決定するのに使うダミポリ
	int32_t signPuddleAppearDmypolyId3_1E4;

	// 名前：騎乗者の落下ダメージ倍率補正_PC用
	// 説明：騎乗者の落下ダメージ倍率補正_PC用
	float fallDamageRate_forRidePC_1E8;

	// 名前：騎乗者の落下ダメージ倍率補正_NPC用
	// 説明：騎乗者の落下ダメージ倍率補正_NPC用
	float fallDamageRate_forRideNPC_1EC;

	// 名前：黄衣の翁サイン作成時特殊効果ID
	// 説明：黄衣の翁サイン作成時特殊効果ID
	int32_t OldMonkOfYellow_CreateSignSpEffectId_1F0;

	// 名前：敗残兵起動距離
	// 説明：敗残兵起動距離
	float StragglerActivateDist_1F4;

	// 名前：敗残兵アイテム使用許可_PC用特殊効果
	// 説明：敗残兵アイテム使用許可_PC用特殊効果
	int32_t SpEffectId_EnableUseItem_StragglerActivate_1F8;

	// 名前：敗残兵起動_敗残兵キャラ用特殊効果
	// 説明：敗残兵起動_敗残兵キャラ用特殊効果
	int32_t SpEffectId_StragglerWakeUp_1FC;

	// 名前：敗残兵_討伐対象用特殊効果
	// 説明：敗残兵_討伐対象用特殊効果
	int32_t SpEffectId_StragglerTarget_200;

	// 名前：敗残兵_敵対後特殊効果
	// 説明：敗残兵_敵対後特殊効果
	int32_t SpEffectId_StragglerOppose_204;

	// 名前：レイ遮断でバディがプレイヤーにワープする時間[s]
	// 説明：レイ遮断でバディがプレイヤーにワープする時間[s]
	float buddyWarp_TriggerTimeRayBlocked_208;

	// 名前：直線距離でバディがプレイヤーにワープする距離[m]
	// 説明：直線距離でバディがプレイヤーにワープする距離[m]
	float buddyWarp_TriggerDistToPlayer_20C;

	// 名前：バディがパス移動で詰まった判定する時間[s]
	// 説明：バディがパス移動で詰まった判定する時間[s]
	float buddyWarp_ThresholdTimePathStacked_210;

	// 名前：バディがパス移動で詰まっているとみなす距離[m]
	// 説明：バディがパス移動で詰まっているとみなす距離[m]
	float buddyWarp_ThresholdRangePathStacked_214;

	// 名前：[朝]AI視界倍率
	// 説明：[朝]AI視界倍率
	float aiSightRate_morning_218;

	// 名前：[昼]AI視界倍率
	// 説明：[昼]AI視界倍率
	float aiSightRate_noonA_21C;

	// 名前：バディとプレイヤーがぶつかって、すり抜け始める時間[s]
	// 説明：バディとプレイヤーがぶつかって、すり抜け始める時間[s]
	float buddyPassThroughTriggerTime_220;

	// 名前：[夕]AI視界倍率
	// 説明：[夕]AI視界倍率
	float aiSightRate_evening_224;

	// 名前：[夜]AI視界倍率
	// 説明：[夜]AI視界倍率
	float aiSightRate_night_228;

	// 名前：[深夜]AI視界倍率
	// 説明：[深夜]AI視界倍率
	float aiSightRate_midnightA_22C;

	// 名前：リザーブ
	// 説明：(dummy8)
	uint8_t reserve4_2_230[4];

	// 名前：AI視界倍率_太陽が見えない場所(明るい)
	// 説明：AI視界倍率_太陽が見えない場所(明るい)
	float aiSightRate_sunloss_light_234;

	// 名前：AI視界倍率_太陽が見えない場所(暗闇)
	// 説明：AI視界倍率_太陽が見えない場所(暗闇)
	float aiSightRate_sunloss_dark_238;

	// 名前：AI視界倍率_太陽が見えない場所(真っ暗闇)
	// 説明：AI視界倍率_太陽が見えない場所(真っ暗闇)
	float aiSightRate_sunloss_veryDark_23C;

	// 名前：ステルス視界角度減衰率_ステルス効果無しでしゃがみ
	// 説明：ステルス視界角度減衰率_ステルス効果無しでしゃがみ
	float stealthSystemSightAngleReduceRate_NotInStealthRigid_NotSightHide_StealthMode_240;

	// 名前：ステルス視界角度減衰率_ステルスレイ遮蔽地帯で立ち
	// 説明：ステルス視界角度減衰率_ステルスレイ遮蔽地帯で立ち
	float stealthSystemSightAngleReduceRate_NotInStealthRigid_SightHide_NotStealthMode_244;

	// 名前：ステルス視界角度減衰率_ステルスレイ遮蔽地帯でしゃがみ
	// 説明：ステルス視界角度減衰率_ステルスレイ遮蔽地帯でしゃがみ
	float stealthSystemSightAngleReduceRate_NotInStealthRigid_SightHide_StealthMode_248;

	// 名前：ステルス視界角度減衰率_ステルスヒット内で立ち
	// 説明：ステルス視界角度減衰率_ステルスヒット内で立ち
	float stealthSystemSightAngleReduceRate_InStealthRigid_NotSightHide_NotStealthMode_24C;

	// 名前：ステルス視界角度減衰率_ステルスヒット内でしゃがみ
	// 説明：ステルス視界角度減衰率_ステルスヒット内でしゃがみ
	float stealthSystemSightAngleReduceRate_InStealthRigid_NotSightHide_StealthMode_250;

	// 名前：ステルス視界角度減衰率_ステルスレイ遮蔽地帯＋ステルスヒット内で立ち
	// 説明：ステルス視界角度減衰率_ステルスレイ遮蔽地帯＋ステルスヒット内で立ち
	float stealthSystemSightAngleReduceRate_InStealthRigid_SightHide_NotStealthMode_254;

	// 名前：ステルス視界角度減衰率_ステルスレイ遮蔽地帯＋ステルスヒット内でしゃがみ
	// 説明：ステルス視界角度減衰率_ステルスレイ遮蔽地帯＋ステルスヒット内でしゃがみ
	float stealthSystemSightAngleReduceRate_InStealthRigid_SightHide_StealthMode_258;

	// 名前：天候抽選条件_朝_開始時刻_時
	// 説明：天候抽選条件_朝_開始時刻_時(SEQ09371)
	uint8_t weatherLotConditionStart_Morning_Hour_25C;

	// 名前：天候抽選条件_朝_開始時刻_分
	// 説明：天候抽選条件_朝_開始時刻_分(SEQ09371)
	uint8_t weatherLotConditionStart_Morning_Minute_25D;

	// 名前：天候抽選条件_昼_開始時刻_時
	// 説明：天候抽選条件_昼_開始時刻_時(SEQ09371)
	uint8_t weatherLotConditionStart_Day_Hour_25E;

	// 名前：天候抽選条件_昼_開始時刻_分
	// 説明：天候抽選条件_昼_開始時刻_分(SEQ09371)
	uint8_t weatherLotConditionStart_Day_Minute_25F;

	// 名前：天候抽選条件_夕_開始時刻_時
	// 説明：天候抽選条件_夕_開始時刻_時(SEQ09371)
	uint8_t weatherLotConditionStart_Evening_Hour_260;

	// 名前：天候抽選条件_夕_開始時刻_分
	// 説明：天候抽選条件_夕_開始時刻_分(SEQ09371)
	uint8_t weatherLotConditionStart_Evening_Minute_261;

	// 名前：天候抽選条件_夜_開始時刻_時
	// 説明：天候抽選条件_夜_開始時刻_時(SEQ09371)
	uint8_t weatherLotConditionStart_Night_Hour_262;

	// 名前：天候抽選条件_夜_開始時刻_分
	// 説明：天候抽選条件_夜_開始時刻_分(SEQ09371)
	uint8_t weatherLotConditionStart_Night_Minute_263;

	// 名前：天候抽選条件_夜明け_開始時刻_時
	// 説明：天候抽選条件_夜明け_開始時刻_時(SEQ09371)
	uint8_t weatherLotConditionStart_DayBreak_Hour_264;

	// 名前：天候抽選条件_夜明け_開始時刻_分
	// 説明：天候抽選条件_夜明け_開始時刻_分(SEQ09371)
	uint8_t weatherLotConditionStart_DayBreak_Minute_265;

	// 名前：天候抽選条件_予約
	// 説明：(dummy8)
	uint8_t weatherLotCondition_reserved_266[2];

	// 名前：Playerライト強度スケール変更時間帯_開始時刻_時
	// 説明：Playerライト強度スケール変更時間帯_開始時刻_時(SEQ16562)
	uint8_t pclightScaleChangeStart_Hour_268;

	// 名前：Playerライト強度スケール変更時間帯_開始時刻_分
	// 説明：Playerライト強度スケール変更時間帯_開始時刻_分(SEQ16562)
	uint8_t pclightScaleChangeStart_Minute_269;

	// 名前：Playerライト強度スケール変更時間帯_終了時刻_時
	// 説明：Playerライト強度スケール変更時間帯_終了時刻_時(SEQ16562)
	uint8_t pclightScaleChangeEnd_Hour_26A;

	// 名前：Playerライト強度スケール変更時間帯_終了時刻_分
	// 説明：Playerライト強度スケール変更時間帯_終了時刻_分(SEQ16562)
	uint8_t pclightScaleChangeEnd_Minute_26B;

	// 名前：時間帯Playerライト強度スケール変更値
	// 説明：時間帯Playerライト強度スケール変更値(SEQ16562)
	float pclightScaleByTimezone_26C;

	// 名前：大ルーン：グレーターデーモンバディ召喚時バディ付与特殊効果ID
	// 説明：大ルーン：グレーターデーモンバディ召喚時バディ付与特殊効果ID
	int32_t bigRuneGreaterDemon_SummonBuddySpecialEffectId_Buddy_270;

	// 名前：大ルーン：グレーターデーモンバディ召喚時PC付与特殊効果ID
	// 説明：大ルーン：グレーターデーモンバディ召喚時PC付与特殊効果ID
	int32_t bigRuneGreaterDemon_SummonBuddySpecialEffectId_Pc_274;

	// 名前：拠点篝火ワープID
	// 説明：拠点篝火の篝火ワープパラメータID
	int32_t homeBonfireParamId_278;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１１白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_11_27C;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１２白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_12_27D;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１３白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_13_27E;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１４白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_14_27F;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１５白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_15_280;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１６白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_16_281;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１７白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_17_282;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１８白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_18_283;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１９白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_19_284;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２０白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_20_285;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２１白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_21_286;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２２白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_22_287;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２３白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_23_288;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２４白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_24_289;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２５白
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_25_28A;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１１赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_11_28B;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１２赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_12_28C;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１３赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_13_28D;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１４赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_14_28E;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１５赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_15_28F;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１６赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_16_290;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１７赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_17_291;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１８赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_18_292;

	// 名前：レベルシンク適用判定最大武器強化レベル係数１９赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_19_293;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２０赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_20_294;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２１赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_21_295;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２２赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_22_296;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２３赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_23_297;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２４赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_24_298;

	// 名前：レベルシンク適用判定最大武器強化レベル係数２５赤
	// 説明：レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_25_299;

	// 名前：メニュー用時間帯表示_朝_開始時刻_時
	// 説明：メニュー用時間帯表示_朝_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Morning_Hour_29A;

	// 名前：メニュー用時間帯表示_朝_開始時刻_分
	// 説明：メニュー用時間帯表示_朝_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Morning_Minute_29B;

	// 名前：メニュー用時間帯表示_昼1_開始時刻_時
	// 説明：メニュー用時間帯表示_昼1_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Day1_Hour_29C;

	// 名前：メニュー用時間帯表示_昼1_開始時刻_分
	// 説明：メニュー用時間帯表示_昼1_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Day1_Minute_29D;

	// 名前：メニュー用時間帯表示_昼2_開始時刻_時
	// 説明：メニュー用時間帯表示_昼2_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Day2_Hour_29E;

	// 名前：メニュー用時間帯表示_昼2_開始時刻_分
	// 説明：メニュー用時間帯表示_昼2_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Day2_Minute_29F;

	// 名前：メニュー用時間帯表示_夕_開始時刻_時
	// 説明：メニュー用時間帯表示_夕_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Evening_Hour_2A0;

	// 名前：メニュー用時間帯表示_夕_開始時刻_分
	// 説明：メニュー用時間帯表示_夕_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Evening_Minute_2A1;

	// 名前：メニュー用時間帯表示_夜_開始時刻_時
	// 説明：メニュー用時間帯表示_夜_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Night_Hour_2A2;

	// 名前：メニュー用時間帯表示_夜_開始時刻_分
	// 説明：メニュー用時間帯表示_夜_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Night_Minute_2A3;

	// 名前：メニュー用時間帯表示_深夜_開始時刻_時
	// 説明：メニュー用時間帯表示_深夜_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Midnight_Hour_2A4;

	// 名前：メニュー用時間帯表示_深夜_開始時刻_分
	// 説明：メニュー用時間帯表示_深夜_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Midnight_Minute_2A5;

	// 名前：ネットワークPC脅威度通知_脅威度
	// 説明：ネットワークPC脅威度通知_脅威度(SEQ21950)
	uint16_t remotePlayerThreatLvNotify_ThreatLv_2A6;

	// 名前：ネットワークPC脅威度通知_通知距離[m]
	// 説明：ネットワークPC脅威度通知_通知距離[m](SEQ21950)
	float remotePlayerThreatLvNotify_NotifyDist_2A8;

	// 名前：ネットワークPC脅威度通知_通知終了距離[m]
	// 説明：ネットワークPC脅威度通知_通知終了距離[m](SEQ21950)
	float remotePlayerThreatLvNotify_EndNotifyDist_2AC;

	// 名前：地図ポイント発見領域のデフォルト拡張距離[m]
	// 説明：地図ポイントの発見領域のデフォルトの拡張距離。地図ポイントの"発見領域 上書き領域"が無効(-1)のときに、自身の領域から拡張して発見領域が生成される。その拡張距離
	float worldMapPointDiscoveryExpandRange_2B0;

	// 名前：地図ポイント出場領域のデフォルト拡張距離[m]
	// 説明：地図ポイントの出場領域のデフォルトの拡張距離。地図ポイントの"出場領域 上書き領域"が無効(-1)のときに、自身の領域から拡張して出場領域が生成される。その拡張距離
	float worldMapPointReentryExpandRange_2B4;

	// 名前：ネットワークPC脅威度通知_通知時間[秒]
	// 説明：ネットワークPC脅威度通知_通知時間[秒](SEQ21950)
	uint16_t remotePlayerThreatLvNotify_NotifyTime_2B8;

	// 名前：侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_グレーター系（ID102）
	// 説明：侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_グレーター系（ID102）
	uint16_t breakIn_A_rebreakInGoodsNum_2BA;

	// 名前：侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_グレーター系（ID102）
	// 説明：侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_グレーター系（ID102）
	int32_t breakIn_A_rebreakInGoodsId_2BC;

	// 名前：降りる大ジャンプ_上空SFXID
	// 説明：降りる大ジャンプ_上空SFXID
	int32_t rideJumpoff_SfxId_2C0;

	// 名前：降りる大ジャンプ_上空SFX基点オフセット
	// 説明：降りる大ジャンプ_上空SFX基点オフセット
	float rideJumpoff_SfxHeightOffset_2C4;

	// 名前：降りる大ジャンプ領域内_PC馬にかかる特殊効果ID
	// 説明：降りる大ジャンプ領域内_PC馬にかかる特殊効果ID
	int32_t rideJumpoff_SpEffectId_2C8;

	// 名前：降りる大ジャンプ領域内_PCにかかる特殊効果ID
	// 説明：降りる大ジャンプ領域内_PCにかかる特殊効果ID
	int32_t rideJumpoff_SpEffectIdPc_2CC;

	// 名前：メインメニュー_アイテム作成_開放イベントフラグ
	// 説明：メインメニュー→アイテム作成メニューをアンロックするイベントフラグ
	uint32_t unlockExchangeMenuEventFlagId_2D0;

	// 名前：メインメニュー_メッセージ_開放イベントフラグ
	// 説明：メインメニュー→メッセージメニューをアンロックするイベントフラグ
	uint32_t unlockMessageMenuEventFlagId_2D4;

	// 名前：侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_グレーター系使い捨て（ID111）
	// 説明：侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_グレーター系使い捨て（ID111）
	uint16_t breakInOnce_A_rebreakInGoodsNum_2D8;

	// 名前：侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_火山館系（ID112）
	// 説明：侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_火山館系（ID112）
	uint16_t breakIn_B_rebreakInGoodsNum_2DA;

	// 名前：侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_グレーター系使い捨て（ID111）
	// 説明：侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_グレーター系使い捨て（ID111）
	int32_t breakInOnce_A_rebreakInGoodsId_2DC;

	// 名前：侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_火山館系（ID112）
	// 説明：侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_火山館系（ID112）
	int32_t breakIn_B_rebreakInGoodsId_2E0;

	// 名前：アクションボタン押しっぱなしでアクションボタン操作を無効化する時間
	// 説明：アクションボタン押しっぱなしでアクションボタン操作を無効化する時間
	float actionButtonInputCancelTime_2E4;

	// 名前：ボス撃破処理後クリアボーナス取得遅延時間
	// 説明：ボス撃破処理後クリアボーナス取得遅延時間
	float blockClearBonusDelayTime_2E8;

	// 名前：【未使用】(SEQ25048参照）敵による篝火無効化を判定するPCから篝火までの距離[m]
	// 説明：【未使用】(SEQ25048参照）敵による篝火無効化を判定するPCから篝火までの距離[m](0以下：PC距離チェックしない。全距離でチェック)
	float bonfireCheckEnemyRange_2EC;

	// 名前：予約
	// 説明：(dummy8)
	uint8_t reserved_124_2F0[48];

} GameSystemCommonParam;

#endif
