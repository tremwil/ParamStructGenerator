/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EnvObjLotParam_H
#define _PARAM_EnvObjLotParam_H
#include <stdint.h>

// ENV_OBJ_LOT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EnvObjLotParam {

	// 名前：AssetId_0
	// 説明：AssetId_0 (-1：無視)
	int32_t AssetId_0_000;

	// 名前：AssetId_1
	// 説明：AssetId_1 (-1：無視)
	int32_t AssetId_1_004;

	// 名前：AssetId_2
	// 説明：AssetId_2 (-1：無視)
	int32_t AssetId_2_008;

	// 名前：AssetId_3
	// 説明：AssetId_3 (-1：無視)
	int32_t AssetId_3_00C;

	// 名前：AssetId_4
	// 説明：AssetId_4 (-1：無視)
	int32_t AssetId_4_010;

	// 名前：AssetId_5
	// 説明：AssetId_5 (-1：無視)
	int32_t AssetId_5_014;

	// 名前：AssetId_6
	// 説明：AssetId_6 (-1：無視) 
	int32_t AssetId_6_018;

	// 名前：AssetId_7
	// 説明：AssetId_7 (-1：無視)
	int32_t AssetId_7_01C;

	// 名前：出現ウェイト_0
	// 説明：出現の比率ポイント(ウェイト)_0: 0だと無視
	uint8_t CreateWeight_0_020;

	// 名前：出現ウェイト_1
	// 説明：出現の比率ポイント(ウェイト)_1
	uint8_t CreateWeight_1_021;

	// 名前：出現ウェイト_2
	// 説明：出現の比率ポイント(ウェイト)_2
	uint8_t CreateWeight_2_022;

	// 名前：出現ウェイト_3
	// 説明：出現の比率ポイント(ウェイト)_3
	uint8_t CreateWeight_3_023;

	// 名前：出現ウェイト_4
	// 説明：出現の比率ポイント(ウェイト)_4
	uint8_t CreateWeight_4_024;

	// 名前：出現ウェイト_5
	// 説明：出現の比率ポイント(ウェイト)_5
	uint8_t CreateWeight_5_025;

	// 名前：出現ウェイト_6
	// 説明：出現の比率ポイント(ウェイト)_6
	uint8_t CreateWeight_6_026;

	// 名前：出現ウェイト_7
	// 説明：出現の比率ポイント(ウェイト)_7
	uint8_t CreateWeight_7_027;

	// 名前：リザーブ
	// 説明：リザーブ
	uint8_t Reserve_0_028[24];

} EnvObjLotParam;

#endif
