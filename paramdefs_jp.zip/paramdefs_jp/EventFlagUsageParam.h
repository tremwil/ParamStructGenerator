/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EventFlagUsageParam_H
#define _PARAM_EventFlagUsageParam_H
#include <stdint.h>

// EVENT_FLAG_USAGE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EventFlagUsageParam {

	// 名前：用途
	// 説明：フラグの用途。
	uint8_t usageType_000;

	// 名前：プレイログカテゴリ
	// 説明：用途が「ON/OFF」の場合のみ有効。これを設定するとフラグがONになったときにプレイログを収集する。
	uint8_t playlogCategory_001;

	// 名前：パディング
	// 説明：パディング
	uint8_t padding1_002[2];

	// 名前：確保フラグ数
	// 説明：「ON/OFF」の場合は1を設定する。「枠割り当て」「整数」の場合は「パラメータ番号～パラメータ番号+確保フラグ数-1」が確保される範囲になる。
	int32_t flagNum_004;

	// 名前：パディング
	// 説明：パディング
	uint8_t padding2_008[24];

} EventFlagUsageParam;

#endif
