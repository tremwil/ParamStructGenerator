/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WeatherParam_H
#define _PARAM_WeatherParam_H
#include <stdint.h>

// WEATHER_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WeatherParam {

	// 名前：天候SfxId(共通)
	// 説明：天候用SfxId -1：天候Sfxなし 屋内屋外共通で出すものを設定。インタラクティブパーティクルの雨粒など、雨遮蔽(AboveShadow)で消せるものはこちらでOK
	int32_t SfxId_000;

	// 名前：風SfxId(屋外)
	// 説明：風SfxId -1：風Sfxなし 屋外のみ作成されます
	int32_t WindSfxId_004;

	// 名前：地面ヒットエフェクト用SfxId
	// 説明：地面ヒットエフェクト用SfxId -1：地面ヒットエフェクト用なし
	int32_t GroundHitSfxId_008;

	// 名前：天候用SoundId(共通)
	// 説明：天候用SoundId -1：Soundなし
	int32_t SoundId_00C;

	// 名前：濡れ時間(秒)
	// 説明：完全に濡れるまでの時間(m00_00_0000_WeatherBaseのウェイトが1.0になるまでの時間) -1：濡れなし(m00_00_0000_WeatherBaseは0.0のまま)
	float WetTime_010;

	// 名前：天候用GparamId
	// 説明：屋外天候用Gparam(m00_00_?XXX_WeatherOutdoor.gparamxml)のXXXの部分を指定する。天候間で使用するGparamの共有が可能。
	uint32_t GparamId_014;

	// 名前：次回天候抽選までの最小時間(インゲーム秒)
	// 説明：次回天候抽選までの時間の最最小値をインゲーム秒単位で指定します。この天候に遷移時、次の天候までの時間が最小から最大の間のランダムな時間になります。
	uint32_t NextLotIngameSecondsMin_018;

	// 名前：次回天候抽選までの最大時間(インゲーム秒)
	// 説明：次回天候抽選までの時間の最大値をインゲーム秒単位で指定します。この天候に遷移時、次の天候までの時間が最小から最大の間のランダムな時間になります。
	uint32_t NextLotIngameSecondsMax_01C;

	// 名前：濡れ特殊効果ID_00
	// 説明：キャラに掛かる特殊効果ID(-1：なし)
	int32_t WetSpEffectId00_020;

	// 名前：濡れ特殊効果ID_01
	// 説明：キャラに掛かる特殊効果ID(-1：なし)
	int32_t WetSpEffectId01_024;

	// 名前：濡れ特殊効果ID_02
	// 説明：キャラに掛かる特殊効果ID(-1：なし)
	int32_t WetSpEffectId02_028;

	// 名前：濡れ特殊効果ID_03
	// 説明：キャラに掛かる特殊効果ID(-1：なし)
	int32_t WetSpEffectId03_02C;

	// 名前：濡れ特殊効果ID_04
	// 説明：キャラに掛かる特殊効果ID(-1：なし)
	int32_t WetSpEffectId04_030;

	// 名前：天候SfxId(屋内)
	// 説明：天候用SfxId -1：天候Sfxなし　屋内のみ
	int32_t SfxIdInoor_034;

	// 名前：天候SfxId(屋外)
	// 説明：天候用SfxId -1：天候Sfxなし　屋外のみ
	int32_t SfxIdOutdoor_038;

	// 名前：AI視界倍率
	// 説明：AI視界倍率
	float aiSightRate_03C;

	// 名前：遠見台カメラ中ウェイト値上書き
	// 説明：遠見台カメラ中ウェイト値上書き(SEQ16724)
	float DistViewWeatherGparamOverrideWeight_040;

} WeatherParam;

#endif
