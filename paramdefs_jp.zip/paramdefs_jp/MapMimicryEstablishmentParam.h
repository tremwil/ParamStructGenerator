/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MapMimicryEstablishmentParam_H
#define _PARAM_MapMimicryEstablishmentParam_H
#include <stdint.h>

// MAP_MIMICRY_ESTABLISHMENT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MapMimicryEstablishmentParam {

	// 名前：擬態重み0
	// 説明：擬態重み0
	float mimicryEstablishment0_000;

	// 名前：擬態重み1
	// 説明：擬態重み1
	float mimicryEstablishment1_004;

	// 名前：擬態重み2
	// 説明：擬態重み2
	float mimicryEstablishment2_008;

	// 名前：擬態0 SFXID 前振り
	// 説明：擬態0 SFXID 前振り
	int32_t mimicryBeginSfxId0_00C;

	// 名前：擬態0 SFXID 本体
	// 説明：擬態0 SFXID 本体
	int32_t mimicrySfxId0_010;

	// 名前：擬態0 SFXID 解除
	// 説明：擬態0 SFXID 解除
	int32_t mimicryEndSfxId0_014;

	// 名前：擬態1 SFXID 前振り
	// 説明：擬態1 SFXID 前振り
	int32_t mimicryBeginSfxId1_018;

	// 名前：擬態1 SFXID 本体
	// 説明：擬態1 SFXID 本体
	int32_t mimicrySfxId1_01C;

	// 名前：擬態1 SFXID 解除
	// 説明：擬態1 SFXID 解除
	int32_t mimicryEndSfxId1_020;

	// 名前：擬態2 SFXID 前振り
	// 説明：擬態2 SFXID 前振り
	int32_t mimicryBeginSfxId2_024;

	// 名前：擬態2 SFXID 本体
	// 説明：擬態2 SFXID 本体
	int32_t mimicrySfxId2_028;

	// 名前：擬態2 SFXID 解除
	// 説明：擬態2 SFXID 解除
	int32_t mimicryEndSfxId2_02C;

	// 名前：パッド
	// 説明：pad
	uint8_t pad1_030[16];

} MapMimicryEstablishmentParam;

#endif
