/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AiStandardInfo_H
#define _PARAM_AiStandardInfo_H
#include <stdint.h>

// AI_STANDARD_INFO_BANK
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AiStandardInfo {

	// 名前：認識距離[m]
	// 説明：敵性キャラクタを認識する距離
	uint16_t RadarRange_000;

	// 名前：認識角度Ｘ[deg]
	// 説明：敵性キャラクタを認識するX角度　現在の視線方向を０度として、上が＋。
	uint8_t RadarAngleX_002;

	// 名前：認識角度Y[deg]
	// 説明：敵性キャラクタを認識するY角度　現在の視線方向を０度として、右が＋。
	uint8_t RadarAngleY_003;

	// 名前：縄張り距離[m]
	// 説明：自分の縄張りの距離。認識しているプレイヤーがこの距離から外れると初期位置に戻ります。
	uint16_t TerritorySize_004;

	// 名前：攻撃前威嚇率[0～100]
	// 説明：攻撃前に威嚇する確率
	uint8_t ThreatBeforeAttackRate_006;

	// 名前：初回認識威嚇
	// 説明：初回プレイヤー認識時に必ず威嚇するかどうか
	uint8_t ForceThreatOnFirstLocked_007;

	// 名前：予約
	uint8_t reserve0_008[24];

	// 名前：攻撃１　間合い[m]
	// 説明：攻撃するときの間合い[m]
	uint16_t Attack1_Distance_020;

	// 名前：攻撃１　間合い遊び[m]
	// 説明：攻撃間合いの遊び。間合い距離近辺で、振動しないように
	uint16_t Attack1_Margin_022;

	// 名前：攻撃１　割合[0～100]
	// 説明：攻撃の頻度
	uint8_t Attack1_Rate_024;

	// 名前：攻撃１　種類
	// 説明：攻撃の種類
	uint8_t Attack1_ActionID_025;

	// 名前：攻撃１　最小遅延時間[frame]
	// 説明：攻撃可能になった時点から、攻撃するまでの遅延時間の最小。
	uint8_t Attack1_DelayMin_026;

	// 名前：攻撃１　最長遅延時間[frame]
	// 説明：攻撃可能になった時点から、攻撃するまでの遅延時間の最長。
	uint8_t Attack1_DelayMax_027;

	// 名前：攻撃１　攻撃許可円錐の角度[deg]
	// 説明：視線方向とターゲットへの方向ベクトルのなす角が、この角度以内の場合、攻撃ＯＫ。
	uint8_t Attack1_ConeAngle_028;

	// 名前：予約
	uint8_t reserve10_029[7];

	// 名前：攻撃２　間合い[m]
	// 説明：攻撃するときの間合い[m]
	uint16_t Attack2_Distance_030;

	// 名前：攻撃２　間合い遊び[m]
	// 説明：攻撃間合いの遊び。間合い距離近辺で、振動しないように
	uint16_t Attack2_Margin_032;

	// 名前：攻撃１　割合[0～100]
	// 説明：攻撃の頻度
	uint8_t Attack2_Rate_034;

	// 名前：攻撃２　種類
	// 説明：攻撃の種類
	uint8_t Attack2_ActionID_035;

	// 名前：攻撃2　最小遅延時間[frame]
	// 説明：攻撃可能になった時点から、攻撃するまでの遅延時間の最小。
	uint8_t Attack2_DelayMin_036;

	// 名前：攻撃2　最長遅延時間[frame]
	// 説明：攻撃可能になった時点から、攻撃するまでの遅延時間の最長。
	uint8_t Attack2_DelayMax_037;

	// 名前：攻撃2　攻撃許可円錐の角度[deg]
	// 説明：視線方向とターゲットへの方向ベクトルのなす角が、この角度以内の場合、攻撃ＯＫ。
	uint8_t Attack2_ConeAngle_038;

	// 名前：予約
	uint8_t reserve11_039[7];

	// 名前：攻撃３　間合い[m]
	// 説明：攻撃するときの間合い[m]
	uint16_t Attack3_Distance_040;

	// 名前：攻撃３　間合い遊び[m]
	// 説明：攻撃間合いの遊び。間合い距離近辺で、振動しないように
	uint16_t Attack3_Margin_042;

	// 名前：攻撃１　割合[0～100]
	// 説明：攻撃の頻度
	uint8_t Attack3_Rate_044;

	// 名前：攻撃３　種類
	// 説明：攻撃の種類
	uint8_t Attack3_ActionID_045;

	// 名前：攻撃3　最小遅延時間[frame]
	// 説明：攻撃可能になった時点から、攻撃するまでの遅延時間の最小。
	uint8_t Attack3_DelayMin_046;

	// 名前：攻撃3　最長遅延時間[frame]
	// 説明：攻撃可能になった時点から、攻撃するまでの遅延時間の最長。
	uint8_t Attack3_DelayMax_047;

	// 名前：攻撃3　攻撃許可円錐の角度[deg]
	// 説明：視線方向とターゲットへの方向ベクトルのなす角が、この角度以内の場合、攻撃ＯＫ。
	uint8_t Attack3_ConeAngle_048;

	// 名前：予約
	uint8_t reserve12_049[7];

	// 名前：攻撃４　間合い[m]
	// 説明：攻撃するときの間合い[m]
	uint16_t Attack4_Distance_050;

	// 名前：攻撃４　間合い遊び[m]
	// 説明：攻撃間合いの遊び。間合い距離近辺で、振動しないように
	uint16_t Attack4_Margin_052;

	// 名前：攻撃１　割合[0～100]
	// 説明：攻撃の頻度
	uint8_t Attack4_Rate_054;

	// 名前：攻撃４　種類
	// 説明：攻撃の種類
	uint8_t Attack4_ActionID_055;

	// 名前：攻撃4　最小遅延時間[frame]
	// 説明：攻撃可能になった時点から、攻撃するまでの遅延時間の最小。
	uint8_t Attack4_DelayMin_056;

	// 名前：攻撃4　最長遅延時間[frame]
	// 説明：攻撃可能になった時点から、攻撃するまでの遅延時間の最長。
	uint8_t Attack4_DelayMax_057;

	// 名前：攻撃4　攻撃許可円錐の角度[deg]
	// 説明：視線方向とターゲットへの方向ベクトルのなす角が、この角度以内の場合、攻撃ＯＫ。
	uint8_t Attack4_ConeAngle_058;

	// 名前：予約
	uint8_t reserve13_059[7];

	// 名前：予約
	uint8_t reserve_last_060[32];

} AiStandardInfo;

#endif
