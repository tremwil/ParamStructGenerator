/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_GparamRefSettingsParam_H
#define _PARAM_GparamRefSettingsParam_H
#include <stdint.h>

// GPARAM_REF_SETTINGS_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GparamRefSettingsParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：参照先マップID 
	// 説明：参照先のマップ番号を指定します。レガシー：m10_10_00_00 -> 10010000, オープン：m60_??_??_?? -> m60000000
	int32_t RefTargetMapId_004;

	// 名前：リザーブ
	// 説明：リザーブ
	uint8_t Reserve_008[24];

} GparamRefSettingsParam;

#endif
