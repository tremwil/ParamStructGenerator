/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ObjActParam_H
#define _PARAM_ObjActParam_H
#include <stdint.h>

// OBJ_ACT_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ObjActParam {

	// 名前：アクション有効時のMsgID
	// 説明：アクションが有効時に表示するメニューのMsgIDです。
	int32_t actionEnableMsgId_000;

	// 名前：アクション失敗時のMsgID
	// 説明：アクションが失敗時に表示するメニューのMsgIDです。
	int32_t actionFailedMsgId_004;

	// 名前：特殊条件パス用イベントフラグ
	// 説明：特殊条件を無条件パスするためのイベントフラグ.
	uint32_t spQualifiedPassEventFlag_008;

	// 名前：プレイヤのアニメID0
	// 説明：プレイヤーキャラのアクション時のアニメIDです。
	uint32_t playerAnimId_00C;

	// 名前：キャラのアニメID0
	// 説明：敵などのアクション時のアニメID
	uint32_t chrAnimId_010;

	// 名前：アクションの有効距離[cm]
	// 説明：アクションの有効距離です。
	uint16_t validDist_014;

	// 名前：特殊条件のID
	// 説明：特殊条件のID
	uint16_t spQualifiedId_016;

	// 名前：特殊条件のID 2
	// 説明：特殊条件のIDその2
	uint16_t spQualifiedId2_018;

	// 名前：オブジェのダミポリID0
	// 説明：オブジェクトのアクション位置となるダミポリIDです
	uint8_t objDummyId_01A;

	// 名前：イベントキックを同期させるか
	// 説明：ObjAct実行判定で使用されるイベントを同期させるか。基本×に設定する。アクターが重要ではない場合のみ○に設定しても良い。
	uint8_t isEventKickSync_01B;

	// 名前：オブジェのアニメID0
	// 説明：オブジェクトのアクション時のアニメＩＤです。
	uint32_t objAnimId_01C;

	// 名前：プレイヤのアクション有効角度
	// 説明：プレイヤのアクションの有効角度です。プレイヤの向きベクトルとオブジェへの方向ベクトルの有効角度差
	uint8_t validPlayerAngle_020;

	// 名前：特殊条件のタイプ
	// 説明：特殊条件の種類
	uint8_t spQualifiedType_021;

	// 名前：特殊条件のタイプ2
	// 説明：特殊条件の種類2
	uint8_t spQualifiedType2_022;

	// 名前：オブジェのアクション有効角度
	// 説明：オブジェのアクション有効角度です。オブジェのアクションベクトルとキャラベクトルの有効角度差
	uint8_t validObjAngle_023;

	// 名前：キャラの吸着タイプ
	// 説明：オブジェアクション時のキャラの吸着方法です
	uint8_t chrSorbType_024;

	// 名前：イベント発動タイミング
	// 説明：イベントの実行タイミング
	uint8_t eventKickTiming_025;

	// 名前：pad1
	uint8_t pad1_026[2];

	// 名前：アクションボタンパラメータID
	// 説明：アクションボタンパラメータID
	int32_t actionButtonParamId_028;

	// 名前：宝有効化ディレイ(秒)
	// 説明：オブジェアクション実行から宝有効化までの秒数。オブジェアクトのオブジェタイプ「宝箱」専用の設定。
	float enableTreasureDelaySec_02C;

	// 名前：実行前SFX用ダミポリID
	// 説明：オブジェアクト実行前のときにこのダミポリIDからSFXを出す。-1なら原点から出す。
	int32_t preActionSfxDmypolyId_030;

	// 名前：実行前SFXID
	// 説明：オブジェアクト実行前のときに出すSFX。-1なら出さない。
	int32_t preActionSfxId_034;

	// 名前：pad2
	uint8_t pad2_038[40];

} ObjActParam;

#endif
