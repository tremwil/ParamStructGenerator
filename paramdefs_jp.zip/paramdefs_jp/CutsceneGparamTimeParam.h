/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_CutsceneGparamTimeParam_H
#define _PARAM_CutsceneGparamTimeParam_H
#include <stdint.h>

// CUTSCENE_GPARAM_TIME_PARAM_ST
// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CutsceneGparamTimeParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：デバッグパラメータか
	// 説明：○をつけたパラメータは全パッケージから除外します（デバッグ用なので）
	uint8_t disableParam_Debug_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 6;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：朝
	// 説明：朝(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_Morning_004;

	// 名前：昼A
	// 説明：昼A(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_Noon_005;

	// 名前：昼B
	// 説明：昼B(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_AfterNoon_006;

	// 名前：夕
	// 説明：夕(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_Evening_007;

	// 名前：夜
	// 説明：夜(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_Night_008;

	// 名前：深夜A
	// 説明：深夜A(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_DeepNightA_009;

	// 名前：深夜B
	// 説明：深夜B(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_DeepNightB_00A;

	// 名前：reserved
	// 説明：reserved
	uint8_t reserved_00B[1];

	// 名前：再生終了時のインゲーム時刻指定[hour]
	// 説明：再生終了時のインゲーム時刻指定[hour][-1.0～24.0](-1(0より小さい)：何もしない)
	float PostPlayIngameTime_00C;

} CutsceneGparamTimeParam;

#endif
