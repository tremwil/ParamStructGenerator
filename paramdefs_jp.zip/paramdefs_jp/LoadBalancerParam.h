/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_LoadBalancerParam_H
#define _PARAM_LoadBalancerParam_H
#include <stdint.h>

// LOAD_BALANCER_PARAM_ST
// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _LoadBalancerParam {

	// 名前：lowerFpsThreshold
	// 説明：このFPSを下回ったら、ロードバランスレベルを1上げる
	float lowerFpsThreshold_000;

	// 名前：upperFpsThreshold
	// 説明：このFPSを上回ったら、ロードバランスレベルを1下げる
	float upperFpsThreshold_004;

	// 名前：lowerFpsContinousCount
	// 説明：このフレーム連続してしきい値を下回ったら、レベルアップ
	uint32_t lowerFpsContinousCount_008;

	// 名前：upperFpsContinousCount
	// 説明：このフレーム連続してしきい値を上回ったら、レベルダウン
	uint32_t upperFpsContinousCount_00C;

	// 名前：downAfterChangeSleep
	// 説明：レベルダウン後のスリープフレームカウント
	uint32_t downAfterChangeSleep_010;

	// 名前：upAfterChangeSleep
	// 説明：レベルアップ後のスリープフレームカウント
	uint32_t upAfterChangeSleep_014;

	// 名前：ライトシャフト
	// 説明：フィルタのライトシャフト
	uint8_t postProcessLightShaft_018;

	// 名前：Bloom
	// 説明：ブルーム
	uint8_t postProcessBloom_019;

	// 名前：Glow
	// 説明：グロー
	uint8_t postProcessGlow_01A;

	// 名前：AA
	// 説明：アンチエイリアス
	uint8_t postProcessAA_01B;

	// 名前：SSAO
	// 説明：SSAO
	uint8_t postProcessSSAO_01C;

	// 名前：DOF
	// 説明：DOF
	uint8_t postProcessDOF_01D;

	// 名前：MotionBlur
	// 説明：MotionBlur
	uint8_t postProcessMotionBlur_01E;

	// 名前：MotionBlurIteration
	// 説明：MotionBlurのイテレーション回数を下げる
	uint8_t postProcessMotionBlurIteration_01F;

	// 名前：予備
	// 説明：予備
	uint8_t reserve0_020[1];

	// 名前：Shadow Blur
	// 説明：影のブラーを切る
	uint8_t shadowBlur_021;

	// 名前：SFXのエミット回り
	// 説明：エミット間隔、エミット数、LOD距離をグラフィックスコンフィグの半分に
	uint8_t sfxParticleHalf_022;

	// 名前：SFXの反射
	// 説明：反射シーンSFXをオミット
	uint8_t sfxReflection_023;

	// 名前：水面インタラクション
	// 説明：水面インタラクトSFXをオミット
	uint8_t sfxWaterInteraction_024;

	// 名前：SFXのグロー
	// 説明：SFXでかけてるGlowをオミット
	uint8_t sfxGlow_025;

	// 名前：SFXの歪み
	// 説明：SFXでかけてる歪みのオミット
	uint8_t sfxDistortion_026;

	// 名前：ソフトスプライト
	// 説明：SFXでかけてるソフトスプライトのオミット
	uint8_t sftSoftSprite_027;

	// 名前：ライトシャフト
	// 説明：SFXのライトシャフトのオミット
	uint8_t sfxLightShaft_028;

	// 名前：動的に縮小バッファに登録されるエフェクトの距離判定にスケール
	// 説明：SFXの距離で動的に縮小バッファに登録されるエフェクトの距離判定にスケール
	uint8_t sfxScaleRenderDistanceScale_029;

	// 名前：動的解像度
	// 説明：動的解像度
	uint8_t dynamicResolution_02A;

	// 名前：Shadow Cascade0 ResolutionHalf
	// 説明：影（カスケード0）の解像度を半分に下げる
	uint8_t shadowCascade0ResolutionHalf_02B;

	// 名前：Shadow Cascade1 ResolutionHalf
	// 説明：影（カスケード1）の解像度を半分に下げる
	uint8_t shadowCascade1ResolutionHalf_02C;

	// 名前：ローカルプレイヤー
	// 説明：ローカルプレイヤーの水濡れ処理を切る
	uint8_t chrWetDisablePlayer_02D;

	// 名前：リモートプレイヤー
	// 説明：リモートプレイヤーの水濡れ処理を切る
	uint8_t chrWetDisableRemotePlayer_02E;

	// 名前：敵キャラ
	// 説明：敵キャラの水濡れ処理を切る
	uint8_t chrWetDisableEnemy_02F;

	// 名前：解像度引き下げ 下限(%)
	// 説明：解像度引き下げ 下限(%)
	uint8_t dynamicResolutionPercentageMin_030;

	// 名前：解像度引き下げ 上限(%)
	// 説明：解像度引き下げ 上限(%)
	uint8_t dynamicResolutionPercentageMax_031;

	// 名前：予備
	// 説明：予備
	uint8_t reserve1_032[30];

} LoadBalancerParam;

#endif
