/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_BulletParam_H
#define _PARAM_BulletParam_H
#include <stdint.h>

// BULLET_PARAM_ST
// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BulletParam {

	// 名前：攻撃ID
	// 説明：攻撃パラメータのＩＤをそれぞれ登録する.→攻撃タイプ／攻撃材質／物理攻撃力／魔法攻撃力／スタミナ攻撃力／ノックバック距離.
	int32_t atkId_Bullet_000;

	// 名前：SFXID【弾】
	// 説明：【弾】用SFX IDを入れる。-1は発生しない。
	int32_t sfxId_Bullet_004;

	// 名前：SFXID【着弾】
	// 説明：【着弾】SFXIDを入れる。-1は発生しない。
	int32_t sfxId_Hit_008;

	// 名前：SFXID【はじき時】
	// 説明：【はじき時】SFXIDを入れる。-1は発生しない。
	int32_t sfxId_Flick_00C;

	// 名前：寿命[s]
	// 説明：飛び道具が存在し続けられる時間（-1なら無限）.
	float life_010;

	// 名前：射程距離[m]
	// 説明：減衰が開始される距離（実際の飛距離ではない）.
	float dist_014;

	// 名前：発射間隔[s]
	// 説明：飛び道具を何秒間隔で発射するかを指定.
	float shootInterval_018;

	// 名前：射程距離内重力[m/s^2]
	// 説明：射程距離内での下向きにかかる重力.
	float gravityInRange_01C;

	// 名前：射程距離外重力[m/s^2]
	// 説明：減衰がはじまったときの下向きにかかる重力（ポトンと落ちる感じを表現.
	float gravityOutRange_020;

	// 名前：誘導停止距離[m]
	// 説明：誘導を停止するターゲットとの距離。誘導弾で当たり過ぎないようにするパラメータ。
	float hormingStopRange_024;

	// 名前：初速[m/s]
	// 説明：ＳＦＸの初速度.
	float initVellocity_028;

	// 名前：射程距離内加速度[m/s^2]
	// 説明：ＳＦＸの射程内の加速度.
	float accelInRange_02C;

	// 名前：射程距離外加速度[m/s^2]
	// 説明：ＳＦＸが射程距離外に出たときの加速度.
	float accelOutRange_030;

	// 名前：最高速度[m/s]
	// 説明：最高速度.
	float maxVellocity_034;

	// 名前：最低速度[m/s]
	// 説明：最低保証速度.
	float minVellocity_038;

	// 名前：加速開始時間[s]
	// 説明：この時間までは、加速しない（ロケット弾みたいな魔法を撃つことができるようにしておく）.
	float accelTime_03C;

	// 名前：誘導開始距離[m]
	// 説明：何ｍ進んだ地点から誘導を開始するか.
	float homingBeginDist_040;

	// 名前：初期弾半径[m]
	// 説明：当たり球の半径を設定する.
	float hitRadius_044;

	// 名前：最大弾半径[m]
	// 説明：あたり球の最大半径（－1の場合、初期半径と同じにする／デフォルト）
	float hitRadiusMax_048;

	// 名前：範囲拡散時間[s]
	// 説明：範囲半径が細大にまで広がる時間.
	float spreadTime_04C;

	// 名前：発動遅延[s]
	// 説明：着弾後、爆発までの時間（０の場合はすぐに爆発）.
	float expDelay_050;

	// 名前：誘導ずらし量[m]
	// 説明：０だと正確。射撃時にXYZ各成分を、この量だけずらして狙うようにする。
	float hormingOffsetRange_054;

	// 名前：ダメージヒット履歴の生存時間[s]
	// 説明：ダメージヒット履歴の生存時間[sec](<=0.0f：無期限)
	float dmgHitRecordLifeTime_058;

	// 名前：外力[m/s^2]
	// 説明：射撃時の方向にかかる外力.(Y軸は抜いている)
	float externalForce_05C;

	// 名前：射撃した人にかける特殊効果
	// 説明：射撃した人にかける特殊効果
	int32_t spEffectIDForShooter_060;

	// 名前：ファンネルNPC思考ID
	// 説明：ファンネルがターゲットの検索使用するパラメータ
	int32_t autoSearchNPCThinkID_064;

	// 名前：発生弾丸ID
	// 説明：弾丸パラメータから、新しく弾丸パラメータを発生させるときにＩＤを指定する
	int32_t HitBulletID_068;

	// 名前：特殊効果ID0
	// 説明：特殊効果パラメータのＩＤをそれぞれ登録する.→特殊効果全般.
	int32_t spEffectId0_06C;

	// 名前：特殊効果ID1
	// 説明：特殊効果パラメータのＩＤをそれぞれ登録する.→特殊効果全般.
	int32_t spEffectId1_070;

	// 名前：特殊効果ID2
	// 説明：特殊効果パラメータのＩＤをそれぞれ登録する.→特殊効果全般.
	int32_t spEffectId2_074;

	// 名前：特殊効果ID3
	// 説明：特殊効果パラメータのＩＤをそれぞれ登録する.→特殊効果全般.
	int32_t spEffectId3_078;

	// 名前：特殊効果ID4
	// 説明：特殊効果パラメータのＩＤをそれぞれ登録する.→特殊効果全般.
	int32_t spEffectId4_07C;

	// 名前：発射数
	// 説明：一度に発射する飛び道具の数.
	uint16_t numShoot_080;

	// 名前：誘導性能[deg/s]
	// 説明：1秒間に何度まで補正するか？.
	int16_t homingAngle_082;

	// 名前：発射角度[deg]
	// 説明：飛び道具を前方何度に向かって発射するかを指定.
	int16_t shootAngle_084;

	// 名前：発射角度間隔[deg]
	// 説明：飛び道具を複数発射する場合、何度間隔で発射するかを指定.(Y軸)
	int16_t shootAngleInterval_086;

	// 名前：発射仰角間隔[deg]
	// 説明：飛び道具を複数発射する場合、何度間隔で発射するかを指定.(X軸)
	int16_t shootAngleXInterval_088;

	// 名前：物理攻撃力減衰率[%/s]
	// 説明：減衰距離以降、1秒間に減少する補正値.
	int8_t damageDamp_08A;

	// 名前：魔法攻撃力減衰率[%/s]
	// 説明：減衰距離以降、1秒間に減少する補正値.
	int8_t spelDamageDamp_08B;

	// 名前：炎攻撃力減衰率[%/s]
	// 説明：減衰距離以降、1秒間に減少する補正値.
	int8_t fireDamageDamp_08C;

	// 名前：電撃攻撃力減衰率[%/s]
	// 説明：減衰距離以降、1秒間に減少する補正値.
	int8_t thunderDamageDamp_08D;

	// 名前：スタミナダメージ減衰率[%/s]
	// 説明：減衰距離以降、1秒間に減少する補正値.
	int8_t staminaDamp_08E;

	// 名前：ノックバック減衰率[%/s]
	// 説明：減衰距離以降、1秒間に減少する補正値.
	int8_t knockbackDamp_08F;

	// 名前：発射仰角[deg]
	// 説明：水平方向からの追加仰角。
	int8_t shootAngleXZ_090;

	// 名前：ロック方向制限角度
	// 説明：ロック方向を向かせるときの制限角度
	uint8_t lockShootLimitAng_091;

	// 名前：pad
	uint8_t pad2_092[1];

	// 名前：前回の移動方向加算率[%]
	// 説明：滑る弾が壁にヒット時に前回の移動方向を今の方向へ加算する比率
	uint8_t prevVelocityDirRate_093;

	// 名前：物理属性
	// 説明：弾丸に設定する物理属性を設定
	uint8_t atkAttribute_094;

	// 名前：特殊属性
	// 説明：弾丸に設定する特殊属性を設定
	uint8_t spAttribute_095;

	// 名前：攻撃属性[SFX/SE]
	// 説明：攻撃属性が何かを指定する
	uint8_t Material_AttackType_096;

	// 名前：攻撃材質[SFX/SE]
	// 説明：攻撃時のSFX/ＳＥに使用
	uint8_t Material_AttackMaterial_097;

	// 名前：キャラを貫通？
	// 説明：ONであればキャラに当たったときに着弾せず貫通する
	uint8_t isPenetrateChr_098: 1;

	// 名前：オブジェを貫通？
	// 説明：ONであれば動的/部分破壊アセットに当たったときに着弾せず貫通する
	uint8_t isPenetrateObj_098: 1;

	// 名前：pad
	uint8_t pad_098: 6;

	// 名前：発生条件
	// 説明：着弾・寿命消滅時に弾を発生させるか判定する条件を指定
	uint8_t launchConditionType_099;

	// 名前：追従タイプ
	// 説明：追従タイプ。「追従しない」がデフォルト。
	uint8_t FollowType_09A: 3;

	// 名前：発生源タイプ
	// 説明：発生源タイプ。ダミポリからが通常。（メテオを判定するために導入）
	uint8_t EmittePosType_09A: 3;

	// 名前：刺さったままになるか
	// 説明：矢などの弾丸が、キャラクターに刺さったままになるかどうかを設定する
	uint8_t isAttackSFX_09A: 1;

	// 名前：あたり続けるか？
	// 説明：あたり続けるか？
	uint8_t isEndlessHit_09A: 1;

	// 名前：マップを貫通？
	// 説明：ONであればヒット/静的アセットに当たったときに着弾せず貫通する
	uint8_t isPenetrateMap_09B: 1;

	// 名前：敵味方共にあたる？
	// 説明：敵味方共にあたるか？（徘徊ゴーストにはあたらない）
	uint8_t isHitBothTeam_09B: 1;

	// 名前：ヒットリストを共有するか？
	// 説明：ヒットリストを共有するかを指定
	uint8_t isUseSharedHitList_09B: 1;

	// 名前：複数のダミポリを使うか？
	// 説明：弾配置時に同一ダミポリIDを複数使うか？
	uint8_t isUseMultiDmyPolyIfPlace_09B: 1;

	// 名前：他弾強制消去Aに当たるか
	// 説明：他弾強制消去Aに当たるか
	uint8_t isHitOtherBulletForceEraseA_09B: 1;

	// 名前：他弾強制消去Bに当たるか
	// 説明：他弾強制消去Bに当たるか
	uint8_t isHitOtherBulletForceEraseB_09B: 1;

	// 名前：フォース魔法に当たるか
	// 説明：フォース魔法に当たるか
	uint8_t isHitForceMagic_09B: 1;

	// 名前：水面衝突時のエフェクト無視するか
	// 説明：水面に当たった場合はエフェクト無視するか
	uint8_t isIgnoreSfxIfHitWater_09B: 1;

	// 名前：水面衝突時の状態遷移を無視するか
	// 説明：水に当たっても状態遷移を無視するか
	uint8_t isIgnoreMoveStateIfHitWater_09C: 1;

	// 名前：闇フォース魔法に当たるか
	// 説明：闇フォース魔法に当たるか
	uint8_t isHitDarkForceMagic_09C: 1;

	// 名前：ダメージ計算サイド
	// 説明：ダメージ計算サイド。　マルチプレイ時に、ダメージの計算を、与えた側 or 受けた側を切り替えるためのもの。
	uint8_t dmgCalcSide_09C: 2;

	// 名前：弾丸自動捕捉許可
	// 説明：非ロックオン時に自動追従するか
	uint8_t isEnableAutoHoming_09C: 1;

	// 名前：同期弾丸の場合、ダミポリ位置での再計算を行うか
	// 説明：同期生成された弾丸の場合、弾丸生成時にダミポリ位置による姿勢の再計算を行わず、同期時のエミッタ姿勢を使用する。
	uint8_t isSyncBulletCulcDumypolyPos_09C: 1;

	// 名前：弾丸の基準方向をオーナーに上書きするか？
	// 説明：子弾丸のみ有効。ONなら基準方向をオーナーにする。
	uint8_t isOwnerOverrideInitAngle_09C: 1;

	// 名前：子弾にSFXを引き継ぐか
	// 説明：親弾のSFXを引き継ぐ。子弾に設定されたSFXIDは無視する 
	uint8_t isInheritSfxToChild_09C: 1;

	// 名前：闇攻撃力減衰率[%/s]
	// 説明：減衰距離以降、1秒間に減少する補正値.
	int8_t darkDamageDamp_09D;

	// 名前：着弾時の弾丸SFX消滅タイプ
	// 説明：着弾or弾き時の弾丸SFX消滅タイプ
	int8_t bulletSfxDeleteType_byHit_09E;

	// 名前：寿命時の弾丸SFX消滅タイプ
	// 説明：寿命時の弾丸SFX消滅タイプ
	int8_t bulletSfxDeleteType_byLifeDead_09F;

	// 名前：目標上下オフセット[m]
	// 説明：着弾位置の上下オフセット。発射時とホーミング中のターゲット位置を上下にずらす。（-n～n）
	float targetYOffsetRange_0A0;

	// 名前：発射角度乱数[deg]
	// 説明：発射角度乱数の上限（0～360）
	float shootAngleYMaxRandom_0A4;

	// 名前：発射仰角乱数[deg]
	// 説明：発射仰角乱数の上限（0～360）
	float shootAngleXMaxRandom_0A8;

	// 名前：間隔指定発生弾丸ID
	// 説明：一定間隔で弾丸を作る時に使う、弾丸のID
	int32_t intervalCreateBulletId_0AC;

	// 名前：発生間隔：最小時間[s]
	// 説明：一定間隔で弾丸を作る間隔の最小（0～n）
	float intervalCreateTimeMin_0B0;

	// 名前：発生間隔：最大時間[s]
	// 説明：一定間隔で弾丸を作る間隔の最大（0～n 0なら機能無効）
	float intervalCreateTimeMax_0B4;

	// 名前：予測射撃の速度観測時間[s]
	// 説明：予測射撃機能の平均速度観測時間（0～4 0なら機能無効）
	float predictionShootObserveTime_0B8;

	// 名前：間隔指定発生開始待ち時間[s]
	// 説明：一定間隔で弾丸を作り始めるまでの待ち時間
	float intervalCreateWaitTime_0BC;

	// 名前：弾丸から発生したSFXの姿勢のタイプ
	// 説明：弾丸から作成されたSFXまたは子弾丸の初期姿勢を設定する
	uint8_t sfxPostureType_0C0;

	// 名前：作成制限グループId
	// 説明：0なら未使用。同一のグループIdに設定された弾丸を作成するときに上限に達していたらその弾丸を作成しない。（ネットワークで同期作成された弾は関係なく出る）
	uint8_t createLimitGroupId_0C1;

	// 名前：pad
	uint8_t pad5_0C2[1];

	// 名前：子弾に速度を引き継ぐか
	// 説明：子弾に差し替わるタイミングの速度を引き継ぐ。子弾に設定された速度は無視する
	uint8_t isInheritSpeedToChild_0C3: 1;

	// 名前：キャラ・OBJヒット時着弾SFXを再生しない
	// 説明：ONの時、キャラクター/オブジェクトに着弾しても弾丸パラメータの「着弾SFX」を再生しない
	uint8_t isDisableHitSfx_byChrAndObj_0C3: 1;

	// 名前：発射位置壁めり込み判定をキャラ中心を平行に結ぶレイを飛ばして行う
	// 説明：弾丸発射時めり込み判定に不具合があったので、それのエラーハンドリング用。SEQ23101 【自キャラ】ロックオン位置の高いキャラに密着してソウルの短矢、強いソウルの短矢を使うと弾丸の方向が反転する
	uint8_t isCheckWall_byCenterRay_0C3: 1;

	// 名前：フレア魔法に当たるか
	// 説明：フレア魔法に当たるか
	uint8_t isHitFlare_0C3: 1;

	// 名前：原始魔法アタリを使うか？
	// 説明：原始魔法アタリを使うか？原始魔法専用アタリに当たるフィルタに変わります。
	uint8_t isUseBulletWallFilter_0C3: 1;

	// 名前：pad
	uint8_t pad1_0C3: 1;

	// 名前：PCのファンネル数が理力で変動しない
	// 説明：PCのファンネル数が理力で変動しない。発射数になる
	uint8_t isNonDependenceMagicForFunnleNum_0C3: 1;

	// 名前：AI弾丸反応するか（攻撃力0でも）
	// 説明：AI弾丸反応するか（攻撃力0でも）
	uint8_t isAiInterruptShootNoDamageBullet_0C3: 1;

	// 名前：ランダム発生時の発生範囲(半径)[m]
	// 説明：発生源タイプがランダムな位置に発生する設定の場合に利用される、弾丸の発生範囲。
	float randomCreateRadius_0C4;

	// 名前：ファンネル追従位置_基点高さ[m]
	// 説明：ファンネル追従位置_基点高さ[m]
	float followOffset_BaseHeight_0C8;

	// 名前：着弾時に発生するアセット番号
	// 説明：着弾時に発生させるアセットの番号。-1：生成しない。アセット番号はアセットの下6桁の数値です。例： AEG999_999 = 999999
	int32_t assetNo_Hit_0CC;

	// 名前：寿命乱数[s]
	// 説明：「寿命[s]」に対して、設定した時間の振れ幅を持つ乱数秒を加える
	float lifeRandomRange_0D0;

	// 名前：誘導性能（X軸個別）[deg/s]
	// 説明：誘導性能のX軸成分だけを変えます。-1で変えません
	int16_t homingAngleX_0D4;

	// 名前：弾道計算タイプ
	// 説明：弾道計算タイプ
	uint8_t ballisticCalcType_0D6;

	// 名前：アタッチ効果タイプ
	// 説明：アタッチする効果タイプ
	uint8_t attachEffectType_0D7;

	// 名前：SEID1【弾】
	// 説明：【弾】用SE ID1 を入れる。-1：生成しない　9桁。サウンドタイプはs：SFX固定。
	int32_t seId_Bullet1_0D8;

	// 名前：SEID2【弾】
	// 説明：【弾】用SE ID2 を入れる。-1：生成しない　9桁。サウンドタイプはs：SFX固定。
	int32_t seId_Bullet2_0DC;

	// 名前：SEID【着弾】
	// 説明：【着弾】用SE ID1 を入れる。-1は発生しない。 9桁。サウンドタイプはs：SFX固定。
	int32_t seId_Hit_0E0;

	// 名前：SEID【はじき時】
	// 説明：【はじき時】用SE ID1 を入れる。-1は発生しない。 9桁。サウンドタイプはs：SFX固定。
	int32_t seId_Flick_0E4;

	// 名前：【曲射】発射仰角制限_下限[deg]
	// 説明：【曲射】曲射計算の適用前の発射仰角を基準(0deg)とした下限[deg]。
	int16_t howitzerShootAngleXMin_0E8;

	// 名前：【曲射】発射仰角制限_上限[deg]
	// 説明：【曲射】曲射計算の適用前の発射仰角を基準(0deg)とした上限[deg]。
	int16_t howitzerShootAngleXMax_0EA;

	// 名前：【曲射】最低制限速度[m/s]
	// 説明：【曲射】曲射計算の最低制限速度[m/s]。
	float howitzerInitMinVelocity_0EC;

	// 名前：【曲射】最高制限速度[m/s]
	// 説明：【曲射】曲射計算の最高制限速度[m/s]。
	float howitzerInitMaxVelocity_0F0;

	// 名前：SFXID【強制消去時】
	// 説明：強制消去時SFXID。-1は発生しない。
	int32_t sfxId_ForceErase_0F4;

	// 名前：強制消去時の弾丸SFX消滅タイプ
	// 説明：強制消去時の弾丸SFX消滅タイプ
	int8_t bulletSfxDeleteType_byForceErase_0F8;

	// 名前：パディング3
	// 説明：pad3
	uint8_t pad3_0F9[1];

	// 名前：追従時SFX方向指定ダミポリ
	// 説明：追従時SFX方向指定ダミポリ
	int16_t followDmypoly_forSfxPose_0FA;

	// 名前：ファンネル追従位置_半径[m]
	// 説明：ファンネル追従位置_半径[m]
	float followOffset_Radius_0FC;

	// 名前：特殊効果飛距離補正倍率
	// 説明：特殊効果飛距離補正倍率
	float spBulletDistUpRate_100;

	// 名前：非ロック時ターゲット射程距離[m]
	// 説明：非ロック時ターゲット射程距離（-1：「射程距離」を参照する、0：ターゲットなし）
	float nolockTargetDist_104;

	// 名前：pad
	uint8_t pad4_108[8];

} BulletParam;

#endif
