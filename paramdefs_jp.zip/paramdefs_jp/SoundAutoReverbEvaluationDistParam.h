/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SoundAutoReverbEvaluationDistParam_H
#define _PARAM_SoundAutoReverbEvaluationDistParam_H
#include <stdint.h>

// SOUND_AUTO_REVERB_EVALUATION_DIST_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SoundAutoReverbEvaluationDistParam {

	// 名前：NoHitとする距離[m]
	// 説明：この距離[m]以上の衝突点をNoHitとして判定する(0より小さい:無効)
	float NoHitDist_000;

	// 名前：NoHitの衝突点含めるか？
	// 説明：NoHitの衝突点含めるか？
	uint8_t isCollectNoHitPoint_004;

	// 名前：屋外の衝突点含めるか？
	// 説明：屋外の衝突点含めるか？
	uint8_t isCollectOutdoorPoint_005;

	// 名前：床の衝突点含めるか？
	// 説明：床の衝突点含めるか？
	uint8_t isCollectFloorPoint_006;

	// 名前：評価距離計算タイプ
	// 説明：評価距離計算タイプ(0:通常,1:Maxからの平均)
	uint8_t distValCalcType_007;

	// 名前：有効な衝突点寿命[秒]
	// 説明：この寿命[秒]以上の衝突点は無効扱いにする。共通設定の寿命以下に設定すること
	float enableLifeTime_008;

	// 名前：Max衝突点レコード数
	// 説明：Max衝突点レコード数
	uint32_t maxDistRecordNum_00C;

	// 名前：Max距離間引き数
	// 説明：Max距離間引き数(0:間引かない)(「Max衝突点レコード数-1」の値に設定する必要がある。不正な値は修正される)
	uint32_t ignoreDistNumForMax_010;

} SoundAutoReverbEvaluationDistParam;

#endif
