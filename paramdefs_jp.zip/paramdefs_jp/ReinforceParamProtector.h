/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ReinforceParamProtector_H
#define _PARAM_ReinforceParamProtector_H
#include <stdint.h>

// REINFORCE_PARAM_PROTECTOR_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ReinforceParamProtector {

	// 名前：物理防御力
	// 説明：物理防御力の補正値
	float physicsDefRate_000;

	// 名前：魔法防御力
	// 説明：魔法防御力の補正値
	float magicDefRate_004;

	// 名前：炎防御力
	// 説明：炎防御力の補正値
	float fireDefRate_008;

	// 名前：電撃防御力
	// 説明：電撃防御力の補正値
	float thunderDefRate_00C;

	// 名前：斬撃防御力
	// 説明：斬撃防御力の補正値
	float slashDefRate_010;

	// 名前：打撃防御力
	// 説明：打撃防御力の補正値
	float blowDefRate_014;

	// 名前：刺突防御力
	// 説明：刺突防御力の補正値
	float thrustDefRate_018;

	// 名前：毒耐性
	// 説明：毒耐性の補正値
	float resistPoisonRate_01C;

	// 名前：疫病耐性
	// 説明：疫病耐性の補正値
	float resistDiseaseRate_020;

	// 名前：出血耐性
	// 説明：出血耐性の補正値
	float resistBloodRate_024;

	// 名前：呪耐性
	// 説明：呪耐性の補正値
	float resistCurseRate_028;

	// 名前：常駐特殊効果ID1
	// 説明：常駐特殊効果ID1の加算補正値
	uint8_t residentSpEffectId1_02C;

	// 名前：常駐特殊効果ID2
	// 説明：常駐特殊効果ID2の加算補正値
	uint8_t residentSpEffectId2_02D;

	// 名前：常駐特殊効果ID3
	// 説明：常駐特殊効果ID3の加算補正値
	uint8_t residentSpEffectId3_02E;

	// 名前：素材ID加算値
	// 説明：素材パラメータIDの加算補正値
	uint8_t materialSetId_02F;

	// 名前：闇防御力
	// 説明：闇防御力の補正値
	float darkDefRate_030;

	// 名前：冷気耐性
	// 説明：冷気耐性の補正値
	float resistFreezeRate_034;

	// 名前：睡眠耐性
	// 説明：睡眠耐性の補正値
	float resistSleepRate_038;

	// 名前：発狂耐性
	// 説明：発狂耐性の補正値
	float resistMadnessRate_03C;

} ReinforceParamProtector;

#endif
