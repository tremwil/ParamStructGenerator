/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_SoundAutoReverbSelectParam_H
#define _PARAM_SoundAutoReverbSelectParam_H
#include <stdint.h>

// SOUND_AUTO_REVERB_SELECT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _SoundAutoReverbSelectParam {

	// 名前：リバーブタイプ
	// 説明：リバーブタイプ
	uint32_t reverbType_000;

	// 名前：エリアNo
	// 説明：条件：エリアNo(-1:無効)
	int32_t AreaNo_004;

	// 名前：屋内外
	// 説明：条件：屋内外指定(0:屋外,1:屋内)(-1:無効)
	int8_t IndoorOutdoor_008;

	// 名前：使用評価距離番号A
	// 説明：条件：使用する評価距離の番号A(-1:無効)
	int8_t useDistNoA_009;

	// 名前：使用評価距離番号B
	// 説明：条件：使用する評価距離の番号B(-1:無効)
	int8_t useDistNoB_00A;

	// 名前：pad0
	// 説明：pad0
	uint8_t pad0_00B[1];

	// 名前：距離MinA[m]
	// 説明：条件：評価距離最小指定A用(0より小さい:無効)
	float DistMinA_00C;

	// 名前：距離MaxA[m]
	// 説明：条件：評価距離最大指定A用(0より小さい:無効)
	float DistMaxA_010;

	// 名前：距離MinB[m]
	// 説明：条件：評価距離最小指定A用(0より小さい:無効)
	float DistMinB_014;

	// 名前：距離MaxB[m]
	// 説明：条件：評価距離最大指定A用(0より小さい:無効)
	float DistMaxB_018;

	// 名前：衝突点NoHit数最小数
	// 説明：条件：NoHit数(-1:無効)
	int32_t NoHitNumMin_01C;

} SoundAutoReverbSelectParam;

#endif
