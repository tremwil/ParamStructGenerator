/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_EquipParamAccessory_H
#define _PARAM_EquipParamAccessory_H
#include <stdint.h>

// EQUIP_PARAM_ACCESSORY_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EquipParamAccessory {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：呼び出しID
	// 説明：装飾品から呼び出すID
	int32_t refId_004;

	// 名前：SFXバリエーションID
	// 説明：ＳＦＸのバリエーションを指定（TimeActEditorのＩＤと組み合わせて、ＳＦＸを特定するのに使用する）
	int32_t sfxVariationId_008;

	// 名前：重量[kg]
	// 説明：重量[kg]
	float weight_00C;

	// 名前：行動ID
	// 説明：行動ID(=Skill)
	int32_t behaviorId_010;

	// 名前：基本価格
	// 説明：基本価格
	int32_t basicPrice_014;

	// 名前：売却価格
	// 説明：販売価格
	int32_t sellValue_018;

	// 名前：sortID
	int32_t sortId_01C;

	// 名前：QWCID
	int32_t qwcId_020;

	// 名前：装備モデル番号
	// 説明：装備モデルの番号
	uint16_t equipModelId_024;

	// 名前：アイコンID
	// 説明：メニューアイコンID
	uint16_t iconId_026;

	// 名前：ショップレベル
	// 説明：お店で販売できるレベル
	int16_t shopLv_028;

	// 名前：トロフィー
	int16_t trophySGradeId_02A;

	// 名前：トロフィーSEQ番号
	// 説明：トロフィーのSEQ番号
	int16_t trophySeqId_02C;

	// 名前：装備モデル種別
	// 説明：装備モデルの種別
	uint8_t equipModelCategory_02E;

	// 名前：装備モデル性別
	// 説明：装備モデルの性別
	uint8_t equipModelGender_02F;

	// 名前：装飾カテゴリ
	// 説明：防具のカテゴリ
	uint8_t accessoryCategory_030;

	// 名前：IDカテゴリ
	// 説明：↓のIDのカテゴリ[攻撃、飛び道具、特殊]
	uint8_t refCategory_031;

	// 名前：特殊効果カテゴリ
	// 説明：スキルや、魔法、アイテムなどで、パラメータが変動する効果（エンチャントウェポンなど）があるので、│定した効果が、「武器攻撃のみをパワーアップする」といった効果に対応できるように行動ごとに設定するバリスタなど、設定の必要のないものは「なし」を設定する

	uint8_t spEffectCategory_032;

	// 名前：ソートアイテム種別ID
	// 説明：ソートアイテム種別ID。ソート「アイテム種別順」にて、同じIDは同じグループとしてまとめて表示されます
	uint8_t sortGroupId_033;

	// 名前：ベイグラント時アイテム抽選ID_マップ用
	// 説明：-1：ベイグラントなし 0：抽選なし 1～：抽選あり
	int32_t vagrantItemLotId_034;

	// 名前：ベイグラントボーナス敵ドロップアイテム抽選ID_マップ用
	// 説明：-1：ドロップなし 0：抽選なし 1～：抽選あり
	int32_t vagrantBonusEneDropItemLotId_038;

	// 名前：ベイグラントアイテム敵ドロップアイテム抽選ID_マップ用
	// 説明：-1：ドロップなし 0：抽選なし 1～：抽選あり
	int32_t vagrantItemEneDropItemLotId_03C;

	// 名前：預けれるか
	// 説明：倉庫へ預けれるか
	uint8_t isDeposit_040: 1;

	// 名前：外すと壊れるか
	// 説明：装備して外す時に壊れるか
	uint8_t isEquipOutBrake_040: 1;

	// 名前：マルチドロップ共有禁止か
	// 説明：マルチドロップ共有禁止か
	uint8_t disableMultiDropShare_040: 1;

	// 名前：捨てれるか
	// 説明：アイテムを捨てれるか？TRUE=捨てれる
	uint8_t isDiscard_040: 1;

	// 名前：その場に置けるか
	// 説明：アイテムをその場に置けるか？TRUE=置ける
	uint8_t isDrop_040: 1;

	// 名前：取得ログ表示条件
	// 説明：アイテム取得時にアイテム取得ログに表示するか（未入力: ○）
	uint8_t showLogCondType_040: 1;

	// 名前：取得ダイアログ表示条件
	// 説明：アイテム取得時にアイテム取得ダイアログに表示するか（未入力: newのみ）
	uint8_t showDialogCondType_040: 2;

	// 名前：レア度
	// 説明：アイテム取得ログで使うレア度
	uint8_t rarity_041;

	// 名前：pad
	// 説明：（旧ログ用アイコンID）
	uint8_t pad2_042[2];

	// 名前：販売価格
	// 説明：販売価格
	int32_t saleValue_044;

	// 名前：装着グループID
	// 説明：同じグループの物は同時装備不可能
	int16_t accessoryGroup_048;

	// 名前：pad
	// 説明：pad
	uint8_t pad3_04A[1];

	// 名前：コンプトロフィーSEQ番号
	// 説明：コンプリート系トロフィのSEQ番号
	int8_t compTrophySedId_04B;

	// 名前：常駐特殊効果ID1
	// 説明：常駐特殊効果ID1
	int32_t residentSpEffectId1_04C;

	// 名前：常駐特殊効果ID2
	// 説明：常駐特殊効果ID2
	int32_t residentSpEffectId2_050;

	// 名前：常駐特殊効果ID3
	// 説明：常駐特殊効果ID3
	int32_t residentSpEffectId3_054;

	// 名前：常駐特殊効果ID4
	// 説明：常駐特殊効果ID4
	int32_t residentSpEffectId4_058;

	// 名前：pad
	// 説明：pad
	uint8_t pad1_05C[4];

} EquipParamAccessory;

#endif
