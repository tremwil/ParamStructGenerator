/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WwiseValueToStrConvertParamFormat_H
#define _PARAM_WwiseValueToStrConvertParamFormat_H
#include <stdint.h>

// WWISE_VALUE_TO_STR_CONVERT_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WwiseValueToStrConvertParamFormat {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：Wwiseパラメータ文字列
	// 説明：Wwiseパラメータ文字列
	char ParamStr_004[32];

} WwiseValueToStrConvertParamFormat;

#endif
