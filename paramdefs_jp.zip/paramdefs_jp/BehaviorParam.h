/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_BehaviorParam_H
#define _PARAM_BehaviorParam_H
#include <stdint.h>

// BEHAVIOR_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BehaviorParam {

	// 名前：行動バリエーションID
	// 説明：攻撃パラメータ用のIDを算出する際に使用します。実機上では直接使用しません。
	int32_t variationId_000;

	// 名前：行動判定ID
	// 説明：攻撃パラメータ用のIDを算出する際に使用します。このIDはTimeActEditorで入力される行動判定IDと一致させます。実機上では直接使用しません。
	int32_t behaviorJudgeId_004;

	// 名前：IDルール用
	// 説明：ID算出ルール用
	uint8_t ezStateBehaviorType_old_008;

	// 名前：参照IDタイプ
	// 説明：参照IDを間違わないように指定.
	uint8_t refType_009;

	// 名前：pad
	uint8_t pad2_00A[2];

	// 名前：参照ID
	// 説明：攻撃力、飛び道具、特殊効果パラメータのID、refTypeによって使い分けられる。
	int32_t refId_00C;

	// 名前：消費SA
	// 説明：行動時の消費SA量を設定.
	float consumeSA_010;

	// 名前：消費スタミナ
	// 説明：行動時の消費スタミナ量を設定.
	int32_t stamina_014;

	// 名前：武器耐久度消費（飛び道具時のみ）
	// 説明：行動時の消費武器耐久度を設定.
	int32_t consumeDurability_018;

	// 名前：カテゴリ
	// 説明：スキルや、魔法、アイテムなどで、パラメータが変動する効果（エンチャントウェポンなど）があるので、│定した効果が、「武器攻撃のみをパワーアップする」といった効果に対応できるように行動ごとに設定するバリスタなど、設定の必要のないものは「なし」を設定する
	uint8_t category_01C;

	// 名前：消費人間性
	// 説明：行動時の消費人間性量を設定
	uint8_t heroPoint_01D;

	// 名前：pad
	uint8_t pad1_01E[2];

} BehaviorParam;

#endif
