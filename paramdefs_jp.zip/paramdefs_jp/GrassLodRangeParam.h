/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_GrassLodRangeParam_H
#define _PARAM_GrassLodRangeParam_H
#include <stdint.h>

// GRASS_LOD_RANGE_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GrassLodRangeParam {

	// 名前：LOD0 - 距離
	float LOD0_range_000;

	// 名前：LOD0 - 遊び
	float LOD0_play_004;

	// 名前：LOD１ - 距離
	float LOD1_range_008;

	// 名前：LOD１ - 遊び
	float LOD1_play_00C;

	// 名前：LOD２ - 距離
	float LOD2_range_010;

	// 名前：LOD２ - 遊び
	float LOD2_play_014;

} GrassLodRangeParam;

#endif
