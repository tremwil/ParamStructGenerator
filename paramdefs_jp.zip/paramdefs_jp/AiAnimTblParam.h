/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AiAnimTblParam_H
#define _PARAM_AiAnimTblParam_H
#include <stdint.h>

// AI_ANIM_TBL_PARAM
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AiAnimTblParam {

	// 名前：攻撃1のEzStateアニメ番号
	// 説明：攻撃1のEzStateアニメ番号
	uint16_t atk0_EzStateId_000;

	// 名前：攻撃2のEzStateアニメ番号
	// 説明：攻撃2のEzStateアニメ番号
	uint16_t atk1_EzStateId_002;

	// 名前：攻撃3のEzStateアニメ番号
	// 説明：攻撃3のEzStateアニメ番号
	uint16_t atk2_EzStateId_004;

	// 名前：攻撃4のEzStateアニメ番号
	// 説明：攻撃4のEzStateアニメ番号
	uint16_t atk3_EzStateId_006;

	// 名前：攻撃5のEzStateアニメ番号
	// 説明：攻撃5のEzStateアニメ番号
	uint16_t atk4_EzStateId_008;

	// 名前：攻撃6のEzStateアニメ番号
	// 説明：攻撃6のEzStateアニメ番号
	uint16_t atk5_EzStateId_00A;

	// 名前：攻撃7のEzStateアニメ番号
	// 説明：攻撃7のEzStateアニメ番号
	uint16_t atk6_EzStateId_00C;

	// 名前：攻撃8のEzStateアニメ番号
	// 説明：攻撃8のEzStateアニメ番号
	uint16_t atk7_EzStateId_00E;

	// 名前：攻撃9のEzStateアニメ番号
	// 説明：攻撃9のEzStateアニメ番号
	uint16_t atk8_EzStateId_010;

	// 名前：攻撃10のEzStateアニメ番号
	// 説明：攻撃10のEzStateアニメ番号
	uint16_t atk9_EzStateId_012;

	// 名前：攻撃11のEzStateアニメ番号
	// 説明：攻撃11のEzStateアニメ番号
	uint16_t atk10_EzStateId_014;

	// 名前：攻撃12のEzStateアニメ番号
	// 説明：攻撃12のEzStateアニメ番号
	uint16_t atk11_EzStateId_016;

	// 名前：攻撃13のEzStateアニメ番号
	// 説明：攻撃13のEzStateアニメ番号
	uint16_t atk12_EzStateId_018;

	// 名前：攻撃14のEzStateアニメ番号
	// 説明：攻撃14のEzStateアニメ番号
	uint16_t atk13_EzStateId_01A;

	// 名前：攻撃15のEzStateアニメ番号
	// 説明：攻撃15のEzStateアニメ番号
	uint16_t atk14_EzStateId_01C;

	// 名前：攻撃16のEzStateアニメ番号
	// 説明：攻撃16のEzStateアニメ番号
	uint16_t atk15_EzStateId_01E;

	// 名前：攻撃17のEzStateアニメ番号
	// 説明：攻撃17のEzStateアニメ番号
	uint16_t atk16_EzStateId_020;

	// 名前：攻撃18のEzStateアニメ番号
	// 説明：攻撃18のEzStateアニメ番号
	uint16_t atk17_EzStateId_022;

	// 名前：攻撃19のEzStateアニメ番号
	// 説明：攻撃19のEzStateアニメ番号
	uint16_t atk18_EzStateId_024;

	// 名前：攻撃20のEzStateアニメ番号
	// 説明：攻撃20のEzStateアニメ番号
	uint16_t atk19_EzStateId_026;

	// 名前：攻撃21のEzStateアニメ番号
	// 説明：攻撃21のEzStateアニメ番号
	uint16_t atk20_EzStateId_028;

	// 名前：攻撃22のEzStateアニメ番号
	// 説明：攻撃22のEzStateアニメ番号
	uint16_t atk21_EzStateId_02A;

	// 名前：攻撃23のEzStateアニメ番号
	// 説明：攻撃23のEzStateアニメ番号
	uint16_t atk22_EzStateId_02C;

	// 名前：攻撃24のEzStateアニメ番号
	// 説明：攻撃24のEzStateアニメ番号
	uint16_t atk23_EzStateId_02E;

	// 名前：攻撃25のEzStateアニメ番号
	// 説明：攻撃25のEzStateアニメ番号
	uint16_t atk24_EzStateId_030;

	// 名前：攻撃26のEzStateアニメ番号
	// 説明：攻撃26のEzStateアニメ番号
	uint16_t atk25_EzStateId_032;

	// 名前：攻撃27のEzStateアニメ番号
	// 説明：攻撃27のEzStateアニメ番号
	uint16_t atk26_EzStateId_034;

	// 名前：攻撃28のEzStateアニメ番号
	// 説明：攻撃28のEzStateアニメ番号
	uint16_t atk27_EzStateId_036;

	// 名前：攻撃29のEzStateアニメ番号
	// 説明：攻撃29のEzStateアニメ番号
	uint16_t atk28_EzStateId_038;

	// 名前：攻撃30のEzStateアニメ番号
	// 説明：攻撃30のEzStateアニメ番号
	uint16_t atk29_EzStateId_03A;

	// 名前：攻撃1の最小間合距離[cm]
	// 説明：攻撃1の最小間合距離[cm]
	uint16_t atk0_MinDist_03C;

	// 名前：攻撃2の最小間合距離[cm]
	// 説明：攻撃2の最小間合距離[cm]
	uint16_t atk1_MinDist_03E;

	// 名前：攻撃3の最小間合距離[cm]
	// 説明：攻撃3の最小間合距離[cm]
	uint16_t atk2_MinDist_040;

	// 名前：攻撃4の最小間合距離[cm]
	// 説明：攻撃4の最小間合距離[cm]
	uint16_t atk3_MinDist_042;

	// 名前：攻撃5の最小間合距離[cm]
	// 説明：攻撃5の最小間合距離[cm]
	uint16_t atk4_MinDist_044;

	// 名前：攻撃6の最小間合距離[cm]
	// 説明：攻撃6の最小間合距離[cm]
	uint16_t atk5_MinDist_046;

	// 名前：攻撃7の最小間合距離[cm]
	// 説明：攻撃7の最小間合距離[cm]
	uint16_t atk6_MinDist_048;

	// 名前：攻撃8の最小間合距離[cm]
	// 説明：攻撃8の最小間合距離[cm]
	uint16_t atk7_MinDist_04A;

	// 名前：攻撃9の最小間合距離[cm]
	// 説明：攻撃9の最小間合距離[cm]
	uint16_t atk8_MinDist_04C;

	// 名前：攻撃10の最小間合距離[cm]
	// 説明：攻撃10の最小間合距離[cm]
	uint16_t atk9_MinDist_04E;

	// 名前：攻撃11の最小間合距離[cm]
	// 説明：攻撃11の最小間合距離[cm]
	uint16_t atk10_MinDist_050;

	// 名前：攻撃12の最小間合距離[cm]
	// 説明：攻撃12の最小間合距離[cm]
	uint16_t atk11_MinDist_052;

	// 名前：攻撃13の最小間合距離[cm]
	// 説明：攻撃13の最小間合距離[cm]
	uint16_t atk12_MinDist_054;

	// 名前：攻撃14の最小間合距離[cm]
	// 説明：攻撃14の最小間合距離[cm]
	uint16_t atk13_MinDist_056;

	// 名前：攻撃15の最小間合距離[cm]
	// 説明：攻撃15の最小間合距離[cm]
	uint16_t atk14_MinDist_058;

	// 名前：攻撃16の最小間合距離[cm]
	// 説明：攻撃16の最小間合距離[cm]
	uint16_t atk15_MinDist_05A;

	// 名前：攻撃17の最小間合距離[cm]
	// 説明：攻撃17の最小間合距離[cm]
	uint16_t atk16_MinDist_05C;

	// 名前：攻撃18の最小間合距離[cm]
	// 説明：攻撃18の最小間合距離[cm]
	uint16_t atk17_MinDist_05E;

	// 名前：攻撃19の最小間合距離[cm]
	// 説明：攻撃19の最小間合距離[cm]
	uint16_t atk18_MinDist_060;

	// 名前：攻撃20の最小間合距離[cm]
	// 説明：攻撃20の最小間合距離[cm]
	uint16_t atk19_MinDist_062;

	// 名前：攻撃21の最小間合距離[cm]
	// 説明：攻撃21の最小間合距離[cm]
	uint16_t atk20_MinDist_064;

	// 名前：攻撃22の最小間合距離[cm]
	// 説明：攻撃22の最小間合距離[cm]
	uint16_t atk21_MinDist_066;

	// 名前：攻撃23の最小間合距離[cm]
	// 説明：攻撃23の最小間合距離[cm]
	uint16_t atk22_MinDist_068;

	// 名前：攻撃24の最小間合距離[cm]
	// 説明：攻撃24の最小間合距離[cm]
	uint16_t atk23_MinDist_06A;

	// 名前：攻撃25の最小間合距離[cm]
	// 説明：攻撃25の最小間合距離[cm]
	uint16_t atk24_MinDist_06C;

	// 名前：攻撃26の最小間合距離[cm]
	// 説明：攻撃26の最小間合距離[cm]
	uint16_t atk25_MinDist_06E;

	// 名前：攻撃27の最小間合距離[cm]
	// 説明：攻撃27の最小間合距離[cm]
	uint16_t atk26_MinDist_070;

	// 名前：攻撃28の最小間合距離[cm]
	// 説明：攻撃28の最小間合距離[cm]
	uint16_t atk27_MinDist_072;

	// 名前：攻撃29の最小間合距離[cm]
	// 説明：攻撃29の最小間合距離[cm]
	uint16_t atk28_MinDist_074;

	// 名前：攻撃30の最小間合距離[cm]
	// 説明：攻撃30の最小間合距離[cm]
	uint16_t atk29_MinDist_076;

	// 名前：攻撃1の最大間合い距離[cm]
	// 説明：攻撃1の最大間合い距離[cm]
	uint16_t atk0_MaxDist_078;

	// 名前：攻撃2の最大間合距離[cm]
	// 説明：攻撃2の最大間合距離[cm]
	uint16_t atk1_MaxDist_07A;

	// 名前：攻撃3の最大間合距離[cm]
	// 説明：攻撃3の最大間合距離[cm]
	uint16_t atk2_MaxDist_07C;

	// 名前：攻撃4の最大間合距離[cm]
	// 説明：攻撃4の最大間合距離[cm]
	uint16_t atk3_MaxDist_07E;

	// 名前：攻撃5の最大間合距離[cm]
	// 説明：攻撃5の最大間合距離[cm]
	uint16_t atk4_MaxDist_080;

	// 名前：攻撃6の最大間合距離[cm]
	// 説明：攻撃6の最大間合距離[cm]
	uint16_t atk5_MaxDist_082;

	// 名前：攻撃7の最大間合距離[cm]
	// 説明：攻撃7の最大間合距離[cm]
	uint16_t atk6_MaxDist_084;

	// 名前：攻撃8の最大間合距離[cm]
	// 説明：攻撃8の最大間合距離[cm]
	uint16_t atk7_MaxDist_086;

	// 名前：攻撃9の最大間合距離[cm]
	// 説明：攻撃9の最大間合距離[cm]
	uint16_t atk8_MaxDist_088;

	// 名前：攻撃10の最大間合距離[cm]
	// 説明：攻撃10の最大間合距離[cm]
	uint16_t atk9_MaxDist_08A;

	// 名前：攻撃11の最大間合距離[cm]
	// 説明：攻撃11の最大間合距離[cm]
	uint16_t atk10_MaxDist_08C;

	// 名前：攻撃12の最大間合距離[cm]
	// 説明：攻撃12の最大間合距離[cm]
	uint16_t atk11_MaxDist_08E;

	// 名前：攻撃13の最大間合距離[cm]
	// 説明：攻撃13の最大間合距離[cm]
	uint16_t atk12_MaxDist_090;

	// 名前：攻撃14の最大間合距離[cm]
	// 説明：攻撃14の最大間合距離[cm]
	uint16_t atk13_MaxDist_092;

	// 名前：攻撃15の最大間合距離[cm]
	// 説明：攻撃15の最大間合距離[cm]
	uint16_t atk14_MaxDist_094;

	// 名前：攻撃16の最大間合距離[cm]
	// 説明：攻撃16の最大間合距離[cm]
	uint16_t atk15_MaxDist_096;

	// 名前：攻撃17の最大間合距離[cm]
	// 説明：攻撃17の最大間合距離[cm]
	uint16_t atk16_MaxDist_098;

	// 名前：攻撃18の最大間合距離[cm]
	// 説明：攻撃18の最大間合距離[cm]
	uint16_t atk17_MaxDist_09A;

	// 名前：攻撃19の最大間合距離[cm]
	// 説明：攻撃19の最大間合距離[cm]
	uint16_t atk18_MaxDist_09C;

	// 名前：攻撃20の最大間合距離[cm]
	// 説明：攻撃20の最大間合距離[cm]
	uint16_t atk19_MaxDist_09E;

	// 名前：攻撃21の最大間合距離[cm]
	// 説明：攻撃21の最大間合距離[cm]
	uint16_t atk20_MaxDist_0A0;

	// 名前：攻撃22の最大間合距離[cm]
	// 説明：攻撃22の最大間合距離[cm]
	uint16_t atk21_MaxDist_0A2;

	// 名前：攻撃23の最大間合距離[cm]
	// 説明：攻撃23の最大間合距離[cm]
	uint16_t atk22_MaxDist_0A4;

	// 名前：攻撃24の最大間合距離[cm]
	// 説明：攻撃24の最大間合距離[cm]
	uint16_t atk23_MaxDist_0A6;

	// 名前：攻撃25の最大間合距離[cm]
	// 説明：攻撃25の最大間合距離[cm]
	uint16_t atk24_MaxDist_0A8;

	// 名前：攻撃26の最大間合距離[cm]
	// 説明：攻撃26の最大間合距離[cm]
	uint16_t atk25_MaxDist_0AA;

	// 名前：攻撃27の最大間合距離[cm]
	// 説明：攻撃27の最大間合距離[cm]
	uint16_t atk26_MaxDist_0AC;

	// 名前：攻撃28の最大間合距離[cm]
	// 説明：攻撃28の最大間合距離[cm]
	uint16_t atk27_MaxDist_0AE;

	// 名前：攻撃29の最大間合距離[cm]
	// 説明：攻撃29の最大間合距離[cm]
	uint16_t atk28_MaxDist_0B0;

	// 名前：攻撃30の最大間合距離[cm]
	// 説明：攻撃30の最大間合距離[cm]
	uint16_t atk29_MaxDist_0B2;

	// 名前：攻撃1の攻撃成功距離タイプ
	// 説明：攻撃1の攻撃成功距離タイプ
	uint8_t atk0_AtkDistType_0B4: 4;

	// 名前：攻撃2の攻撃成功距離タイプ
	// 説明：攻撃2の攻撃成功距離タイプ
	uint8_t atk1_AtkDistType_0B4: 4;

	// 名前：攻撃3の攻撃成功距離タイプ
	// 説明：攻撃3の攻撃成功距離タイプ
	uint8_t atk2_AtkDistType_0B5: 4;

	// 名前：攻撃4の攻撃成功距離タイプ
	// 説明：攻撃4の攻撃成功距離タイプ
	uint8_t atk3_AtkDistType_0B5: 4;

	// 名前：攻撃5の攻撃成功距離タイプ
	// 説明：攻撃5の攻撃成功距離タイプ
	uint8_t atk4_AtkDistType_0B6: 4;

	// 名前：攻撃6の攻撃成功距離タイプ
	// 説明：攻撃6の攻撃成功距離タイプ
	uint8_t atk5_AtkDistType_0B6: 4;

	// 名前：攻撃7の攻撃成功距離タイプ
	// 説明：攻撃7の攻撃成功距離タイプ
	uint8_t atk6_AtkDistType_0B7: 4;

	// 名前：攻撃8の攻撃成功距離タイプ
	// 説明：攻撃8の攻撃成功距離タイプ
	uint8_t atk7_AtkDistType_0B7: 4;

	// 名前：攻撃9の攻撃成功距離タイプ
	// 説明：攻撃9の攻撃成功距離タイプ
	uint8_t atk8_AtkDistType_0B8: 4;

	// 名前：攻撃10の攻撃成功距離タイプ
	// 説明：攻撃10の攻撃成功距離タイプ
	uint8_t atk9_AtkDistType_0B8: 4;

	// 名前：攻撃11の攻撃成功距離タイプ
	// 説明：攻撃11の攻撃成功距離タイプ
	uint8_t atk10_AtkDistType_0B9: 4;

	// 名前：攻撃12の攻撃成功距離タイプ
	// 説明：攻撃12の攻撃成功距離タイプ
	uint8_t atk11_AtkDistType_0B9: 4;

	// 名前：攻撃13の攻撃成功距離タイプ
	// 説明：攻撃13の攻撃成功距離タイプ
	uint8_t atk12_AtkDistType_0BA: 4;

	// 名前：攻撃14の攻撃成功距離タイプ
	// 説明：攻撃14の攻撃成功距離タイプ
	uint8_t atk13_AtkDistType_0BA: 4;

	// 名前：攻撃15の攻撃成功距離タイプ
	// 説明：攻撃15の攻撃成功距離タイプ
	uint8_t atk14_AtkDistType_0BB: 4;

	// 名前：攻撃16の攻撃成功距離タイプ
	// 説明：攻撃16の攻撃成功距離タイプ
	uint8_t atk15_AtkDistType_0BB: 4;

	// 名前：攻撃17の攻撃成功距離タイプ
	// 説明：攻撃17の攻撃成功距離タイプ
	uint8_t atk16_AtkDistType_0BC: 4;

	// 名前：攻撃18の攻撃成功距離タイプ
	// 説明：攻撃18の攻撃成功距離タイプ
	uint8_t atk17_AtkDistType_0BC: 4;

	// 名前：攻撃19の攻撃成功距離タイプ
	// 説明：攻撃19の攻撃成功距離タイプ
	uint8_t atk18_AtkDistType_0BD: 4;

	// 名前：攻撃20の攻撃成功距離タイプ
	// 説明：攻撃20の攻撃成功距離タイプ
	uint8_t atk19_AtkDistType_0BD: 4;

	// 名前：攻撃21の攻撃成功距離タイプ
	// 説明：攻撃21の攻撃成功距離タイプ
	uint8_t atk20_AtkDistType_0BE: 4;

	// 名前：攻撃22の攻撃成功距離タイプ
	// 説明：攻撃22の攻撃成功距離タイプ
	uint8_t atk21_AtkDistType_0BE: 4;

	// 名前：攻撃23の攻撃成功距離タイプ
	// 説明：攻撃23の攻撃成功距離タイプ
	uint8_t atk22_AtkDistType_0BF: 4;

	// 名前：攻撃24の攻撃成功距離タイプ
	// 説明：攻撃24の攻撃成功距離タイプ
	uint8_t atk23_AtkDistType_0BF: 4;

	// 名前：攻撃25の攻撃成功距離タイプ
	// 説明：攻撃25の攻撃成功距離タイプ
	uint8_t atk24_AtkDistType_0C0: 4;

	// 名前：攻撃26の攻撃成功距離タイプ
	// 説明：攻撃26の攻撃成功距離タイプ
	uint8_t atk25_AtkDistType_0C0: 4;

	// 名前：攻撃27の攻撃成功距離タイプ
	// 説明：攻撃27の攻撃成功距離タイプ
	uint8_t atk26_AtkDistType_0C1: 4;

	// 名前：攻撃28の攻撃成功距離タイプ
	// 説明：攻撃28の攻撃成功距離タイプ
	uint8_t atk27_AtkDistType_0C1: 4;

	// 名前：攻撃29の攻撃成功距離タイプ
	// 説明：攻撃29の攻撃成功距離タイプ
	uint8_t atk28_AtkDistType_0C2: 4;

	// 名前：攻撃30の攻撃成功距離タイプ
	// 説明：攻撃30の攻撃成功距離タイプ
	uint8_t atk29_AtkDistType_0C2: 4;

	// 名前：pad
	// 説明：pad
	uint8_t pad0_0C3[13];

} AiAnimTblParam;

#endif
