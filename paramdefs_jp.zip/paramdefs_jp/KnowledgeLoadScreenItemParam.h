/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_KnowledgeLoadScreenItemParam_H
#define _PARAM_KnowledgeLoadScreenItemParam_H
#include <stdint.h>

// KNOWLEDGE_LOADSCREEN_ITEM_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _KnowledgeLoadScreenItemParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：解禁フラグ
	// 説明：解禁フラグ(default: 0)。このイベントフラグが立っていれば解禁される（ローディング画面に表示される）。0なら常に解禁されている。無効フラグの方が優先される
	uint32_t unlockFlagId_004;

	// 名前：無効フラグ
	// 説明：無効フラグ(default: 0)。このイベントフラグが立っていると無効化（ローディング画面に表示されなくなる）。0なら常にこのフラグは立っていないものとする
	uint32_t invalidFlagId_008;

	// 名前：テキストID
	// 説明：テキストID(Loading Text.xlsx)。ローディングタイトルとローディングテキスト両方に使われる
	int32_t msgId_00C;

} KnowledgeLoadScreenItemParam;

#endif
