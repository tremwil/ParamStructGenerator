/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MagicParam_H
#define _PARAM_MagicParam_H
#include <stdint.h>

// MAGIC_PARAM_ST
// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MagicParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：Yes/NoダイアログメッセージID
	// 説明：魔法使用時に出すYes/NoダイアログのメッセージID
	int32_t yesNoDialogMessageId_004;

	// 名前：使用制限から外れる特殊効果ID
	// 説明：指定した特殊効果IDが発動している時は使用制限を無視できる
	int32_t limitCancelSpEffectId_008;

	// 名前：SortID
	// 説明：ソートID(-1:集めない)
	int16_t sortId_00C;

	// 名前：装備条件【運】
	// 説明：PCの運がこれ以上無いと装備できない
	uint8_t requirementLuck_00E;

	// 名前：AI通知タイプ
	// 説明：act("魔法発動時AI通知")でAIインタラプトが発生する
	uint8_t aiNotifyType_00F;

	// 名前：消費MP[通常]
	// 説明：消費MP
	int16_t mp_010;

	// 名前：消費スタミナ[通常]
	// 説明：消費スタミナ
	int16_t stamina_012;

	// 名前：アイコンID
	// 説明：アイコンを指定　＞メニュー用
	int16_t iconId_014;

	// 名前：行動ID
	// 説明：行動IDを設定する
	int16_t behaviorId_016;

	// 名前：必要アイテムID
	// 説明：購入に必要なアイテムID
	int16_t mtrlItemId_018;

	// 名前：差し替える魔法ID
	// 説明：状態変化一致時に差し替えるID(-1:無効)
	int16_t replaceMagicId_01A;

	// 名前：最大個数
	// 説明：１個当たりの個数(-1:無限)
	int16_t maxQuantity_01C;

	// 名前：IDカテゴリ
	// 説明：呼び出しIDのカテゴリ[攻撃、飛び道具、特殊効果]
	uint8_t refCategory1_01E;

	// 名前：技量オーバー開始値
	// 説明：技量オーバー開始値
	uint8_t overDexterity_01F;

	// 名前：IDカテゴリ
	// 説明：呼び出しIDのカテゴリ[攻撃、飛び道具、特殊効果]
	uint8_t refCategory2_020;

	// 名前：必要スロット
	// 説明：装備に必要なスロット数 ＞メニュー用
	uint8_t slotLength_021;

	// 名前：装備条件【知力】
	// 説明：PCの知力がこれ以上無いと装備できない
	uint8_t requirementIntellect_022;

	// 名前：装備条件【理力】
	// 説明：PCの理力がこれ以上無いと装備できない
	uint8_t requirementFaith_023;

	// 名前：アナログ最低技量
	// 説明：モーションキャンセルアナログ化：最低技量値
	uint8_t analogDexterityMin_024;

	// 名前：アナログ最大技量
	// 説明：モーションキャンセルアナログ化：最高技量値
	uint8_t analogDexterityMax_025;

	// 名前：カテゴリ
	// 説明：並べ替えに使用　＞メニュー用
	uint8_t ezStateBehaviorType_026;

	// 名前：IDカテゴリ
	// 説明：呼び出しIDのカテゴリ[攻撃、飛び道具、特殊効果]
	uint8_t refCategory3_027;

	// 名前：特殊効果カテゴリ
	// 説明：スキルや、魔法、アイテムなどで、パラメータが変動する効果（エンチャントウェポンなど）があるので、│定した効果が、「武器攻撃のみをパワーアップする」といった効果に対応できるように行動ごとに設定するバリスタなど、設定の必要のないものは「なし」を設定する

	uint8_t spEffectCategory_028;

	// 名前：モーションカテゴリ
	// 説明：モーションを指定　＞EzState用
	uint8_t refType_029;

	// 名前：使用時メニュータイプ
	// 説明：魔法使用時に出すメニュータイプ
	uint8_t opmeMenuType_02A;

	// 名前：IDカテゴリ
	// 説明：呼び出しIDのカテゴリ[攻撃、飛び道具、特殊効果]
	uint8_t refCategory4_02B;

	// 名前：どの常態か？
	// 説明：魔法IDを差し替える必要がある状態変化を指定
	uint16_t hasSpEffectType_02C;

	// 名前：差し替えカテゴリ
	// 説明：魔法IDを差し替える時の追加条件
	uint8_t replaceCategory_02E;

	// 名前：特殊効果カテゴリによる使用制限
	// 説明：特殊効果によって使用可能かどうかを制御する為に指定
	uint8_t useLimitCategory_02F;

	// 名前：誓約0
	// 説明：誓約0
	uint8_t vowType0_030: 1;

	// 名前：誓約1
	// 説明：誓約1
	uint8_t vowType1_030: 1;

	// 名前：誓約2
	// 説明：誓約2
	uint8_t vowType2_030: 1;

	// 名前：誓約3
	// 説明：誓約3
	uint8_t vowType3_030: 1;

	// 名前：誓約4
	// 説明：誓約4
	uint8_t vowType4_030: 1;

	// 名前：誓約5
	// 説明：誓約5
	uint8_t vowType5_030: 1;

	// 名前：誓約6
	// 説明：誓約6
	uint8_t vowType6_030: 1;

	// 名前：誓約7
	// 説明：誓約7
	uint8_t vowType7_030: 1;

	// 名前：マルチでも使用可能か
	// 説明：マルチでも使用できるか。シングル、マルチ両方で使える
	uint8_t enable_multi_031: 1;

	// 名前：マルチ専用か
	// 説明：マルチ専用か。シングルのときには使えない。マルチのときは使える。
	uint8_t enable_multi_only_031: 1;

	// 名前：エンチャントか
	// 説明：エンチャントする魔法か
	uint8_t isEnchant_031: 1;

	// 名前：盾エンチャントか
	// 説明：ガード・盾エンチャントする魔法か
	uint8_t isShieldEnchant_031: 1;

	// 名前：生存使用可
	// 説明：生存キャラが使用可能か
	uint8_t enable_live_031: 1;

	// 名前：グレイ使用可
	// 説明：グレイキャラが使用可能か
	uint8_t enable_gray_031: 1;

	// 名前：白使用可
	// 説明：白ゴーストキャラが使用可能か
	uint8_t enable_white_031: 1;

	// 名前：黒使用可
	// 説明：黒ゴーストキャラが使用可能か
	uint8_t enable_black_031: 1;

	// 名前：オフラインで使用不可か
	// 説明：オフラインで使用不可か
	uint8_t disableOffline_032: 1;

	// 名前：共鳴魔法配信するか
	// 説明：共鳴魔法配信するか
	uint8_t castResonanceMagic_032: 1;

	// 名前：防具SAダメージ倍率が初期値でも有効か？
	// 説明：防具SAが初期値でも強靭度計算が行われるかどうか。詳細は強靭度仕様書.xlsxを確認してください
	uint8_t isValidTough_ProtSADmg_032: 1;

	// 名前：ワープ魔法か
	// 説明：ワープする魔法か。ここにチェックが入っている魔法は特殊効果「ワープ禁止」により使用が禁止されます
	uint8_t isWarpMagic_032: 1;

	// 名前：騎乗中使用可能か
	// 説明：騎乗中使用可能か
	uint8_t enableRiding_032: 1;

	// 名前：非騎乗中使用禁止か
	// 説明：非騎乗中使用禁止か
	uint8_t disableRiding_032: 1;

	// 名前：攻撃禁止区域で使用できるか
	// 説明：攻撃禁止区域で使用できるか
	uint8_t isUseNoAttackRegion_032: 1;

	// 名前：pading
	uint8_t pad_1_032: 1;

	// 名前：誓約8
	// 説明：誓約8
	uint8_t vowType8_033: 1;

	// 名前：誓約9
	// 説明：誓約9
	uint8_t vowType9_033: 1;

	// 名前：誓約10
	// 説明：誓約10
	uint8_t vowType10_033: 1;

	// 名前：誓約11
	// 説明：誓約11
	uint8_t vowType11_033: 1;

	// 名前：誓約12
	// 説明：誓約12
	uint8_t vowType12_033: 1;

	// 名前：誓約13
	// 説明：誓約13
	uint8_t vowType13_033: 1;

	// 名前：誓約14
	// 説明：誓約14
	uint8_t vowType14_033: 1;

	// 名前：誓約15
	// 説明：誓約15
	uint8_t vowType15_033: 1;

	// 名前：詠唱SFXID
	// 説明：魔法詠唱中のSFXID
	int32_t castSfxId_034;

	// 名前：発動SFXID
	// 説明：魔法発動時のSFXID
	int32_t fireSfxId_038;

	// 名前：効果SFXID
	// 説明：魔法効果中のSFXID
	int32_t effectSfxId_03C;

	// 名前：強靭度 補正倍率
	// 説明：強靭度の基本値を補正する倍率です
	float toughnessCorrectRate_040;

	// 名前：差し替えステータスタイプ
	// 説明：差し替えステータスタイプ
	uint8_t ReplacementStatusType_044;

	// 名前：差し替えステータス値1
	// 説明：差し替えステータス値1
	int8_t ReplacementStatus1_045;

	// 名前：差し替えステータス値2
	// 説明：差し替えステータス値2
	int8_t ReplacementStatus2_046;

	// 名前：差し替えステータス値3
	// 説明：差し替えステータス値3
	int8_t ReplacementStatus3_047;

	// 名前：差し替えステータス値4
	// 説明：差し替えステータス値4
	int8_t ReplacementStatus4_048;

	// 名前：IDカテゴリ
	// 説明：呼び出しIDのカテゴリ[攻撃、飛び道具、特殊効果]
	uint8_t refCategory5_049;

	// 名前：消費SA[通常/溜め]
	// 説明：消費SA量[通常/溜め]
	int16_t consumeSA_04A;

	// 名前：差し替えID1
	// 説明：差し替えID1
	int32_t ReplacementMagic1_04C;

	// 名前：差し替えID2
	// 説明：差し替えID2
	int32_t ReplacementMagic2_050;

	// 名前：差し替えID3
	// 説明：差し替えID3
	int32_t ReplacementMagic3_054;

	// 名前：差し替えID4
	// 説明：差し替えID4
	int32_t ReplacementMagic4_058;

	// 名前：消費MP[溜め]
	// 説明：消費MP[溜め]
	int16_t mp_charge_05C;

	// 名前：消費スタミナ[溜め]
	// 説明：消費スタミナ[溜め]
	int16_t stamina_charge_05E;

	// 名前：作成制限グループId
	// 説明：0なら未使用。指定したグループIdの弾丸作成数を確認し、上限に達していたら魔法の使用をできなくする。
	uint8_t createLimitGroupId_060;

	// 名前：IDカテゴリ
	// 説明：呼び出しIDのカテゴリ[攻撃、飛び道具、特殊効果]
	uint8_t refCategory6_061;

	// 名前：サブカテゴリ1
	// 説明：サブカテゴリ1
	uint8_t subCategory1_062;

	// 名前：サブカテゴリ2
	// 説明：サブカテゴリ2
	uint8_t subCategory2_063;

	// 名前：IDカテゴリ
	// 説明：呼び出しIDのカテゴリ[攻撃、飛び道具、特殊効果]
	uint8_t refCategory7_064;

	// 名前：IDカテゴリ
	// 説明：呼び出しIDのカテゴリ[攻撃、飛び道具、特殊効果]
	uint8_t refCategory8_065;

	// 名前：IDカテゴリ
	// 説明：呼び出しIDのカテゴリ[攻撃、飛び道具、特殊効果]
	uint8_t refCategory9_066;

	// 名前：IDカテゴリ
	// 説明：呼び出しIDのカテゴリ[攻撃、飛び道具、特殊効果]
	uint8_t refCategory10_067;

	// 名前：呼び出しID
	// 説明：魔法から呼び出すID
	int32_t refId1_068;

	// 名前：呼び出しID
	// 説明：魔法から呼び出すID
	int32_t refId2_06C;

	// 名前：呼び出しID
	// 説明：魔法から呼び出すID
	int32_t refId3_070;

	// 名前：AI使用判断ID
	// 説明：AI使用判断ID
	int32_t aiUseJudgeId_074;

	// 名前：呼び出しID
	// 説明：魔法から呼び出すID
	int32_t refId4_078;

	// 名前：呼び出しID
	// 説明：魔法から呼び出すID
	int32_t refId5_07C;

	// 名前：呼び出しID
	// 説明：魔法から呼び出すID
	int32_t refId6_080;

	// 名前：呼び出しID
	// 説明：魔法から呼び出すID
	int32_t refId7_084;

	// 名前：呼び出しID
	// 説明：魔法から呼び出すID
	int32_t refId8_088;

	// 名前：呼び出しID
	// 説明：魔法から呼び出すID
	int32_t refId9_08C;

	// 名前：呼び出しID
	// 説明：魔法から呼び出すID
	int32_t refId10_090;

	// 名前：消費タイプ
	// 説明：消費タイプ
	uint8_t consumeType1_094;

	// 名前：消費タイプ
	// 説明：消費タイプ
	uint8_t consumeType2_095;

	// 名前：消費タイプ
	// 説明：消費タイプ
	uint8_t consumeType3_096;

	// 名前：消費タイプ
	// 説明：消費タイプ
	uint8_t consumeType4_097;

	// 名前：消費タイプ
	// 説明：消費タイプ
	uint8_t consumeType5_098;

	// 名前：消費タイプ
	// 説明：消費タイプ
	uint8_t consumeType6_099;

	// 名前：消費タイプ
	// 説明：消費タイプ
	uint8_t consumeType7_09A;

	// 名前：消費タイプ
	// 説明：消費タイプ
	uint8_t consumeType8_09B;

	// 名前：消費タイプ
	// 説明：消費タイプ
	uint8_t consumeType9_09C;

	// 名前：消費タイプ
	// 説明：消費タイプ
	uint8_t consumeType10_09D;

	// 名前：メニュー補足表示用消費MP
	// 説明：メニュー補足表示用消費MP
	int16_t consumeLoopMP_forMenu_09E;

	// 名前：PAD12
	// 説明：PAD12
	uint8_t pad_0A0[8];

} MagicParam;

#endif
