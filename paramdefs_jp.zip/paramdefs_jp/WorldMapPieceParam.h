/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_WorldMapPieceParam_H
#define _PARAM_WorldMapPieceParam_H
#include <stdint.h>

// WORLD_MAP_PIECE_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _WorldMapPieceParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：開放イベントフラグID
	// 説明：開放条件のイベントフラグID
	uint32_t openEventFlagId_004;

	// 名前：開放される踏破エリア：Xmin
	// 説明：開放時に拡張する踏破エリアの座標（Xmin）
	float openTravelAreaLeft_008;

	// 名前：開放される踏破エリア：Xmax
	// 説明：開放時に拡張する踏破エリアの座標（Xmax）
	float openTravelAreaRight_00C;

	// 名前：開放される踏破エリア：Ymin
	// 説明：開放時に拡張する踏破エリアの座標（Ymin）
	float openTravelAreaTop_010;

	// 名前：開放される踏破エリア：Ymax
	// 説明：開放時に拡張する踏破エリアの座標（Ymax）
	float openTravelAreaBottom_014;

	// 名前：入手演出イベントフラグID
	// 説明：入手演出開始条件のイベントフラグID。いずれかの地図断片ひとつのみがOnになっている想定
	uint32_t acquisitionEventFlagId_018;

	// 名前：入手演出：表示倍率
	// 説明：入手演出時の表示倍率
	float acquisitionEventScale_01C;

	// 名前：入手演出：中心座標X
	// 説明：入手演出時の中心座標（X）
	float acquisitionEventCenterX_020;

	// 名前：入手演出：中心座標Y
	// 説明：入手演出時の中心座用（Y）
	float acquisitionEventCenterY_024;

	// 名前：入手演出：リソース倍率
	// 説明：入手演出用目隠しリソースの表示倍率
	float acquisitionEventResScale_028;

	// 名前：入手演出：リソースオフセットX
	// 説明：入手演出用目隠しリソースの表示位置オフセット（X）
	float acquisitionEventResOffsetX_02C;

	// 名前：入手演出：リソースオフセットY
	// 説明：入手演出用目隠しリソースの表示位置オフセット（Y）
	float acquisitionEventResOffsetY_030;

	// 名前：パッド
	uint8_t pad_034[12];

} WorldMapPieceParam;

#endif
