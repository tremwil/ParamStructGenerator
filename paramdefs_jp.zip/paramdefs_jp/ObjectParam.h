/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ObjectParam_H
#define _PARAM_ObjectParam_H
#include <stdint.h>

// OBJECT_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 106
typedef struct _ObjectParam {

	// 名前：HP
	// 説明：破壊までの耐久力(-1:破壊不可)
	int16_t hp_000;

	// 名前：防御力
	// 説明：この値以下の攻撃力はダメージなし
	uint16_t defense_002;

	// 名前：外部参照テクスチャID
	// 説明：mAA/mAA_????.tpf(-1:なし)(AA:エリア番号)
	int16_t extRefTexId_004;

	// 名前：材質ID
	// 説明：マテリアルID。床材質と同じ扱い。-1のときは今までと同じ挙動
	int16_t materialId_006;

	// 名前：アニメ破壊ID最大値
	// 説明：アニメ破壊IDが0番から何番までか
	uint8_t animBreakIdMax_008;

	// 名前：カメラが当たるか
	// 説明：カメラが当たるか(0:当たらない, 1:当たる)
	uint8_t isCamHit_009: 1;

	// 名前：プレイヤ衝突で壊れるか
	// 説明：プレイヤが接触したときに壊れ(0:ない, 1:る)
	uint8_t isBreakByPlayerCollide_009: 1;

	// 名前：アニメ破壊か
	// 説明：アニメ破壊か(0:物理破壊, 1:アニメ破壊)
	uint8_t isAnimBreak_009: 1;

	// 名前：貫通弾丸が当たるか
	// 説明：貫通弾丸が当たるか(0:当たらない, 1:当たる)
	uint8_t isPenetrationBulletHit_009: 1;

	// 名前：キャラが当たるか
	// 説明：キャラが当たるか(0:当たらない, 1:当たる)
	uint8_t isChrHit_009: 1;

	// 名前：攻撃を弾くか
	// 説明：攻撃を弾くか(0:弾かない, 1:弾く)
	uint8_t isAttackBacklash_009: 1;

	// 名前：初期出現用破壊禁止
	// 説明：プレイヤの初期出現で壊れ(0:る, 1:ない)
	uint8_t isDisableBreakForFirstAppear_009: 1;

	// 名前：ハシゴか
	// 説明：ハシゴか(0:ちがう, 1:そう)
	uint8_t isLadder_009: 1;

	// 名前：ポリ劇中アニメを停止するか
	// 説明：ポリ劇中アニメを停止するか(0:しない, 1:する)
	uint8_t isAnimPauseOnRemoPlay_00A: 1;

	// 名前：ダメージが当たらないか
	// 説明：ダメージが当たらない(0:当たる, 1:当たらない)
	uint8_t isDamageNoHit_00A: 1;

	// 名前：移動オブジェか
	// 説明：移動オブジェか(0:ちがう, 1:そう)
	uint8_t isMoveObj_00A: 1;

	// 名前：吊り橋オブジェクトか
	// 説明：吊り橋オブジェクトか(0:ちがう, 1:そう)
	uint8_t isRopeBridge_00A: 1;

	// 名前：ダメージによって剛体が吹き飛ぶか
	// 説明：ダメージによって剛体が吹き飛ぶか(0:吹き飛ばない, 1:吹き飛ぶ)
	uint8_t isAddRigidImpulse_ByDamage_00A: 1;

	// 名前：キャラが乗ったら壊れるか
	// 説明：キャラが乗ったら壊れるか(0:壊れるない 1:壊れる)
	uint8_t isBreak_ByChrRide_00A: 1;

	// 名前：燃焼するか
	// 説明：燃焼するか(0:しない, 1:する)
	uint8_t isBurn_00A: 1;

	// 名前：敵キャラ衝突で壊れるか
	// 説明：敵キャラが接触したときに壊れ(0:ない, 1:る)
	uint8_t isBreakByEnemyCollide_00A: 1;

	// 名前：デフォルトLODパラムID
	// 説明：デフォルトLODパラムID(-1：なし)
	int8_t defaultLodParamId_00B;

	// 名前：破壊時SFXID
	// 説明：オブジェ破壊時のSFXID(-1:デフォルト(810030))
	int32_t breakSfxId_00C;

	// 名前：破壊時SFXダミポリID
	// 説明：オブジェ破壊時SFXの発生位置ダミポリID(-1：配置位置）
	int32_t breakSfxCpId_010;

	// 名前：破壊時 弾発生 行動パラメータID
	// 説明：破壊時[弾]の行動パラメータ(-1:発生しない)
	int32_t breakBulletBehaviorId_014;

	// 名前：破壊時 弾発生 ダミポリID
	// 説明：破壊時[弾]の発生位置ダミポリID(-1:配置位置)
	int32_t breakBulletCpId_018;

	// 名前：落下破壊高さ(m)
	// 説明：落下時にオブジェクトが壊れる高さ（0：落下では壊れない)
	uint8_t breakFallHeight_01C;

	// 名前：風影響タイプ(破壊前)
	// 説明：風影響タイプ(破壊前)
	uint8_t windEffectType_0_01D;

	// 名前：風影響タイプ(破壊後)
	// 説明：風影響タイプ(破壊後)
	uint8_t windEffectType_1_01E;

	// 名前：カメラ回避設定
	// 説明：オブジェクトがカメラ・プレイヤー間を遮蔽した場合の対処方法
	uint8_t camAvoidType_01F;

	// 名前：風係数(破壊前)
	// 説明：風係数(破壊前)
	float windEffectRate_0_020;

	// 名前：風係数(破壊後)
	// 説明：風係数(破壊後)
	float windEffectRate_1_024;

	// 名前：破壊後強制停止時間
	// 説明：破壊されてから剛体を強制的に停止するまでの時間（0で強制停止しない）
	float breakStopTime_028;

	// 名前：燃焼時間(秒)
	// 説明：燃焼時間(秒)(0で燃え続ける)
	float burnTime_02C;

	// 名前：燃焼 破壊判定進行度
	// 説明：破壊状態に切り替わる燃焼度の閾値
	float burnBraekRate_030;

	// 名前：燃焼 SFXID：0
	// 説明：燃焼時のSFXID：0 (-1：SFXなし)
	int32_t burnSfxId_034;

	// 名前：燃焼 SFXID：1
	// 説明：燃焼時のSFXID：1 (-1：SFXなし)
	int32_t burnSfxId_1_038;

	// 名前：燃焼 SFXID：2
	// 説明：燃焼時のSFXID：2 (-1：SFXなし)
	int32_t burnSfxId_2_03C;

	// 名前：燃焼 SFXID：3
	// 説明：燃焼時のSFXID：3 (-1：SFXなし)
	int32_t burnSfxId_3_040;

	// 名前：燃焼 弾発生 行動パラメータ：0
	// 説明：燃焼時の弾発生行動パラメータ：0(-1:発生しない)
	int32_t burnBulletBehaviorId_044;

	// 名前：燃焼 弾発生 行動パラメータ：1
	// 説明：燃焼時の弾発生行動パラメータ：1(-1:発生しない)
	int32_t burnBulletBehaviorId_1_048;

	// 名前：燃焼 弾発生 行動パラメータ：2
	// 説明：燃焼時の弾発生行動パラメータ：2(-1:発生しない)
	int32_t burnBulletBehaviorId_2_04C;

	// 名前：燃焼 弾発生 行動パラメータ：3
	// 説明：燃焼時の弾発生行動パラメータ：3(-1:発生しない)
	int32_t burnBulletBehaviorId_3_050;

	// 名前：燃焼 弾発生間隔(フレーム)
	// 説明：延焼用の弾を発生する間隔(フレーム)
	uint16_t burnBulletInterval_054;

	// 名前：ナビメッシュフラグ
	// 説明：オブジェから設定されるナビメッシュフラグ
	uint8_t navimeshFlag_056;

	// 名前：衝突判定タイプ
	// 説明：衝突判定タイプ
	uint8_t collisionType_057;

	// 名前：燃焼 弾発生遅延時間(秒)
	// 説明：延焼用の弾発生を遅らせる時間(秒)
	float burnBulletDelayTime_058;

	// 名前：燃焼 SFX発生遅延 開始時間(秒)：0
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin_05C;

	// 名前：燃焼 SFX発生遅延 開始時間(秒)：1
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin_1_060;

	// 名前：燃焼 SFX発生遅延 開始時間(秒)：2
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin_2_064;

	// 名前：燃焼 SFX発生遅延 開始時間(秒)：3
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin_3_068;

	// 名前：燃焼 SFX発生遅延 終了時間(秒)：0
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax_06C;

	// 名前：燃焼 SFX発生遅延 終了時間(秒)：1
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax_1_070;

	// 名前：燃焼 SFX発生遅延 終了時間(秒)：2
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax_2_074;

	// 名前：燃焼 SFX発生遅延 終了時間(秒)：3
	// 説明：燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax_3_078;

	// 名前：破壊時発生AI音ID
	// 説明：破壊時に発生させるAI音ID
	int32_t BreakAiSoundID_07C;

	// 名前：破片非表示 待機時間(秒)
	// 説明：破片のマテリアルID(-1：非表示処理を行なわない)
	float FragmentInvisibleWaitTime_080;

	// 名前：破片非表示 時間(秒)
	// 説明：破片を非表示にさせる時間(秒)
	float FragmentInvisibleTime_084;

	// 名前：パディング
	// 説明：破片のマテリアルID(-1：非表示処理を行なわない)
	uint8_t pad_3_088[16];

	// 名前：剛体 衝突点距離係数 [柔らかい]
	// 説明：剛体ソフトコンタクト設定 衝突点距離係数 [柔らかい]
	float RigidPenetrationScale_Soft_098;

	// 名前：剛体 衝突点距離係数 [通常]
	// 説明：剛体ソフトコンタクト設定 衝突点距離係数 [通常]
	float RigidPenetrationScale_Normal_09C;

	// 名前：剛体 衝突点距離係数 [固い]
	// 説明：剛体ソフトコンタクト設定 衝突点距離係数 [固い]
	float RigidPenetrationScale_Hard_0A0;

	// 名前：地形接触時のSFXID
	// 説明：地形接触時のSFXID(-1:地形のマテリアルによりオフセット)
	int32_t LandTouchSfxId_0A4;

	// 名前：ダメージを遮蔽するか
	// 説明：ダメージを受けたときに、そのダメージを反対側に通さないかどうか　(0:通す, 1:通さない)
	uint8_t isDamageCover_0A8: 1;

	// 名前：パディング
	uint8_t pad_4_0A8[1];

	// 名前：ペイントデカールターゲットサイズ
	// 説明：ペイントデカールターゲットサイズ(0～4096 ２のべき乗のみ許可)
	uint16_t paintDecalTargetTextureSize_0A9;

	// 名前：動的生成Objの寿命(秒)
	// 説明：動的生成Objが生成後に消滅するまでの時間 (0:消滅しない)
	float lifeTime_forDC_0AB;

	// 名前：クロス更新距離(m)
	// 説明：havokClothの更新を行なうカメラからの距離(0:必ず更新する)
	float clothUpdateDist_0AF;

	// 名前：プレイヤー接触時SE ID
	// 説明：自分が操作するローカルプレイヤーが触れた際に再生するSEのID(-1:再生しない)
	int32_t contactSeId_0B3;

	// 名前：破壊後着地時SFX識別子
	// 説明：破壊された後、最初に着地した際に再生するオブジェ材質依存SFXの識別子(-1:発生しない)
	int32_t breakLandingSfxId_0B7;

	// 名前：ウェイポイントダミポリID_0
	// 説明：ウェイポイントダミポリID_0(-1:なし)
	int32_t waypointDummyPolyId_0_0BB;

	// 名前：ウェイポイントパラメータID_0
	// 説明：ウェイポイントパラメータID_0(-1:なし)
	int32_t waypointParamId_0_0BF;

	// 名前：サウンドのバンクID
	// 説明：サウンドのバンクID(-1:バンクなし, それ以外:指定したIDのバンク)
	int32_t soundBankId_0C3;

	// 名前：描画パラメータ参照ID
	// 説明：描画パラメータの参照ID
	int32_t refDrawParamId_0C7;

	// 名前：自動生成出現高さオフセット[m]
	// 説明：マップ自動生成OBJの出現高さオフセット[m]、レイキャストが当たったところから度ぐらい浮かすか
	float autoCreateDynamicOffsetHeight_0CB;

	// 名前：リザーブ
	// 説明：リザーブ
	int32_t reserved0_0CF;

	// 名前：破壊音SEID
	// 説明：破壊音SEID(9桁) -1：objIdから生成
	int32_t soundBreakSEId_0D3;

	// 名前：パディング
	uint8_t pad_5_0D7[40];

} ObjectParam;

#endif
