/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_ThrowParam_H
#define _PARAM_ThrowParam_H
#include <stdint.h>

// THROW_PARAM_ST
// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ThrowParam {

	// 名前：投げ側キャラID
	// 説明：投げ側キャラID
	int32_t AtkChrId_000;

	// 名前：受け側キャラID
	// 説明：受け側キャラID
	int32_t DefChrId_004;

	// 名前：有効距離[m]
	// 説明：この値より近い距離じゃないと投げない[m]
	float Dist_008;

	// 名前：自分の向きと相手の向きの角度差範囲min
	// 説明：投げ側と受け側の角度差(Y軸)がこの角度より大きくないと投げない
	float DiffAngMin_00C;

	// 名前：自分の向きと相手の向きの角度差範囲max
	// 説明：投げ側と受け側の角度差(Y軸)がこの角度より小さくないと投げない
	float DiffAngMax_010;

	// 名前：高さ範囲上[m]
	// 説明：投げ側から受け側のY軸の相対距離がこの値より小さくないと投げない
	float upperYRange_014;

	// 名前：高さ範囲下[m]
	// 説明：投げ側から受け側のY軸の相対距離がこの値より小さくないと投げない
	float lowerYRange_018;

	// 名前：自分の向きと自分から相手への方向の角度差
	// 説明：自分の正面のベクトルと、自分から相手への方向のベクトルの角度差。この値より大きいと投げない
	float diffAngMyToDef_01C;

	// 名前：投げタイプID
	// 説明：投げの種類を特定するID(攻撃パラメタと紐付け)
	int32_t throwTypeId_020;

	// 名前：投げ側アニメID
	// 説明：攻撃アニメIDを設定(EzStateと紐付け)
	int32_t atkAnimId_024;

	// 名前：受け側アニメID
	// 説明：ダメージアニメIDを設定(EzStateと紐付け)
	int32_t defAnimId_028;

	// 名前：投げ抜けHP
	// 説明：投げ抜けに耐えられる値
	uint16_t escHp_02C;

	// 名前：自力投げ抜けサイクル時間[ms]
	// 説明：自力投げ抜けのサイクル時間[ms]
	uint16_t selfEscCycleTime_02E;

	// 名前：スフィアキャスト半径比率_上[1/100Rate]
	// 説明：スフィアキャストの上側半径の比率[80->0.8]
	uint16_t sphereCastRadiusRateTop_030;

	// 名前：スフィアキャスト半径比率_下[1/100Rate]
	// 説明：スフィアキャストの下側半径の比率[80->0.8]
	uint16_t sphereCastRadiusRateLow_032;

	// 名前：操作タイプ
	// 説明：操作タイプ
	uint8_t PadType_034;

	// 名前：投げ側の投げ可能状態タイプ
	// 説明：投げ側の投げが可能な状態タイプを設定してください
	uint8_t AtkEnableState_035;

	// 名前：投げ追従方式
	// 説明：投げ実行中、吸着ダミポリ所持キャラにどのように追従するか。※追従期間はTAEアクションでコントロール
	uint8_t throwFollowingType_036;

	// 名前：pad
	// 説明：pad
	uint8_t pad2_037[1];

	// 名前：投げ種別
	// 説明：投げの種別
	uint8_t throwType_038;

	// 名前：自力投げ抜けサイクル回数
	// 説明：自力投げ抜けのサイクル回数
	uint8_t selfEscCycleCnt_039;

	// 名前：投げ発生時のダミポリ所持キャラの向き
	// 説明：投げ発生時のダミポリ所持キャラの向き
	uint8_t dmyHasChrDirType_03A;

	// 名前：投げ側が旋回するか？
	// 説明：投げ側が旋回するか？
	uint8_t isTurnAtker_03B: 1;

	// 名前：武器カテゴリチェックをスキップするか？
	// 説明：攻撃側の武器カテゴリチェックをスキップするか？
	uint8_t isSkipWepCate_03B: 1;

	// 名前：スフィアキャストをスキップするか？
	// 説明：スフィアキャストをスキップするか？
	uint8_t isSkipSphereCast_03B: 1;

	// 名前：投げ吸着時、平地相当の位置関係に戻すか
	// 説明：◯にすると投げ位置合わせの場所が「平地相当の位置関係に戻した吸着ダミポリの位置」になる
	uint8_t isEnableCorrectPos_forThrowAdjust_03B: 1;

	// 名前：投げ追従解除時の落下を防止するか？
	// 説明：追従解除時に段差から落下しないよう、壁抜け防止と同じ処理を落下防止壁に対しても行うか？
	uint8_t isEnableThrowFollowingFallAssist_03B: 1;

	// 名前：投げ追従中の壁めり込みを抑制するか？
	// 説明：追従中壁にめり込んだり段差から落下しそうな見た目にならないよう、ヒットや落下防止壁に接触したときに吸着ダミポリ所持キャラごと戻す処理を行うか？
	uint8_t isEnableThrowFollowingFeedback_03B: 1;

	// 名前：pad
	// 説明：pad
	uint8_t pad0_03B: 2;

	// 名前：投げ側 吸着ダミポリID
	// 説明：投げ側のどこに受け側を吸着させるか？
	int16_t atkSorbDmyId_03C;

	// 名前：受け側 吸着ダミポリID
	// 説明：受け側のどこに投げ側を吸着させるか？
	int16_t defSorbDmyId_03E;

	// 名前：有効距離(投げ開始)[m]
	// 説明：この値より近い距離じゃないと投げない[m]　バックスタブ開始時の投げに使われる
	float Dist_start_040;

	// 名前：自分の向きと相手の向きの角度差範囲min(投げ開始)
	// 説明：投げ側と受け側の角度差(Y軸)がこの角度より大きくないと投げない　バックスタブ開始時の投げに使われる
	float DiffAngMin_start_044;

	// 名前：自分の向きと相手の向きの角度差範囲max(投げ開始)
	// 説明：投げ側と受け側の角度差(Y軸)がこの角度より小さくないと投げない　バックスタブ開始時の投げに使われる
	float DiffAngMax_start_048;

	// 名前：高さ範囲上(投げ開始)[m]
	// 説明：投げ側から受け側のY軸の相対距離がこの値より小さくないと投げない　バックスタブ開始時の投げに使われる
	float upperYRange_start_04C;

	// 名前：高さ範囲下(投げ開始)[m]
	// 説明：投げ側から受け側のY軸の相対距離がこの値より小さくないと投げない　バックスタブ開始時の投げに使われる
	float lowerYRange_start_050;

	// 名前：自分の向きと自分から相手への方向の角度差(投げ開始)
	// 説明：自分の正面のベクトルと、自分から相手への方向のベクトルの角度差。この値より大きいと投げない　バックスタブ開始時の投げに使われる
	float diffAngMyToDef_start_054;

	// 名前：投げ側の投げ範囲判定基準ダミポリId
	// 説明：投げ側が、投げ範囲を計算するときに自分の位置と見なすダミポリ。-1ならカプセル原点
	int32_t judgeRangeBasePosDmyId1_058;

	// 名前：投られ側の投げ範囲判定基準ダミポリId
	// 説明：投げられ側が、投げ範囲を計算するときに自分の位置と見なすダミポリ。-1ならカプセル原点
	int32_t judgeRangeBasePosDmyId2_05C;

	// 名前：吸着時モデル位置補間時間[s]
	// 説明：カプセルが吸着ダミポリに吸着したあと、キャラモデルが投げアニメデータ通りの位置に補間移動する時間（0を設定した場合はモデル位置の補間が行われず、吸着直後からアニメデータ通りの位置関係で再生開始される）
	float adsrobModelPosInterpolationTime_060;

	// 名前：追従終了時モデル位置補間時間[s]
	// 説明：追従終了時モデル位置補間時間
	float throwFollowingEndEasingTime_064;

	// 名前：pad
	// 説明：pad
	uint8_t pad1_068[24];

} ThrowParam;

#endif
