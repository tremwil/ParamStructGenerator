/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_DirectionCameraParam_H
#define _PARAM_DirectionCameraParam_H
#include <stdint.h>

// DIRECTION_CAMERA_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _DirectionCameraParam {

	// 名前：オプションの影響を受けるか
	// 説明：演出カメラON/OFFオプションの影響を受けるか？
	uint8_t isUseOption_000: 1;

	// 名前：パッド
	// 説明：pad
	uint8_t pad2_000: 3;

	// 名前：パッド
	// 説明：pad
	uint8_t pad1_000[15];

} DirectionCameraParam;

#endif
