/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_AssetMaterialSfxParam_H
#define _PARAM_AssetMaterialSfxParam_H
#include <stdint.h>

// ASSET_MATERIAL_SFX_PARAM_ST
// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AssetMaterialSfxParam {

	// 名前：SFX識別子：00
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_00_000;

	// 名前：SFX識別子：01
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_01_004;

	// 名前：SFX識別子：02
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_02_008;

	// 名前：SFX識別子：03
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_03_00C;

	// 名前：SFX識別子：04
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_04_010;

	// 名前：SFX識別子：05
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_05_014;

	// 名前：SFX識別子：06
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_06_018;

	// 名前：SFX識別子：07
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_07_01C;

	// 名前：SFX識別子：08
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_08_020;

	// 名前：SFX識別子：09
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_09_024;

	// 名前：SFX識別子：10
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_10_028;

	// 名前：SFX識別子：11
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_11_02C;

	// 名前：SFX識別子：12
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_12_030;

	// 名前：SFX識別子：13
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_13_034;

	// 名前：SFX識別子：14
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_14_038;

	// 名前：SFX識別子：15
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_15_03C;

	// 名前：SFX識別子：16
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_16_040;

	// 名前：SFX識別子：17
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_17_044;

	// 名前：SFX識別子：18
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_18_048;

	// 名前：SFX識別子：19
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_19_04C;

	// 名前：SFX識別子：20
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_20_050;

	// 名前：SFX識別子：21
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_21_054;

	// 名前：SFX識別子：22
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_22_058;

	// 名前：SFX識別子：23
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_23_05C;

	// 名前：SFX識別子：24
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_24_060;

	// 名前：SFX識別子：25
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_25_064;

	// 名前：SFX識別子：26
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_26_068;

	// 名前：SFX識別子：27
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_27_06C;

	// 名前：SFX識別子：28
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_28_070;

	// 名前：SFX識別子：29
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_29_074;

	// 名前：SFX識別子：30
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_30_078;

	// 名前：SFX識別子：31
	// 説明：アセットパラメータの「破壊後着地SFX識別子」に対応する、SFX識別子
	uint32_t sfxId_31_07C;

} AssetMaterialSfxParam;

#endif
