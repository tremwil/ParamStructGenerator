/* NOTE: AUTO-GENERATED CODE. Modify at your own risk. */
#pragma once
#ifndef _PARAM_MapDefaultInfoParam_H
#define _PARAM_MapDefaultInfoParam_H
#include <stdint.h>

// MAP_DEFAULT_INFO_PARAM_ST
// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _MapDefaultInfoParam {

	// 名前：NT版出力から外すか
	// 説明：○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT_000: 1;

	// 名前：パッケージ出力用リザーブ1
	// 説明：パッケージ出力用リザーブ1
	uint8_t disableParamReserve1_000: 7;

	// 名前：パッケージ出力用リザーブ2
	// 説明：パッケージ出力用リザーブ2
	uint8_t disableParamReserve2_001[3];

	// 名前：ファストトラベル許可フラグID
	// 説明：ファストトラベル許可フラグID
	uint32_t EnableFastTravelEventFlagId_004;

	// 名前：天候抽選時間オフセット(インゲーム秒)
	// 説明：天候抽選時間にかかるオフセット(単位：インゲーム秒)。ゲームプロパティのインゲーム時間スケールで割ると現実時間になります
	int32_t WeatherLotTimeOffsetIngameSeconds_008;

	// 名前：天候生成アセット生成制限用ID
	// 説明：天候アセット生成パラメータ.xlsmで生成されるアセットの生成制限に使うID
	int8_t WeatherCreateAssetLimitId_00C;

	// 名前：マップ視界タイプ
	// 説明：マップ視界タイプ
	uint8_t MapAiSightType_00D;

	// 名前：サウンド屋内、完全屋内振り分け
	// 説明：マップGD設定の「屋内」をサウンド用の「屋内」、「完全屋内」どちらに振り分けるかを設定します(SEQ09833)
	uint8_t SoundIndoorType_00E;

	// 名前：リバーブデフォルト設定
	// 説明：このマップのリバーブデフォルトタイプを指定します
	int8_t ReverbDefaultType_00F;

	// 名前：BGM用場所情報
	// 説明：BGM用の場所デフォルト情報を指定します
	int16_t BgmPlaceInfo_010;

	// 名前：環境音用場所情報
	// 説明：環境音用の場所デフォルト情報を指定します
	int16_t EnvPlaceInfo_012;

	// 名前：マップ追加バンクID
	// 説明：追加で読み込むサウンドの「マップ追加バンク」のIDを指定します(-1:マップ追加バンクなし)(SEQ15725)
	int32_t MapAdditionalSoundBankId_014;

	// 名前：サウンド用マップ高さ情報[m]
	// 説明：サウンド用マップ高さ情報[m](SEQ15727)
	int16_t MapHeightForSound_018;

	// 名前：【レガシー用】マップ環境マップ時間ブレンド有効か？
	// 説明：環境マップの時間ブレンドを行うかを指定します。0番の時間帯のTexureだけが撮影、使用されます。GPU負荷,メモリが軽減されます。レガシー(m00-m49)のみ有効な設定です(SEQ16464)
	uint8_t IsEnableBlendTimezoneEnvmap_01A;

	// 名前：GI解像度上書き設定_XSSプラット
	// 説明：XSS(Xbox SeriesS,Lockhart)で使用するGI解像度上書きします
	int8_t OverrideGIResolution_XSS_01B;

	// 名前：マップハイヒット切り替判定AABB_幅奥行き(XZ)[m]
	// 説明：マップハイヒット切り替判定AABB_幅奥行き(XZ)[m](SEQ16295)
	float MapLoHiChangeBorderDist_XZ_01C;

	// 名前：マップハイヒット切り替え判定AABB_高さ(Y)[m]
	// 説明：マップハイヒット切り替え判定AABB_高さ(Y)[m](SEQ16295)
	float MapLoHiChangeBorderDist_Y_020;

	// 名前：マップハイヒット切り替え判定遊び距離[m]
	// 説明：マップハイヒット切り替え判定遊び距離[m]。通常はデフォルトでいいはず。小さいAABBの場合は必要に応じて調整してください。遊びがあまりに小さいと頻繁に切り替えが起こります。AABBサイズより大きい場合は想定してません(SEQ16295)
	float MapLoHiChangePlayDist_024;

	// 名前：自動描画グループ計算で、裏面判定となるピクセル数
	// 説明：自動描画グループ計算で、裏面判定となるピクセル数
	uint32_t MapAutoDrawGroupBackFacePixelNum_028;

	// 名前：Playerライト強度スケール値
	// 説明：このマップでPC、PC馬常駐光源にかけるスケールを指定します(SEQ16562)
	float PlayerLigntScale_02C;

	// 名前：時間帯によるPlayerライト強度スケール変化をするか？
	// 説明：このマップでPC、PC馬常駐光源、時間帯によるPlayerライト強度スケール変化をするか？を指定します(SEQ16562)
	uint8_t IsEnableTimezonnePlayerLigntScale_030;

	// 名前：自動崖風SE無効にするか？
	// 説明：自動崖風SE無効にするか？(SEQ15729)
	uint8_t isDisableAutoCliffWind_031;

	// 名前：オープンキャラアクティベート制限_評価値閾値
	// 説明：オープンキャラアクティベート制限_評価値閾値
	int16_t OpenChrActivateThreshold_032;

	// 名前：マップ別擬態確率パラメータID
	// 説明：マップ別擬態確率パラメータID(SEQ22471)
	int32_t MapMimicryEstablishmentParamId_034;

	// 名前：GI解像度上書き設定_XSXプラット
	// 説明：XSX(Xbox SeriesX,Anaconda)で使用するGI解像度上書きします
	int8_t OverrideGIResolution_XSX_038;

	// 名前：リザーブ
	// 説明：リザーブ
	uint8_t Reserve_039[7];

} MapDefaultInfoParam;

#endif
