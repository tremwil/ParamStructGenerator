/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_DECAL_PARAM_ST_H
#define _PARAMDEF_DECAL_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _DECAL_PARAM_ST {

	// NAME: テクスチャID
	// DESC: テクスチャID
	int32_t textureId;

	// NAME: ダミポリID
	// DESC: デカール発生基準のダミポリID。TAEで指定している場合はTAEの値になる
	int32_t dmypolyId;

	// NAME: 基準角度オフセット_上下[deg]
	// DESC: 基準角度オフセット_上下[deg]
	float pitchAngle;

	// NAME: 基準角度オフセット_左右[deg]
	// DESC: 基準角度オフセット_左右[deg]
	float yawAngle;

	// NAME: 貼り付け開始距離[m]
	// DESC: 貼り付け開始距離[m]
	float nearDistance;

	// NAME: 貼り付け終了距離[m]
	// DESC: 貼り付け終了距離[m]
	float farDistance;

	// NAME: 開始距離での大きさ[m]
	// DESC: 開始距離での大きさ[m]
	float nearSize;

	// NAME: 終了距離での大きさ[m]
	// DESC: 終了距離での大きさ[m]
	float farSize;

	// NAME: 監視特殊効果ID
	// DESC: 監視特殊効果ID。任意の特殊効果IDを入れた場合、その特殊効果がかかっていないとデカールを発生しなくなる。
	int32_t maskSpeffectId;

	// NAME: パディング
	// DESC: パディング
	uint32_t pad_10: 4;

	// NAME: 材質によるテクスチャ差し替え
	// DESC: 攻撃のヒットで発生させるときに1で防御材質によってテクスチャを変える。新しいテクスチャID=血材質ID*10000000+元のテクスチャID
	uint32_t replaceTextureId_byMaterial: 1;

	// NAME: ダミポリ検索場所
	// DESC: ダミポリ検索場所 0:本体 1:左手武器 2:右手武器
	uint32_t dmypolyCategory: 2;

	// NAME: パディング
	// DESC: パディング
	uint32_t pad_05: 4;

	// NAME: デファード
	// DESC: 1でデファードデカールとして機能する
	uint32_t useDeferredDecal: 1;

	// NAME: ペイント
	// DESC: 1でペイントデカールとして機能する
	uint32_t usePaintDecal: 1;

	// NAME: 流血表現
	// DESC: オプションの流血表現の影響を受けるか、マイルドでIDが+1000される、非表示だと貼り付けない
	uint32_t bloodTypeEnable: 1;

	// NAME: ノーマル成分を使用するか
	// DESC: ノーマル成分を使用するなら1（ノーマルとシャイニネスのテクスチャ統合対応）
	uint32_t bUseNormal: 1;

	// NAME: パディング
	// DESC: パディング
	uint32_t pad_08: 1;

	// NAME: パディング
	// DESC: パディング
	uint32_t pad_09: 1;

	// NAME: POMを有効にするか
	// DESC: POMを有効にするか
	uint32_t usePom: 1;

	// NAME: エミッシブを更新するか
	// DESC: エミッシブを更新するか
	uint32_t useEmissive: 1;

	// NAME: 垂直に貼り付けるか
	// DESC: 垂直に貼り付けるか
	uint32_t putVertical: 1;

	// NAME: ランダムスケール最小値[％]
	// DESC: ランダムスケール最小値[％]
	int16_t randomSizeMin;

	// NAME: ランダムスケール最大値[％]
	// DESC: ランダムスケール最大値[％]
	int16_t randomSizeMax;

	// NAME: ランダム角度_ひねり最小値[deg]
	// DESC: ランダム角度_ひねり最小値[deg]
	float randomRollMin;

	// NAME: ランダム角度_ひねり最大値[deg]
	// DESC: ランダム角度_ひねり最大値[deg]
	float randomRollMax;

	// NAME: ランダム角度_上下最小値[deg]
	// DESC: ランダム角度_上下最小値[deg]
	float randomPitchMin;

	// NAME: ランダム角度_上下最大値[deg]
	// DESC: ランダム角度_上下最大値[deg]
	float randomPitchMax;

	// NAME: ランダム角度_左右最小値[deg]
	// DESC: ランダム角度_左右最小値[deg]
	float randomYawMin;

	// NAME: ランダム角度_左右最大値[deg]
	// DESC: ランダム角度_左右最大値[deg]
	float randomYawMax;

	// NAME: POM高さスケール
	// DESC: POM高さスケール
	float pomHightScale;

	// NAME: POM最小サンプル数
	// DESC: POM最小サンプル数
	uint8_t pomSampleMin;

	// NAME: POM最大サンプル数
	// DESC: POM最大サンプル数
	uint8_t pomSampleMax;

	// NAME: ブレンドモード
	// DESC: ブレンドモード
	int8_t blendMode;

	// NAME: デカールを飛ばす基準座標
	// DESC: デカールを飛ばす方向を決定する基準座標
	int8_t appearDirType;

	// NAME: エミッシブ 開始値
	// DESC: エミッシブ 開始値
	float emissiveValueBegin;

	// NAME: エミッシブ 終了値
	// DESC: エミッシブ 終了値
	float emissiveValueEnd;

	// NAME: エミッシブ 更新時間(秒)
	// DESC: 開始値～終了値の補間時間
	float emissiveTime;

	// NAME: 補間するか？
	// DESC: TAEのデカル発生でバーを伸ばしてる時間発生させるか？
	uint8_t bIntpEnable;

	// NAME: パディング
	// DESC: パディング
	uint8_t pad_01[3];

	// NAME: 補間間隔[m]
	// DESC: 補間有効時にTAEのバーの間で発生したデカルを補間する距離
	float intpIntervalDist;

	// NAME: 補間開始時のテクスチャID
	// DESC: 補間開始時のテクスチャID（-1でテクスチャIDと同じ値を使う）
	int32_t beginIntpTextureId;

	// NAME: 補間終了時のテクスチャID
	// DESC: 補間終了時のテクスチャテクスチャID（-1でテクスチャIDと同じ値を使う）
	int32_t endIntpTextureId;

	// NAME: デカールが貼られた時に出すSFXID
	// DESC: デカールが貼られた時に出すSFXID（-1で何も出さない）
	int32_t appearSfxId;

	// NAME: SFXのオフセット位置
	// DESC: SFX発生位置のオフセット距離
	float appearSfxOffsetPos;

	// NAME: マスクテクスチャID
	// DESC: マスクテクスチャID（-1でテクスチャIDを見る）
	int32_t maskTextureId;

	// NAME: アルベドテクスチャID
	// DESC: アルベドテクスチャID（-1でテクスチャIDを見る）
	int32_t diffuseTextureId;

	// NAME: リフレクテクスチャID
	// DESC: リフレクタンステクスチャID（-1でテクスチャIDを見る）
	int32_t reflecTextureId;

	// NAME: マスクの強さ
	// DESC: マスクの強さ（現状、デファードデカールでのみ有効）
	float maskScale;

	// NAME: ノーマルテクスチャID
	// DESC: ノーマルテクスチャID（-1でテクスチャIDを見る）
	int32_t normalTextureId;

	// NAME: ハイトテクスチャID
	// DESC: ハイトテクスチャID（-1でテクスチャIDを見る）
	int32_t heightTextureId;

	// NAME: エミッシブテクスチャID
	// DESC: エミッシブテクスチャID（-1でテクスチャIDを見る）
	int32_t emissiveTextureId;

	// NAME: アルベドカラー：R
	// DESC: アルベドの色：R
	uint8_t diffuseColorR;

	// NAME: アルベドカラー：G
	// DESC: アルベドの色：G
	uint8_t diffuseColorG;

	// NAME: アルベドカラー：B
	// DESC: アルベドの色：B
	uint8_t diffuseColorB;

	// NAME: パディング
	// DESC: パディング
	uint8_t pad_03[1];

	// NAME: リフレクカラー：R
	// DESC: リフレクの色：R
	uint8_t reflecColorR;

	// NAME: リフレクカラー：G
	// DESC: リフレクの色：G
	uint8_t reflecColorG;

	// NAME: リフレクカラー：B
	// DESC: リフレクの色：B
	uint8_t reflecColorB;

	// NAME: 寿命が有効か
	// DESC: 寿命が有効か
	uint8_t bLifeEnable;

	// NAME: シャイニネスの強さ
	// DESC: シャイニネスの強さ
	float siniScale;

	// NAME: 寿命[秒]
	// DESC: 寿命[秒]（デカールが貼られてからの時間、フェードイン時間は関係ない）
	float lifeTimeSec;

	// NAME: フェードアウト時間[秒]
	// DESC: フェードアウト時間[秒]
	float fadeOutTimeSec;

	// NAME: 優先度
	// DESC: この値が大きいほど残りやすい（-1は消滅しない）
	int16_t priority;

	// NAME: 近くにデカールがあれば間引くか
	// DESC: 近くにデカールがあれば間引くかどうか
	uint8_t bDistThinOutEnable;

	// NAME: ランダムパターンを固定化する
	// DESC: 「はい」にすると、各バリエーション数が0以外のテクスチャについてランダムに決めた一つのバリエーション番号が適用されるようになります。0以外の各バリエーション数は同じ値に揃える必要があります。
	uint8_t bAlignedTexRandomVariationEnable;

	// NAME: この距離以内なら間引き候補
	// DESC: この距離以内にデカールがあれば間引き候補
	float distThinOutCheckDist;

	// NAME: 方向の差がこの角度[度]以内なら間引き候補
	// DESC: デカールの方向の差がこの角度以内なら間引き候補
	float distThinOutCheckAngleDeg;

	// NAME: 条件を満たした数がこの数以上なら間引く
	// DESC: 距離、角度がこの数以上なら間引く
	uint8_t distThinOutMaxNum;

	// NAME: 直近何個まで間引きチェックするか
	// DESC: 間引き候補を直近何個まで調べるか
	uint8_t distThinOutCheckNum;

	// NAME: 発生するまでの遅延フレーム[フレーム（30FPS換算）]
	// DESC: デカールを貼り付けようとしてからこのフレーム後に実際に貼り付けられる
	int16_t delayAppearFrame;

	// NAME: アルベド・バリエーション数
	// DESC: アルベドテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Diffuse: 4;

	// NAME: マスク・バリエーション数
	// DESC: マスクテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Mask: 4;

	// NAME: リフレク・バリエーション数
	// DESC: リフレクテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Reflec: 4;

	// NAME: パディング
	uint32_t pad_12: 4;

	// NAME: ノーマル・バリエーション数
	// DESC: ノーマルテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Normal: 4;

	// NAME: ハイト・バリエーション数
	// DESC: ハイトテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Height: 4;

	// NAME: エミッシブ・バリエーション数
	// DESC: エミッシブテクスチャのランダムバリエーション数（0番目を含む、2でテクスチャ2枚分）
	uint32_t randVaria_Emissive: 4;

	// NAME: パディング
	// DESC: パディング
	uint32_t pad_11: 4;

	// NAME: フェードイン時間[秒]
	// DESC: フェードイン時間[秒]
	float fadeInTimeSec;

	// NAME: 間引き:重複乗算値
	// DESC: デカールサイズにこの値を乗算した範囲で重複かを判定する
	float thinOutOverlapMultiRadius;

	// NAME: 間引き:近隣加算距離[m]
	// DESC: デカールサイズにこの距離[m]を加算した範囲で近隣かを判定する
	float thinOutNeighborAddRadius;

	// NAME: 間引き:重複限界数
	// DESC: 重複可能な限界数
	uint32_t thinOutOverlapLimitNum;

	// NAME: 間引き:近隣限界数
	// DESC: 近隣可能な限界数
	uint32_t thinOutNeighborLimitNum;

	// NAME: 間引きモード
	// DESC: 間引きモード
	int8_t thinOutMode;

	// NAME: エミッシブカラー：R
	// DESC: エミッシブの色：R
	uint8_t emissiveColorR;

	// NAME: エミッシブカラー：G
	// DESC: エミッシブの色：G
	uint8_t emissiveColorG;

	// NAME: エミッシブカラー：B
	// DESC: エミッシブの色：B
	uint8_t emissiveColorB;

	// NAME: SFX発生上限角度
	// DESC: SFX発生上限角度
	float maxDecalSfxCreatableSlopeAngleDeg;

	// NAME: パディング
	// DESC: パディング
	uint8_t pad_02[40];
} DECAL_PARAM_ST;

#endif
