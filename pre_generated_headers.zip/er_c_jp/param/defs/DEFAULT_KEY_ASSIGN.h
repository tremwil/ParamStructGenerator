/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_DEFAULT_KEY_ASSIGN_H
#define _PARAMDEF_DEFAULT_KEY_ASSIGN_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 202
typedef struct _DEFAULT_KEY_ASSIGN {

	// NAME: パッド0
	// DESC: 下位抑制パッド0
	uint8_t priority0: 1;

	// NAME: GUIフレームワーク用
	// DESC: 下位抑制GUIフレームワーク用パッド
	uint8_t priority1: 1;

	// NAME: パッド2
	// DESC: 下位抑制パッド2
	uint8_t priority2: 1;

	// NAME: デバッグメニューモード切替
	// DESC: 下位抑制デバッグメニューモード切替パッド
	uint8_t priority3: 1;

	// NAME: パッド4
	// DESC: 下位抑制パッド4
	uint8_t priority4: 1;

	// NAME: パッドデバッグメニュー
	// DESC: 下位抑制パッドデバッグメニューパッド
	uint8_t priority5: 1;

	// NAME: パッド6
	// DESC: 下位抑制パッド6
	uint8_t priority6: 1;

	// NAME: パッド7
	// DESC: 下位抑制パッド7
	uint8_t priority7: 1;

	// NAME: パッド8
	// DESC: 下位抑制パッド8
	uint8_t priority8: 1;

	// NAME: パッド9
	// DESC: 下位抑制パッド9
	uint8_t priority9: 1;

	// NAME: パッド10
	// DESC: 下位抑制パッド10
	uint8_t priority10: 1;

	// NAME: パッド11
	// DESC: 下位抑制パッド11
	uint8_t priority11: 1;

	// NAME: パッド12
	// DESC: 下位抑制パッド12
	uint8_t priority12: 1;

	// NAME: パッド13
	// DESC: 下位抑制パッド13
	uint8_t priority13: 1;

	// NAME: パッド14
	// DESC: 下位抑制パッド14
	uint8_t priority14: 1;

	// NAME: パッド15
	// DESC: 下位抑制パッド15
	uint8_t priority15: 1;

	// NAME: パッド16
	// DESC: 下位抑制パッド16
	uint8_t priority16: 1;

	// NAME: パッド17
	// DESC: 下位抑制パッド17
	uint8_t priority17: 1;

	// NAME: パッド18
	// DESC: 下位抑制パッド18
	uint8_t priority18: 1;

	// NAME: パッド19
	// DESC: 下位抑制パッド19
	uint8_t priority19: 1;

	// NAME: パッド20
	// DESC: 下位抑制パッド20
	uint8_t priority20: 1;

	// NAME: パッド21
	// DESC: 下位抑制パッド21
	uint8_t priority21: 1;

	// NAME: パッド22
	// DESC: 下位抑制パッド22
	uint8_t priority22: 1;

	// NAME: パッド23
	// DESC: 下位抑制パッド23
	uint8_t priority23: 1;

	// NAME: パッド24
	// DESC: 下位抑制パッド24
	uint8_t priority24: 1;

	// NAME: パッド25
	// DESC: 下位抑制パッド25
	uint8_t priority25: 1;

	// NAME: パッド26
	// DESC: 下位抑制パッド26
	uint8_t priority26: 1;

	// NAME: パッド27
	// DESC: 下位抑制パッド27
	uint8_t priority27: 1;

	// NAME: パッド28
	// DESC: 下位抑制パッド28
	uint8_t priority28: 1;

	// NAME: パッド29
	// DESC: 下位抑制パッド29
	uint8_t priority29: 1;

	// NAME: パッド30
	// DESC: 下位抑制パッド30
	uint8_t priority30: 1;

	// NAME: パッド31
	// DESC: 下位抑制パッド31
	uint8_t priority31: 1;

	// NAME: ダミー
	uint8_t dummy[12];

	// NAME: パッド物理キー
	// DESC: パッド物理キー
	int32_t phyisicalKey_0;

	// NAME: 押され方
	// DESC: 押され方
	uint8_t traitsType_0;

	// NAME: アナログ→デジタル変換方法
	// DESC: アナログ→デジタル変換方法
	uint8_t a2dOperator_0;

	// NAME: 適用ターゲット
	// DESC: 反映ターゲット
	uint8_t applyTarget_0;

	// NAME: デジタル・アナログ
	// DESC: デジタルorアナログ
	uint8_t isAnalog_0: 1;

	// NAME: Win64
	// DESC: Win64で使用されるか
	uint8_t enableWin64_0: 1;

	// NAME: PS4
	// DESC: PS4で使用されるか
	uint8_t enablePS4_0: 1;

	// NAME: XboxOne
	// DESC: XboxOneで使用されるか
	uint8_t enableXboxOne_0: 1;

	// NAME: 時間
	// DESC: 時間
	float time1_0;

	// NAME: リピート用インターバル時間
	// DESC: リピート用インターバル時間
	float time2_0;

	// NAME: アナログ→デジタル変換閾値
	// DESC: アナログ→デジタル変換閾値
	float a2dThreshold_0;

	// NAME: パッド物理キー
	// DESC: パッド物理キー
	int32_t phyisicalKey_1;

	// NAME: 押され方
	// DESC: 押され方
	uint8_t traitsType_1;

	// NAME: アナログ→デジタル変換方法
	// DESC: アナログ→デジタル変換方法
	uint8_t a2dOperator_1;

	// NAME: 適用ターゲット
	// DESC: 反映ターゲット
	uint8_t applyTarget_1;

	// NAME: デジタル・アナログ
	// DESC: デジタルorアナログ
	uint8_t isAnalog_1: 1;

	// NAME: Win64
	// DESC: Win64で使用されるか
	uint8_t enableWin64_1: 1;

	// NAME: PS4
	// DESC: PS4で使用されるか
	uint8_t enablePS4_1: 1;

	// NAME: XboxOne
	// DESC: XboxOneで使用されるか
	uint8_t enableXboxOne_1: 1;

	// NAME: 時間
	// DESC: 時間
	float time1_1;

	// NAME: リピート用インターバル時間
	// DESC: リピート用インターバル時間
	float time2_1;

	// NAME: アナログ→デジタル変換閾値
	// DESC: アナログ→デジタル変換閾値
	float a2dThreshold_1;

	// NAME: パッド物理キー
	// DESC: パッド物理キー
	int32_t phyisicalKey_2;

	// NAME: 押され方
	// DESC: 押され方
	uint8_t traitsType_2;

	// NAME: アナログ→デジタル変換方法
	// DESC: アナログ→デジタル変換方法
	uint8_t a2dOperator_2;

	// NAME: 適用ターゲット
	// DESC: 反映ターゲット
	uint8_t applyTarget_2;

	// NAME: デジタル・アナログ
	// DESC: デジタルorアナログ
	uint8_t isAnalog_2: 1;

	// NAME: Win64
	// DESC: Win64で使用されるか
	uint8_t enableWin64_2: 1;

	// NAME: PS4
	// DESC: PS4で使用されるか
	uint8_t enablePS4_2: 1;

	// NAME: XboxOne
	// DESC: XboxOneで使用されるか
	uint8_t enableXboxOne_2: 1;

	// NAME: 時間
	// DESC: 時間
	float time1_2;

	// NAME: リピート用インターバル時間
	// DESC: リピート用インターバル時間
	float time2_2;

	// NAME: アナログ→デジタル変換閾値
	// DESC: アナログ→デジタル変換閾値
	float a2dThreshold_2;

	// NAME: パッド物理キー
	// DESC: パッド物理キー
	int32_t phyisicalKey_3;

	// NAME: 押され方
	// DESC: 押され方
	uint8_t traitsType_3;

	// NAME: アナログ→デジタル変換方法
	// DESC: アナログ→デジタル変換方法
	uint8_t a2dOperator_3;

	// NAME: 適用ターゲット
	// DESC: 反映ターゲット
	uint8_t applyTarget_3;

	// NAME: デジタル・アナログ
	// DESC: デジタルorアナログ
	uint8_t isAnalog_3: 1;

	// NAME: Win64
	// DESC: Win64で使用されるか
	uint8_t enableWin64_3: 1;

	// NAME: PS4
	// DESC: PS4で使用されるか
	uint8_t enablePS4_3: 1;

	// NAME: XboxOne
	// DESC: XboxOneで使用されるか
	uint8_t enableXboxOne_3: 1;

	// NAME: 時間
	// DESC: 時間
	float time1_3;

	// NAME: リピート用インターバル時間
	// DESC: リピート用インターバル時間
	float time2_3;

	// NAME: アナログ→デジタル変換閾値
	// DESC: アナログ→デジタル変換閾値
	float a2dThreshold_3;

	// NAME: PC物理キー
	// DESC: PC物理キー
	int32_t phyisicalKey_4;

	// NAME: 押され方
	// DESC: 押され方
	uint8_t traitsType_4;

	// NAME: アナログ→デジタル変換方法
	// DESC: アナログ→デジタル変換方法
	uint8_t a2dOperator_4;

	// NAME: 適用ターゲット
	// DESC: 反映ターゲット
	uint8_t applyTarget_4;

	// NAME: デジタル・アナログ
	// DESC: デジタルorアナログ
	uint8_t isAnalog_4: 1;

	// NAME: Win64
	// DESC: Win64で使用されるか
	uint8_t enableWin64_4: 1;

	// NAME: PS4
	// DESC: PS4で使用されるか
	uint8_t enablePS4_4: 1;

	// NAME: XboxOne
	// DESC: XboxOneで使用されるか
	uint8_t enableXboxOne_4: 1;

	// NAME: 時間
	// DESC: 時間
	float time1_4;

	// NAME: リピート用インターバル時間
	// DESC: リピート用インターバル時間
	float time2_4;

	// NAME: アナログ→デジタル変換閾値
	// DESC: アナログ→デジタル変換閾値
	float a2dThreshold_4;

	// NAME: PC物理キー
	// DESC: PC物理キー
	int32_t phyisicalKey_5;

	// NAME: 押され方
	// DESC: 押され方
	uint8_t traitsType_5;

	// NAME: アナログ→デジタル変換方法
	// DESC: アナログ→デジタル変換方法
	uint8_t a2dOperator_5;

	// NAME: 適用ターゲット
	// DESC: 反映ターゲット
	uint8_t applyTarget_5;

	// NAME: デジタル・アナログ
	// DESC: デジタルorアナログ
	uint8_t isAnalog_5: 1;

	// NAME: Win64
	// DESC: Win64で使用されるか
	uint8_t enableWin64_5: 1;

	// NAME: PS4
	// DESC: PS4で使用されるか
	uint8_t enablePS4_5: 1;

	// NAME: XboxOne
	// DESC: XboxOneで使用されるか
	uint8_t enableXboxOne_5: 1;

	// NAME: 時間
	// DESC: 時間
	float time1_5;

	// NAME: リピート用インターバル時間
	// DESC: リピート用インターバル時間
	float time2_5;

	// NAME: アナログ→デジタル変換閾値
	// DESC: アナログ→デジタル変換閾値
	float a2dThreshold_5;

	// NAME: PC物理キー
	// DESC: PC物理キー
	int32_t phyisicalKey_6;

	// NAME: 押され方
	// DESC: 押され方
	uint8_t traitsType_6;

	// NAME: アナログ→デジタル変換方法
	// DESC: アナログ→デジタル変換方法
	uint8_t a2dOperator_6;

	// NAME: 適用ターゲット
	// DESC: 反映ターゲット
	uint8_t applyTarget_6;

	// NAME: デジタル・アナログ
	// DESC: デジタルorアナログ
	uint8_t isAnalog_6: 1;

	// NAME: Win64
	// DESC: Win64で使用されるか
	uint8_t enableWin64_6: 1;

	// NAME: PS4
	// DESC: PS4で使用されるか
	uint8_t enablePS4_6: 1;

	// NAME: XboxOne
	// DESC: XboxOneで使用されるか
	uint8_t enableXboxOne_6: 1;

	// NAME: 時間
	// DESC: 時間
	float time1_6;

	// NAME: リピート用インターバル時間
	// DESC: リピート用インターバル時間
	float time2_6;

	// NAME: アナログ→デジタル変換閾値
	// DESC: アナログ→デジタル変換閾値
	float a2dThreshold_6;

	// NAME: PC物理キー
	// DESC: PC物理キー
	int32_t phyisicalKey_7;

	// NAME: 押され方
	// DESC: 押され方
	uint8_t traitsType_7;

	// NAME: アナログ→デジタル変換方法
	// DESC: アナログ→デジタル変換方法
	uint8_t a2dOperator_7;

	// NAME: 適用ターゲット
	// DESC: 反映ターゲット
	uint8_t applyTarget_7;

	// NAME: デジタル・アナログ
	// DESC: デジタルorアナログ
	uint8_t isAnalog_7: 1;

	// NAME: Win64
	// DESC: Win64で使用されるか
	uint8_t enableWin64_7: 1;

	// NAME: PS4
	// DESC: PS4で使用されるか
	uint8_t enablePS4_7: 1;

	// NAME: XboxOne
	// DESC: XboxOneで使用されるか
	uint8_t enableXboxOne_7: 1;

	// NAME: 時間
	// DESC: 時間
	float time1_7;

	// NAME: リピート用インターバル時間
	// DESC: リピート用インターバル時間
	float time2_7;

	// NAME: アナログ→デジタル変換閾値
	// DESC: アナログ→デジタル変換閾値
	float a2dThreshold_7;
} DEFAULT_KEY_ASSIGN;

#endif
