/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_REFLECTION_QUALITY_DETAIL_H
#define _PARAMDEF_CS_REFLECTION_QUALITY_DETAIL_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_REFLECTION_QUALITY_DETAIL {

	// NAME: 反射有効
	// DESC: 反射有効
	uint8_t enabled;

	// NAME: ローカルライト有効
	// DESC: ローカルライト有効
	uint8_t localLightEnabled;

	// NAME: ローカルライト強制有効
	// DESC: ローカルライト強制有効
	uint8_t localLightForceEnabled;

	// NAME: dmy
	uint8_t dmy[1];

	// NAME: 解像度スケール
	// DESC: 解像度スケール
	uint32_t resolutionDivider;

	// NAME: SSR有効
	// DESC: SSR有効
	uint8_t ssrEnabled;

	// NAME: ガウスぼかしの許可
	// DESC: ガウスぼかしの許可
	uint8_t ssrGaussianBlurEnabled;

	// NAME: dmy
	uint8_t dmy2[2];

	// NAME: 計算距離スケール
	// DESC: 計算距離スケール
	float ssrDepthRejectThresholdScale;

	// NAME: レイトレースステップ係数（SSRパラメータに乗算）
	// DESC: レイトレースステップ係数（SSRパラメータに乗算）
	float ssrRayTraceStepScale;

	// NAME: フェード角度バイアス。小さくすると高品質
	// DESC: フェード角度バイアス。小さくすると高品質
	float ssrFadeToViewerBias;

	// NAME: フレネルリジェクトバイアス。小さくすると高品質
	// DESC: フレネルリジェクトバイアス。小さくすると高品質
	float ssrFresnelRejectBias;
} CS_REFLECTION_QUALITY_DETAIL;

#endif
