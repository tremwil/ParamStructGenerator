/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_BONFIRE_WARP_SUB_CATEGORY_PARAM_ST_H
#define _PARAMDEF_BONFIRE_WARP_SUB_CATEGORY_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BONFIRE_WARP_SUB_CATEGORY_PARAM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: テキストID
	// DESC: サブカテゴリの表示名テキストID[MenuText]
	int32_t textId;

	// NAME: 篝火ワープタブID
	// DESC: 篝火ワープタブID。このサブカテゴリが所属するタブのID
	uint16_t tabId;

	// NAME: 篝火ワープタブソートID
	// DESC: 篝火ワープタブソートID。タブの中サブカテゴリの表示順
	uint16_t sortId;

	// NAME: pad
	uint8_t pad[4];
} BONFIRE_WARP_SUB_CATEGORY_PARAM_ST;

#endif
