/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_SHADOW_QUALITY_DETAIL_H
#define _PARAMDEF_CS_SHADOW_QUALITY_DETAIL_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_SHADOW_QUALITY_DETAIL {

	// NAME: シャドウが有効
	// DESC: シャドウが有効
	uint8_t enabled;

	// NAME: 許可される最大のフィルタ品質
	// DESC: 許可される最大のフィルタ品質
	uint8_t maxFilterLevel;

	// NAME: dmy
	uint8_t dmy[2];

	// NAME: 設定されたシャドウマップ解像度のスケーラ
	// DESC: 設定されたシャドウマップ解像度のスケーラ
	uint32_t textureSizeScaler;

	// NAME: 設定されたシャドウマップ解像度を除算
	// DESC: 設定されたシャドウマップ解像度を除算
	uint32_t textureSizeDivider;

	// NAME: 解像度最小
	// DESC: 解像度をクランプ
	uint32_t textureMinSize;

	// NAME: 解像度最大
	// DESC: 解像度をクランプ。カスケード毎の解像度判定になります
	uint32_t textureMaxSize;

	// NAME: ブラーカウントバイアス
	// DESC: ブラーカウントバイアス(設定されたカウントのバイアス。0で変更なし)
	int32_t blurCountBias;
} CS_SHADOW_QUALITY_DETAIL;

#endif
