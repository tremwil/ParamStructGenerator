/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_AI_ODDS_PARAM_H
#define _PARAMDEF_AI_ODDS_PARAM_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AI_ODDS_PARAM {

	// NAME: アクション0
	// DESC: アクション0の比率
	uint8_t act0;

	// NAME: アクション1
	// DESC: アクション1の比率
	uint8_t act1;

	// NAME: アクション2
	// DESC: アクション2の比率
	uint8_t act2;

	// NAME: アクション3
	// DESC: アクション3の比率
	uint8_t act3;

	// NAME: アクション4
	// DESC: アクション4の比率
	uint8_t act4;

	// NAME: アクション5
	// DESC: アクション5の比率
	uint8_t act5;

	// NAME: アクション6
	// DESC: アクション6の比率
	uint8_t act6;

	// NAME: アクション7
	// DESC: アクション7の比率
	uint8_t act7;

	// NAME: アクション8
	// DESC: アクション8の比率
	uint8_t act8;

	// NAME: アクション9
	// DESC: アクション9の比率
	uint8_t act9;

	// NAME: アクション10
	// DESC: アクション10の比率
	uint8_t act10;

	// NAME: アクション11
	// DESC: アクション11の比率
	uint8_t act11;

	// NAME: アクション12
	// DESC: アクション12の比率
	uint8_t act12;

	// NAME: アクション13
	// DESC: アクション13の比率
	uint8_t act13;

	// NAME: アクション14
	// DESC: アクション14の比率
	uint8_t act14;

	// NAME: アクション15
	// DESC: アクション15の比率
	uint8_t act15;

	// NAME: アクション16
	// DESC: アクション16の比率
	uint8_t act16;

	// NAME: アクション17
	// DESC: アクション17の比率
	uint8_t act17;

	// NAME: アクション18
	// DESC: アクション18の比率
	uint8_t act18;

	// NAME: アクション19
	// DESC: アクション19の比率
	uint8_t act19;

	// NAME: アクション20
	// DESC: アクション20の比率
	uint8_t act20;

	// NAME: アクション21
	// DESC: アクション21の比率
	uint8_t act21;

	// NAME: アクション22
	// DESC: アクション22の比率
	uint8_t act22;

	// NAME: アクション23
	// DESC: アクション23の比率
	uint8_t act23;

	// NAME: アクション24
	// DESC: アクション24の比率
	uint8_t act24;

	// NAME: アクション25
	// DESC: アクション25の比率
	uint8_t act25;

	// NAME: アクション26
	// DESC: アクション26の比率
	uint8_t act26;

	// NAME: アクション27
	// DESC: アクション27の比率
	uint8_t act27;

	// NAME: アクション28
	// DESC: アクション28の比率
	uint8_t act28;

	// NAME: アクション29
	// DESC: アクション29の比率
	uint8_t act29;

	// NAME: アクション30
	// DESC: アクション30の比率
	uint8_t act30;

	// NAME: アクション31
	// DESC: アクション31の比率
	uint8_t act31;

	// NAME: アクション32
	// DESC: アクション32の比率
	uint8_t act32;

	// NAME: アクション33
	// DESC: アクション33の比率
	uint8_t act33;

	// NAME: アクション34
	// DESC: アクション34の比率
	uint8_t act34;

	// NAME: アクション35
	// DESC: アクション35の比率
	uint8_t act35;

	// NAME: アクション36
	// DESC: アクション36の比率
	uint8_t act36;

	// NAME: アクション37
	// DESC: アクション37の比率
	uint8_t act37;

	// NAME: アクション38
	// DESC: アクション38の比率
	uint8_t act38;

	// NAME: アクション39
	// DESC: アクション39の比率
	uint8_t act39;

	// NAME: アクション40
	// DESC: アクション40の比率
	uint8_t act40;

	// NAME: アクション41
	// DESC: アクション41の比率
	uint8_t act41;

	// NAME: アクション42
	// DESC: アクション42の比率
	uint8_t act42;

	// NAME: アクション43
	// DESC: アクション43の比率
	uint8_t act43;

	// NAME: アクション44
	// DESC: アクション44の比率
	uint8_t act44;

	// NAME: アクション45
	// DESC: アクション45の比率
	uint8_t act45;

	// NAME: アクション46
	// DESC: アクション46の比率
	uint8_t act46;

	// NAME: アクション47
	// DESC: アクション47の比率
	uint8_t act47;

	// NAME: アクション48
	// DESC: アクション48の比率
	uint8_t act48;

	// NAME: アクション49
	// DESC: アクション49の比率
	uint8_t act49;

	// NAME: アクション50
	// DESC: アクション50の比率
	uint8_t act50;

	// NAME: アクション51
	// DESC: アクション51の比率
	uint8_t act51;

	// NAME: アクション52
	// DESC: アクション52の比率
	uint8_t act52;

	// NAME: アクション53
	// DESC: アクション53の比率
	uint8_t act53;

	// NAME: アクション54
	// DESC: アクション54の比率
	uint8_t act54;

	// NAME: アクション55
	// DESC: アクション55の比率
	uint8_t act55;

	// NAME: アクション56
	// DESC: アクション56の比率
	uint8_t act56;

	// NAME: アクション57
	// DESC: アクション57の比率
	uint8_t act57;

	// NAME: アクション58
	// DESC: アクション58の比率
	uint8_t act58;

	// NAME: アクション59
	// DESC: アクション59の比率
	uint8_t act59;

	// NAME: アクション60
	// DESC: アクション60の比率
	uint8_t act60;

	// NAME: アクション61
	// DESC: アクション61の比率
	uint8_t act61;

	// NAME: アクション62
	// DESC: アクション62の比率
	uint8_t act62;

	// NAME: アクション63
	// DESC: アクション63の比率
	uint8_t act63;

	// NAME: アクション64
	// DESC: アクション64の比率
	uint8_t act64;

	// NAME: アクション65
	// DESC: アクション65の比率
	uint8_t act65;

	// NAME: アクション66
	// DESC: アクション66の比率
	uint8_t act66;

	// NAME: アクション67
	// DESC: アクション67の比率
	uint8_t act67;

	// NAME: アクション68
	// DESC: アクション68の比率
	uint8_t act68;

	// NAME: アクション69
	// DESC: アクション69の比率
	uint8_t act69;

	// NAME: アクション70
	// DESC: アクション70の比率
	uint8_t act70;

	// NAME: アクション71
	// DESC: アクション71の比率
	uint8_t act71;

	// NAME: アクション72
	// DESC: アクション72の比率
	uint8_t act72;

	// NAME: アクション73
	// DESC: アクション73の比率
	uint8_t act73;

	// NAME: アクション74
	// DESC: アクション74の比率
	uint8_t act74;

	// NAME: アクション75
	// DESC: アクション75の比率
	uint8_t act75;

	// NAME: アクション76
	// DESC: アクション76の比率
	uint8_t act76;

	// NAME: アクション77
	// DESC: アクション77の比率
	uint8_t act77;

	// NAME: アクション78
	// DESC: アクション78の比率
	uint8_t act78;

	// NAME: アクション79
	// DESC: アクション79の比率
	uint8_t act79;

	// NAME: アクション80
	// DESC: アクション80の比率
	uint8_t act80;

	// NAME: アクション81
	// DESC: アクション81の比率
	uint8_t act81;

	// NAME: アクション82
	// DESC: アクション82の比率
	uint8_t act82;

	// NAME: アクション83
	// DESC: アクション83の比率
	uint8_t act83;

	// NAME: アクション84
	// DESC: アクション84の比率
	uint8_t act84;

	// NAME: アクション85
	// DESC: アクション85の比率
	uint8_t act85;

	// NAME: アクション86
	// DESC: アクション86の比率
	uint8_t act86;

	// NAME: アクション87
	// DESC: アクション87の比率
	uint8_t act87;

	// NAME: アクション88
	// DESC: アクション88の比率
	uint8_t act88;

	// NAME: アクション89
	// DESC: アクション89の比率
	uint8_t act89;

	// NAME: アクション90
	// DESC: アクション90の比率
	uint8_t act90;

	// NAME: アクション91
	// DESC: アクション91の比率
	uint8_t act91;

	// NAME: アクション92
	// DESC: アクション92の比率
	uint8_t act92;

	// NAME: アクション93
	// DESC: アクション93の比率
	uint8_t act93;

	// NAME: アクション94
	// DESC: アクション94の比率
	uint8_t act94;

	// NAME: アクション95
	// DESC: アクション95の比率
	uint8_t act95;

	// NAME: アクション96
	// DESC: アクション96の比率
	uint8_t act96;

	// NAME: アクション97
	// DESC: アクション97の比率
	uint8_t act97;

	// NAME: アクション98
	// DESC: アクション98の比率
	uint8_t act98;

	// NAME: アクション99
	// DESC: アクション99の比率
	uint8_t act99;

	// NAME: pad
	// DESC: pad
	uint8_t pad0[12];
} AI_ODDS_PARAM;

#endif
