/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CUTSCENE_GPARAM_TIME_PARAM_ST_H
#define _PARAMDEF_CUTSCENE_GPARAM_TIME_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CUTSCENE_GPARAM_TIME_PARAM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: デバッグパラメータか
	// DESC: ○をつけたパラメータは全パッケージから除外します（デバッグ用なので）
	uint8_t disableParam_Debug: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 6;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: 朝
	// DESC: 朝(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_Morning;

	// NAME: 昼A
	// DESC: 昼A(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_Noon;

	// NAME: 昼B
	// DESC: 昼B(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_AfterNoon;

	// NAME: 夕
	// DESC: 夕(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_Evening;

	// NAME: 夜
	// DESC: 夜(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_Night;

	// NAME: 深夜A
	// DESC: 深夜A(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_DeepNightA;

	// NAME: 深夜B
	// DESC: 深夜B(変換時刻はカットシーン時間変換設定シートを参照）
	uint8_t DstTimezone_DeepNightB;

	// NAME: reserved
	// DESC: reserved
	uint8_t reserved[1];

	// NAME: 再生終了時のインゲーム時刻指定[hour]
	// DESC: 再生終了時のインゲーム時刻指定[hour][-1.0～24.0](-1(0より小さい)：何もしない)
	float PostPlayIngameTime;
} CUTSCENE_GPARAM_TIME_PARAM_ST;

#endif
