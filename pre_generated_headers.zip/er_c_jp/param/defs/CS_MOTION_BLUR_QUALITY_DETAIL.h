/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_MOTION_BLUR_QUALITY_DETAIL_H
#define _PARAMDEF_CS_MOTION_BLUR_QUALITY_DETAIL_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_MOTION_BLUR_QUALITY_DETAIL {

	// NAME: モーションブラー有効
	// DESC: モーションブラー有効
	uint8_t enabled;

	// NAME: OMB(オブジェクトモーションブラー)有効
	// DESC: OMB(オブジェクトモーションブラー)有効
	uint8_t ombEnabled;

	// NAME: 内部で使用するベロシティバッファの解像度を下げる
	// DESC: 内部で使用するベロシティバッファの解像度を下げる。高精度ベロシティバッファを使っていない場合は効果ない
	uint8_t forceScaleVelocityBuffer;

	// NAME: 通常、Reconstructionフィルタで処理されるが、軽い処理にダウングレードする
	// DESC: 通常、Reconstructionフィルタで処理されるが、軽い処理にダウングレードする
	uint8_t cheapFilterMode;

	// NAME: サンプルカウントにオフセットを与える
	// DESC: サンプルカウントにオフセットを与える※2の倍数に設定して下さい
	int32_t sampleCountBias;

	// NAME: 再帰ブラー回数にオフセットを与える
	// DESC: 再帰ブラー回数にオフセットを与える
	int32_t recurrenceCountBias;

	// NAME: ブラー最大長さパラメータに対するスケール値
	// DESC: ブラー最大長さパラメータに対するスケール値
	float blurMaxLengthScale;
} CS_MOTION_BLUR_QUALITY_DETAIL;

#endif
