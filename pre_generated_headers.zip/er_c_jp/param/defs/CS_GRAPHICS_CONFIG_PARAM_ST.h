/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_GRAPHICS_CONFIG_PARAM_ST_H
#define _PARAMDEF_CS_GRAPHICS_CONFIG_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_GRAPHICS_CONFIG_PARAM_ST {

	// NAME: テクスチャフィルタ品質
	// DESC: テクスチャフィルタ品質(デフォルトMidele)
	uint8_t m_textureFilterQuality;

	// NAME: AA品質
	// DESC: AA品質(デフォルトHigh)
	uint8_t m_aaQuality;

	// NAME: SSAO品質
	// DESC: SSAO品質(デフォルトHigh)
	uint8_t m_ssaoQuality;

	// NAME: 被写界深度品質
	// DESC: 被写界深度品質(デフォルトHigh)
	uint8_t m_dofQuality;

	// NAME: モーションブラー品質
	// DESC: モーションブラー品質(デフォルトHigh)
	uint8_t m_motionBlurQuality;

	// NAME: シャドウ品質
	// DESC: シャドウ品質(デフォルトHigh)
	uint8_t m_shadowQuality;

	// NAME: ライティング品質
	// DESC: ライティング品質(デフォルトHigh)
	uint8_t m_lightingQuality;

	// NAME: エフェクト品質
	// DESC: エフェクト品質(デフォルトHigh)
	uint8_t m_effectQuality;

	// NAME: デカール品質
	// DESC: デカール品質(デフォルトHigh)
	uint8_t m_decalQuality;

	// NAME: 反射品質
	// DESC: 反射品質(デフォルトHigh)
	uint8_t m_reflectionQuality;

	// NAME: ウォーター品質
	// DESC: ウォーター品質(デフォルトHigh)
	uint8_t m_waterQuality;

	// NAME: シェーダー品質
	// DESC: シェーダー品質(デフォルトHigh)
	uint8_t m_shaderQuality;

	// NAME: ボリューメトリック効果品質
	// DESC: ボリューメトリック効果品質(デフォルトHigh)
	uint8_t m_volumetricEffectQuality;

	// NAME: dmy
	uint8_t m_dummy[3];
} CS_GRAPHICS_CONFIG_PARAM_ST;

#endif
