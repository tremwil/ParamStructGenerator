/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_EFFECT_QUALITY_DETAIL_H
#define _PARAMDEF_CS_EFFECT_QUALITY_DETAIL_H
#pragma once
#include <inttypes.h>

// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_EFFECT_QUALITY_DETAIL {

	// NAME: ソフトパーティクル有効
	// DESC: ソフトパーティクル有効
	uint8_t softParticleEnabled;

	// NAME: グロー有効
	// DESC: グロー有効
	uint8_t glowEnabled;

	// NAME: 歪み有効
	// DESC: 歪み有効
	uint8_t distortionEnable;

	// NAME: バイラテラルアップスケールを有効
	// DESC: バイラテラルアップスケール有効
	uint8_t cs_upScaleEnabledType;

	// NAME: 一回のエミット数
	// DESC: 一回のエミット数
	float fNumOnceEmitsScale;

	// NAME: エミット間隔
	// DESC: エミット間隔
	float fEmitSpanScale;

	// NAME: 1段階目のLOD距離スケール
	// DESC: 1段階目のLOD距離スケール
	float fLodDistance1Scale;

	// NAME: 2段階目のLOD距離スケール
	// DESC: 2段階目のLOD距離スケール
	float fLodDistance2Scale;

	// NAME: 3段階目のLOD距離スケール
	// DESC: 3段階目のLOD距離スケール
	float fLodDistance3Scale;

	// NAME: 4段階目のLOD距離スケール
	// DESC: 4段階目のLOD距離スケール
	float fLodDistance4Scale;

	// NAME: 縮小バッファへ登録される距離への倍率
	// DESC: 縮小バッファへ登録される距離への倍率
	float fScaleRenderDistanceScale;

	// NAME: ダミー
	uint8_t dmy[4];
} CS_EFFECT_QUALITY_DETAIL;

#endif
