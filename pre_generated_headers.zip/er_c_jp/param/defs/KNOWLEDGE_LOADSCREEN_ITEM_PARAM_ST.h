/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_KNOWLEDGE_LOADSCREEN_ITEM_PARAM_ST_H
#define _PARAMDEF_KNOWLEDGE_LOADSCREEN_ITEM_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _KNOWLEDGE_LOADSCREEN_ITEM_PARAM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: 解禁フラグ
	// DESC: 解禁フラグ(default: 0)。このイベントフラグが立っていれば解禁される（ローディング画面に表示される）。0なら常に解禁されている。無効フラグの方が優先される
	uint32_t unlockFlagId;

	// NAME: 無効フラグ
	// DESC: 無効フラグ(default: 0)。このイベントフラグが立っていると無効化（ローディング画面に表示されなくなる）。0なら常にこのフラグは立っていないものとする
	uint32_t invalidFlagId;

	// NAME: テキストID
	// DESC: テキストID(Loading Text.xlsx)。ローディングタイトルとローディングテキスト両方に使われる
	int32_t msgId;
} KNOWLEDGE_LOADSCREEN_ITEM_PARAM_ST;

#endif
