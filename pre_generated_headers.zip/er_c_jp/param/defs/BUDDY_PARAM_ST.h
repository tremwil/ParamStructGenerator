/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_BUDDY_PARAM_ST_H
#define _PARAMDEF_BUDDY_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BUDDY_PARAM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: 召喚特殊効果ID
	// DESC: 召喚条件になる特殊効果IDを設定します 
	int32_t triggerSpEffectId;

	// NAME: NPCパラメータID
	// DESC: 召喚されるバディのNPCパラメータIDを設定します
	int32_t npcParamId;

	// NAME: 思考パラメータID
	// DESC: 召喚されるバディのNPC思考パラメータIDを設定します
	int32_t npcThinkParamId;

	// NAME: 騎乗（乗られる側）：NPCパラメータID
	// DESC: 騎乗状態で召喚したいバディの場合、「乗られる側」のNPCパラメータIDを設定します 
	int32_t npcParamId_ridden;

	// NAME: 騎乗（乗られる側）：思考パラメータID
	// DESC: 騎乗状態で召喚したいバディの場合、「乗られる側」のNPC思考パラメータIDを設定します
	int32_t npcThinkParamId_ridden;

	// NAME: X：配置座標オフセット[m]
	// DESC: バディを召喚ポイントから、X座標にオフセットする距離をメートル単位で設定します
	float x_offset;

	// NAME: Z：配置座標オフセット[m]
	// DESC: バディを召喚ポイントから、Z座標にオフセットする距離をメートル単位で設定します
	float z_offset;

	// NAME: Y：自分の配置角度[deg]
	// DESC: Y軸を中心に、自分を回転させる角度を設定します
	float y_angle;

	// NAME: 石碑周辺から出現するか？
	// DESC: 石碑周辺から出現するか？
	uint8_t appearOnAroundSekihi;

	// NAME: PCとのターゲット共有をスキップするか？
	// DESC: PCとのターゲット共有をスキップするか？
	uint8_t disablePCTargetShare;

	// NAME: PC追従＆ワープタイプ 
	// DESC: PC追従＆ワープタイプ 
	uint8_t pcFollowType;

	// NAME: リザーブ
	// DESC: リザーブ
	uint8_t Reserve[1];

	// NAME: +0時ドーピング特殊効果
	// DESC: +0時ドーピング特殊効果
	int32_t dopingSpEffect_lv0;

	// NAME: +1時ドーピング特殊効果
	// DESC: +0時ドーピング特殊効果
	int32_t dopingSpEffect_lv1;

	// NAME: +2時ドーピング特殊効果
	// DESC: +0時ドーピング特殊効果
	int32_t dopingSpEffect_lv2;

	// NAME: +3時ドーピング特殊効果
	// DESC: +0時ドーピング特殊効果
	int32_t dopingSpEffect_lv3;

	// NAME: +4時ドーピング特殊効果
	// DESC: +0時ドーピング特殊効果
	int32_t dopingSpEffect_lv4;

	// NAME: +5時ドーピング特殊効果
	// DESC: +0時ドーピング特殊効果
	int32_t dopingSpEffect_lv5;

	// NAME: +6時ドーピング特殊効果
	// DESC: +0時ドーピング特殊効果
	int32_t dopingSpEffect_lv6;

	// NAME: +7時ドーピング特殊効果
	// DESC: +0時ドーピング特殊効果
	int32_t dopingSpEffect_lv7;

	// NAME: +8時ドーピング特殊効果
	// DESC: +0時ドーピング特殊効果
	int32_t dopingSpEffect_lv8;

	// NAME: +9時ドーピング特殊効果
	// DESC: +0時ドーピング特殊効果
	int32_t dopingSpEffect_lv9;

	// NAME: +10時ドーピング特殊効果
	// DESC: +0時ドーピング特殊効果
	int32_t dopingSpEffect_lv10;

	// NAME: アーキタイプ別初期パラメータID
	// DESC: アーキタイプ別初期パラメータID
	int32_t npcPlayerInitParamId;

	// NAME: ジェネレートアニメID
	// DESC: ジェネレートアニメID
	int32_t generateAnimId;

	// NAME: リザーブ2
	// DESC: リザーブ２
	uint8_t Reserve2[4];
} BUDDY_PARAM_ST;

#endif
