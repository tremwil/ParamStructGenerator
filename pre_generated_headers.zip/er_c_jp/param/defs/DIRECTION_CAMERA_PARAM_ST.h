/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_DIRECTION_CAMERA_PARAM_ST_H
#define _PARAMDEF_DIRECTION_CAMERA_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _DIRECTION_CAMERA_PARAM_ST {

	// NAME: オプションの影響を受けるか
	// DESC: 演出カメラON/OFFオプションの影響を受けるか？
	uint8_t isUseOption: 1;

	// NAME: パッド
	// DESC: pad
	uint8_t pad2: 3;

	// NAME: パッド
	// DESC: pad
	uint8_t pad1[15];
} DIRECTION_CAMERA_PARAM_ST;

#endif
