/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_BASECHR_SELECT_MENU_PARAM_ST_H
#define _PARAMDEF_BASECHR_SELECT_MENU_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BASECHR_SELECT_MENU_PARAM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: アーキタイプID：ベースキャラクター
	// DESC: フェイスパラを設定したアーキタイプ別初期パラメータIDを指定する 
	uint32_t chrInitParam;

	// NAME: アーキタイプID：素性
	// DESC: 素性のアーキタイプ別初期パラメータIDを指定する
	uint32_t originChrInitParam;

	// NAME: イメージID
	// DESC: ベースキャラクター選択画面に並ぶ画像。Flaに埋め込まれたリソースのフレーム数を指定
	int32_t imageId;

	// NAME: テキストID
	// DESC: 職業名のメニューテキストID
	int32_t textId;

	// NAME: リザーブ
	uint8_t reserve[12];
} BASECHR_SELECT_MENU_PARAM_ST;

#endif
