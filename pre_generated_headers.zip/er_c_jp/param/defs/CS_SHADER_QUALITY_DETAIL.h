/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_SHADER_QUALITY_DETAIL_H
#define _PARAMDEF_CS_SHADER_QUALITY_DETAIL_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_SHADER_QUALITY_DETAIL {

	// NAME: SSS有効
	// DESC: SSS有効
	uint8_t sssEnabled;

	// NAME: テッセレーション有効
	// DESC: テッセレーション有効
	uint8_t tessellationEnabled;

	// NAME: 高精度ノーマル有効
	// DESC: 高精度ノーマル有効(G-Bufferに格納する法線の精度の設定)
	uint8_t highPrecisionNormalEnabled;

	// NAME: dmy
	char dmy[1];
} CS_SHADER_QUALITY_DETAIL;

#endif
