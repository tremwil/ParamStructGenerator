/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_ESTUS_FLASK_RECOVERY_PARAM_ST_H
#define _PARAMDEF_ESTUS_FLASK_RECOVERY_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ESTUS_FLASK_RECOVERY_PARAM_ST {

	// NAME: ホスト
	// DESC: ホストのエスト回復数
	uint8_t host;

	// NAME: 侵入経路_オーブ_なし
	// DESC: 侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_None;

	// NAME: 侵入経路_オーブ_太陽
	// DESC: 侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_Umbasa;

	// NAME: 侵入経路_オーブ_バーサーカー
	// DESC: 侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_Berserker;

	// NAME: 侵入経路_オーブ_罪人
	// DESC: 侵入経路がオーブの勢力のエスト回復数
	uint8_t invadeOrb_Sinners;

	// NAME: 侵入経路_サイン_なし
	// DESC: 侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_None;

	// NAME: 侵入経路_サイン_太陽
	// DESC: 侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_Umbasa;

	// NAME: 侵入経路_サイン_バーサーカー
	// DESC: 侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_Berserker;

	// NAME: 侵入経路_サイン_罪人
	// DESC: 侵入経路がサインの勢力のエスト回復数
	uint8_t invadeSign_Sinners;

	// NAME: 侵入経路_指輪_罪人
	// DESC: 侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Sinners;

	// NAME: 侵入経路_指輪_ボス守(ロザリア)
	// DESC: 侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Rosalia;

	// NAME: 侵入経路_指輪_マップ守(森)
	// DESC: 侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Forest;

	// NAME: 協力経路_サイン_なし
	// DESC: 協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_None;

	// NAME: 協力経路_サイン_太陽
	// DESC: 協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_Umbasa;

	// NAME: 協力経路_サイン_バーサーカー
	// DESC: 協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_Berserker;

	// NAME: 協力経路_サイン_罪人
	// DESC: 協力経路がサインの勢力のエスト回復数
	uint8_t coopSign_Sinners;

	// NAME: 協力経路_指輪 _赤狩り
	// DESC: 協力経路が指輪の勢力のエスト回復数
	uint8_t coopRing_RedHunter;

	// NAME: 侵入経路_指輪_マップ守(アノール)
	// DESC: 侵入経路が指輪の勢力のエスト回復数
	uint8_t invadeRing_Anor;

	// NAME: 回復数パラメータ差し替え率
	// DESC: 回復数パラメータ差し替え率
	uint16_t paramReplaceRate;

	// NAME: 回復数パラメータ差し替え先ID
	// DESC: 回復数パラメータ差し替え先ID
	int32_t paramReplaceId;

	// NAME: pad
	uint8_t pad[8];
} ESTUS_FLASK_RECOVERY_PARAM_ST;

#endif
