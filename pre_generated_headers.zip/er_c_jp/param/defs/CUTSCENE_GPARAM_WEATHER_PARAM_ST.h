/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CUTSCENE_GPARAM_WEATHER_PARAM_ST_H
#define _PARAMDEF_CUTSCENE_GPARAM_WEATHER_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CUTSCENE_GPARAM_WEATHER_PARAM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: デバッグパラメータか
	// DESC: ○をつけたパラメータは全パッケージから除外します（デバッグ用なので）
	uint8_t disableParam_Debug: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 6;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: 晴れ
	// DESC: 晴れ
	int16_t DstWeather_Sunny;

	// NAME: 快晴
	// DESC: 快晴
	int16_t DstWeather_ClearSky;

	// NAME: 薄曇り
	// DESC: 薄曇り
	int16_t DstWeather_WeakCloudy;

	// NAME: 曇り
	// DESC: 曇り
	int16_t DstWeather_Cloud;

	// NAME: 雨
	// DESC: 雨
	int16_t DstWeather_Rain;

	// NAME: 豪雨
	// DESC: 豪雨
	int16_t DstWeather_HeavyRain;

	// NAME: 嵐
	// DESC: 嵐
	int16_t DstWeather_Storm;

	// NAME: 嵐（守護者の末裔との戦闘用）
	// DESC: 嵐（守護者の末裔との戦闘用）
	int16_t DstWeather_StormForBattle;

	// NAME: 雪
	// DESC: 雪
	int16_t DstWeather_Snow;

	// NAME: 大雪
	// DESC: 大雪
	int16_t DstWeather_HeavySnow;

	// NAME: 霧
	// DESC: 霧
	int16_t DstWeather_Fog;

	// NAME: 濃霧
	// DESC: 濃霧
	int16_t DstWeather_HeavyFog;

	// NAME: 砂嵐
	// DESC: 砂嵐
	int16_t DstWeather_SandStorm;

	// NAME: 濃霧（雨）
	// DESC: 濃霧（雨）
	int16_t DstWeather_HeavyFogRain;

	// NAME: 再生終了時のインゲーム天候指定(未使用、無効)
	// DESC: 再生終了時のインゲーム天候指定(空白または「無効」の場合は何も行われない。)
	int16_t PostPlayIngameWeather;

	// NAME: 屋内屋外指定
	// DESC: 屋内にすると「天候パラメータ.xlsm」の「天候SfxId(屋外)」と「風SfxId(屋外)」で指定されたSFXがカットシーン内で無効になります。
	uint8_t IndoorOutdoorType;

	// NAME: インゲームの天候SFX引き継ぐか？_晴れ
	// DESC: インゲームの天候SFX引き継ぐか？_晴れ
	uint8_t TakeOverDstWeather_Sunny;

	// NAME: インゲームの天候SFX引き継ぐか？_快晴
	// DESC: インゲームの天候SFX引き継ぐか？_快晴
	uint8_t TakeOverDstWeather_ClearSky;

	// NAME: インゲームの天候SFX引き継ぐか？_薄曇り
	// DESC: インゲームの天候SFX引き継ぐか？_薄曇り
	uint8_t TakeOverDstWeather_WeakCloudy;

	// NAME: インゲームの天候SFX引き継ぐか？_曇り
	// DESC: インゲームの天候SFX引き継ぐか？_曇り
	uint8_t TakeOverDstWeather_Cloud;

	// NAME: インゲームの天候SFX引き継ぐか？_雨
	// DESC: インゲームの天候SFX引き継ぐか？_雨
	uint8_t TakeOverDstWeather_Rain;

	// NAME: インゲームの天候SFX引き継ぐか？_豪雨
	// DESC: インゲームの天候SFX引き継ぐか？_豪雨
	uint8_t TakeOverDstWeather_HeavyRain;

	// NAME: インゲームの天候SFX引き継ぐか？_嵐
	// DESC: インゲームの天候SFX引き継ぐか？_嵐
	uint8_t TakeOverDstWeather_Storm;

	// NAME: インゲームの天候SFX引き継ぐか？_嵐（守護者の末裔との戦闘用）
	// DESC: インゲームの天候SFX引き継ぐか？_嵐（守護者の末裔との戦闘用）
	uint8_t TakeOverDstWeather_StormForBattle;

	// NAME: インゲームの天候SFX引き継ぐか？_雪
	// DESC: インゲームの天候SFX引き継ぐか？_雪
	uint8_t TakeOverDstWeather_Snow;

	// NAME: インゲームの天候SFX引き継ぐか？_大雪
	// DESC: インゲームの天候SFX引き継ぐか？_大雪
	uint8_t TakeOverDstWeather_HeavySnow;

	// NAME: インゲームの天候SFX引き継ぐか？_霧
	// DESC: インゲームの天候SFX引き継ぐか？_霧
	uint8_t TakeOverDstWeather_Fog;

	// NAME: インゲームの天候SFX引き継ぐか？_濃霧
	// DESC: インゲームの天候SFX引き継ぐか？_濃霧
	uint8_t TakeOverDstWeather_HeavyFog;

	// NAME: インゲームの天候SFX引き継ぐか？_砂嵐
	// DESC: インゲームの天候SFX引き継ぐか？_砂嵐
	uint8_t TakeOverDstWeather_SandStorm;

	// NAME: インゲームの天候SFX引き継ぐか？_濃霧（雨）
	// DESC: インゲームの天候SFX引き継ぐか？_濃霧（雨）
	uint8_t TakeOverDstWeather_HeavyFogRain;

	// NAME: reserved
	// DESC: reserved
	uint8_t reserved[7];

	// NAME: 吹雪
	// DESC: 吹雪
	int16_t DstWeather_Snowstorm;

	// NAME: 嵐（雷）
	// DESC: 予備天候2
	int16_t DstWeather_LightningStorm;

	// NAME: 雪特殊(予備3)
	// DESC: 予備天候3
	int16_t DstWeather_Reserved3;

	// NAME: 予備天候4
	// DESC: 予備天候4
	int16_t DstWeather_Reserved4;

	// NAME: 予備天候5
	// DESC: 予備天候5
	int16_t DstWeather_Reserved5;

	// NAME: 予備天候6
	// DESC: 予備天候6
	int16_t DstWeather_Reserved6;

	// NAME: 予備天候7
	// DESC: 予備天候7
	int16_t DstWeather_Reserved7;

	// NAME: 予備天候8
	// DESC: 予備天候8
	int16_t DstWeather_Reserved8;

	// NAME: インゲームの天候SFX引き継ぐか？_吹雪
	// DESC: インゲームの天候SFX引き継ぐか？_吹雪
	uint8_t TakeOverDstWeather_Snowstorm;

	// NAME: インゲームの天候SFX引き継ぐか？_嵐（雷）
	// DESC: インゲームの天候SFX引き継ぐか？_嵐（雷）
	uint8_t TakeOverDstWeather_LightningStorm;

	// NAME: インゲームの天候SFX引き継ぐか？_雪特殊(予備3)
	// DESC: インゲームの天候SFX引き継ぐか？_予備天候3
	uint8_t TakeOverDstWeather_Reserved3;

	// NAME: インゲームの天候SFX引き継ぐか？_予備天候4
	// DESC: インゲームの天候SFX引き継ぐか？_予備天候4
	uint8_t TakeOverDstWeather_Reserved4;

	// NAME: インゲームの天候SFX引き継ぐか？_予備天候5
	// DESC: インゲームの天候SFX引き継ぐか？_予備天候5
	uint8_t TakeOverDstWeather_Reserved5;

	// NAME: インゲームの天候SFX引き継ぐか？_予備天候6
	// DESC: インゲームの天候SFX引き継ぐか？_予備天候6
	uint8_t TakeOverDstWeather_Reserved6;

	// NAME: インゲームの天候SFX引き継ぐか？_予備天候7
	// DESC: インゲームの天候SFX引き継ぐか？_予備天候7
	uint8_t TakeOverDstWeather_Reserved7;

	// NAME: インゲームの天候SFX引き継ぐか？_予備天候8
	// DESC: インゲームの天候SFX引き継ぐか？_予備天候8
	uint8_t TakeOverDstWeather_Reserved8;

	// NAME: 天候GparamにMapGD地方IDを適用するか？
	// DESC: カットシーン天候Gparamにインゲーム同様MapGD地方IDによる変化を適用するか？(【GR】SEQ30194)
	uint8_t IsEnableApplyMapGdRegionIdForGparam;

	// NAME: reserved1
	// DESC: reserved1 ver4->5 64->96へ増量
	uint8_t reserved2[1];

	// NAME: 天候GparamMapGD用地方ID上書き
	// DESC: カットシーン天候Gparamに使用されるIDを上書きする(-1：上書きなし。カットシーン再生時のMapGD地方IDが使用される)。「天候GparamにMapGD地方IDを適用するか？」が×の場合は参照されない
	int16_t OverrideMapGdRegionId;

	// NAME: reserved1
	// DESC: reserved1 ver4->5 64->96へ増量
	uint8_t reserved1[12];
} CUTSCENE_GPARAM_WEATHER_PARAM_ST;

#endif
