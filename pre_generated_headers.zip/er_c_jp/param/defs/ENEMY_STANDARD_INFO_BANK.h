/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_ENEMY_STANDARD_INFO_BANK_H
#define _PARAMDEF_ENEMY_STANDARD_INFO_BANK_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ENEMY_STANDARD_INFO_BANK {

	// NAME: 挙動ｉｄ
	// DESC: 敵の挙動ＩＤ
	int32_t EnemyBehaviorID;

	// NAME: ヒットポイント
	// DESC: ヒットポイント
	uint16_t HP;

	// NAME: 攻撃力
	// DESC: 攻撃力（プロト専用）
	uint16_t AttackPower;

	// NAME: キャラタイプ
	// DESC: キャラタイプ
	int32_t ChrType;

	// NAME: あたりの高さ[m]
	// DESC: あたりの高さ（直径以上のサイズを指定してください）
	float HitHeight;

	// NAME: あたりの半径[m]
	// DESC: あたりの半径
	float HitRadius;

	// NAME: 重さ[kg]
	// DESC: キャラの重さ
	float Weight;

	// NAME: 動摩擦力
	// DESC: 動摩擦力
	float DynamicFriction;

	// NAME: 静摩擦力
	// DESC: 静止摩擦力
	float StaticFriction;

	// NAME: 上半身初期状態
	// DESC: 上半身初期状態（PG入力）
	int32_t UpperDefState;

	// NAME: アクション初期状態
	// DESC: アクション初期状態（PG入力）
	int32_t ActionDefState;

	// NAME: 単位時間当たり旋回できる角度[deg/s]
	// DESC: 単位時間当たりのＹ軸旋回角度[deg/s]
	float RotY_per_Second;

	// NAME: 予約
	uint8_t reserve0[20];

	// NAME: 未使用
	// DESC: 未使用
	uint8_t RotY_per_Second_old;

	// NAME: 左右移動できるか
	// DESC: 左右移動できるか
	uint8_t EnableSideStep;

	// NAME: キャラあたりにラグドールを使用するか
	// DESC: キャラあたりにラグドールを使用するか
	uint8_t UseRagdollHit;

	// NAME: 予約
	uint8_t reserve_last[5];

	// NAME: スタミナ量
	// DESC: スタミナ総量
	uint16_t stamina;

	// NAME: スタミナ回復
	// DESC: 1秒間あたりのスタミナ回復量
	uint16_t staminaRecover;

	// NAME: スタミナ基本消費
	// DESC: 攻撃、ガード時に使用するスタミナ消費の基本値
	uint16_t staminaConsumption;

	// NAME: 物理防御力
	// DESC: 物理攻撃に対するダメージ減少基本値
	uint16_t deffenct_Phys;

	// NAME: 予約1
	uint8_t reserve_last2[48];
} ENEMY_STANDARD_INFO_BANK;

#endif
