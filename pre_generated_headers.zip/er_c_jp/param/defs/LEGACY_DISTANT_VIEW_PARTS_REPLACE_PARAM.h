/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_LEGACY_DISTANT_VIEW_PARTS_REPLACE_PARAM_H
#define _PARAMDEF_LEGACY_DISTANT_VIEW_PARTS_REPLACE_PARAM_H
#pragma once
#include <inttypes.h>

// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _LEGACY_DISTANT_VIEW_PARTS_REPLACE_PARAM {

	// NAME: マップID
	// DESC: 対象のマップIDを指定します。レガシーのみ。(m12_34_56_78→12345678) 。当初レガシーのみでしたがオープンの天球マップも対応しました
	int32_t TargetMapId;

	// NAME: 天変地異イベントID
	// DESC: 「300、310、311、312」の中から、対象天変地異イベントIDを入力した場合は【天変地異差し替えデータ】となります。0or空白の場合は【地方IDの切り替えデータ】となります(SEQ16039)
	uint32_t TargetEventId;

	// NAME: 差し替え元アセットID
	// DESC: 差し替え元AssetId：AEG123_456_9999→123456
	int32_t SrcAssetId;

	// NAME: 差し替え元アセットパーツID
	// DESC: 差し替え元PartsNo：AEG123_456_9999→9999
	int32_t SrcAssetPartsNo;

	// NAME: 差し替え先アセットID
	// DESC: 差し替え先AssetId：AEG123_456_9999→123456
	int32_t DstAssetId;

	// NAME: 差し替え先アセットパーツID
	// DESC: 差し替え先PartsNo：AEG123_456_9999→9999
	int32_t DstAssetPartsNo;

	// NAME: 差し替え元アセットID範囲指定Min
	// DESC: 差し替え元アセットID範囲指定Min
	int32_t SrcAssetIdRangeMin;

	// NAME: 差し替え元アセットID範囲指定Max
	// DESC: 差し替え元アセットID範囲指定Max
	int32_t SrcAssetIdRangeMax;

	// NAME: 差し替え先アセットID範囲指定Min
	// DESC: 差し替え先アセットID範囲指定Min
	int32_t DstAssetIdRangeMin;

	// NAME: 差し替え先アセットID範囲指定Max
	// DESC: 差し替え先アセットID範囲指定Max
	int32_t DstAssetIdRangeMax;

	// NAME: 地方ID制限0
	// DESC: MapGD地方IDの制限0：「天変地異イベントID」が0の時だけ有効。設定したMapGD地方IDでのみパーツが有効になります(SEQ16039)
	int8_t LimitedMapRegionId0;

	// NAME: 地方ID制限1
	// DESC: MapGD地方IDの制限1：「天変地異イベントID」が0の時だけ有効。設定したMapGD地方IDでのみパーツが有効になります(SEQ16039)
	int8_t LimitedMapRegionId1;

	// NAME: 地方ID制限2
	// DESC: MapGD地方IDの制限2：「天変地異イベントID」が0の時だけ有効。設定したMapGD地方IDでのみパーツが有効になります(SEQ16039)
	int8_t LimitedMapRegionId2;

	// NAME: 地方ID制限3
	// DESC: MapGD地方IDの制限3：「天変地異イベントID」が0の時だけ有効。設定したMapGD地方IDでのみパーツが有効になります(SEQ16039)
	int8_t LimitedMapRegionId3;

	// NAME: 予約
	// DESC: 予約
	uint8_t reserve[4];

	// NAME: 地方制限アセットID
	// DESC: MapGD地方IDで有効なアセット指定：AssetId：AEG123_456_9999→123456
	int32_t LimitedMapRegionAssetId;

	// NAME: 地方制限アセットパーツID
	// DESC: MapGD地方IDで有効なアセット指定：PartsNo：AEG123_456_9999→9999
	int32_t LimitedMapRegioAssetPartsNo;

	// NAME: 地方制限アセットID範囲指定Min
	// DESC: MapGD地方IDで有効なアセット指定：アセットID範囲指定Min
	int32_t LimitedMapRegioAssetIdRangeMin;

	// NAME: 地方制限アセットID範囲指定Max
	// DESC: MapGD地方IDで有効なアセット指定：アセットID範囲指定Max
	int32_t LimitedMapRegioAssetIdRangeMax;
} LEGACY_DISTANT_VIEW_PARTS_REPLACE_PARAM;

#endif
