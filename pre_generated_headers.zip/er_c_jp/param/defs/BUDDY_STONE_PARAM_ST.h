/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_BUDDY_STONE_PARAM_ST_H
#define _PARAMDEF_BUDDY_STONE_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BUDDY_STONE_PARAM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: 会話キャラエンティティID
	// DESC: 会話から参照する時の外部キーとして使う。
	uint32_t talkChrEntityId;

	// NAME: 撃破対象リストエンティティID
	// DESC: この石碑から召喚した際に、バディの撃破対象になるキャラ/グループのエンティティID
	uint32_t eliminateTargetEntityId;

	// NAME: 召喚済みイベントフラグID
	// DESC: 一度石碑から召喚した際に立つフラグID。このフラグが立っていると、石碑が召喚不可になる。
	uint32_t summonedEventFlagId;

	// NAME: スペシャルか
	// DESC: 石碑がSP石碑か汎用石碑か？を区別するbool。
	uint8_t isSpecial: 1;

	// NAME: パディング
	uint8_t pad1: 7;

	// NAME: パディング
	uint8_t pad2[3];

	// NAME: バディID
	// DESC: バディパラメータのID。「スペシャルか」が○の場合、このバディIDが召喚される。
	int32_t buddyId;

	// NAME: ドーピング用特殊効果ID
	// DESC: バディ召喚時に、バディにかかる特殊効果ID。
	int32_t dopingSpEffectId;

	// NAME: バディ起動距離[m]
	// DESC: 撃破対象のキャラがこの範囲に1体でも居れば、その石碑でバディ召喚が可能になる
	uint16_t activateRange;

	// NAME: バディ帰巣距離上書き[m]
	// DESC: バディの帰巣距離を上書きできる
	int16_t overwriteReturnRange;

	// NAME: 起動範囲上書き領域エンティティID
	// DESC: バディを召喚できる範囲を、指定エンティティIDの領域で上書きできる
	uint32_t overwriteActivateRegionEntityId;

	// NAME: 警告範囲上書き領域エンティティID
	// DESC: 警告領域エンティティID
	uint32_t warnRegionEntityId;

	// NAME: パディング
	uint8_t pad3[24];
} BUDDY_STONE_PARAM_ST;

#endif
