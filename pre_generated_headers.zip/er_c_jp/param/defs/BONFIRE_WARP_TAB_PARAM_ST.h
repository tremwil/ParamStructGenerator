/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_BONFIRE_WARP_TAB_PARAM_ST_H
#define _PARAMDEF_BONFIRE_WARP_TAB_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BONFIRE_WARP_TAB_PARAM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: テキストID
	// DESC: タブの表示名テキストID[MenuText]
	int32_t textId;

	// NAME: ソートID
	// DESC: タブの表示順ソートID。照準で左から並ぶ
	int32_t sortId;

	// NAME: アイコンID
	// DESC: タブのアイコンID。メニューリソース準拠
	uint16_t iconId;

	// NAME: パッド
	uint8_t pad[2];
} BONFIRE_WARP_TAB_PARAM_ST;

#endif
