/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_AI_STANDARD_INFO_BANK_H
#define _PARAMDEF_AI_STANDARD_INFO_BANK_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AI_STANDARD_INFO_BANK {

	// NAME: 認識距離[m]
	// DESC: 敵性キャラクタを認識する距離
	uint16_t RadarRange;

	// NAME: 認識角度Ｘ[deg]
	// DESC: 敵性キャラクタを認識するX角度　現在の視線方向を０度として、上が＋。
	uint8_t RadarAngleX;

	// NAME: 認識角度Y[deg]
	// DESC: 敵性キャラクタを認識するY角度　現在の視線方向を０度として、右が＋。
	uint8_t RadarAngleY;

	// NAME: 縄張り距離[m]
	// DESC: 自分の縄張りの距離。認識しているプレイヤーがこの距離から外れると初期位置に戻ります。
	uint16_t TerritorySize;

	// NAME: 攻撃前威嚇率[0～100]
	// DESC: 攻撃前に威嚇する確率
	uint8_t ThreatBeforeAttackRate;

	// NAME: 初回認識威嚇
	// DESC: 初回プレイヤー認識時に必ず威嚇するかどうか
	uint8_t ForceThreatOnFirstLocked;

	// NAME: 予約
	uint8_t reserve0[24];

	// NAME: 攻撃１　間合い[m]
	// DESC: 攻撃するときの間合い[m]
	uint16_t Attack1_Distance;

	// NAME: 攻撃１　間合い遊び[m]
	// DESC: 攻撃間合いの遊び。間合い距離近辺で、振動しないように
	uint16_t Attack1_Margin;

	// NAME: 攻撃１　割合[0～100]
	// DESC: 攻撃の頻度
	uint8_t Attack1_Rate;

	// NAME: 攻撃１　種類
	// DESC: 攻撃の種類
	uint8_t Attack1_ActionID;

	// NAME: 攻撃１　最小遅延時間[frame]
	// DESC: 攻撃可能になった時点から、攻撃するまでの遅延時間の最小。
	uint8_t Attack1_DelayMin;

	// NAME: 攻撃１　最長遅延時間[frame]
	// DESC: 攻撃可能になった時点から、攻撃するまでの遅延時間の最長。
	uint8_t Attack1_DelayMax;

	// NAME: 攻撃１　攻撃許可円錐の角度[deg]
	// DESC: 視線方向とターゲットへの方向ベクトルのなす角が、この角度以内の場合、攻撃ＯＫ。
	uint8_t Attack1_ConeAngle;

	// NAME: 予約
	uint8_t reserve10[7];

	// NAME: 攻撃２　間合い[m]
	// DESC: 攻撃するときの間合い[m]
	uint16_t Attack2_Distance;

	// NAME: 攻撃２　間合い遊び[m]
	// DESC: 攻撃間合いの遊び。間合い距離近辺で、振動しないように
	uint16_t Attack2_Margin;

	// NAME: 攻撃１　割合[0～100]
	// DESC: 攻撃の頻度
	uint8_t Attack2_Rate;

	// NAME: 攻撃２　種類
	// DESC: 攻撃の種類
	uint8_t Attack2_ActionID;

	// NAME: 攻撃2　最小遅延時間[frame]
	// DESC: 攻撃可能になった時点から、攻撃するまでの遅延時間の最小。
	uint8_t Attack2_DelayMin;

	// NAME: 攻撃2　最長遅延時間[frame]
	// DESC: 攻撃可能になった時点から、攻撃するまでの遅延時間の最長。
	uint8_t Attack2_DelayMax;

	// NAME: 攻撃2　攻撃許可円錐の角度[deg]
	// DESC: 視線方向とターゲットへの方向ベクトルのなす角が、この角度以内の場合、攻撃ＯＫ。
	uint8_t Attack2_ConeAngle;

	// NAME: 予約
	uint8_t reserve11[7];

	// NAME: 攻撃３　間合い[m]
	// DESC: 攻撃するときの間合い[m]
	uint16_t Attack3_Distance;

	// NAME: 攻撃３　間合い遊び[m]
	// DESC: 攻撃間合いの遊び。間合い距離近辺で、振動しないように
	uint16_t Attack3_Margin;

	// NAME: 攻撃１　割合[0～100]
	// DESC: 攻撃の頻度
	uint8_t Attack3_Rate;

	// NAME: 攻撃３　種類
	// DESC: 攻撃の種類
	uint8_t Attack3_ActionID;

	// NAME: 攻撃3　最小遅延時間[frame]
	// DESC: 攻撃可能になった時点から、攻撃するまでの遅延時間の最小。
	uint8_t Attack3_DelayMin;

	// NAME: 攻撃3　最長遅延時間[frame]
	// DESC: 攻撃可能になった時点から、攻撃するまでの遅延時間の最長。
	uint8_t Attack3_DelayMax;

	// NAME: 攻撃3　攻撃許可円錐の角度[deg]
	// DESC: 視線方向とターゲットへの方向ベクトルのなす角が、この角度以内の場合、攻撃ＯＫ。
	uint8_t Attack3_ConeAngle;

	// NAME: 予約
	uint8_t reserve12[7];

	// NAME: 攻撃４　間合い[m]
	// DESC: 攻撃するときの間合い[m]
	uint16_t Attack4_Distance;

	// NAME: 攻撃４　間合い遊び[m]
	// DESC: 攻撃間合いの遊び。間合い距離近辺で、振動しないように
	uint16_t Attack4_Margin;

	// NAME: 攻撃１　割合[0～100]
	// DESC: 攻撃の頻度
	uint8_t Attack4_Rate;

	// NAME: 攻撃４　種類
	// DESC: 攻撃の種類
	uint8_t Attack4_ActionID;

	// NAME: 攻撃4　最小遅延時間[frame]
	// DESC: 攻撃可能になった時点から、攻撃するまでの遅延時間の最小。
	uint8_t Attack4_DelayMin;

	// NAME: 攻撃4　最長遅延時間[frame]
	// DESC: 攻撃可能になった時点から、攻撃するまでの遅延時間の最長。
	uint8_t Attack4_DelayMax;

	// NAME: 攻撃4　攻撃許可円錐の角度[deg]
	// DESC: 視線方向とターゲットへの方向ベクトルのなす角が、この角度以内の場合、攻撃ＯＫ。
	uint8_t Attack4_ConeAngle;

	// NAME: 予約
	uint8_t reserve13[7];

	// NAME: 予約
	uint8_t reserve_last[32];
} AI_STANDARD_INFO_BANK;

#endif
