/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_FACE_PARAM_ST_H
#define _PARAMDEF_FACE_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _FACE_PARAM_ST {

	// NAME: 顔パーツID
	// DESC: 顔パーツID
	uint8_t face_partsId;

	// NAME: 肌の色(Ｒ)
	// DESC: 肌の色(Ｒ)
	uint8_t skin_color_R;

	// NAME: 肌の色(Ｇ)
	// DESC: 肌の色(Ｇ)
	uint8_t skin_color_G;

	// NAME: 肌の色(Ｂ)
	// DESC: 肌の色(Ｂ)
	uint8_t skin_color_B;

	// NAME: 肌のつや
	// DESC: 肌のつや
	uint8_t skin_gloss;

	// NAME: 毛穴
	// DESC: 毛穴
	uint8_t skin_pores;

	// NAME: 青ひげ
	// DESC: 青ひげ
	uint8_t face_beard;

	// NAME: くま
	// DESC: くま
	uint8_t face_aroundEye;

	// NAME: くまの色(R)
	// DESC: くまの色(R)
	uint8_t face_aroundEyeColor_R;

	// NAME: くまの色(G)
	// DESC: くまの色(G)
	uint8_t face_aroundEyeColor_G;

	// NAME: くまの色(B)
	// DESC: くまの色(B)
	uint8_t face_aroundEyeColor_B;

	// NAME: チーク
	// DESC: チーク
	uint8_t face_cheek;

	// NAME: チークの色(R)
	// DESC: チークの色(R)
	uint8_t face_cheekColor_R;

	// NAME: チークの色(G)
	// DESC: チークの色(G)
	uint8_t face_cheekColor_G;

	// NAME: チークの色(B)
	// DESC: チークの色(B)
	uint8_t face_cheekColor_B;

	// NAME: アイライン
	// DESC: アイライン
	uint8_t face_eyeLine;

	// NAME: アイラインの色(R)
	// DESC: アイラインの色(R)
	uint8_t face_eyeLineColor_R;

	// NAME: アイラインの色(G)
	// DESC: アイラインの色(G)
	uint8_t face_eyeLineColor_G;

	// NAME: アイラインの色(B)
	// DESC: アイラインの色(B)
	uint8_t face_eyeLineColor_B;

	// NAME: アイシャドウ(下)
	// DESC: アイシャドウ(下)
	uint8_t face_eyeShadowDown;

	// NAME: アイシャドウ(下)の色(R)
	// DESC: アイシャドウ(下)の色(R)
	uint8_t face_eyeShadowDownColor_R;

	// NAME: アイシャドウ(下)の色(G)
	// DESC: アイシャドウ(下)の色(G)
	uint8_t face_eyeShadowDownColor_G;

	// NAME: アイシャドウ(下)の色(B)
	// DESC: アイシャドウ(下)の色(B)
	uint8_t face_eyeShadowDownColor_B;

	// NAME: アイシャドウ(上)
	// DESC: アイシャドウ(上)
	uint8_t face_eyeShadowUp;

	// NAME: アイシャドウ(上)の色(R)
	// DESC: アイシャドウ(上)の色(R)
	uint8_t face_eyeShadowUpColor_R;

	// NAME: アイシャドウ(上)の色(G)
	// DESC: アイシャドウ(上)の色(G)
	uint8_t face_eyeShadowUpColor_G;

	// NAME: アイシャドウ(上)の色(B)
	// DESC: アイシャドウ(上)の色(B)
	uint8_t face_eyeShadowUpColor_B;

	// NAME: 口紅
	// DESC: 口紅
	uint8_t face_lip;

	// NAME: 口紅の色(R)
	// DESC: 口紅の色(R)
	uint8_t face_lipColor_R;

	// NAME: 口紅の色(G)
	// DESC: 口紅の色(G)
	uint8_t face_lipColor_G;

	// NAME: 口紅の色(B)
	// DESC: 口紅の色(B)
	uint8_t face_lipColor_B;

	// NAME: 体毛の濃さ
	// DESC: 体毛の濃さ
	uint8_t body_hair;

	// NAME: 体毛の色(R)
	// DESC: 体毛の色(R)
	uint8_t body_hairColor_R;

	// NAME: 体毛の色(G)
	// DESC: 体毛の色(G)
	uint8_t body_hairColor_G;

	// NAME: 体毛の色(B)
	// DESC: 体毛の色(B)
	uint8_t body_hairColor_B;

	// NAME: 眼球パーツID
	// DESC: 眼球パーツID
	uint8_t eye_partsId;

	// NAME: 虹彩の色(Ｒ)
	// DESC: 右目の虹彩の色(Ｒ)
	uint8_t eyeR_irisColor_R;

	// NAME: 虹彩の色(Ｇ)
	// DESC: 右目の虹彩の色(Ｇ)
	uint8_t eyeR_irisColor_G;

	// NAME: 虹彩の色(Ｂ)
	// DESC: 右目の虹彩の色(Ｂ)
	uint8_t eyeR_irisColor_B;

	// NAME: 虹彩の大きさ
	// DESC: 右目の虹彩の大きさ
	uint8_t eyeR_irisScale;

	// NAME: 水晶体の濁り
	// DESC: 右目の水晶体の濁り
	uint8_t eyeR_cataract;

	// NAME: 水晶体の濁りの色(Ｒ)
	// DESC: 右目の水晶体の濁りの色(Ｒ)
	uint8_t eyeR_cataractColor_R;

	// NAME: 水晶体の濁りの色(Ｇ)
	// DESC: 右目の水晶体の濁りの色(Ｇ)
	uint8_t eyeR_cataractColor_G;

	// NAME: 水晶体の濁りの色(Ｂ)
	// DESC: 右目の水晶体の濁りの色(Ｂ)
	uint8_t eyeR_cataractColor_B;

	// NAME: 白目の色(Ｒ)
	// DESC: 右目の白目の色(Ｒ)
	uint8_t eyeR_scleraColor_R;

	// NAME: 白目の色(G)
	// DESC: 右目の白目の色(G)
	uint8_t eyeR_scleraColor_G;

	// NAME: 白目の色(B)
	// DESC: 右目の白目の色(B)
	uint8_t eyeR_scleraColor_B;

	// NAME: 虹彩の位置
	// DESC: 右目の虹彩の位置
	uint8_t eyeR_irisDistance;

	// NAME: 虹彩の色(Ｒ)
	// DESC: 左目の虹彩の色(Ｒ)
	uint8_t eyeL_irisColor_R;

	// NAME: 虹彩の色(Ｇ)
	// DESC: 左目の虹彩の色(Ｇ)
	uint8_t eyeL_irisColor_G;

	// NAME: 虹彩の色(Ｂ)
	// DESC: 左目の虹彩の色(Ｂ)
	uint8_t eyeL_irisColor_B;

	// NAME: 虹彩の大きさ
	// DESC: 左目の虹彩の大きさ
	uint8_t eyeL_irisScale;

	// NAME: 水晶体の濁り
	// DESC: 左目の水晶体の濁り
	uint8_t eyeL_cataract;

	// NAME: 水晶体の濁りの色(Ｒ)
	// DESC: 左目の水晶体の濁りの色(Ｒ)
	uint8_t eyeL_cataractColor_R;

	// NAME: 水晶体の濁りの色(Ｇ)
	// DESC: 左目の水晶体の濁りの色(Ｇ)
	uint8_t eyeL_cataractColor_G;

	// NAME: 水晶体の濁りの色(Ｂ)
	// DESC: 左目の水晶体の濁りの色(Ｂ)
	uint8_t eyeL_cataractColor_B;

	// NAME: 白目の色(Ｒ)
	// DESC: 左目の白目の色(Ｒ)
	uint8_t eyeL_scleraColor_R;

	// NAME: 白目の色(G)
	// DESC: 左目の白目の色(G)
	uint8_t eyeL_scleraColor_G;

	// NAME: 白目の色(B)
	// DESC: 左目の白目の色(B)
	uint8_t eyeL_scleraColor_B;

	// NAME: 虹彩の位置
	// DESC: 左目の虹彩の位置
	uint8_t eyeL_irisDistance;

	// NAME: 髪パーツID
	// DESC: 髪パーツID
	uint8_t hair_partsId;

	// NAME: 髪の色(Ｒ)
	// DESC: 髪の色(Ｒ)
	uint8_t hair_color_R;

	// NAME: 髪の色(Ｇ)
	// DESC: 髪の色(Ｇ)
	uint8_t hair_color_G;

	// NAME: 髪の色(Ｂ)
	// DESC: 髪の色(Ｂ)
	uint8_t hair_color_B;

	// NAME: 光沢
	// DESC: 髪の光沢
	uint8_t hair_shininess;

	// NAME: 根元の黒さ
	// DESC: 髪の根元の黒さ
	uint8_t hair_rootBlack;

	// NAME: 白髪の量
	// DESC: 髪の白髪の量
	uint8_t hair_whiteDensity;

	// NAME: 髭パーツID
	// DESC: 髭パーツID
	uint8_t beard_partsId;

	// NAME: 髭の色(Ｒ)
	// DESC: 髭の色(Ｒ)
	uint8_t beard_color_R;

	// NAME: 髭の色(Ｇ)
	// DESC: 髭の色(Ｇ)
	uint8_t beard_color_G;

	// NAME: 髭の色(Ｂ)
	// DESC: 髭の色(Ｂ)
	uint8_t beard_color_B;

	// NAME: 光沢
	// DESC: 髭の光沢
	uint8_t beard_shininess;

	// NAME: 根元の黒さ
	// DESC: 髭の根元の黒さ
	uint8_t beard_rootBlack;

	// NAME: 白髪の量
	// DESC: 髭の白髪の量
	uint8_t beard_whiteDensity;

	// NAME: 眉パーツID
	// DESC: 眉パーツID
	uint8_t eyebrow_partsId;

	// NAME: 眉の色(Ｒ)
	// DESC: 眉の色(Ｒ)
	uint8_t eyebrow_color_R;

	// NAME: 眉の色(Ｇ)
	// DESC: 眉の色(Ｇ)
	uint8_t eyebrow_color_G;

	// NAME: 眉の色(Ｂ)
	// DESC: 眉の色(Ｂ)
	uint8_t eyebrow_color_B;

	// NAME: 光沢
	// DESC: 眉の光沢
	uint8_t eyebrow_shininess;

	// NAME: 根元の黒さ
	// DESC: 眉の根元の黒さ
	uint8_t eyebrow_rootBlack;

	// NAME: 白髪の量
	// DESC: 眉の白髪の量
	uint8_t eyebrow_whiteDensity;

	// NAME: まつげパーツID
	// DESC: まつげパーツID
	uint8_t eyelash_partsId;

	// NAME: まつげの色(Ｒ)
	// DESC: まつげの色(Ｒ)
	uint8_t eyelash_color_R;

	// NAME: まつげの色(Ｇ)
	// DESC: まつげの色(Ｇ)
	uint8_t eyelash_color_G;

	// NAME: まつげの色(Ｂ)
	// DESC: まつげの色(Ｂ)
	uint8_t eyelash_color_B;

	// NAME: 装飾パーツID
	// DESC: 装飾パーツID
	uint8_t accessories_partsId;

	// NAME: 装飾の色(Ｒ)
	// DESC: 装飾の色(Ｒ)
	uint8_t accessories_color_R;

	// NAME: 装飾の色(Ｇ)
	// DESC: 装飾の色(Ｇ)
	uint8_t accessories_color_G;

	// NAME: 装飾の色(Ｂ)
	// DESC: 装飾の色(Ｂ)
	uint8_t accessories_color_B;

	// NAME: デカールパーツID
	// DESC: デカールパーツID
	uint8_t decal_partsId;

	// NAME: デカール位置(x)
	// DESC: デカール位置(x)
	uint8_t decal_posX;

	// NAME: デカール位置(y)
	// DESC: デカール位置(y)
	uint8_t decal_posY;

	// NAME: デカール角度
	// DESC: デカール角度
	uint8_t decal_angle;

	// NAME: デカールスケール
	// DESC: デカールスケール
	uint8_t decal_scale;

	// NAME: デカールの色(Ｒ)
	// DESC: デカールの色(Ｒ)
	uint8_t decal_color_R;

	// NAME: デカールの色(Ｇ)
	// DESC: デカールの色(Ｇ)
	uint8_t decal_color_G;

	// NAME: デカールの色(Ｂ)
	// DESC: デカールの色(Ｂ)
	uint8_t decal_color_B;

	// NAME: デカールのつや
	// DESC: デカールのつや
	uint8_t decal_gloss;

	// NAME: デカールの反転
	// DESC: デカールの反転
	uint8_t decal_mirror;

	// NAME: キャラ体型頭部スケール
	// DESC: キャラ体型頭部スケール
	uint8_t chrBodyScaleHead;

	// NAME: キャラ体型胸部スケール
	// DESC: キャラ体型胸部スケール
	uint8_t chrBodyScaleBreast;

	// NAME: キャラ体型腹部スケール
	// DESC: キャラ体型腹部スケール
	uint8_t chrBodyScaleAbdomen;

	// NAME: キャラ体型右腕部スケール
	// DESC: キャラ体型右腕部スケール
	uint8_t chrBodyScaleRArm;

	// NAME: キャラ体型右脚部スケール
	// DESC: キャラ体型右脚部スケール
	uint8_t chrBodyScaleRLeg;

	// NAME: キャラ体型左腕部スケール
	// DESC: キャラ体型左腕部スケール
	uint8_t chrBodyScaleLArm;

	// NAME: キャラ体型左脚部スケール
	// DESC: キャラ体型左脚部スケール
	uint8_t chrBodyScaleLLeg;

	// NAME: 火傷跡
	// DESC: 火傷跡
	uint8_t burn_scar;

	// NAME: 眼球パーツID
	// DESC: 眼球パーツIDを上書きするか
	uint8_t override_eye_partsId: 1;

	// NAME: 虹彩の色
	// DESC: 虹彩の色を上書きするか
	uint8_t override_eye_irisColor: 1;

	// NAME: 水晶体の濁り
	// DESC: 水晶体の濁りを上書きするか
	uint8_t override_eye_cataract: 1;

	// NAME: 水晶体の濁り色
	// DESC: 水晶体の濁り色を上書きするか
	uint8_t override_eye_cataractColor: 1;

	// NAME: 白目の色
	// DESC: 白目の色を上書きするか
	uint8_t override_eye_scleraColor: 1;

	// NAME: 火傷跡
	// DESC: 火傷跡を上書きするか
	uint8_t override_burn_scar: 1;

	// NAME: pad2
	uint8_t pad2: 2;

	// NAME: pad
	uint8_t pad[5];

	// NAME: 年齢
	// DESC: 年齢
	uint8_t age;

	// NAME: 性別
	// DESC: 性別
	uint8_t gender;

	// NAME: 誇張（モデル）
	// DESC: 誇張（モデル）
	uint8_t caricatureGeometry;

	// NAME: 誇張（テクスチャ）
	// DESC: 誇張（テクスチャ）
	uint8_t caricatureTexture;

	// NAME: 顔作成ジオメトリデータ00
	// DESC: 顔作成ジオメトリデータ00
	uint8_t faceGeoData00;

	// NAME: 顔作成ジオメトリデータ01
	// DESC: 顔作成ジオメトリデータ01
	uint8_t faceGeoData01;

	// NAME: 顔作成ジオメトリデータ02
	// DESC: 顔作成ジオメトリデータ02
	uint8_t faceGeoData02;

	// NAME: 顔作成ジオメトリデータ03
	// DESC: 顔作成ジオメトリデータ03
	uint8_t faceGeoData03;

	// NAME: 顔作成ジオメトリデータ04
	// DESC: 顔作成ジオメトリデータ04
	uint8_t faceGeoData04;

	// NAME: 顔作成ジオメトリデータ05
	// DESC: 顔作成ジオメトリデータ05
	uint8_t faceGeoData05;

	// NAME: 顔作成ジオメトリデータ06
	// DESC: 顔作成ジオメトリデータ06
	uint8_t faceGeoData06;

	// NAME: 顔作成ジオメトリデータ07
	// DESC: 顔作成ジオメトリデータ07
	uint8_t faceGeoData07;

	// NAME: 顔作成ジオメトリデータ08
	// DESC: 顔作成ジオメトリデータ08
	uint8_t faceGeoData08;

	// NAME: 顔作成ジオメトリデータ09
	// DESC: 顔作成ジオメトリデータ09
	uint8_t faceGeoData09;

	// NAME: 顔作成ジオメトリデータ10
	// DESC: 顔作成ジオメトリデータ10
	uint8_t faceGeoData10;

	// NAME: 顔作成ジオメトリデータ11
	// DESC: 顔作成ジオメトリデータ11
	uint8_t faceGeoData11;

	// NAME: 顔作成ジオメトリデータ12
	// DESC: 顔作成ジオメトリデータ12
	uint8_t faceGeoData12;

	// NAME: 顔作成ジオメトリデータ13
	// DESC: 顔作成ジオメトリデータ13
	uint8_t faceGeoData13;

	// NAME: 顔作成ジオメトリデータ14
	// DESC: 顔作成ジオメトリデータ14
	uint8_t faceGeoData14;

	// NAME: 顔作成ジオメトリデータ15
	// DESC: 顔作成ジオメトリデータ15
	uint8_t faceGeoData15;

	// NAME: 顔作成ジオメトリデータ16
	// DESC: 顔作成ジオメトリデータ16
	uint8_t faceGeoData16;

	// NAME: 顔作成ジオメトリデータ17
	// DESC: 顔作成ジオメトリデータ17
	uint8_t faceGeoData17;

	// NAME: 顔作成ジオメトリデータ18
	// DESC: 顔作成ジオメトリデータ18
	uint8_t faceGeoData18;

	// NAME: 顔作成ジオメトリデータ19
	// DESC: 顔作成ジオメトリデータ19
	uint8_t faceGeoData19;

	// NAME: 顔作成ジオメトリデータ20
	// DESC: 顔作成ジオメトリデータ20
	uint8_t faceGeoData20;

	// NAME: 顔作成ジオメトリデータ21
	// DESC: 顔作成ジオメトリデータ21
	uint8_t faceGeoData21;

	// NAME: 顔作成ジオメトリデータ22
	// DESC: 顔作成ジオメトリデータ22
	uint8_t faceGeoData22;

	// NAME: 顔作成ジオメトリデータ23
	// DESC: 顔作成ジオメトリデータ23
	uint8_t faceGeoData23;

	// NAME: 顔作成ジオメトリデータ24
	// DESC: 顔作成ジオメトリデータ24
	uint8_t faceGeoData24;

	// NAME: 顔作成ジオメトリデータ25
	// DESC: 顔作成ジオメトリデータ25
	uint8_t faceGeoData25;

	// NAME: 顔作成ジオメトリデータ26
	// DESC: 顔作成ジオメトリデータ26
	uint8_t faceGeoData26;

	// NAME: 顔作成ジオメトリデータ27
	// DESC: 顔作成ジオメトリデータ27
	uint8_t faceGeoData27;

	// NAME: 顔作成ジオメトリデータ28
	// DESC: 顔作成ジオメトリデータ28
	uint8_t faceGeoData28;

	// NAME: 顔作成ジオメトリデータ29
	// DESC: 顔作成ジオメトリデータ29
	uint8_t faceGeoData29;

	// NAME: 顔作成ジオメトリデータ30
	// DESC: 顔作成ジオメトリデータ30
	uint8_t faceGeoData30;

	// NAME: 顔作成ジオメトリデータ31
	// DESC: 顔作成ジオメトリデータ31
	uint8_t faceGeoData31;

	// NAME: 顔作成ジオメトリデータ32
	// DESC: 顔作成ジオメトリデータ32
	uint8_t faceGeoData32;

	// NAME: 顔作成ジオメトリデータ33
	// DESC: 顔作成ジオメトリデータ33
	uint8_t faceGeoData33;

	// NAME: 顔作成ジオメトリデータ34
	// DESC: 顔作成ジオメトリデータ34
	uint8_t faceGeoData34;

	// NAME: 顔作成ジオメトリデータ35
	// DESC: 顔作成ジオメトリデータ35
	uint8_t faceGeoData35;

	// NAME: 顔作成ジオメトリデータ36
	// DESC: 顔作成ジオメトリデータ36
	uint8_t faceGeoData36;

	// NAME: 顔作成ジオメトリデータ37
	// DESC: 顔作成ジオメトリデータ37
	uint8_t faceGeoData37;

	// NAME: 顔作成ジオメトリデータ38
	// DESC: 顔作成ジオメトリデータ38
	uint8_t faceGeoData38;

	// NAME: 顔作成ジオメトリデータ39
	// DESC: 顔作成ジオメトリデータ39
	uint8_t faceGeoData39;

	// NAME: 顔作成ジオメトリデータ40
	// DESC: 顔作成ジオメトリデータ40
	uint8_t faceGeoData40;

	// NAME: 顔作成ジオメトリデータ41
	// DESC: 顔作成ジオメトリデータ41
	uint8_t faceGeoData41;

	// NAME: 顔作成ジオメトリデータ42
	// DESC: 顔作成ジオメトリデータ42
	uint8_t faceGeoData42;

	// NAME: 顔作成ジオメトリデータ43
	// DESC: 顔作成ジオメトリデータ43
	uint8_t faceGeoData43;

	// NAME: 顔作成ジオメトリデータ44
	// DESC: 顔作成ジオメトリデータ44
	uint8_t faceGeoData44;

	// NAME: 顔作成ジオメトリデータ45
	// DESC: 顔作成ジオメトリデータ45
	uint8_t faceGeoData45;

	// NAME: 顔作成ジオメトリデータ46
	// DESC: 顔作成ジオメトリデータ46
	uint8_t faceGeoData46;

	// NAME: 顔作成ジオメトリデータ47
	// DESC: 顔作成ジオメトリデータ47
	uint8_t faceGeoData47;

	// NAME: 顔作成ジオメトリデータ48
	// DESC: 顔作成ジオメトリデータ48
	uint8_t faceGeoData48;

	// NAME: 顔作成ジオメトリデータ49
	// DESC: 顔作成ジオメトリデータ49
	uint8_t faceGeoData49;

	// NAME: 顔作成ジオメトリデータ50
	// DESC: 顔作成ジオメトリデータ50
	uint8_t faceGeoData50;

	// NAME: 顔作成ジオメトリデータ51
	// DESC: 顔作成ジオメトリデータ51
	uint8_t faceGeoData51;

	// NAME: 顔作成ジオメトリデータ52
	// DESC: 顔作成ジオメトリデータ52
	uint8_t faceGeoData52;

	// NAME: 顔作成ジオメトリデータ53
	// DESC: 顔作成ジオメトリデータ53
	uint8_t faceGeoData53;

	// NAME: 顔作成ジオメトリデータ54
	// DESC: 顔作成ジオメトリデータ54
	uint8_t faceGeoData54;

	// NAME: 顔作成ジオメトリデータ55
	// DESC: 顔作成ジオメトリデータ55
	uint8_t faceGeoData55;

	// NAME: 顔作成ジオメトリデータ56
	// DESC: 顔作成ジオメトリデータ56
	uint8_t faceGeoData56;

	// NAME: 顔作成ジオメトリデータ57
	// DESC: 顔作成ジオメトリデータ57
	uint8_t faceGeoData57;

	// NAME: 顔作成ジオメトリデータ58
	// DESC: 顔作成ジオメトリデータ58
	uint8_t faceGeoData58;

	// NAME: 顔作成ジオメトリデータ59
	// DESC: 顔作成ジオメトリデータ59
	uint8_t faceGeoData59;

	// NAME: 顔作成ジオメトリデータ60
	// DESC: 顔作成ジオメトリデータ60
	uint8_t faceGeoData60;

	// NAME: 顔作成テクスチャデータ00
	// DESC: 顔作成テクスチャデータ00
	uint8_t faceTexData00;

	// NAME: 顔作成テクスチャデータ01
	// DESC: 顔作成テクスチャデータ01
	uint8_t faceTexData01;

	// NAME: 顔作成テクスチャデータ02
	// DESC: 顔作成テクスチャデータ02
	uint8_t faceTexData02;

	// NAME: 顔作成テクスチャデータ03
	// DESC: 顔作成テクスチャデータ03
	uint8_t faceTexData03;

	// NAME: 顔作成テクスチャデータ04
	// DESC: 顔作成テクスチャデータ04
	uint8_t faceTexData04;

	// NAME: 顔作成テクスチャデータ05
	// DESC: 顔作成テクスチャデータ05
	uint8_t faceTexData05;

	// NAME: 顔作成テクスチャデータ06
	// DESC: 顔作成テクスチャデータ06
	uint8_t faceTexData06;

	// NAME: 顔作成テクスチャデータ07
	// DESC: 顔作成テクスチャデータ07
	uint8_t faceTexData07;

	// NAME: 顔作成テクスチャデータ08
	// DESC: 顔作成テクスチャデータ08
	uint8_t faceTexData08;

	// NAME: 顔作成テクスチャデータ09
	// DESC: 顔作成テクスチャデータ09
	uint8_t faceTexData09;

	// NAME: 顔作成テクスチャデータ10
	// DESC: 顔作成テクスチャデータ10
	uint8_t faceTexData10;

	// NAME: 顔作成テクスチャデータ11
	// DESC: 顔作成テクスチャデータ11
	uint8_t faceTexData11;

	// NAME: 顔作成テクスチャデータ12
	// DESC: 顔作成テクスチャデータ12
	uint8_t faceTexData12;

	// NAME: 顔作成テクスチャデータ13
	// DESC: 顔作成テクスチャデータ13
	uint8_t faceTexData13;

	// NAME: 顔作成テクスチャデータ14
	// DESC: 顔作成テクスチャデータ14
	uint8_t faceTexData14;

	// NAME: 顔作成テクスチャデータ15
	// DESC: 顔作成テクスチャデータ15
	uint8_t faceTexData15;

	// NAME: 顔作成テクスチャデータ16
	// DESC: 顔作成テクスチャデータ16
	uint8_t faceTexData16;

	// NAME: 顔作成テクスチャデータ17
	// DESC: 顔作成テクスチャデータ17
	uint8_t faceTexData17;

	// NAME: 顔作成テクスチャデータ18
	// DESC: 顔作成テクスチャデータ18
	uint8_t faceTexData18;

	// NAME: 顔作成テクスチャデータ19
	// DESC: 顔作成テクスチャデータ19
	uint8_t faceTexData19;

	// NAME: 顔作成テクスチャデータ20
	// DESC: 顔作成テクスチャデータ20
	uint8_t faceTexData20;

	// NAME: 顔作成テクスチャデータ21
	// DESC: 顔作成テクスチャデータ21
	uint8_t faceTexData21;

	// NAME: 顔作成テクスチャデータ22
	// DESC: 顔作成テクスチャデータ22
	uint8_t faceTexData22;

	// NAME: 顔作成テクスチャデータ23
	// DESC: 顔作成テクスチャデータ23
	uint8_t faceTexData23;

	// NAME: 顔作成テクスチャデータ24
	// DESC: 顔作成テクスチャデータ24
	uint8_t faceTexData24;

	// NAME: 顔作成テクスチャデータ25
	// DESC: 顔作成テクスチャデータ25
	uint8_t faceTexData25;

	// NAME: 顔作成テクスチャデータ26
	// DESC: 顔作成テクスチャデータ26
	uint8_t faceTexData26;

	// NAME: 顔作成テクスチャデータ27
	// DESC: 顔作成テクスチャデータ27
	uint8_t faceTexData27;

	// NAME: 顔作成テクスチャデータ28
	// DESC: 顔作成テクスチャデータ28
	uint8_t faceTexData28;

	// NAME: 顔作成テクスチャデータ29
	// DESC: 顔作成テクスチャデータ29
	uint8_t faceTexData29;

	// NAME: 顔作成テクスチャデータ30
	// DESC: 顔作成テクスチャデータ30
	uint8_t faceTexData30;

	// NAME: 顔作成テクスチャデータ31
	// DESC: 顔作成テクスチャデータ31
	uint8_t faceTexData31;

	// NAME: 顔作成テクスチャデータ32
	// DESC: 顔作成テクスチャデータ32
	uint8_t faceTexData32;

	// NAME: 顔作成テクスチャデータ33
	// DESC: 顔作成テクスチャデータ33
	uint8_t faceTexData33;

	// NAME: 顔作成テクスチャデータ34
	// DESC: 顔作成テクスチャデータ34
	uint8_t faceTexData34;

	// NAME: 顔作成テクスチャデータ35
	// DESC: 顔作成テクスチャデータ35
	uint8_t faceTexData35;

	// NAME: 顔作成ジオメトリ非対称データ00
	// DESC: 顔作成ジオメトリ非対称データ00
	uint8_t faceGeoAsymData00;

	// NAME: 顔作成ジオメトリ非対称データ01
	// DESC: 顔作成ジオメトリ非対称データ01
	uint8_t faceGeoAsymData01;

	// NAME: 顔作成ジオメトリ非対称データ02
	// DESC: 顔作成ジオメトリ非対称データ02
	uint8_t faceGeoAsymData02;

	// NAME: 顔作成ジオメトリ非対称データ03
	// DESC: 顔作成ジオメトリ非対称データ03
	uint8_t faceGeoAsymData03;

	// NAME: 顔作成ジオメトリ非対称データ04
	// DESC: 顔作成ジオメトリ非対称データ04
	uint8_t faceGeoAsymData04;

	// NAME: 顔作成ジオメトリ非対称データ05
	// DESC: 顔作成ジオメトリ非対称データ05
	uint8_t faceGeoAsymData05;

	// NAME: 顔作成ジオメトリ非対称データ06
	// DESC: 顔作成ジオメトリ非対称データ06
	uint8_t faceGeoAsymData06;

	// NAME: 顔作成ジオメトリ非対称データ07
	// DESC: 顔作成ジオメトリ非対称データ07
	uint8_t faceGeoAsymData07;

	// NAME: 顔作成ジオメトリ非対称データ08
	// DESC: 顔作成ジオメトリ非対称データ08
	uint8_t faceGeoAsymData08;

	// NAME: 顔作成ジオメトリ非対称データ09
	// DESC: 顔作成ジオメトリ非対称データ09
	uint8_t faceGeoAsymData09;

	// NAME: 顔作成ジオメトリ非対称データ10
	// DESC: 顔作成ジオメトリ非対称データ10
	uint8_t faceGeoAsymData10;

	// NAME: 顔作成ジオメトリ非対称データ11
	// DESC: 顔作成ジオメトリ非対称データ11
	uint8_t faceGeoAsymData11;

	// NAME: 顔作成ジオメトリ非対称データ12
	// DESC: 顔作成ジオメトリ非対称データ12
	uint8_t faceGeoAsymData12;

	// NAME: 顔作成ジオメトリ非対称データ13
	// DESC: 顔作成ジオメトリ非対称データ13
	uint8_t faceGeoAsymData13;

	// NAME: 顔作成ジオメトリ非対称データ14
	// DESC: 顔作成ジオメトリ非対称データ14
	uint8_t faceGeoAsymData14;

	// NAME: 顔作成ジオメトリ非対称データ15
	// DESC: 顔作成ジオメトリ非対称データ15
	uint8_t faceGeoAsymData15;

	// NAME: 顔作成ジオメトリ非対称データ16
	// DESC: 顔作成ジオメトリ非対称データ16
	uint8_t faceGeoAsymData16;

	// NAME: 顔作成ジオメトリ非対称データ17
	// DESC: 顔作成ジオメトリ非対称データ17
	uint8_t faceGeoAsymData17;

	// NAME: 顔作成ジオメトリ非対称データ18
	// DESC: 顔作成ジオメトリ非対称データ18
	uint8_t faceGeoAsymData18;

	// NAME: 顔作成ジオメトリ非対称データ19
	// DESC: 顔作成ジオメトリ非対称データ19
	uint8_t faceGeoAsymData19;

	// NAME: 顔作成ジオメトリ非対称データ20
	// DESC: 顔作成ジオメトリ非対称データ20
	uint8_t faceGeoAsymData20;

	// NAME: 顔作成ジオメトリ非対称データ21
	// DESC: 顔作成ジオメトリ非対称データ21
	uint8_t faceGeoAsymData21;

	// NAME: 顔作成ジオメトリ非対称データ22
	// DESC: 顔作成ジオメトリ非対称データ22
	uint8_t faceGeoAsymData22;

	// NAME: 顔作成ジオメトリ非対称データ23
	// DESC: 顔作成ジオメトリ非対称データ23
	uint8_t faceGeoAsymData23;

	// NAME: 顔作成ジオメトリ非対称データ24
	// DESC: 顔作成ジオメトリ非対称データ24
	uint8_t faceGeoAsymData24;

	// NAME: 顔作成ジオメトリ非対称データ25
	// DESC: 顔作成ジオメトリ非対称データ25
	uint8_t faceGeoAsymData25;
} FACE_PARAM_ST;

#endif
