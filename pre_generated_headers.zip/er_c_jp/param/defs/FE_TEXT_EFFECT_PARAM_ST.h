/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_FE_TEXT_EFFECT_PARAM_ST_H
#define _PARAMDEF_FE_TEXT_EFFECT_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _FE_TEXT_EFFECT_PARAM_ST {

	// NAME: リソースID
	// DESC: メニューリソースのインスタンス名。TextEffect_X のID
	int16_t resId;

	// NAME: パディング
	uint8_t pad1[2];

	// NAME: テキストID
	// DESC: 表示するテキストID(-1: テキストなし)。MenuText
	int32_t textId;

	// NAME: SEのID
	// DESC: 再生するVoiceのID(-1: SEなし)
	int32_t seId;

	// NAME: マップ名と同時に表示するか
	// DESC: マップ名と同時に表示するか
	uint8_t canMixMapName: 1;

	// NAME: パディング
	uint8_t pad3: 7;

	// NAME: パディング
	uint8_t pad2[19];
} FE_TEXT_EFFECT_PARAM_ST;

#endif
