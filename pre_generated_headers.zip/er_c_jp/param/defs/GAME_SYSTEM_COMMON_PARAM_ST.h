/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_GAME_SYSTEM_COMMON_PARAM_ST_H
#define _PARAMDEF_GAME_SYSTEM_COMMON_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GAME_SYSTEM_COMMON_PARAM_ST {

	// NAME: 基本強靭度耐久値回復時間
	// DESC: 強靭度回復時間の基本値です。（秒）
	float baseToughnessRecoverTime;

	// NAME: キャラのイベント旋回アニメーション（左90°）
	// DESC: 「キャラの旋回」イベント用の左90°旋回アニメーションです。
	int32_t chrEventTrun_byLeft90;

	// NAME: キャラのイベント旋回アニメーション（右90°）
	// DESC: 「キャラの旋回」イベント用の右90°旋回アニメーションです。
	int32_t chrEventTrun_byRight90;

	// NAME: キャラのイベント旋回アニメーション（左180°）
	// DESC: 「キャラの旋回」イベント用の左180°旋回アニメーションです。
	int32_t chrEventTrun_byLeft180;

	// NAME: キャラのイベント旋回アニメーション（右180°）
	// DESC: 「キャラの旋回」イベント用の右180°旋回アニメーションです。
	int32_t chrEventTrun_byRight180;

	// NAME: キャラのイベント旋回90°アニメーション開始角度
	// DESC: 「キャラの旋回」イベント用の90°旋回アニメーションを適用する角度の開始角度。この角度より小さい角度でイベントが始まった場合は、システム旋回が行われます
	int16_t chrEventTrun_90TurnStartAngle;

	// NAME: キャラのイベント旋回180°アニメーション開始角度
	// DESC: 「キャラの旋回」イベント用の180°旋回アニメーションを適用する角度の開始角度。
	int16_t chrEventTrun_180TurnStartAngle;

	// NAME: ステルス攻撃被ダメージ倍率
	// DESC: ステルス攻撃被ダメージ倍率
	float stealthAtkDamageRate;

	// NAME: はじかれ時ガード成功時ダメージカット率
	// DESC: はじかれ時ガード成功時ダメージカット率。最終ダメージに乗算
	float flickDamageCutRateSuccessGurad;

	// NAME: NPC会話のアニメ再生開始する差分角度
	// DESC: NPC会話の会話中モーションのアニメ再生開始する差分角度です。
	float npcTalkAnimBeginDiffAngle;

	// NAME: NPC会話のアニメ再生停止する差分角度
	// DESC: NPC会話の会話中モーションのアニメ再生停止する差分角度です。
	float npcTalkAnimEndDiffAngle;

	// NAME: ネムリアイテム取得範囲_アクションボタンパラID
	// DESC: ネムリアイテム取得範囲_アクションボタンパラID。TAEフラグ「イベント＞ネムリアイテム登録」で上書きしないときのデフォルト値として使われる。
	int32_t sleepCollectorItemActionButtonParamId;

	// NAME: バディアイテム許可_SFX発生間隔[s]
	// DESC: バディアイテム許可_SFX発生間隔[s]
	float allowUseBuddyItem_sfxInterval;

	// NAME: バディアイテム許可_SFX発生PCダミポリID
	// DESC: バディアイテム許可_SFX発生PCダミポリID
	int32_t allowUseBuddyItem_sfxDmyPolyId;

	// NAME: バディアイテム許可_SFX発生馬ダミポリID_騎乗時
	// DESC: バディアイテム許可_SFX発生馬ダミポリID_騎乗時
	int32_t allowUseBuddyItem_sfxDmyPolyId_horse;

	// NAME: バディアイテム許可_発生SFXID
	// DESC: バディアイテム許可_発生SFXID
	int32_t allowUseBuddyItem_sfxId;

	// NAME: バディ召喚中_起動範囲内_SFX発生間隔[s]
	// DESC: バディ召喚中_起動範囲内_SFX発生間隔[s]
	float onBuddySummon_inActivateRange_sfxInterval;

	// NAME: バディ召喚中_起動範囲内_SFX発生PCダミポリID
	// DESC: バディ召喚中_起動範囲内_SFX発生PCダミポリID
	int32_t onBuddySummon_inActivateRange_sfxDmyPolyId;

	// NAME: バディ召喚中_起動範囲内_SFX発生馬ダミポリID_騎乗時
	// DESC: バディ召喚中_起動範囲内_SFX発生馬ダミポリID_騎乗時
	int32_t onBuddySummon_inActivateRange_sfxDmyPolyId_horse;

	// NAME: バディ召喚中_起動範囲内_発生SFXID
	// DESC: バディ召喚中_起動範囲内_発生SFXID
	int32_t onBuddySummon_inActivateRange_sfxId;

	// NAME: バディ召喚中_起動範囲内特殊効果ID_PC用
	// DESC: バディ召喚中_起動範囲内特殊効果ID_PC用
	int32_t onBuddySummon_inActivateRange_spEffectId_pc;

	// NAME: バディ召喚中_警告範囲内特殊効果ID_PC用
	// DESC: バディ召喚中_警告範囲内特殊効果ID_PC用
	int32_t onBuddySummon_inWarnRange_spEffectId_pc;

	// NAME: バディ召喚中_バディ帰還時特殊効果ID_PC用
	// DESC: バディ召喚中_バディ帰還時特殊効果ID_PC用
	int32_t onBuddySummon_atBuddyUnsummon_spEffectId_pc;

	// NAME: バディ召喚中_警告範囲内特殊効果ID_バディ用
	// DESC: バディ召喚中_警告範囲内特殊効果ID_バディ用
	int32_t onBuddySummon_inWarnRange_spEffectId_buddy;

	// NAME: 朝のインゲーム時間（時）
	// DESC: 朝のインゲーム時間（時）。会話で使用します。
	uint8_t morningIngameHour;

	// NAME: 朝のインゲーム時間（分）
	// DESC: 朝のインゲーム時間（分）。会話で使用します。
	uint8_t morningIngameMinute;

	// NAME: 朝のインゲーム時間（秒）
	// DESC: 朝のインゲーム時間（秒）。会話で使用します。
	uint8_t morningIngameSecond;

	// NAME: 昼のインゲーム時間（時）
	// DESC: 昼のインゲーム時間（時）。会話で使用します。
	uint8_t noonIngameHour;

	// NAME: 昼のインゲーム時間（分）
	// DESC: 昼のインゲーム時間（分）。会話で使用します。
	uint8_t noonIngameMinute;

	// NAME: 昼のインゲーム時間（秒）
	// DESC: 昼のインゲーム時間（秒）。会話で使用します。
	uint8_t noonIngameSecond;

	// NAME: 夜のインゲーム時間（時）
	// DESC: 夜のインゲーム時間（時）。会話で使用します。
	uint8_t nightIngameHour;

	// NAME: 夜のインゲーム時間（分）
	// DESC: 夜のインゲーム時間（分）。会話で使用します。
	uint8_t nightIngameMinute;

	// NAME: 夜のインゲーム時間（秒）
	// DESC: 夜のインゲーム時間（秒）。会話で使用します。
	uint8_t nightIngameSecond;

	// NAME: AI視界倍率_朝_開始時刻(時)
	// DESC: AI視界倍率_朝_開始時刻(時)
	uint8_t aiSightRateStart_Morning_Hour;

	// NAME: AI視界倍率_朝_開始時刻(分)
	// DESC: AI視界倍率_朝_開始時刻(分)
	uint8_t aiSightRateStart_Morning_Minute;

	// NAME: AI視界倍率_昼_開始時刻(時)
	// DESC: AI視界倍率_昼_開始時刻(時)
	uint8_t aiSightRateStart_Noon_Hour;

	// NAME: AI視界倍率_昼_開始時刻(分)
	// DESC: AI視界倍率_昼_開始時刻(分)
	uint8_t aiSightRateStart_Noon_Minute;

	// NAME: AI視界倍率_夕_開始時刻(時)
	// DESC: AI視界倍率_夕_開始時刻(時)
	uint8_t aiSightRateStart_Evening_Hour;

	// NAME: AI視界倍率_夕_開始時刻(分)
	// DESC: AI視界倍率_夕_開始時刻(分)
	uint8_t aiSightRateStart_Evening_Minute;

	// NAME: AI視界倍率_夜_開始時刻(時)
	// DESC: AI視界倍率_夜_開始時刻(時)
	uint8_t aiSightRateStart_Night_Hour;

	// NAME: AI視界倍率_夜_開始時刻(分)
	// DESC: AI視界倍率_夜_開始時刻(分)
	uint8_t aiSightRateStart_Night_Minute;

	// NAME: AI視界倍率_深夜_開始時刻(時)
	// DESC: AI視界倍率_深夜_開始時刻(時)
	uint8_t aiSightRateStart_Midnight_Hour;

	// NAME: AI視界倍率_深夜_開始時刻(分)
	// DESC: AI視界倍率_深夜_開始時刻(分)
	uint8_t aiSightRateStart_Midnight_Minute;

	// NAME: SA大ダメージヒット演出SFX_発生条件SAダメージ閾値比率[％]
	// DESC: SA大ダメージヒット演出SFX_発生条件SAダメージ閾値比率[％]
	uint8_t saLargeDamageHitSfx_Threshold;

	// NAME: SA大ダメージヒット演出SFX_SFXID
	// DESC: SA大ダメージヒット演出SFX_SFXID
	int32_t saLargeDamageHitSfx_SfxId;

	// NAME: 安全位置から離れてサインを作成できる距離[m]
	// DESC: PCの最後の安全位置から離れてサインを作成できる距離[m]
	float signCreatableDistFromSafePos;

	// NAME: 再召喚が発生するホストとゲストの距離[m]
	// DESC: 再召喚が発生するホストとゲストの距離[m]
	float guestResummonDist;

	// NAME: ゲストがホストから離れそうになってることを通知する距離[m]
	// DESC: ゲストがホストから離れそうになってることを通知する距離[m]。この距離より離れたら通知する。
	float guestLeavingMessageDistMax;

	// NAME: ゲストがホストから離れそうになってることを再通知可能にする距離[m]
	// DESC: ゲストがホストから離れそうになってることを再通知可能にする距離[m]。この距離より近づくまで再通知しない。
	float guestLeavingMessageDistMin;

	// NAME: ゲストがホストから離れられる最大距離[m] 
	// DESC: ゲストがホストから離れられる最大距離[m]。この距離より離れた状態で一定時間経過するとセッション脱退する。
	float guestLeaveSessionDist;

	// NAME: リトライエリア半径_デフォルト値(m)
	// DESC: リトライエリア半径_デフォルト値(m)。MapStudioのイベントタイプ「リトライポイント」で半径も領域も未設定の場合のデフォルト値として使われる。
	float retryPointAreaRadius;

	// NAME: ネムリアイテム取得可能時に発動する特殊効果ID
	// DESC: ネムリアイテム取得可能時に発動する特殊効果ID。TAEフラグ「イベント＞ネムリアイテム登録」で上書きしないときのデフォルト値として使われる。
	int32_t sleepCollectorSpEffectId;

	// NAME: 「HP最大以下で回復」特殊効果完了通知特殊効果ID
	// DESC: 「HP最大以下で回復」が完了したことを通知する特殊効果のID。主にマルチの同期用に使われる。 
	int32_t recoverBelowMaxHpCompletionNoticeSpEffectId;

	// NAME: HPエスト吸収演出SFXID
	// DESC: 侵入者撃破時などにHPエスト瓶の使用回数を回復する際の吸収演出SFXID
	int32_t estusFlaskRecovery_AbsorptionProductionSfxId_byHp;

	// NAME: MPエスト吸収演出SFXID
	// DESC: 侵入者撃破時などにMPエスト瓶の使用回数を回復する際の吸収演出SFXID
	int32_t estusFlaskRecovery_AbsorptionProductionSfxId_byMp;

	// NAME: 復活特殊効果発動判定用特殊効果ID
	// DESC: 復活特殊効果が発動したことを通知する特殊効果のID。主にマルチの同期用に使われる。 
	int32_t respawnSpecialEffectActiveCheckerSpEffectId;

	// NAME: バディ召喚中_起動範囲内特殊効果ID_バディ用
	// DESC: バディ召喚中_起動範囲内特殊効果ID_バディ用
	int32_t onBuddySummon_inActivateRange_spEffectId_buddy;

	// NAME: エスト吸収SFX再生開始からエスト追加処理を行うまでの時間
	// DESC: エスト吸収SFX再生開始からエスト追加処理を行うまでの時間
	float estusFlaskRecovery_AddEstusTime;

	// NAME: マルチ時エネミー撃破時取得ソウル補正値_ホスト
	// DESC: マルチプレイで通常敵を撃破した時のホストの取得ソウル量の補正値
	float defeatMultiModeEnemyOfSoulCorrectRate_byHost;

	// NAME: マルチ時エネミー撃破時取得ソウル補正値_協力霊
	// DESC: マルチプレイで通常敵を撃破した時の協力霊の取得ソウル量の補正値
	float defeatMultiModeEnemyOfSoulCorrectRate_byTeamGhost;

	// NAME: マルチ時ボス撃破時取得ソウル補正値_ホスト
	// DESC: マルチプレイでボスを撃破した時のホストの取得ソウル量の補正値
	float defeatMultiModeBossOfSoulCorrectRate_byHost;

	// NAME: マルチ時ボス撃破時取得ソウル補正値_協力霊
	// DESC: マルチプレイでボスを撃破した時の協力霊の取得ソウル量の補正値
	float defeatMultiModeBossOfSoulCorrectRate_byTeamGhost;

	// NAME: 敵キャラのHPゲージが画面上に見切れないようにするためのオフセット
	// DESC: 敵のHPゲージが画面上に見切れた時に画面内に収めるオフセット値[pixel]（FullHD基準）
	uint16_t enemyHpGaugeScreenOffset_byUp;

	// NAME: プレイ領域収集半径
	// DESC: PC周辺のプレイ領域の収集半径
	uint16_t playRegionCollectDist;

	// NAME: 「敵探知」時弾丸発射位置ダミポリID
	// DESC: 探知弾丸の発射位置ダミポリID
	uint16_t enemyDetectionSpEffect_ShootBulletDummypolyId;

	// NAME: 大ルーン：グレーターデーモン侵入時付与道具個数
	// DESC: 大ルーン：グレーターデーモン侵入時付与道具個数
	uint16_t bigRuneGreaterDemonBreakInGoodsNum;

	// NAME: 大ルーン：グレーターデーモン侵入時付与道具アイテムID
	// DESC: 大ルーン：グレーターデーモン侵入時付与道具アイテムID
	int32_t bigRuneGreaterDemonBreakInGoodsId;

	// NAME: 大ジャンプ領域SFXID
	// DESC: 騎乗大ジャンプ領域のSFXID
	int32_t rideJumpRegionDefaultSfxId;

	// NAME: 共通_騎乗特攻倍率
	// DESC: 騎乗特攻時に補正する倍率
	float saAttackRate_forVsRideAtk;

	// NAME: ネムリアイテム抽選時に敵側にかかる特殊効果
	// DESC: ネムリアイテム抽選時に敵側にかかる特殊効果
	int32_t enemySpEffectIdAfterSleepCollectorItemLot;

	// NAME: 周回保留時マップUID
	// DESC: 周回保留時マップUID、8桁で入力（例…m60_42_36_00 -> 60423600）
	int32_t afterEndingMapUid;

	// NAME: 周回保留時復帰ポイント
	// DESC: 周回保留時復帰ポイントのエンティティID
	uint32_t afterEndingReturnPointEntityId;

	// NAME: 「敵探知」時発射弾丸ID_協力指輪_赤狩り
	// DESC: 敵の勢力/タイプによって飛ばす弾丸のID(マルチ自動発射でも使う)
	int32_t enemyDetectionSpEffect_BulletId_byCoopRing_RedHunter;

	// NAME: 「敵探知」時発射弾丸ID_侵入オーブ_なし
	// DESC: 敵の勢力/タイプによって飛ばす弾丸のID(マルチ自動発射でも使う)
	int32_t enemyDetectionSpEffect_BulletId_byInvadeOrb_None;

	// NAME: チュートリアル判定用：遠見台にアクセスした時にONにするイベントフラグ
	// DESC: チュートリアル判定用：遠見台にアクセスした時にONにするイベントフラグ
	uint32_t tutorialFlagOnAccessDistView;

	// NAME: チュートリアル判定用：リトライポイントにアクセスした時にONにするイベントフラグ
	// DESC: チュートリアル判定用：リトライポイントにアクセスした時にONにするイベントフラグ
	uint32_t tutorialFlagOnAccessRetryPoint;

	// NAME: チュートリアル判定用：集団を倒してグループ報酬が入った時にONにするイベントフラグ
	// DESC: チュートリアル判定用：集団を倒してグループ報酬が入った時にONにするイベントフラグ
	uint32_t tutorialFlagOnGetGroupReward;

	// NAME: チュートリアル判定用：騎乗大ジャンプポイントに入った時にONにするイベントフラグ
	// DESC: チュートリアル判定用：騎乗大ジャンプポイントに入った時にONにするイベントフラグ
	uint32_t tutorialFlagOnEnterRideJumpRegion;

	// NAME: チュートリアル判定用：騎乗大ジャンプポイントを○[m]拡張して内外判定
	// DESC: チュートリアル判定用：騎乗大ジャンプポイントを○[m]拡張して内外判定。○[m]の値をここに設定する。
	float tutorialCheckRideJumpRegionExpandRange;

	// NAME: リトライポイント起動時のPCアニメID
	// DESC: リトライポイント起動時のPCアニメID。-1の場合は再生しない。
	int32_t retryPointActivatedPcAnimId;

	// NAME: リトライポイント起動時のダイアログ表示の遅延時間[秒]
	// DESC: リトライポイント起動時のダイアログ表示の遅延時間[秒]
	float retryPointActivatedDialogDelayTime;

	// NAME: リトライポイント起動時のダイアログのテキストID
	// DESC: リトライポイント起動時のダイアログのテキストID。EventText_ForMap.xlsm のテキストを設定する。-1の場合はダイアログを出さない。
	int32_t retryPointActivatedDialogTextId;

	// NAME: サイン溜まり起動時のPCアニメID
	// DESC: サイン溜まり起動時のPCアニメID。-1の場合は再生しない。
	int32_t signPuddleOpenPcAnimId;

	// NAME: サイン溜まり起動時のダイアログ表示の遅延時間[秒]
	// DESC: サイン溜まり起動時のダイアログ表示の遅延時間[秒]
	float signPuddleOpenDialogDelayTime;

	// NAME: 「死者の活性」特殊効果発動時弾丸ID
	// DESC: 「死者の活性」特殊効果が発動したときに発射する弾丸ID
	int32_t activityOfDeadSpEffect_BulletId;

	// NAME: 「死者の活性」特殊効果発動時弾丸発生位置ダミポリID
	// DESC: 「死者の活性」特殊効果が発動したときに弾丸が発生する位置のダミポリID
	int32_t activityOfDeadSpEffect_ShootBulletDummypolyId;

	// NAME: 「死者の活性」特殊効果発動時の死体のフェードアウト時間
	// DESC: 「死者の活性」特殊効果が発動したときに死体がフェードアウトする際のフェード時間
	float activityOfDeadSpEffect_DeadFadeOutTime;

	// NAME: 投げ開始時のネットワーク情報による遷移を無視する時間
	// DESC: 投げ開始時のネットワーク情報による遷移を無視する時間
	float ignorNetStateSyncTime_ForThrow;

	// NAME: マルチプレペナルティ：LAN切断
	// DESC: マルチプレペナルティ：LAN切断
	uint16_t netPenaltyPointLanDisconnect;

	// NAME: マルチプレペナルティ：プロフィールサインアウト
	// DESC: マルチプレペナルティ：プロフィールサインアウト
	uint16_t netPenaltyPointProfileSignout;

	// NAME: マルチプレペナルティ：電源断
	// DESC: マルチプレペナルティ：電源断
	uint16_t netPenaltyPointReboot;

	// NAME: マルチプレペナルティ：サスペンド・一時停止
	// DESC: マルチプレペナルティ：サスペンド・一時停止
	uint16_t netPnaltyPointSuspend;

	// NAME: マルチプレペナルティ：理の骨の生成（販売）開始待ち時間
	// DESC: マルチプレペナルティ：理の骨の生成（販売）開始待ち時間(秒)
	float netPenaltyForgiveItemLimitTime;

	// NAME: マルチプレペナルティ：ペナルティ判定ポイント
	// DESC: マルチプレペナルティ：ペナルティ判定ポイント
	uint16_t netPenaltyPointThreshold;

	// NAME: 未操作判定時間
	// DESC: マルチで一定期間操作ない人を退出させるためのもの。単位は秒。
	uint16_t uncontrolledMoveThresholdTime;

	// NAME: 「敵探知」時発射弾丸ID_敵対NPC/敵キャラ
	// DESC: 敵意の探知に失敗したときに敵対NPC/敵キャラに飛ばす弾丸のID
	int32_t enemyDetectionSpEffect_BulletId_byNpcEnemy;

	// NAME: 「死者の活性ターゲット検索」対象にかける特殊効果ID 
	// DESC: 検索した対象にかける特殊効果
	int32_t activityOfDeadTargetSearchSpEffect_OnHitSpEffect;

	// NAME: 「死者の活性ターゲット検索」距離 
	// DESC: 検索可能最大距離
	float activityOfDeadTargetSearchSpEffect_MaxLength;

	// NAME: 視界_最低保証距離[倍率換算]
	// DESC: 視界_最低保証距離[倍率換算]
	float sightRangeLowerPromiseRate;

	// NAME: SA大ダメージヒット演出SFX_発生条件SAダメージ必要最低値[pt]
	// DESC: SA大ダメージヒット演出SFX_発生条件SAダメージ必要最低値[pt]
	int16_t saLargeDamageHitSfx_MinDamage;

	// NAME: SA大ダメージヒット演出SFX_発生条件SAダメージ強制発生最低値[pt]
	// DESC: SA大ダメージヒット演出SFX_発生条件SAダメージ強制発生最低値[pt]
	int16_t saLargeDamageHitSfx_ForceDamage;

	// NAME: ソロ侵入最大ポイント
	// DESC: ソロ侵入ポイントの最大値。この値を越えたときにソロで侵入されるようになる
	uint32_t soloBreakInMaxPoint;

	// NAME: NPC会話のボイス再生タイムアウト時間
	// DESC: NPC会話のボイス再生タイムアウト時間。この時間経過してもボイス再生が終わらない場合は次のメッセージへ進む
	float npcTalkTimeOutThreshold;

	// NAME: プレイログの送信間隔
	// DESC: アイテム使用ログ などをサーバーへ送信する間隔
	float sendPlayLogIntervalTime;

	// NAME: 七色石の最大設置数
	// DESC: 七色石の最大設置数
	uint8_t item370_MaxSfxNum;

	// NAME: キャラディアクティベート中にアクティベート許可する距離[m]
	// DESC: キャラディアクティベート中にアクティベート許可する距離（オープン配置キャラのみ有効）
	uint8_t chrActivateDist_forLeavePC;

	// NAME: マルチ弱体化レベル補正係数１
	// DESC: マルチ時ステータス弱体化。ホストのレベル加算補正
	int16_t summonDataCoopMatchingLevelUpperAbs;

	// NAME: マルチ弱体化レベル補正係数２
	// DESC: マルチ時ステータス弱体化。ホストのレベル倍率補正
	int16_t summonDataCoopMatchingLevelUpperRel;

	// NAME: マルチ弱体化最大武器補正係数
	// DESC: マルチ時ステータス弱体化。最大武器強化レベル補正
	int16_t summonDataCoopMatchingWepLevelMul;

	// NAME: バーサーカーサインを拾った時のまたたび効果用弾丸ID
	// DESC: サイン位置に特殊効果用の弾丸を発生させる際の弾丸ID
	int32_t pickUpBerserkerSignSpEffectBulletId;

	// NAME: バーサーカーがPC自力殺害に成功演出用特殊効果ID
	// DESC: バーサーカーがPC自力殺害に成功した際に専用の演出を再生する特殊効果
	int32_t succeedBerserkerSelfKillingEffectId;

	// NAME: レベルシンク適用判定係数１白
	// DESC: レベルシンク適用するかどうかのソウルレベル係数
	uint8_t machingLevelWhiteSignUpperRel;

	// NAME: レベルシンク適用判定係数２白
	// DESC: レベルシンク適用するかどうかのソウルレベル係数
	uint8_t machingLevelWhiteSignUpperAbs;

	// NAME: レベルシンク適用判定係数１赤
	// DESC: レベルシンク適用するかどうかのソウルレベル係数
	uint8_t machingLevelRedSignUpperRel;

	// NAME: レベルシンク適用判定係数２赤
	// DESC: レベルシンク適用するかどうかのソウルレベル係数
	uint8_t machingLevelRedSignUpperAbs;

	// NAME: レベルシンク適用判定最大武器強化レベル係数０白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_0;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_1;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_2;

	// NAME: レベルシンク適用判定最大武器強化レベル係数３白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_3;

	// NAME: レベルシンク適用判定最大武器強化レベル係数４白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_4;

	// NAME: レベルシンク適用判定最大武器強化レベル係数５白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_5;

	// NAME: レベルシンク適用判定最大武器強化レベル係数６白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_6;

	// NAME: レベルシンク適用判定最大武器強化レベル係数７白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_7;

	// NAME: レベルシンク適用判定最大武器強化レベル係数８白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_8;

	// NAME: レベルシンク適用判定最大武器強化レベル係数９白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_9;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１０白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_10;

	// NAME: レベルシンク適用判定最大武器強化レベル係数０赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_0;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_1;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_2;

	// NAME: レベルシンク適用判定最大武器強化レベル係数３赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_3;

	// NAME: レベルシンク適用判定最大武器強化レベル係数４赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_4;

	// NAME: レベルシンク適用判定最大武器強化レベル係数５赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_5;

	// NAME: レベルシンク適用判定最大武器強化レベル係数６赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_6;

	// NAME: レベルシンク適用判定最大武器強化レベル係数７赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_7;

	// NAME: レベルシンク適用判定最大武器強化レベル係数８赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_8;

	// NAME: レベルシンク適用判定最大武器強化レベル係数９赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_9;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１０赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_10;

	// NAME: 侵入ポイントの自動配置間隔
	// DESC: 侵入ポイントの自動配置間隔
	uint8_t autoInvadePoint_generateDist;

	// NAME: 侵入ポイント自動配置取り消し範囲
	// DESC: 侵入ポイント自動配置取り消し範囲
	uint8_t autoInvadePoint_cancelDist;

	// NAME: グローバルイベントログの送信間隔
	// DESC: グローバルイベントログ をサーバーへ送信する間隔
	float sendGlobalEventLogIntervalTime;

	// NAME: ソロ侵入ポイント加算値_白サイン
	// DESC: ソロ侵入ポイント加算値_白サイン
	uint16_t addSoloBreakInPoint_White;

	// NAME: ソロ侵入ポイント加算値_赤サイン
	// DESC: ソロ侵入ポイント加算値_赤サイン
	uint16_t addSoloBreakInPoint_Black;

	// NAME: ソロ侵入ポイント加算値_乱入
	// DESC: ソロ侵入ポイント加算値_乱入
	uint16_t addSoloBreakInPoint_ForceJoin;

	// NAME: ソロ侵入ポイント加算値_マップ守護訪問
	// DESC: ソロ侵入ポイント加算値_マップ守護訪問
	uint16_t addSoloBreakInPoint_VisitorGuardian;

	// NAME: ソロ侵入ポイント加算値_赤狩り訪問
	// DESC: ソロ侵入ポイント加算値_赤狩り訪問
	uint16_t addSoloBreakInPoint_VisitorRedHunter;

	// NAME: 初期同期PC用の無敵タイマー
	// DESC: 初期同期PC用の無敵タイマー
	uint8_t invincibleTimer_forNetPC_initSync;

	// NAME: 初期同期PC以外用の無敵タイマー
	// DESC: 初期同期PC以外用の無敵タイマー
	uint8_t invincibleTimer_forNetPC;

	// NAME: 【赤狩り】ホストが白扉を通過した際にもらえるソウル率
	// DESC: ホストが白扉を通過した時に赤狩りがもらえるソウル=赤狩りが一つ前のLvから現在Lvになるために必要なソウル*この倍率
	float redHunter_HostBossAreaGetSoulRate;

	// NAME: 徘徊幻影の痕跡のデカールパラメータID
	// DESC: 徘徊幻影が移動中に出す痕跡のデカールパラメータID
	int32_t ghostFootprintDecalParamId;

	// NAME: マルチプレイ制限距離外の警告メッセージ表示のカウント時間[秒]
	// DESC: マルチプレイ制限距離外に出たままこのカウント時間経過したらマルチプレイの解散を行う
	float leaveAroundHostWarningTime;

	// NAME: ホスト化コストアイテムID
	// DESC: ホスト化をONにした際に消費するコストアイテムのID
	int32_t hostModeCostItemId;

	// NAME: AIジャンプ減速パラメータ
	// DESC: AIジャンプ用減速パラメータ(0.0：等速運動、1.0：最大減速、目標地点で速度0)
	float aIJump_DecelerateParam;

	// NAME: バディインスタンス削除保証時間
	// DESC: 死亡フラグから実際にインスタンスが消滅するまでの時間
	float buddyDisappearDelaySec;

	// NAME: AIジャンプ飛び降り時Y移動量補正率
	// DESC: AIジャンプ飛び降り時Y移動量補正率
	float aIJump_AnimYMoveCorrectRate_onJumpOff;

	// NAME: ステルス視界倍率_ステルス効果無しでしゃがみ
	// DESC: ステルス視界倍率_ステルス効果無しでしゃがみ
	float stealthSystemSightRate_NotInStealthRigid_NotSightHide_StealthMode;

	// NAME: ステルス視界倍率_ステルスレイ遮蔽地帯で立ち
	// DESC: ステルス視界倍率_ステルスレイ遮蔽地帯で立ち
	float stealthSystemSightRate_NotInStealthRigid_SightHide_NotStealthMode;

	// NAME: ステルス視界倍率_ステルスレイ遮蔽地帯でしゃがみ
	// DESC: ステルス視界倍率_ステルスレイ遮蔽地帯でしゃがみ
	float stealthSystemSightRate_NotInStealthRigid_SightHide_StealthMode;

	// NAME: ステルス視界倍率_ステルスヒット内で立ち
	// DESC: ステルス視界倍率_ステルスヒット内で立ち
	float stealthSystemSightRate_InStealthRigid_NotSightHide_NotStealthMode;

	// NAME: ステルス視界倍率_ステルスヒット内でしゃがみ
	// DESC: ステルス視界倍率_ステルスヒット内でしゃがみ
	float stealthSystemSightRate_InStealthRigid_NotSightHide_StealthMode;

	// NAME: ステルス視界倍率_ステルスレイ遮蔽地帯＋ステルスヒット内で立ち
	// DESC: ステルス視界倍率_ステルスレイ遮蔽地帯＋ステルスヒット内で立ち
	float stealthSystemSightRate_InStealthRigid_SightHide_NotStealthMode;

	// NAME: ステルス視界倍率_ステルスレイ遮蔽地帯＋ステルスヒット内でしゃがみ
	// DESC: ステルス視界倍率_ステルスレイ遮蔽地帯＋ステルスヒット内でしゃがみ
	float stealthSystemSightRate_InStealthRigid_SightHide_StealthMode;

	// NAME: 宝死体のデフォルトアクションボタンパラメータID
	// DESC: MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「宝死体」を選択したときのデフォルトアクションボタンパラメータID
	int32_t msbEventGeomTreasureInfo_actionButtonParamId_corpse;

	// NAME: 宝死体のデフォルトアイテム取得時アニメID
	// DESC: MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「宝死体」を選択したときのデフォルトアイテム取得時アニメID
	int32_t msbEventGeomTreasureInfo_itemGetAnimId_corpse;

	// NAME: 宝箱のデフォルトアクションボタンパラメータID
	// DESC: MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「宝箱」を選択したときのデフォルトアクションボタンパラメータID
	int32_t msbEventGeomTreasureInfo_actionButtonParamId_box;

	// NAME: 宝箱のデフォルトアイテム取得時アニメID
	// DESC: MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「宝箱」を選択したときのデフォルトアイテム取得時アニメID
	int32_t msbEventGeomTreasureInfo_itemGetAnimId_box;

	// NAME: アイテム光のデフォルトアクションボタンパラメータID
	// DESC: MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「アイテム光」を選択したときのデフォルトアクションボタンパラメータID
	int32_t msbEventGeomTreasureInfo_actionButtonParamId_shine;

	// NAME: アイテム光のデフォルトアイテム取得時アニメID
	// DESC: MapStudioイベントのOBJ用宝箱情報の宝箱タイプで「アイテム光」を選択したときのデフォルトアイテム取得時アニメID
	int32_t msbEventGeomTreasureInfo_itemGetAnimId_shine;

	// NAME: サイン溜まり：アセットID
	// DESC: サイン溜まりに使うアセット
	int32_t signPuddleAssetId;

	// NAME: サイン溜まり：サイン出現ダミポリ0
	// DESC: サイン溜まりのサインの表示位置を決定するのに使うダミポリ
	int32_t signPuddleAppearDmypolyId0;

	// NAME: サイン溜まり：サイン出現ダミポリ1
	// DESC: サイン溜まりのサインの表示位置を決定するのに使うダミポリ
	int32_t signPuddleAppearDmypolyId1;

	// NAME: サイン溜まり：サイン出現ダミポリ2
	// DESC: サイン溜まりのサインの表示位置を決定するのに使うダミポリ
	int32_t signPuddleAppearDmypolyId2;

	// NAME: サイン溜まり：サイン出現ダミポリ3
	// DESC: サイン溜まりのサインの表示位置を決定するのに使うダミポリ
	int32_t signPuddleAppearDmypolyId3;

	// NAME: 騎乗者の落下ダメージ倍率補正_PC用
	// DESC: 騎乗者の落下ダメージ倍率補正_PC用
	float fallDamageRate_forRidePC;

	// NAME: 騎乗者の落下ダメージ倍率補正_NPC用
	// DESC: 騎乗者の落下ダメージ倍率補正_NPC用
	float fallDamageRate_forRideNPC;

	// NAME: 黄衣の翁サイン作成時特殊効果ID
	// DESC: 黄衣の翁サイン作成時特殊効果ID
	int32_t OldMonkOfYellow_CreateSignSpEffectId;

	// NAME: 敗残兵起動距離
	// DESC: 敗残兵起動距離
	float StragglerActivateDist;

	// NAME: 敗残兵アイテム使用許可_PC用特殊効果
	// DESC: 敗残兵アイテム使用許可_PC用特殊効果
	int32_t SpEffectId_EnableUseItem_StragglerActivate;

	// NAME: 敗残兵起動_敗残兵キャラ用特殊効果
	// DESC: 敗残兵起動_敗残兵キャラ用特殊効果
	int32_t SpEffectId_StragglerWakeUp;

	// NAME: 敗残兵_討伐対象用特殊効果
	// DESC: 敗残兵_討伐対象用特殊効果
	int32_t SpEffectId_StragglerTarget;

	// NAME: 敗残兵_敵対後特殊効果
	// DESC: 敗残兵_敵対後特殊効果
	int32_t SpEffectId_StragglerOppose;

	// NAME: レイ遮断でバディがプレイヤーにワープする時間[s]
	// DESC: レイ遮断でバディがプレイヤーにワープする時間[s]
	float buddyWarp_TriggerTimeRayBlocked;

	// NAME: 直線距離でバディがプレイヤーにワープする距離[m]
	// DESC: 直線距離でバディがプレイヤーにワープする距離[m]
	float buddyWarp_TriggerDistToPlayer;

	// NAME: バディがパス移動で詰まった判定する時間[s]
	// DESC: バディがパス移動で詰まった判定する時間[s]
	float buddyWarp_ThresholdTimePathStacked;

	// NAME: バディがパス移動で詰まっているとみなす距離[m]
	// DESC: バディがパス移動で詰まっているとみなす距離[m]
	float buddyWarp_ThresholdRangePathStacked;

	// NAME: [朝]AI視界倍率
	// DESC: [朝]AI視界倍率
	float aiSightRate_morning;

	// NAME: [昼]AI視界倍率
	// DESC: [昼]AI視界倍率
	float aiSightRate_noonA;

	// NAME: バディとプレイヤーがぶつかって、すり抜け始める時間[s]
	// DESC: バディとプレイヤーがぶつかって、すり抜け始める時間[s]
	float buddyPassThroughTriggerTime;

	// NAME: [夕]AI視界倍率
	// DESC: [夕]AI視界倍率
	float aiSightRate_evening;

	// NAME: [夜]AI視界倍率
	// DESC: [夜]AI視界倍率
	float aiSightRate_night;

	// NAME: [深夜]AI視界倍率
	// DESC: [深夜]AI視界倍率
	float aiSightRate_midnightA;

	// NAME: リザーブ
	// DESC: (dummy8)
	uint8_t reserve4_2[4];

	// NAME: AI視界倍率_太陽が見えない場所(明るい)
	// DESC: AI視界倍率_太陽が見えない場所(明るい)
	float aiSightRate_sunloss_light;

	// NAME: AI視界倍率_太陽が見えない場所(暗闇)
	// DESC: AI視界倍率_太陽が見えない場所(暗闇)
	float aiSightRate_sunloss_dark;

	// NAME: AI視界倍率_太陽が見えない場所(真っ暗闇)
	// DESC: AI視界倍率_太陽が見えない場所(真っ暗闇)
	float aiSightRate_sunloss_veryDark;

	// NAME: ステルス視界角度減衰率_ステルス効果無しでしゃがみ
	// DESC: ステルス視界角度減衰率_ステルス効果無しでしゃがみ
	float stealthSystemSightAngleReduceRate_NotInStealthRigid_NotSightHide_StealthMode;

	// NAME: ステルス視界角度減衰率_ステルスレイ遮蔽地帯で立ち
	// DESC: ステルス視界角度減衰率_ステルスレイ遮蔽地帯で立ち
	float stealthSystemSightAngleReduceRate_NotInStealthRigid_SightHide_NotStealthMode;

	// NAME: ステルス視界角度減衰率_ステルスレイ遮蔽地帯でしゃがみ
	// DESC: ステルス視界角度減衰率_ステルスレイ遮蔽地帯でしゃがみ
	float stealthSystemSightAngleReduceRate_NotInStealthRigid_SightHide_StealthMode;

	// NAME: ステルス視界角度減衰率_ステルスヒット内で立ち
	// DESC: ステルス視界角度減衰率_ステルスヒット内で立ち
	float stealthSystemSightAngleReduceRate_InStealthRigid_NotSightHide_NotStealthMode;

	// NAME: ステルス視界角度減衰率_ステルスヒット内でしゃがみ
	// DESC: ステルス視界角度減衰率_ステルスヒット内でしゃがみ
	float stealthSystemSightAngleReduceRate_InStealthRigid_NotSightHide_StealthMode;

	// NAME: ステルス視界角度減衰率_ステルスレイ遮蔽地帯＋ステルスヒット内で立ち
	// DESC: ステルス視界角度減衰率_ステルスレイ遮蔽地帯＋ステルスヒット内で立ち
	float stealthSystemSightAngleReduceRate_InStealthRigid_SightHide_NotStealthMode;

	// NAME: ステルス視界角度減衰率_ステルスレイ遮蔽地帯＋ステルスヒット内でしゃがみ
	// DESC: ステルス視界角度減衰率_ステルスレイ遮蔽地帯＋ステルスヒット内でしゃがみ
	float stealthSystemSightAngleReduceRate_InStealthRigid_SightHide_StealthMode;

	// NAME: 天候抽選条件_朝_開始時刻_時
	// DESC: 天候抽選条件_朝_開始時刻_時(SEQ09371)
	uint8_t weatherLotConditionStart_Morning_Hour;

	// NAME: 天候抽選条件_朝_開始時刻_分
	// DESC: 天候抽選条件_朝_開始時刻_分(SEQ09371)
	uint8_t weatherLotConditionStart_Morning_Minute;

	// NAME: 天候抽選条件_昼_開始時刻_時
	// DESC: 天候抽選条件_昼_開始時刻_時(SEQ09371)
	uint8_t weatherLotConditionStart_Day_Hour;

	// NAME: 天候抽選条件_昼_開始時刻_分
	// DESC: 天候抽選条件_昼_開始時刻_分(SEQ09371)
	uint8_t weatherLotConditionStart_Day_Minute;

	// NAME: 天候抽選条件_夕_開始時刻_時
	// DESC: 天候抽選条件_夕_開始時刻_時(SEQ09371)
	uint8_t weatherLotConditionStart_Evening_Hour;

	// NAME: 天候抽選条件_夕_開始時刻_分
	// DESC: 天候抽選条件_夕_開始時刻_分(SEQ09371)
	uint8_t weatherLotConditionStart_Evening_Minute;

	// NAME: 天候抽選条件_夜_開始時刻_時
	// DESC: 天候抽選条件_夜_開始時刻_時(SEQ09371)
	uint8_t weatherLotConditionStart_Night_Hour;

	// NAME: 天候抽選条件_夜_開始時刻_分
	// DESC: 天候抽選条件_夜_開始時刻_分(SEQ09371)
	uint8_t weatherLotConditionStart_Night_Minute;

	// NAME: 天候抽選条件_夜明け_開始時刻_時
	// DESC: 天候抽選条件_夜明け_開始時刻_時(SEQ09371)
	uint8_t weatherLotConditionStart_DayBreak_Hour;

	// NAME: 天候抽選条件_夜明け_開始時刻_分
	// DESC: 天候抽選条件_夜明け_開始時刻_分(SEQ09371)
	uint8_t weatherLotConditionStart_DayBreak_Minute;

	// NAME: 天候抽選条件_予約
	// DESC: (dummy8)
	uint8_t weatherLotCondition_reserved[2];

	// NAME: Playerライト強度スケール変更時間帯_開始時刻_時
	// DESC: Playerライト強度スケール変更時間帯_開始時刻_時(SEQ16562)
	uint8_t pclightScaleChangeStart_Hour;

	// NAME: Playerライト強度スケール変更時間帯_開始時刻_分
	// DESC: Playerライト強度スケール変更時間帯_開始時刻_分(SEQ16562)
	uint8_t pclightScaleChangeStart_Minute;

	// NAME: Playerライト強度スケール変更時間帯_終了時刻_時
	// DESC: Playerライト強度スケール変更時間帯_終了時刻_時(SEQ16562)
	uint8_t pclightScaleChangeEnd_Hour;

	// NAME: Playerライト強度スケール変更時間帯_終了時刻_分
	// DESC: Playerライト強度スケール変更時間帯_終了時刻_分(SEQ16562)
	uint8_t pclightScaleChangeEnd_Minute;

	// NAME: 時間帯Playerライト強度スケール変更値
	// DESC: 時間帯Playerライト強度スケール変更値(SEQ16562)
	float pclightScaleByTimezone;

	// NAME: 大ルーン：グレーターデーモンバディ召喚時バディ付与特殊効果ID
	// DESC: 大ルーン：グレーターデーモンバディ召喚時バディ付与特殊効果ID
	int32_t bigRuneGreaterDemon_SummonBuddySpecialEffectId_Buddy;

	// NAME: 大ルーン：グレーターデーモンバディ召喚時PC付与特殊効果ID
	// DESC: 大ルーン：グレーターデーモンバディ召喚時PC付与特殊効果ID
	int32_t bigRuneGreaterDemon_SummonBuddySpecialEffectId_Pc;

	// NAME: 拠点篝火ワープID
	// DESC: 拠点篝火の篝火ワープパラメータID
	int32_t homeBonfireParamId;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１１白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_11;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１２白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_12;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１３白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_13;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１４白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_14;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１５白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_15;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１６白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_16;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１７白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_17;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１８白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_18;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１９白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_19;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２０白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_20;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２１白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_21;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２２白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_22;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２３白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_23;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２４白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_24;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２５白
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperWhiteSign_25;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１１赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_11;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１２赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_12;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１３赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_13;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１４赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_14;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１５赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_15;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１６赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_16;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１７赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_17;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１８赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_18;

	// NAME: レベルシンク適用判定最大武器強化レベル係数１９赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_19;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２０赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_20;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２１赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_21;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２２赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_22;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２３赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_23;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２４赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_24;

	// NAME: レベルシンク適用判定最大武器強化レベル係数２５赤
	// DESC: レベルシンク適用するかどうかの最大武器強化レベル係数
	uint8_t machingWeaponLevelUpperRedSign_25;

	// NAME: メニュー用時間帯表示_朝_開始時刻_時
	// DESC: メニュー用時間帯表示_朝_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Morning_Hour;

	// NAME: メニュー用時間帯表示_朝_開始時刻_分
	// DESC: メニュー用時間帯表示_朝_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Morning_Minute;

	// NAME: メニュー用時間帯表示_昼1_開始時刻_時
	// DESC: メニュー用時間帯表示_昼1_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Day1_Hour;

	// NAME: メニュー用時間帯表示_昼1_開始時刻_分
	// DESC: メニュー用時間帯表示_昼1_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Day1_Minute;

	// NAME: メニュー用時間帯表示_昼2_開始時刻_時
	// DESC: メニュー用時間帯表示_昼2_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Day2_Hour;

	// NAME: メニュー用時間帯表示_昼2_開始時刻_分
	// DESC: メニュー用時間帯表示_昼2_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Day2_Minute;

	// NAME: メニュー用時間帯表示_夕_開始時刻_時
	// DESC: メニュー用時間帯表示_夕_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Evening_Hour;

	// NAME: メニュー用時間帯表示_夕_開始時刻_分
	// DESC: メニュー用時間帯表示_夕_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Evening_Minute;

	// NAME: メニュー用時間帯表示_夜_開始時刻_時
	// DESC: メニュー用時間帯表示_夜_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Night_Hour;

	// NAME: メニュー用時間帯表示_夜_開始時刻_分
	// DESC: メニュー用時間帯表示_夜_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Night_Minute;

	// NAME: メニュー用時間帯表示_深夜_開始時刻_時
	// DESC: メニュー用時間帯表示_深夜_開始時刻_時(SEQ22108)
	uint8_t menuTimezoneStart_Midnight_Hour;

	// NAME: メニュー用時間帯表示_深夜_開始時刻_分
	// DESC: メニュー用時間帯表示_深夜_開始時刻_分(SEQ22108)
	uint8_t menuTimezoneStart_Midnight_Minute;

	// NAME: ネットワークPC脅威度通知_脅威度
	// DESC: ネットワークPC脅威度通知_脅威度(SEQ21950)
	uint16_t remotePlayerThreatLvNotify_ThreatLv;

	// NAME: ネットワークPC脅威度通知_通知距離[m]
	// DESC: ネットワークPC脅威度通知_通知距離[m](SEQ21950)
	float remotePlayerThreatLvNotify_NotifyDist;

	// NAME: ネットワークPC脅威度通知_通知終了距離[m]
	// DESC: ネットワークPC脅威度通知_通知終了距離[m](SEQ21950)
	float remotePlayerThreatLvNotify_EndNotifyDist;

	// NAME: 地図ポイント発見領域のデフォルト拡張距離[m]
	// DESC: 地図ポイントの発見領域のデフォルトの拡張距離。地図ポイントの"発見領域 上書き領域"が無効(-1)のときに、自身の領域から拡張して発見領域が生成される。その拡張距離
	float worldMapPointDiscoveryExpandRange;

	// NAME: 地図ポイント出場領域のデフォルト拡張距離[m]
	// DESC: 地図ポイントの出場領域のデフォルトの拡張距離。地図ポイントの"出場領域 上書き領域"が無効(-1)のときに、自身の領域から拡張して出場領域が生成される。その拡張距離
	float worldMapPointReentryExpandRange;

	// NAME: ネットワークPC脅威度通知_通知時間[秒]
	// DESC: ネットワークPC脅威度通知_通知時間[秒](SEQ21950)
	uint16_t remotePlayerThreatLvNotify_NotifyTime;

	// NAME: 侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_グレーター系（ID102）
	// DESC: 侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_グレーター系（ID102）
	uint16_t breakIn_A_rebreakInGoodsNum;

	// NAME: 侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_グレーター系（ID102）
	// DESC: 侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_グレーター系（ID102）
	int32_t breakIn_A_rebreakInGoodsId;

	// NAME: 降りる大ジャンプ_上空SFXID
	// DESC: 降りる大ジャンプ_上空SFXID
	int32_t rideJumpoff_SfxId;

	// NAME: 降りる大ジャンプ_上空SFX基点オフセット
	// DESC: 降りる大ジャンプ_上空SFX基点オフセット
	float rideJumpoff_SfxHeightOffset;

	// NAME: 降りる大ジャンプ領域内_PC馬にかかる特殊効果ID
	// DESC: 降りる大ジャンプ領域内_PC馬にかかる特殊効果ID
	int32_t rideJumpoff_SpEffectId;

	// NAME: 降りる大ジャンプ領域内_PCにかかる特殊効果ID
	// DESC: 降りる大ジャンプ領域内_PCにかかる特殊効果ID
	int32_t rideJumpoff_SpEffectIdPc;

	// NAME: メインメニュー_アイテム作成_開放イベントフラグ
	// DESC: メインメニュー→アイテム作成メニューをアンロックするイベントフラグ
	uint32_t unlockExchangeMenuEventFlagId;

	// NAME: メインメニュー_メッセージ_開放イベントフラグ
	// DESC: メインメニュー→メッセージメニューをアンロックするイベントフラグ
	uint32_t unlockMessageMenuEventFlagId;

	// NAME: 侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_グレーター系使い捨て（ID111）
	// DESC: 侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_グレーター系使い捨て（ID111）
	uint16_t breakInOnce_A_rebreakInGoodsNum;

	// NAME: 侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_火山館系（ID112）
	// DESC: 侵入時に付与する"再侵入アイテム"の付与個数：侵入アイテム_火山館系（ID112）
	uint16_t breakIn_B_rebreakInGoodsNum;

	// NAME: 侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_グレーター系使い捨て（ID111）
	// DESC: 侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_グレーター系使い捨て（ID111）
	int32_t breakInOnce_A_rebreakInGoodsId;

	// NAME: 侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_火山館系（ID112）
	// DESC: 侵入時に付与する"再侵入アイテム"の道具アイテムID：侵入アイテム_火山館系（ID112）
	int32_t breakIn_B_rebreakInGoodsId;

	// NAME: アクションボタン押しっぱなしでアクションボタン操作を無効化する時間
	// DESC: アクションボタン押しっぱなしでアクションボタン操作を無効化する時間
	float actionButtonInputCancelTime;

	// NAME: ボス撃破処理後クリアボーナス取得遅延時間
	// DESC: ボス撃破処理後クリアボーナス取得遅延時間
	float blockClearBonusDelayTime;

	// NAME: 【未使用】(SEQ25048参照）敵による篝火無効化を判定するPCから篝火までの距離[m]
	// DESC: 【未使用】(SEQ25048参照）敵による篝火無効化を判定するPCから篝火までの距離[m](0以下：PC距離チェックしない。全距離でチェック)
	float bonfireCheckEnemyRange;

	// NAME: 予約
	// DESC: (dummy8)
	uint8_t reserved_124[48];
} GAME_SYSTEM_COMMON_PARAM_ST;

#endif
