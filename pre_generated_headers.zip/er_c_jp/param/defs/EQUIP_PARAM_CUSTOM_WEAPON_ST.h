/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_EQUIP_PARAM_CUSTOM_WEAPON_ST_H
#define _PARAMDEF_EQUIP_PARAM_CUSTOM_WEAPON_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EQUIP_PARAM_CUSTOM_WEAPON_ST {

	// NAME: 武器ベースID
	// DESC: 武器ベースID
	int32_t baseWepId;

	// NAME: 魔石ID
	// DESC: 魔石ID
	int32_t gemId;

	// NAME: 強化値
	// DESC: 強化値
	uint8_t reinforceLv;

	// NAME: pad
	// DESC: pad
	uint8_t pad[7];
} EQUIP_PARAM_CUSTOM_WEAPON_ST;

#endif
