/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CEREMONY_PARAM_ST_H
#define _PARAMDEF_CEREMONY_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CEREMONY_PARAM_ST {

	// NAME: イベントレイヤーID
	// DESC: イベントメーカーのレイヤーID
	int32_t eventLayerId;

	// NAME: MapStudioレイヤーID
	// DESC: MapStudioのレイヤーID
	int32_t mapStudioLayerId;

	// NAME: マルチプレイエリアオフセット
	// DESC: マルチプレイエリアIDのオフセット。例えば「100」と入れるとマルチプレイエリアIDが「100」オフセットされる。
	int32_t multiPlayAreaOffset;

	// NAME: マップ名ID上書き_地名表示
	// DESC: マップ名ID_地名表示を指定IDに上書きする。-1:上書き無し、-2以下,0以上:そのIDに上書き。
	int32_t overrideMapPlaceNameId;

	// NAME: マップ名ID上書き_セーブデータ表示
	// DESC: マップ名ID_セーブデータ表示を指定IDに上書きする。-1:上書き無し、-2以下,0以上:そのIDに上書き。
	int32_t overrideSaveMapNameId;

	// NAME: pad2
	uint8_t pad2[16];
} CEREMONY_PARAM_ST;

#endif
