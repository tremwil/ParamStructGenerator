/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_ATK_PARAM_ST_H
#define _PARAMDEF_ATK_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ATK_PARAM_ST {

	// NAME: あたり0 半径
	// DESC: 球、カプセルの半径
	float hit0_Radius;

	// NAME: あたり1 半径
	// DESC: 球、カプセルの半径
	float hit1_Radius;

	// NAME: あたり2 半径
	// DESC: 球、カプセルの半径
	float hit2_Radius;

	// NAME: あたり3 半径
	// DESC: 球、カプセルの半径
	float hit3_Radius;

	// NAME: ノックバック距離[m]
	// DESC: ノックバック距離[m]
	float knockbackDist;

	// NAME: ヒットストップ時間[s]
	// DESC: ヒットストップの停止時間[s]
	float hitStopTime;

	// NAME: 特殊効果0
	// DESC: 特殊効果パラメータで作成したＩＤを入れる
	int32_t spEffectId0;

	// NAME: 特殊効果1
	// DESC: 特殊効果パラメータで作成したＩＤを入れる
	int32_t spEffectId1;

	// NAME: 特殊効果2
	// DESC: 特殊効果パラメータで作成したＩＤを入れる
	int32_t spEffectId2;

	// NAME: 特殊効果3
	// DESC: 特殊効果パラメータで作成したＩＤを入れる
	int32_t spEffectId3;

	// NAME: 特殊効果4
	// DESC: 特殊効果パラメータで作成したＩＤを入れる
	int32_t spEffectId4;

	// NAME: あたり0 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit0_DmyPoly1;

	// NAME: あたり1 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit1_DmyPoly1;

	// NAME: あたり2 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit2_DmyPoly1;

	// NAME: あたり3 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit3_DmyPoly1;

	// NAME: あたり0 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit0_DmyPoly2;

	// NAME: あたり1 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit1_DmyPoly2;

	// NAME: あたり2 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit2_DmyPoly2;

	// NAME: あたり3 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit3_DmyPoly2;

	// NAME: 吹き飛ばし補正値
	// DESC: 吹き飛ばす時の補正値
	uint16_t blowingCorrection;

	// NAME: 物理攻撃力補正値
	// DESC: PCのみ。物理攻撃力基本値に掛ける倍率
	uint16_t atkPhysCorrection;

	// NAME: 魔法攻撃力補正値
	// DESC: PCのみ。魔法攻撃力に掛ける倍率（弓の場合は、飛び道具を補正）
	uint16_t atkMagCorrection;

	// NAME: 炎攻撃力補正値
	// DESC: PCのみ。炎攻撃力に掛ける倍率（弓の場合は、飛び道具を補正）
	uint16_t atkFireCorrection;

	// NAME: 電撃攻撃力補正値
	// DESC: PCのみ。電撃攻撃力に掛ける倍率（弓の場合は、飛び道具を補正）
	uint16_t atkThunCorrection;

	// NAME: スタミナ攻撃力補正値
	// DESC: PCのみ。スタミナ攻撃力に掛ける倍率
	uint16_t atkStamCorrection;

	// NAME: はじき攻撃力補正値
	// DESC: PCのみ。1のみ
	uint16_t guardAtkRateCorrection;

	// NAME: はじき防御力補正値
	// DESC: PCのみ。攻撃のはじかれ基本値に掛ける倍率
	uint16_t guardBreakCorrection;

	// NAME: 投げ抜け攻撃力補正値
	// DESC: 投げ抜け攻撃に対する武器補正値
	uint16_t atkThrowEscapeCorrection;

	// NAME: サブカテゴリ1
	// DESC: サブカテゴリ1
	uint8_t subCategory1;

	// NAME: サブカテゴリ2
	// DESC: サブカテゴリ2
	uint8_t subCategory2;

	// NAME: 物理攻撃力
	// DESC: NPCのみ。物理攻撃の基本ダメージ
	uint16_t atkPhys;

	// NAME: 魔法攻撃力
	// DESC: NPCのみ。魔法攻撃の追加ダメージ
	uint16_t atkMag;

	// NAME: 炎攻撃力
	// DESC: NPCのみ。炎攻撃の追加ダメージ
	uint16_t atkFire;

	// NAME: 電撃攻撃力
	// DESC: NPCのみ。電撃攻撃の追加ダメージ
	uint16_t atkThun;

	// NAME: スタミナ攻撃力
	// DESC: NPCのみ。敵（プレイヤー）のスタミナに対するダメージ量
	uint16_t atkStam;

	// NAME: はじき攻撃力
	// DESC: NPCのみ。はじき値
	uint16_t guardAtkRate;

	// NAME: はじき防御力
	// DESC: NPCのみ。攻撃がはじかれるかどうかの判定に利用する値
	uint16_t guardBreakRate;

	// NAME: pad
	uint8_t pad6[1];

	// NAME: 茂みにダメージ可
	// DESC: 「茂みダメージで壊れるか」ONのアセットに対してダメージ計算をするか？を設定します。〇：計算する、×：計算しない(つまりダメージをあたえることはできない)【GR】SEQ20617 
	uint8_t isEnableCalcDamageForBushesObj;

	// NAME: 投げ抜け攻撃力
	// DESC: 投げ抜け攻撃力
	uint16_t atkThrowEscape;

	// NAME: オブジェ攻撃力
	// DESC: ＯＢＪに対する攻撃力
	uint16_t atkObj;

	// NAME: ガード時スタミナカット率補正
	// DESC: 武器パラメータ、ＮＰＣパラメータに設定されている【ガード時スタミナカット率】を補正する
	int16_t guardStaminaCutRate;

	// NAME: ガード倍率
	// DESC: ＮＰＣ、武器パラメータで設定してあるガード性能を一律で補正を掛ける0で、1倍／100で、2倍／－100で、0　にパラメータが増減するようにするガード倍率　=　（ガード倍率/100　+　1）
	int16_t guardRate;

	// NAME: 投げタイプID
	// DESC: 投げパラメータと紐付けされているID
	uint16_t throwTypeId;

	// NAME: あたり0 部位
	// DESC: あたり部位
	uint8_t hit0_hitType;

	// NAME: あたり1 部位
	// DESC: あたり部位
	uint8_t hit1_hitType;

	// NAME: あたり2 部位
	// DESC: あたり部位
	uint8_t hit2_hitType;

	// NAME: あたり3 部位
	// DESC: あたり部位
	uint8_t hit3_hitType;

	// NAME: あたり0 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti0_Priority;

	// NAME: あたり1 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti1_Priority;

	// NAME: あたり2 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti2_Priority;

	// NAME: あたり3 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti3_Priority;

	// NAME: ダメージレベル
	// DESC: 攻撃したとき、敵にどのダメージモーションを再生するか？を決める.
	uint8_t dmgLevel;

	// NAME: マップあたり参照
	// DESC: 攻撃あたりが、どのマップあたりを見るか？を設定
	uint8_t mapHitType;

	// NAME: ガードカット率無効化倍率
	// DESC: ガードカット率無効化倍率（－100～100）　→0のとき通常／－100で完全無効化／100で相手の防御効果倍増 　→－50とすれば、100％カットの盾が、50％カットになります 
	int8_t guardCutCancelRate;

	// NAME: 物理属性
	// DESC: 攻撃に設定する物理属性
	uint8_t atkAttribute;

	// NAME: 特殊属性
	// DESC: 攻撃に設定する特殊属性
	uint8_t spAttribute;

	// NAME: 攻撃属性[SFX/SE]
	// DESC: 攻撃時のSFX/SEを指定(属性、材質、サイズで1セット)
	uint8_t atkType;

	// NAME: 攻撃材質[SFX/SE]
	// DESC: 攻撃時のSFX/SEを指定(属性、材質、サイズで1セット)
	uint8_t atkMaterial;

	// NAME: ガード判定位置
	// DESC: ガード判定位置
	uint8_t guardRangeType;

	// NAME: 防御材質1[SE]
	// DESC: ガード時のSEに使用1
	uint16_t defSeMaterial1;

	// NAME: あたり発生源
	// DESC: 攻撃あたりのダミポリＩＤをどこから取ってくるか？を指定する
	uint8_t hitSourceType;

	// NAME: 投げ
	// DESC: 投げ情報に用いるフラグ
	uint8_t throwFlag;

	// NAME: ガード不可フラグ
	// DESC: 1の場合、ガード側のガードを無視して、ダメージレベルを入れる
	uint8_t disableGuard: 1;

	// NAME: スタミナ減らない
	// DESC: スタミナ攻撃力による「崩され判定」は行うが、実際にスタミナは減らさない
	uint8_t disableStaminaAttack: 1;

	// NAME: ヒット時特殊効果無効
	// DESC: 攻撃ヒットしたときの特殊効果を無効にします。SCEバグ対策
	uint8_t disableHitSpEffect: 1;

	// NAME: AIに空振り通知しない
	// DESC: AIに空振り通知しない
	uint8_t IgnoreNotifyMissSwingForAI: 1;

	// NAME: ＨＩＴ時にＳＦＸを何度も出すか
	// DESC: 敵専用：壁Hit時のSFXが連続で発生するか
	uint8_t repeatHitSfx: 1;

	// NAME: 矢攻撃か
	// DESC: 部位ダメージ判定に使用する。
	uint8_t isArrowAtk: 1;

	// NAME: 霊体攻撃か
	// DESC: 霊体ダメージ判定に使用。
	uint8_t isGhostAtk: 1;

	// NAME: 無敵を貫通するか
	// DESC: ステップ等の無敵効果を無視します、TAEの完全無敵は無視できません。
	uint8_t isDisableNoDamage: 1;

	// NAME: 攻撃強度[SFX]
	// DESC: 攻撃強度[SFX]
	int8_t atkPow_forSfx;

	// NAME: 攻撃方向[SFX]
	// DESC: 攻撃方向[SFX]
	int8_t atkDir_forSfx;

	// NAME: 対象：●敵対
	// DESC: 対象：●敵対
	uint8_t opposeTarget: 1;

	// NAME: 対象：○味方
	// DESC: 対象：○味方
	uint8_t friendlyTarget: 1;

	// NAME: 対象：自分
	// DESC: 対象：自分
	uint8_t selfTarget: 1;

	// NAME: 扉貫通チェックを行うか
	// DESC: 扉貫通チェックを行うかどうか。○の場合は扉越しの対象を攻撃できるかどうかの判定を行います。
	uint8_t isCheckDoorPenetration: 1;

	// NAME: 騎乗特攻か
	// DESC: 騎乗中の騎乗特攻対象に攻撃を当てた場合、SAダメージに倍率補正が掛かる
	uint8_t isVsRideAtk: 1;

	// NAME: 武器攻撃でも加算攻撃力を参照するか
	// DESC: 武器攻撃でも加算攻撃力を参照するか
	uint8_t isAddBaseAtk: 1;

	// NAME: 脅威度通知対象除外か
	// DESC: 脅威度通知対象除外か
	uint8_t excludeThreatLvNotify: 1;

	// NAME: pad1
	uint8_t pad1: 1;

	// NAME: Behavior用識別値1
	// DESC: Behavior用識別値：特大ダメージ遷移
	uint8_t atkBehaviorId;

	// NAME: 攻撃強度[SE]
	// DESC: 攻撃強度[SE]
	int8_t atkPow_forSe;

	// NAME: SA攻撃力
	// DESC: NPCのみ。SAブレイク計算式に利用すする値
	float atkSuperArmor;

	// NAME: デカールID1（直接指定）
	// DESC: デカールID1（直接指定）
	int32_t decalId1;

	// NAME: デカールID2（直接指定）
	// DESC: デカールID2（直接指定）
	int32_t decalId2;

	// NAME: 発生時AI音ID
	// DESC: 攻撃発生時に発生させるAI音のID
	int32_t AppearAiSoundId;

	// NAME: ヒット時AI音ID
	// DESC: ヒット時に発生させるAI音のID
	int32_t HitAiSoundId;

	// NAME: ヒット時振動効果(-1無効)
	// DESC: ヒット時の振動ID（-1無効）。次の3つのどれにも当てはまらない時の振動IDとなる
	int32_t HitRumbleId;

	// NAME: 先端ヒット時振動ID
	// DESC: 先端にヒットした時のヒット時振動ID（-1無効）
	int32_t HitRumbleIdByNormal;

	// NAME: 真ん中ヒット時振動ID
	// DESC: 真ん中にヒットした時のヒット時振動ID（-1無効）
	int32_t HitRumbleIdByMiddle;

	// NAME: 根本ヒット時振動ID
	// DESC: 根本にヒットした時のヒット時振動ID（-1無効）
	int32_t HitRumbleIdByRoot;

	// NAME: 剣閃SfxID_０
	// DESC: 剣閃SfxID_０(-1無効)
	int32_t traceSfxId0;

	// NAME: 根元剣閃ダミポリID_０
	// DESC: 剣閃根元ダミポリID_０(-1無効)
	int32_t traceDmyIdHead0;

	// NAME: 剣先剣閃ダミポリID_０
	// DESC: 剣閃剣先ダミポリID_０
	int32_t traceDmyIdTail0;

	// NAME: 剣閃SfxID_１
	// DESC: 剣閃SfxID_１(-1無効)
	int32_t traceSfxId1;

	// NAME: 根元剣閃ダミポリID_１
	// DESC: 剣閃根元ダミポリID_１(-1無効)
	int32_t traceDmyIdHead1;

	// NAME: 剣先剣閃ダミポリID_１
	// DESC: 剣閃剣先ダミポリID_１
	int32_t traceDmyIdTail1;

	// NAME: 剣閃SfxID_２
	// DESC: 剣閃SfxID_２(-1無効)
	int32_t traceSfxId2;

	// NAME: 根元剣閃ダミポリID_２
	// DESC: 剣閃根元ダミポリID_２(-1無効)
	int32_t traceDmyIdHead2;

	// NAME: 剣先剣閃ダミポリID_２
	// DESC: 剣閃剣先ダミポリID_２
	int32_t traceDmyIdTail2;

	// NAME: 剣閃SfxID_３
	// DESC: 剣閃SfxID_３(-1無効)
	int32_t traceSfxId3;

	// NAME: 根元剣閃ダミポリID_３
	// DESC: 剣閃根元ダミポリID_３(-1無効)
	int32_t traceDmyIdHead3;

	// NAME: 剣先剣閃ダミポリID_３
	// DESC: 剣閃剣先ダミポリID_３
	int32_t traceDmyIdTail3;

	// NAME: 剣閃SfxID_４
	// DESC: 剣閃SfxID_４(-1無効)
	int32_t traceSfxId4;

	// NAME: 根元剣閃ダミポリID_４
	// DESC: 剣閃根元ダミポリID_４(-1無効)
	int32_t traceDmyIdHead4;

	// NAME: 剣先剣閃ダミポリID_４
	// DESC: 剣閃剣先ダミポリID_４
	int32_t traceDmyIdTail4;

	// NAME: 剣閃SfxID_５
	// DESC: 剣閃SfxID_５(-1無効)
	int32_t traceSfxId5;

	// NAME: 根元剣閃ダミポリID_５
	// DESC: 剣閃根元ダミポリID_５(-1無効)
	int32_t traceDmyIdHead5;

	// NAME: 剣先剣閃ダミポリID_５
	// DESC: 剣閃剣先ダミポリID_５
	int32_t traceDmyIdTail5;

	// NAME: 剣閃SfxID_６
	// DESC: 剣閃SfxID_６(-1無効)
	int32_t traceSfxId6;

	// NAME: 根元剣閃ダミポリID_６
	// DESC: 剣閃根元ダミポリID_６(-1無効)
	int32_t traceDmyIdHead6;

	// NAME: 剣先剣閃ダミポリID_６
	// DESC: 剣閃剣先ダミポリID_６
	int32_t traceDmyIdTail6;

	// NAME: 剣閃SfxID_７
	// DESC: 剣閃SfxID_７(-1無効)
	int32_t traceSfxId7;

	// NAME: 根元剣閃ダミポリID_７
	// DESC: 剣閃根元ダミポリID_７(-1無効)
	int32_t traceDmyIdHead7;

	// NAME: 剣先剣閃ダミポリID_７
	// DESC: 剣閃剣先ダミポリID_７
	int32_t traceDmyIdTail7;

	// NAME: あたり4 半径
	// DESC: 球、カプセルの半径
	float hit4_Radius;

	// NAME: あたり5 半径
	// DESC: 球、カプセルの半径
	float hit5_Radius;

	// NAME: あたり6 半径
	// DESC: 球、カプセルの半径
	float hit6_Radius;

	// NAME: あたり7 半径
	// DESC: 球、カプセルの半径
	float hit7_Radius;

	// NAME: あたり8 半径
	// DESC: 球、カプセルの半径
	float hit8_Radius;

	// NAME: あたり9 半径
	// DESC: 球、カプセルの半径
	float hit9_Radius;

	// NAME: あたり10 半径
	// DESC: 球、カプセルの半径
	float hit10_Radius;

	// NAME: あたり11 半径
	// DESC: 球、カプセルの半径
	float hit11_Radius;

	// NAME: あたり12 半径
	// DESC: 球、カプセルの半径
	float hit12_Radius;

	// NAME: あたり13 半径
	// DESC: 球、カプセルの半径
	float hit13_Radius;

	// NAME: あたり14 半径
	// DESC: 球、カプセルの半径
	float hit14_Radius;

	// NAME: あたり15 半径
	// DESC: 球、カプセルの半径
	float hit15_Radius;

	// NAME: あたり4 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit4_DmyPoly1;

	// NAME: あたり5 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit5_DmyPoly1;

	// NAME: あたり6 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit6_DmyPoly1;

	// NAME: あたり7 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit7_DmyPoly1;

	// NAME: あたり8ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit8_DmyPoly1;

	// NAME: あたり9 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit9_DmyPoly1;

	// NAME: あたり10 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit10_DmyPoly1;

	// NAME: あたり11 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit11_DmyPoly1;

	// NAME: あたり12 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit12_DmyPoly1;

	// NAME: あたり13ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit13_DmyPoly1;

	// NAME: あたり14 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit14_DmyPoly1;

	// NAME: あたり15 ダミポリ1
	// DESC: 球、カプセル位置のダミポリ
	int16_t hit15_DmyPoly1;

	// NAME: あたり4 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit4_DmyPoly2;

	// NAME: あたり5ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit5_DmyPoly2;

	// NAME: あたり6ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit6_DmyPoly2;

	// NAME: あたり7ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit7_DmyPoly2;

	// NAME: あたり8 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit8_DmyPoly2;

	// NAME: あたり9ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit9_DmyPoly2;

	// NAME: あたり10 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit10_DmyPoly2;

	// NAME: あたり11 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit11_DmyPoly2;

	// NAME: あたり12 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit12_DmyPoly2;

	// NAME: あたり13 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit13_DmyPoly2;

	// NAME: あたり14 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit14_DmyPoly2;

	// NAME: あたり15 ダミポリ2
	// DESC: カプセルのもうひとつの点の位置ダミポリ。-1だと球になる
	int16_t hit15_DmyPoly2;

	// NAME: あたり4 部位
	// DESC: あたり部位
	uint8_t hit4_hitType;

	// NAME: あたり5 部位
	// DESC: あたり部位
	uint8_t hit5_hitType;

	// NAME: あたり6 部位
	// DESC: あたり部位
	uint8_t hit6_hitType;

	// NAME: あたり7 部位
	// DESC: あたり部位
	uint8_t hit7_hitType;

	// NAME: あたり8 部位
	// DESC: あたり部位
	uint8_t hit8_hitType;

	// NAME: あたり9 部位
	// DESC: あたり部位
	uint8_t hit9_hitType;

	// NAME: あたり10 部位
	// DESC: あたり部位
	uint8_t hit10_hitType;

	// NAME: あたり11 部位
	// DESC: あたり部位
	uint8_t hit11_hitType;

	// NAME: あたり12 部位
	// DESC: あたり部位
	uint8_t hit12_hitType;

	// NAME: あたり13 部位
	// DESC: あたり部位
	uint8_t hit13_hitType;

	// NAME: あたり14 部位
	// DESC: あたり部位
	uint8_t hit14_hitType;

	// NAME: あたり15 部位
	// DESC: あたり部位
	uint8_t hit15_hitType;

	// NAME: あたり4 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti4_Priority;

	// NAME: あたり5 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti5_Priority;

	// NAME: あたり6 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti6_Priority;

	// NAME: あたり7 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti7_Priority;

	// NAME: あたり8 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti8_Priority;

	// NAME: あたり9 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti9_Priority;

	// NAME: あたり10 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti10_Priority;

	// NAME: あたり11 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti11_Priority;

	// NAME: あたり12 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti12_Priority;

	// NAME: あたり13 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti13_Priority;

	// NAME: あたり14 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti14_Priority;

	// NAME: あたり15 優先順位
	// DESC: 優先度。同時に2つ以上のあたりがあたった場合、優先度が高いほうを採用する。
	uint8_t hti15_Priority;

	// NAME: 防御材質1[SFX]
	// DESC: ガード時のSFXに使用.1
	uint16_t defSfxMaterial1;

	// NAME: 防御材質2[SE]
	// DESC: ガード時のSEに使用2
	uint16_t defSeMaterial2;

	// NAME: 防御材質2[SFX]
	// DESC: ガード時のSFXに使用.2
	uint16_t defSfxMaterial2;

	// NAME: 闇攻撃力補正値
	// DESC: PCのみ。闇攻撃力に掛ける倍率（弓の場合は、飛び道具を補正）
	uint16_t atkDarkCorrection;

	// NAME: 闇攻撃力
	// DESC: NPCのみ。闇攻撃の追加ダメージ
	uint16_t atkDark;

	// NAME: pad
	// DESC: pad
	uint8_t pad5: 1;

	// NAME: 攻撃接触パリィ判定無効
	// DESC: 新パリィ制御を無効化するかどうかのフラグです。攻撃側のダメージが、防御側でパリィ状態のキャラに接触した場合にパリィされたと判定する処理。
	uint8_t isDisableParry: 1;

	// NAME: 両手持ち時攻撃力ボーナス無効か
	// DESC: 両手時の成長ステータス1.5倍適応を使わないようにする
	uint8_t isDisableBothHandsAtkBonus: 1;

	// NAME: 限定無敵（空中のみ）で無効化されるか
	// DESC: 「無敵を貫通するか」が◯の場合、この設定は無視されます
	uint8_t isInvalidatedByNoDamageInAir: 1;

	// NAME: pad1
	uint8_t pad2: 4;

	// NAME: ダメージレベル 対プレイヤー
	// DESC: プレイヤーに対するダメージレベル。“0(デフォルト)”であれば使わない。“0(デフォルト)”以外の値域の意味は、《ダメージレベル》と同じ。
	int8_t dmgLevel_vsPlayer;

	// NAME: 状態異常攻撃力倍率補正
	// DESC: 特殊効果の状態異常攻撃力に対して、倍率補正を行う。
	uint16_t statusAilmentAtkPowerCorrectRate;

	// NAME: 特殊効果攻撃力倍率補正（攻撃力ポイント）
	// DESC: 特殊効果の～～攻撃力[point]に対して、倍率補正を行う。
	uint16_t spEffectAtkPowerCorrectRate_byPoint;

	// NAME: 特殊効果攻撃力倍率補正（攻撃力倍率）
	// DESC: 特殊効果の～～攻撃力倍率に対して、倍率補正を行う。
	uint16_t spEffectAtkPowerCorrectRate_byRate;

	// NAME: 特殊効果攻撃力倍率補正（最終攻撃力倍率）
	// DESC: 特殊効果の攻撃側：～～ダメージ倍率に対して、倍率補正を行う。
	uint16_t spEffectAtkPowerCorrectRate_byDmg;

	// NAME: Behavior用識別値2
	// DESC: Behavior用識別値：特定の時だけダメージモーションを再生する 
	uint8_t atkBehaviorId_2;

	// NAME: 投げダメージ属性
	// DESC: 攻撃判定の投げダメージの属性。対応する特殊効果がかかるようになる。攻撃のATK_PATAM_THROWFLAG_TYPEが「2：投げ」の場合にのみ、機能を発揮する
	uint8_t throwDamageAttribute;

	// NAME: 特殊効果状態異常補正（攻撃力ポイント）
	// DESC: 特殊効果の「状態異常攻撃力倍率補正を適応するか」に対して、倍率補正を行う。
	uint16_t statusAilmentAtkPowerCorrectRate_byPoint;

	// NAME: 攻撃属性補正ID上書き
	// DESC: 攻撃属性を補正するパラメータのID上書き用
	int32_t overwriteAttackElementCorrectId;

	// NAME: デカール識別子1
	// DESC: デカール識別子1(3桁)
	int16_t decalBaseId1;

	// NAME: デカール識別子2
	// DESC: デカール識別子2(3桁)
	int16_t decalBaseId2;

	// NAME: 武器リゲイン量補正値
	// DESC: 武器リゲイン量補正値
	uint16_t wepRegainHpScale;

	// NAME: 攻撃リゲイン量
	// DESC: 攻撃リゲイン量
	uint16_t atkRegainHp;

	// NAME: リゲイン可能時間補正倍率
	// DESC: リゲイン可能時間補正倍率
	float regainableTimeScale;

	// NAME: リゲイン可能率補正倍率
	// DESC: リゲイン可能率補正倍率
	float regainableHpRateScale;

	// NAME: 同一攻撃判定ID
	// DESC: 同一攻撃判定ID
	int8_t regainableSlotId;

	// NAME: 特殊属性バリエーション値
	// DESC: 「特殊属性」と組み合わせて特殊属性によって発生するSFX、SEにバリエーションを持たせるための値(SEQ16473)
	uint8_t spAttributeVariationValue;

	// NAME: パリィ成立条件の正面角度オフセット
	// DESC: パリィ成立条件の【崩される側】の正面角度オフセット
	int16_t parryForwardOffset;

	// NAME: SA攻撃力補正値
	// DESC: PCのみ。武器に設定された【基本値】にかける補正値
	float atkSuperArmorCorrection;

	// NAME: 防御材質バリエーション値
	// DESC: ガード時に使用される「防御材質1or2」と組み合わせてダメージSFX、SEのバリエーションを持たせるための値。(SEQ16473)
	uint8_t defSfxMaterialVariationValue;

	// NAME: pad
	uint8_t pad4[19];
} ATK_PARAM_ST;

#endif
