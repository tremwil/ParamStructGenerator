/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CLEAR_COUNT_CORRECT_PARAM_ST_H
#define _PARAMDEF_CLEAR_COUNT_CORRECT_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CLEAR_COUNT_CORRECT_PARAM_ST {

	// NAME: 《最大HP倍率[%]》
	// DESC: 最大HP倍率[%]
	float MaxHpRate;

	// NAME: 《最大MP倍率[%]》
	// DESC: 最大MP倍率[%]
	float MaxMpRate;

	// NAME: 《最大スタミナ倍率[%]》
	// DESC: 最大スタミナ倍率[%]
	float MaxStaminaRate;

	// NAME: 《物理攻撃力倍率》
	// DESC: 物理攻撃力倍率
	float PhysicsAttackRate;

	// NAME: 《斬撃攻撃力倍率》
	// DESC: 斬撃攻撃力倍率
	float SlashAttackRate;

	// NAME: 《打撃攻撃力倍率》
	// DESC: 打撃攻撃力倍率
	float BlowAttackRate;

	// NAME: 《刺突攻撃力倍率》
	// DESC: 刺突攻撃力倍率
	float ThrustAttackRate;

	// NAME: 《無属性攻撃力倍率》
	// DESC: 無属性攻撃力倍率
	float NeturalAttackRate;

	// NAME: 《魔法攻撃力倍率》
	// DESC: 魔法攻撃力倍率
	float MagicAttackRate;

	// NAME: 《炎攻撃力倍率》
	// DESC: 炎攻撃力倍率
	float FireAttackRate;

	// NAME: 《電撃攻撃力倍率》
	// DESC: 電撃攻撃力倍率
	float ThunderAttackRate;

	// NAME: 《闇攻撃力倍率》
	// DESC: 闇攻撃力倍率
	float DarkAttackRate;

	// NAME: 《物理防御力倍率》
	// DESC: 物理防御力倍率
	float PhysicsDefenseRate;

	// NAME: 《魔法防御力倍率》
	// DESC: 魔法防御力倍率
	float MagicDefenseRate;

	// NAME: 《炎防御力倍率》
	// DESC: 炎防御力倍率
	float FireDefenseRate;

	// NAME: 《電撃防御力倍率》
	// DESC: 電撃防御力倍率
	float ThunderDefenseRate;

	// NAME: 《闇防御力倍率》
	// DESC: 闇防御力倍率
	float DarkDefenseRate;

	// NAME: 《スタミナ攻撃力倍率》
	// DESC: スタミナ攻撃力倍率
	float StaminaAttackRate;

	// NAME: 《所持ソウル率》
	// DESC: 所持ソウル率
	float SoulRate;

	// NAME: 《毒耐性変化倍率》
	// DESC: 毒耐性変化倍率
	float PoisionResistRate;

	// NAME: 《疫病耐性変化倍率》
	// DESC: 疫病耐性変化倍率
	float DiseaseResistRate;

	// NAME: 《出血耐性変化倍率》
	// DESC: 出血耐性変化倍率
	float BloodResistRate;

	// NAME: 《呪耐性変化倍率》
	// DESC: 呪耐性変化倍率
	float CurseResistRate;

	// NAME: 《冷気耐性変化倍率》
	// DESC: 冷気耐性変化倍率
	float FreezeResistRate;

	// NAME: 《出血ダメージ補正倍率》
	// DESC: 出血ダメージ補正倍率
	float BloodDamageRate;

	// NAME: 《SAダメージ補正倍率》
	// DESC: SAダメージ補正倍率
	float SuperArmorDamageRate;

	// NAME: 《冷気ダメージ補正倍率》
	// DESC: 冷気ダメージ補正倍率
	float FreezeDamageRate;

	// NAME: 《睡眠耐性変化倍率》
	// DESC: 睡眠耐性変化倍率
	float SleepResistRate;

	// NAME: 《発狂耐性変化倍率》
	// DESC: 発狂耐性変化倍率
	float MadnessResistRate;

	// NAME: 《睡眠ダメージ補正倍率》
	// DESC: 睡眠ダメージ補正倍率
	float SleepDamageRate;

	// NAME: 《発狂ダメージ補正倍率》
	// DESC: 発狂ダメージ補正倍率
	float MadnessDamageRate;

	// NAME: pad
	uint8_t pad1[4];
} CLEAR_COUNT_CORRECT_PARAM_ST;

#endif
