/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_EQUIP_PARAM_GOODS_ST_H
#define _PARAMDEF_EQUIP_PARAM_GOODS_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EQUIP_PARAM_GOODS_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: 呼び出しID0(デフォルト)
	// DESC: アイテムから呼び出されるID0(デフォルト)
	int32_t refId_default;

	// NAME: SFXバリエーションID
	// DESC: ＳＦＸのバリエーションを指定（TimeActEditorのＩＤと組み合わせて、ＳＦＸを特定するのに使用する）
	int32_t sfxVariationId;

	// NAME: 重量[kg]
	// DESC: 重量[kg]
	float weight;

	// NAME: 基本価格
	// DESC: 基本価格
	int32_t basicPrice;

	// NAME: 売却価格
	// DESC: 販売価格
	int32_t sellValue;

	// NAME: 行動ID
	// DESC: 道具を使ったときに発生する効果を設定します
	int32_t behaviorId;

	// NAME: 差し替えアイテムID
	// DESC: 差し替えるときのアイテムID
	int32_t replaceItemId;

	// NAME: ソートID
	// DESC: ソートID(-1:集めない)
	int32_t sortId;

	// NAME: 表示差し替え先アイテムID
	// DESC: 条件付きで表示を別の道具IDに差し替える。ゲームデータ側の道具IDは変わらない
	int32_t appearanceReplaceItemId;

	// NAME: YES/NOメッセージID
	// DESC: YesNoダイアログ表示時に使用するメッセージID
	int32_t yesNoDialogMessageId;

	// NAME: 使用可能条件_状態変化タイプ
	// DESC: 設定した状態変化タイプの特殊効果が掛かったときだけ、使用許可する
	uint16_t useEnableSpEffectType;

	// NAME: 壺グループID
	// DESC: 壺グループIDに0以上が設定されている「消費アイテム」は同じ壺グループIDの「壺」の個数だけ所持可能
	int8_t potGroupId;

	// NAME: PAD
	// DESC: 旧(巻物と紐づいた魔法ID)
	uint8_t pad[1];

	// NAME: アイコンID
	// DESC: メニュー用アイコンID
	uint16_t iconId;

	// NAME: モデルID
	// DESC: モデルID
	uint16_t modelId;

	// NAME: ショップレベル
	// DESC: お店で販売できるレベル
	int16_t shopLv;

	// NAME: コンプトロフィーSEQ番号
	// DESC: コンプリート系トロフィのSEQ番号
	int16_t compTrophySedId;

	// NAME: トロフィーSEQ番号
	// DESC: トロフィーのSEQ番号
	int16_t trophySeqId;

	// NAME: 最大所持数
	// DESC: 最大所持数
	int16_t maxNum;

	// NAME: 消費人間性
	// DESC: 消費人間性
	uint8_t consumeHeroPoint;

	// NAME: 技量オーバー開始値
	// DESC: 技量オーバー開始値
	uint8_t overDexterity;

	// NAME: 道具のタイプ
	// DESC: 道具の種類
	uint8_t goodsType;

	// NAME: IDカテゴリ
	// DESC: ↓のIDのカテゴリ[攻撃、飛び道具、特殊]
	uint8_t refCategory;

	// NAME: 特殊効果カテゴリ
	// DESC: スキルや、魔法、アイテムなどで、パラメータが変動する効果（エンチャントウェポンなど）があるので、│定した効果が、「武器攻撃のみをパワーアップする」といった効果に対応できるように行動ごとに設定するバリスタなど、設定の必要のないものは「なし」を設定する

	uint8_t spEffectCategory;

	// NAME: pad
	uint8_t pad3[1];

	// NAME: 道具使用時アニメ
	// DESC: 道具を使ったときに再生するアニメを設定します
	uint8_t goodsUseAnim;

	// NAME: メニュー開くか
	// DESC: アイテム使用時に開くメニュータイプ
	uint8_t opmeMenuType;

	// NAME: 使用禁止条件_特殊効果カテゴリ
	// DESC: かかっている特殊効果によって使用可能かを制御する為に指定
	uint8_t useLimitCategory;

	// NAME: 差し替えカテゴリ
	// DESC: 呼び出しIDに加算しる条件カテゴリ
	uint8_t replaceCategory;

	// NAME: リザーブ
	uint8_t reserve4[2];

	// NAME: 生存使用可
	// DESC: 生存プレイヤー使用可能か
	uint8_t enable_live: 1;

	// NAME: グレイ使用可
	// DESC: グレイゴースト使用可能か
	uint8_t enable_gray: 1;

	// NAME: 白使用可
	// DESC: ホワイトゴースト使用可能か
	uint8_t enable_white: 1;

	// NAME: 黒使用可
	// DESC: ブラックゴーストしよう可能か
	uint8_t enable_black: 1;

	// NAME: マルチプレイ可
	// DESC: マルチプレイ中に使用可能か？
	uint8_t enable_multi: 1;

	// NAME: オフラインで使用不可
	// DESC: オフライン中に使用不可か？
	uint8_t disable_offline: 1;

	// NAME: 装備可能
	// DESC: 装備できるかどうか
	uint8_t isEquip: 1;

	// NAME: 消耗品か
	// DESC: 使用時に消耗するか(所持数が減るか)
	uint8_t isConsume: 1;

	// NAME: 自動装備するか？
	// DESC: 拾った時に自動で装備するか？
	uint8_t isAutoEquip: 1;

	// NAME: 設置型アイテムか？
	// DESC: 設置型アイテムか？
	uint8_t isEstablishment: 1;

	// NAME: 1個しか持てないか
	// DESC: 1個しか持てないアイテムか
	uint8_t isOnlyOne: 1;

	// NAME: 捨てれるか
	// DESC: アイテムを捨てれるか？TRUE=捨てれる
	uint8_t isDiscard: 1;

	// NAME: 預けれるか
	// DESC: 倉庫に預けれるか
	uint8_t isDeposit: 1;

	// NAME: 右素手に使えないか
	// DESC: 右手武器が素手の場合に使用不可か
	uint8_t isDisableHand: 1;

	// NAME: 周回時削除するか
	// DESC: 周回時削除するか
	uint8_t isRemoveItem_forGameClear: 1;

	// NAME: 補充アイテムか
	// DESC: 補充可能アイテムを判別するのに使用します
	uint8_t isSuppleItem: 1;

	// NAME: 補充済みアイテムか
	// DESC: 補充済みアイテムを判別するのに使用します
	uint8_t isFullSuppleItem: 1;

	// NAME: エンチャントするか？
	// DESC: 武器にエンチャントするか？
	uint8_t isEnhance: 1;

	// NAME: 修理アイテムか
	// DESC: 修理するアイテムか？
	uint8_t isFixItem: 1;

	// NAME: マルチドロップ共有禁止か
	// DESC: マルチドロップ共有禁止か
	uint8_t disableMultiDropShare: 1;

	// NAME: 闘技場で使用禁止か
	// DESC: 闘技場で使用禁止か
	uint8_t disableUseAtColiseum: 1;

	// NAME: 闘技場以外で使用禁止か
	// DESC: 闘技場以外で使用禁止か
	uint8_t disableUseAtOutOfColiseum: 1;

	// NAME: 早いキャンセル可能か
	// DESC: 早いキャンセル可能か
	uint8_t isEnableFastUseItem: 1;

	// NAME: 特殊効果を反映するか
	// DESC: （能力値補正など）特殊効果を反映するか
	uint8_t isApplySpecialEffect: 1;

	// NAME: 個数増減を同期させるID
	// DESC: アイテムの個数が変更された際に、同じIDを設定したアイテムも一緒に変更を行います。 0：同期しない
	uint8_t syncNumVaryId;

	// NAME: 呼び出しID1
	// DESC: アイテムから呼び出されるID1
	int32_t refId_1;

	// NAME: 参照仮想武器ID
	// DESC: 道具使用時に参照する武器ID
	int32_t refVirtualWepId;

	// NAME: ベイグラント時アイテム抽選ID_マップ用
	// DESC: -1：ベイグラントなし 0：抽選なし 1～：抽選あり
	int32_t vagrantItemLotId;

	// NAME: ベイグラントボーナス敵ドロップアイテム抽選ID_マップ用
	// DESC: -1：ドロップなし 0：抽選なし 1～：抽選あり
	int32_t vagrantBonusEneDropItemLotId;

	// NAME: ベイグラントアイテム敵ドロップアイテム抽選ID_マップ用
	// DESC: -1：ドロップなし 0：抽選なし 1～：抽選あり
	int32_t vagrantItemEneDropItemLotId;

	// NAME: 手持ちSFXID
	// DESC: アイテムを使用しようとし、効果が発動するまでのSFXID
	int32_t castSfxId;

	// NAME: 発動SFXID
	// DESC: アイテムが発動したときのSFXID
	int32_t fireSfxId;

	// NAME: 効果SFXID
	// DESC: アイテムが発動後、効果中のSFXID
	int32_t effectSfxId;

	// NAME: 大ルーン発動中使用可
	// DESC: 大ルーン発動状態で使用可能か
	uint8_t enable_ActiveBigRune: 1;

	// NAME: 篝火ワープアイテムか
	// DESC: TRUEの時に状態変化タイプの「ワープ禁止」がかかっていればそのアイテムを使用不可にする機能を外す
	uint8_t isBonfireWarpItem: 1;

	// NAME: はしご中使用可能か
	// DESC: はしご中に使用可能なアイテムはここにチェックを入れます
	uint8_t enable_Ladder: 1;

	// NAME: マルチプレイ準備中可
	// DESC: セッション確率～初期同期の間でアイテムを使用できるかどうか
	uint8_t isUseMultiPlayPreparation: 1;

	// NAME: まとめて使えるか
	// DESC: まとめて使えるか
	uint8_t canMultiUse: 1;

	// NAME: 盾エンチャントか
	// DESC: 盾エンチャントか
	uint8_t isShieldEnchant: 1;

	// NAME: ワープ禁止対象か
	// DESC: これがTRUEの時に、状態変化タイプの「ワープ禁止」がかかっていればそのアイテムを使用不可にする 
	uint8_t isWarpProhibited: 1;

	// NAME: 切断ペナルティが発生しているときのみ使用可能
	// DESC: クライアント切断ペナルティが発生しているときのみ使用可能なアイテムかどうかを判断できるようにするためのフラグ
	uint8_t isUseMultiPenaltyOnly: 1;

	// NAME: 補充タイプ
	// DESC: 補充アイテム/補充済みアイテムを補充する際の補充タイプ。
	uint8_t suppleType;

	// NAME: 自動補充タイプ
	// DESC: 自動補充する/しないの可否およびデフォルト設定をコントロールします
	uint8_t autoReplenishType;

	// NAME: その場に置けるか
	// DESC: アイテムをその場に置けるか？TRUE=置ける
	uint8_t isDrop: 1;

	// NAME: 取得ログ表示条件
	// DESC: アイテム取得時にアイテム取得ログに表示するか（未入力: ○）
	uint8_t showLogCondType: 1;

	// NAME: 馬呼びアイテムか
	// DESC: 馬を召喚するアイテムか？馬が死亡、PCが馬禁止エリアに居る場合は使用不可
	uint8_t isSummonHorse: 1;

	// NAME: 取得ダイアログ表示条件
	// DESC: アイテム取得時にアイテム取得ダイアログに表示するか（未入力: newのみ）
	uint8_t showDialogCondType: 2;

	// NAME: ネムリ収集アイテムか
	// DESC: ネムリ収集アイテムか
	uint8_t isSleepCollectionItem: 1;

	// NAME: 騎乗中使用可能か
	// DESC: 騎乗中使用可能か
	uint8_t enableRiding: 1;

	// NAME: 非騎乗中使用禁止か
	// DESC: 非騎乗中使用禁止か
	uint8_t disableRiding: 1;

	// NAME: 倉庫所持数
	// DESC: 倉庫所持数
	int16_t maxRepositoryNum;

	// NAME: ソートアイテム種別ID
	// DESC: ソートアイテム種別ID。ソート「アイテム種別順」にて、同じIDは同じグループとしてまとめて表示されます
	uint8_t sortGroupId;

	// NAME: 攻撃禁止区域で使用できるか
	// DESC: 攻撃禁止区域で使用できるか
	uint8_t isUseNoAttackRegion: 1;

	// NAME: pad
	// DESC: （旧ログ用アイコン）
	uint8_t pad1: 7;

	// NAME: 販売価格
	// DESC: 販売価格
	int32_t saleValue;

	// NAME: レア度
	// DESC: アイテム取得ログで使うレア度
	uint8_t rarity;

	// NAME: バディアイテムか
	// DESC: バディアイテム用のアイテム使用制限がかかるかどうか
	uint8_t useLimitSummonBuddy;

	// NAME: 使用禁止条件_状態変化タイプ
	// DESC: かかっている特殊効果の状態変化タイプによって使用可能かを制御する為に指定
	uint16_t useLimitSpEffectType;

	// NAME: AI使用判断ID
	// DESC: AI使用判断ID
	int32_t aiUseJudgeId;

	// NAME: 消費MP
	// DESC: 消費MP
	int16_t consumeMP;

	// NAME: 消費HP
	// DESC: 消費HP
	int16_t consumeHP;

	// NAME: 強化先道具ID
	// DESC: 強化先道具ID
	int32_t reinforceGoodsId;

	// NAME: 強化時素材ID
	// DESC: 強化時素材ID
	int32_t reinforceMaterialId;

	// NAME: 強化価格
	// DESC: 強化価格
	int32_t reinforcePrice;

	// NAME: 誓約0使用レベル
	// DESC: 誓約0使用レベル
	int8_t useLevel_vowType0;

	// NAME: 誓約1使用レベル
	// DESC: 誓約1使用レベル
	int8_t useLevel_vowType1;

	// NAME: 誓約2使用レベル
	// DESC: 誓約2使用レベル
	int8_t useLevel_vowType2;

	// NAME: 誓約3使用レベル
	// DESC: 誓約3使用レベル
	int8_t useLevel_vowType3;

	// NAME: 誓約4使用レベル
	// DESC: 誓約4使用レベル
	int8_t useLevel_vowType4;

	// NAME: 誓約5使用レベル
	// DESC: 誓約5使用レベル
	int8_t useLevel_vowType5;

	// NAME: 誓約6使用レベル
	// DESC: 誓約6使用レベル
	int8_t useLevel_vowType6;

	// NAME: 誓約7使用レベル
	// DESC: 誓約7使用レベル
	int8_t useLevel_vowType7;

	// NAME: 誓約8使用レベル
	// DESC: 誓約8使用レベル
	int8_t useLevel_vowType8;

	// NAME: 誓約9使用レベル
	// DESC: 誓約9使用レベル
	int8_t useLevel_vowType9;

	// NAME: 誓約10使用レベル
	// DESC: 誓約10使用レベル
	int8_t useLevel_vowType10;

	// NAME: 誓約11使用レベル
	// DESC: 誓約11使用レベル
	int8_t useLevel_vowType11;

	// NAME: 誓約12使用レベル
	// DESC: 誓約12使用レベル
	int8_t useLevel_vowType12;

	// NAME: 誓約13使用レベル
	// DESC: 誓約13使用レベル
	int8_t useLevel_vowType13;

	// NAME: 誓約14使用レベル
	// DESC: 誓約14使用レベル
	int8_t useLevel_vowType14;

	// NAME: 誓約15使用レベル
	// DESC: 誓約15使用レベル
	int8_t useLevel_vowType15;

	// NAME: 使用適正レベル
	// DESC: 使用適正レベル
	uint16_t useLevel;

	// NAME: 予約領域
	// DESC: 予約領域
	uint8_t reserve5[2];

	// NAME: アイテム入手チュートリアル判定フラグID
	// DESC: 初めてアイテム入手した時のチュートリアル用のイベントフラグID。アイテム入手時にフラグON。
	uint32_t itemGetTutorialFlagId;

	// NAME: 予約領域
	// DESC: 予約領域
	uint8_t reserve3[8];
} EQUIP_PARAM_GOODS_ST;

#endif
