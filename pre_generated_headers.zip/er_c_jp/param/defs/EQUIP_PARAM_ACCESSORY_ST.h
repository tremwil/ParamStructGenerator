/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_EQUIP_PARAM_ACCESSORY_ST_H
#define _PARAMDEF_EQUIP_PARAM_ACCESSORY_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EQUIP_PARAM_ACCESSORY_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: 呼び出しID
	// DESC: 装飾品から呼び出すID
	int32_t refId;

	// NAME: SFXバリエーションID
	// DESC: ＳＦＸのバリエーションを指定（TimeActEditorのＩＤと組み合わせて、ＳＦＸを特定するのに使用する）
	int32_t sfxVariationId;

	// NAME: 重量[kg]
	// DESC: 重量[kg]
	float weight;

	// NAME: 行動ID
	// DESC: 行動ID(=Skill)
	int32_t behaviorId;

	// NAME: 基本価格
	// DESC: 基本価格
	int32_t basicPrice;

	// NAME: 売却価格
	// DESC: 販売価格
	int32_t sellValue;

	// NAME: sortID
	int32_t sortId;

	// NAME: QWCID
	int32_t qwcId;

	// NAME: 装備モデル番号
	// DESC: 装備モデルの番号
	uint16_t equipModelId;

	// NAME: アイコンID
	// DESC: メニューアイコンID
	uint16_t iconId;

	// NAME: ショップレベル
	// DESC: お店で販売できるレベル
	int16_t shopLv;

	// NAME: トロフィー
	int16_t trophySGradeId;

	// NAME: トロフィーSEQ番号
	// DESC: トロフィーのSEQ番号
	int16_t trophySeqId;

	// NAME: 装備モデル種別
	// DESC: 装備モデルの種別
	uint8_t equipModelCategory;

	// NAME: 装備モデル性別
	// DESC: 装備モデルの性別
	uint8_t equipModelGender;

	// NAME: 装飾カテゴリ
	// DESC: 防具のカテゴリ
	uint8_t accessoryCategory;

	// NAME: IDカテゴリ
	// DESC: ↓のIDのカテゴリ[攻撃、飛び道具、特殊]
	uint8_t refCategory;

	// NAME: 特殊効果カテゴリ
	// DESC: スキルや、魔法、アイテムなどで、パラメータが変動する効果（エンチャントウェポンなど）があるので、│定した効果が、「武器攻撃のみをパワーアップする」といった効果に対応できるように行動ごとに設定するバリスタなど、設定の必要のないものは「なし」を設定する

	uint8_t spEffectCategory;

	// NAME: ソートアイテム種別ID
	// DESC: ソートアイテム種別ID。ソート「アイテム種別順」にて、同じIDは同じグループとしてまとめて表示されます
	uint8_t sortGroupId;

	// NAME: ベイグラント時アイテム抽選ID_マップ用
	// DESC: -1：ベイグラントなし 0：抽選なし 1～：抽選あり
	int32_t vagrantItemLotId;

	// NAME: ベイグラントボーナス敵ドロップアイテム抽選ID_マップ用
	// DESC: -1：ドロップなし 0：抽選なし 1～：抽選あり
	int32_t vagrantBonusEneDropItemLotId;

	// NAME: ベイグラントアイテム敵ドロップアイテム抽選ID_マップ用
	// DESC: -1：ドロップなし 0：抽選なし 1～：抽選あり
	int32_t vagrantItemEneDropItemLotId;

	// NAME: 預けれるか
	// DESC: 倉庫へ預けれるか
	uint8_t isDeposit: 1;

	// NAME: 外すと壊れるか
	// DESC: 装備して外す時に壊れるか
	uint8_t isEquipOutBrake: 1;

	// NAME: マルチドロップ共有禁止か
	// DESC: マルチドロップ共有禁止か
	uint8_t disableMultiDropShare: 1;

	// NAME: 捨てれるか
	// DESC: アイテムを捨てれるか？TRUE=捨てれる
	uint8_t isDiscard: 1;

	// NAME: その場に置けるか
	// DESC: アイテムをその場に置けるか？TRUE=置ける
	uint8_t isDrop: 1;

	// NAME: 取得ログ表示条件
	// DESC: アイテム取得時にアイテム取得ログに表示するか（未入力: ○）
	uint8_t showLogCondType: 1;

	// NAME: 取得ダイアログ表示条件
	// DESC: アイテム取得時にアイテム取得ダイアログに表示するか（未入力: newのみ）
	uint8_t showDialogCondType: 2;

	// NAME: レア度
	// DESC: アイテム取得ログで使うレア度
	uint8_t rarity;

	// NAME: pad
	// DESC: （旧ログ用アイコンID）
	uint8_t pad2[2];

	// NAME: 販売価格
	// DESC: 販売価格
	int32_t saleValue;

	// NAME: 装着グループID
	// DESC: 同じグループの物は同時装備不可能
	int16_t accessoryGroup;

	// NAME: pad
	// DESC: pad
	uint8_t pad3[1];

	// NAME: コンプトロフィーSEQ番号
	// DESC: コンプリート系トロフィのSEQ番号
	int8_t compTrophySedId;

	// NAME: 常駐特殊効果ID1
	// DESC: 常駐特殊効果ID1
	int32_t residentSpEffectId1;

	// NAME: 常駐特殊効果ID2
	// DESC: 常駐特殊効果ID2
	int32_t residentSpEffectId2;

	// NAME: 常駐特殊効果ID3
	// DESC: 常駐特殊効果ID3
	int32_t residentSpEffectId3;

	// NAME: 常駐特殊効果ID4
	// DESC: 常駐特殊効果ID4
	int32_t residentSpEffectId4;

	// NAME: pad
	// DESC: pad
	uint8_t pad1[4];
} EQUIP_PARAM_ACCESSORY_ST;

#endif
