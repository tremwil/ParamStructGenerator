/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_GRASS_TYPE_PARAM_ST_H
#define _PARAMDEF_GRASS_TYPE_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GRASS_TYPE_PARAM_ST {

	// NAME: LOD距離
	uint16_t lodRange;

	// NAME: LOD0のクラスタータイプ
	uint8_t lod0ClusterType;

	// NAME: LOD1のクラスタータイプ
	uint8_t lod1ClusterType;

	// NAME: LOD2のクラスタータイプ
	uint8_t lod2ClusterType;

	// NAME: pad0
	uint8_t pad0[2];

	// NAME: 配置方法
	uint8_t distributionType;

	// NAME: 基本密度
	float baseDensity;

	// NAME: モデル名（０）
	wchar_t model0Name[16];

	// NAME: フラットテクスチャー名
	wchar_t flatTextureName[32];

	// NAME: ビルボードのテクスチャー名
	wchar_t billboardTextureName[32];

	// NAME: 傾きの影響（％）
	uint8_t normalInfluence;

	// NAME: 傾きの最大角度（度）
	uint8_t inclinationMax;

	// NAME: 傾斜角のランダム性（度）
	uint8_t inclinationJitter;

	// NAME: 幅のスケール範囲(min，％)
	uint8_t scaleBaseMin;

	// NAME: 幅のスケール範囲(max，％)
	uint8_t scaleBaseMax;

	// NAME: 高さのスケール範囲(min，％)
	uint8_t scaleHeightMin;

	// NAME: 高さのスケール範囲(max，％)
	uint8_t scaleHeightMax;

	// NAME: 乗算カラー１ (赤）
	uint8_t colorShade1_r;

	// NAME: 乗算カラー１ （緑）
	uint8_t colorShade1_g;

	// NAME: 乗算カラー １（青）
	uint8_t colorShade1_b;

	// NAME: 乗算カラー２ （赤）
	uint8_t colorShade2_r;

	// NAME: 乗算カラー２ （緑）
	uint8_t colorShade2_g;

	// NAME: 乗算カラー ２（青）
	uint8_t colorShade2_b;

	// NAME: 平面の分離
	uint8_t flatSplitType;

	// NAME: 平面の枚数
	uint8_t flatBladeCount;

	// NAME: 平面の角度（度）
	int8_t flatSlant;

	// NAME: 平面の距離
	float flatRadius;

	// NAME: 影を落とすか
	uint8_t castShadow;

	// NAME: 振幅(揺れの大きさ)
	uint8_t windAmplitude;

	// NAME: pad1
	uint8_t pad1[1];

	// NAME: 周期(速度)
	uint8_t windCycle;

	// NAME: 方向（度）
	// DESC: -1の場合はランダム
	float orientationAngle;

	// NAME: 方向の範囲（度）
	float orientationRange;

	// NAME: モデル間隔
	float spacing;

	// NAME: ディザリング
	uint8_t dithering;

	// NAME: pad2
	uint8_t pad[3];

	// NAME: Simpleモデル名
	wchar_t simpleModelName[16];

	// NAME: モデル名（１）
	wchar_t model1Name[16];
} GRASS_TYPE_PARAM_ST;

#endif
