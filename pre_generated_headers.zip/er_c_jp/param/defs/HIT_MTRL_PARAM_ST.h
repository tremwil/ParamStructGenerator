/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_HIT_MTRL_PARAM_ST_H
#define _PARAMDEF_HIT_MTRL_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _HIT_MTRL_PARAM_ST {

	// NAME: 音半径倍率
	// DESC: 1倍のときは普通。0にすると音半径が0になる（SEとSFXは無関係のゲーム的なパラメータ）
	float aiVolumeRate;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果0
	// DESC: キャラがヒットマテリアルを踏んだ時に、設定した特殊効果0が発揮される
	int32_t spEffectIdOnHit0;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果1
	// DESC: キャラがヒットマテリアルを踏んだ時に、設定した特殊効果1が発揮される
	int32_t spEffectIdOnHit1;

	// NAME: フットエフェクトの高さタイプ
	// DESC: フットエフェクトを発生させる高さ
	uint8_t footEffectHeightType: 2;

	// NAME: フットエフェクトの向きタイプ
	// DESC: フットエフェクトの発生向き
	uint8_t footEffectDirType: 2;

	// NAME: 地面の高さタイプ
	// DESC: 水面などアイテムを浮かせるとき用
	uint8_t floorHeightType: 2;

	// NAME: 落下ダメージ無効か
	// DESC: 落下ダメージを受けない床の場合に 1 を設定する
	uint8_t disableFallDamage: 1;

	// NAME: サウンド反響用硬い材質か？
	// DESC: サウンド反響用 硬い材質か？(0:やわらかい,1:かたい)
	uint8_t isHardnessForSoundReverb: 1;

	// NAME: 材質の固さタイプ
	// DESC: 材質の固さ。剛体のソフトコンタクト処理に使用。
	uint8_t hardnessType;

	// NAME: pad
	// DESC: pad
	uint8_t pad2[6];

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果0　2周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果0　2周目
	int32_t spEffectIdOnHit0_ClearCount_2;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果0　3周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果0　3周目
	int32_t spEffectIdOnHit0_ClearCount_3;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果0　4周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果0　4周目
	int32_t spEffectIdOnHit0_ClearCount_4;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果0　5周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果0　5周目
	int32_t spEffectIdOnHit0_ClearCount_5;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果0　6周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果0　6周目
	int32_t spEffectIdOnHit0_ClearCount_6;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果0　7周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果0　7周目
	int32_t spEffectIdOnHit0_ClearCount_7;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果0　8周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果0　8周目
	int32_t spEffectIdOnHit0_ClearCount_8;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果1　2周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果1　2周目
	int32_t spEffectIdOnHit1_ClearCount_2;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果1　3周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果1　3周目
	int32_t spEffectIdOnHit1_ClearCount_3;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果1　4周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果1　4周目
	int32_t spEffectIdOnHit1_ClearCount_4;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果1　5周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果1　5周目
	int32_t spEffectIdOnHit1_ClearCount_5;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果1　6周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果1　6周目
	int32_t spEffectIdOnHit1_ClearCount_6;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果1　7周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果1　7周目
	int32_t spEffectIdOnHit1_ClearCount_7;

	// NAME: ヒットマテリアルを踏んだ時にかかる特殊効果1　8周目
	// DESC: ヒットマテリアルを踏んだ時にかかる特殊効果1　8周目
	int32_t spEffectIdOnHit1_ClearCount_8;

	// NAME: ヒットマテリアル差し替え(雨)
	// DESC: 天候(雨)によるヒットマテリアル変更先ID(-1：変更を行なわない)
	int16_t replaceMateiralId_Rain;

	// NAME: pad
	// DESC: pad
	uint8_t pad4[2];

	// NAME: 濡れ特殊効果ID_00
	// DESC: 濡れ用特殊効果00
	int32_t spEffectId_forWet00;

	// NAME: 濡れ特殊効果ID_01
	// DESC: 濡れ用特殊効果01
	int32_t spEffectId_forWet01;

	// NAME: 濡れ特殊効果ID_02
	// DESC: 濡れ用特殊効果02
	int32_t spEffectId_forWet02;

	// NAME: 濡れ特殊効果ID_03
	// DESC: 濡れ用特殊効果03
	int32_t spEffectId_forWet03;

	// NAME: 濡れ特殊効果ID_04
	// DESC: 濡れ用特殊効果04
	int32_t spEffectId_forWet04;
} HIT_MTRL_PARAM_ST;

#endif
