/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_KNOCKBACK_PARAM_ST_H
#define _PARAMDEF_KNOCKBACK_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _KNOCKBACK_PARAM_ST {

	// NAME: 極小ダメージ_速度維持時間[s]
	// DESC: 極小ダメージアニメの時に使用される維持時間を設定
	float damage_Min_ContTime;

	// NAME: 小ダメージ_速度維持時間[s]
	// DESC: 小ダメージアニメの時に使用される維持時間を設定
	float damage_S_ContTime;

	// NAME: 中ダメージ_速度維持時間[s]
	// DESC: 中ダメージアニメの時に使用される維持時間を設定
	float damage_M_ContTime;

	// NAME: 大ダメージ_速度維持時間[s]
	// DESC: 大ダメージアニメの時に使用される維持時間を設定
	float damage_L_ContTime;

	// NAME: 小吹っ飛び_速度維持時間[s]
	// DESC: 小吹っ飛びダメージアニメの時に使用される維持時間を設定
	float damage_BlowS_ContTime;

	// NAME: 大吹っ飛び_速度維持時間[s]
	// DESC: 大吹っ飛びダメージアニメの時に使用される維持時間を設定
	float damage_BlowM_ContTime;

	// NAME: 叩きつけ_速度維持時間[s]
	// DESC: 叩きつけダメージアニメの時に使用される維持時間を設定
	float damage_Strike_ContTime;

	// NAME: 打ち上げ_速度維持時間[s]
	// DESC: 打ち上げダメージアニメの時に使用される維持時間を設定
	float damage_Uppercut_ContTime;

	// NAME: プッシュ_速度維持時間[s]
	// DESC: プッシュダメージアニメの時に使用される維持時間を設定
	float damage_Push_ContTime;

	// NAME: ブレス_速度維持時間[s]
	// DESC: ブレスダメージアニメの時に使用される維持時間を設定
	float damage_Breath_ContTime;

	// NAME: ヘッドショット_速度維持時間[s]
	// DESC: ヘッドショットダメージアニメの時に使用される維持時間を設定
	float damage_HeadShot_ContTime;

	// NAME: ガード受け小_速度維持時間[s]
	// DESC: ガード受け小アニメの時に使用される維持時間を設定
	float guard_S_ContTime;

	// NAME: ガード受け大_速度維持時間[s]
	// DESC: ガード受け大アニメの時に使用される維持時間を設定
	float guard_L_ContTime;

	// NAME: ガード受け特大_速度維持時間[s]
	// DESC: ガード受け特大アニメの時に使用される維持時間を設定
	float guard_LL_ContTime;

	// NAME: ガードくずされ_速度維持時間[s]
	// DESC: ガードくずされアニメの時に仕様される維持時間を設定
	float guardBrake_ContTime;

	// NAME: 極小ダメージ_減速時間[s]
	// DESC: 極小ダメージアニメの時に使用される減速時間を設定
	float damage_Min_DecTime;

	// NAME: 小ダメージ_減速時間[s]
	// DESC: 小ダメージアニメの時に使用される減速時間を設定
	float damage_S_DecTime;

	// NAME: 中ダメージ_減速時間[s]
	// DESC: 中ダメージアニメの時に使用される減速時間を設定
	float damage_M_DecTime;

	// NAME: 大ダメージ_減速時間[s]
	// DESC: 大ダメージアニメの時に使用される減速時間を設定
	float damage_L_DecTime;

	// NAME: 小吹っ飛び_減速時間[s]
	// DESC: 小吹っ飛びダメージアニメの時に使用される減速時間を設定
	float damage_BlowS_DecTime;

	// NAME: 大吹っ飛び_減速時間[s]
	// DESC: 大吹っ飛びダメージアニメの時に使用される減速時間を設定
	float damage_BlowM_DecTime;

	// NAME: 叩きつけ_減速時間[s]
	// DESC: 叩きつけダメージアニメの時に使用される減速時間を設定
	float damage_Strike_DecTime;

	// NAME: 打ち上げ_減速時間[s]
	// DESC: 打ち上げダメージアニメの時に使用される減速時間を設定
	float damage_Uppercut_DecTime;

	// NAME: プッシュ_減速時間[s]
	// DESC: プッシュダメージアニメの時に使用される減速時間を設定
	float damage_Push_DecTime;

	// NAME: ブレス_減速時間[s]
	// DESC: ブレスダメージアニメの時に使用される減速時間を設定
	float damage_Breath_DecTime;

	// NAME: ヘッドショット_減速時間[s]
	// DESC: ヘッドショットダメージアニメの時に使用される減速時間を設定
	float damage_HeadShot_DecTime;

	// NAME: ガード受け小_減速時間[s]
	// DESC: ガード受け小アニメの時に使用される減速時間を設定
	float guard_S_DecTime;

	// NAME: ガード受け大_減速時間[s]
	// DESC: ガード受け大アニメの時に使用される減速時間を設定
	float guard_L_DecTime;

	// NAME: ガード受け特大_減速時間[s]
	// DESC: ガード受け特大アニメの時に使用される減速時間を設定
	float guard_LL_DecTime;

	// NAME: ガードくずされ_減速時間[s]
	// DESC: ガードくずされアニメの時に仕様される減速時間を設定
	float guardBrake_DecTime;

	// NAME: pading
	uint8_t pad[8];
} KNOCKBACK_PARAM_ST;

#endif
