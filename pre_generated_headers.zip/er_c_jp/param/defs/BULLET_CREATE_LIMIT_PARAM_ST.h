/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_BULLET_CREATE_LIMIT_PARAM_ST_H
#define _PARAMDEF_BULLET_CREATE_LIMIT_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BULLET_CREATE_LIMIT_PARAM_ST {

	// NAME: グループ内上限弾数
	// DESC: 同一グループ内での作成上限数
	uint8_t limitNum_byGroup;

	// NAME: オーナー毎に制限するか
	// DESC: オーナー毎に制限するか
	uint8_t isLimitEachOwner: 1;

	// NAME: パディング
	// DESC: pad2
	uint8_t pad2: 7;

	// NAME: パディング
	// DESC: pad3
	uint8_t pad[30];
} BULLET_CREATE_LIMIT_PARAM_ST;

#endif
