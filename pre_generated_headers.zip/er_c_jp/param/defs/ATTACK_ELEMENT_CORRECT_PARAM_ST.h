/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_ATTACK_ELEMENT_CORRECT_PARAM_ST_H
#define _PARAMDEF_ATTACK_ELEMENT_CORRECT_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ATTACK_ELEMENT_CORRECT_PARAM_ST {

	// NAME: 筋力補正するか（物理）
	uint8_t isStrengthCorrect_byPhysics: 1;

	// NAME: 技量補正するか（物理）
	uint8_t isDexterityCorrect_byPhysics: 1;

	// NAME: 理力補正するか（物理）
	uint8_t isMagicCorrect_byPhysics: 1;

	// NAME: 信仰補正するか（物理）
	uint8_t isFaithCorrect_byPhysics: 1;

	// NAME: 運補正するか（物理）
	uint8_t isLuckCorrect_byPhysics: 1;

	// NAME: 筋力補正するか（魔法）
	uint8_t isStrengthCorrect_byMagic: 1;

	// NAME: 技量補正するか（魔法）
	uint8_t isDexterityCorrect_byMagic: 1;

	// NAME: 理力補正するか（魔法）
	uint8_t isMagicCorrect_byMagic: 1;

	// NAME: 信仰補正するか（魔法）
	uint8_t isFaithCorrect_byMagic: 1;

	// NAME: 運補正するか（魔法）
	uint8_t isLuckCorrect_byMagic: 1;

	// NAME: 筋力補正するか（炎）
	uint8_t isStrengthCorrect_byFire: 1;

	// NAME: 技量補正するか（炎）
	uint8_t isDexterityCorrect_byFire: 1;

	// NAME: 理力補正するか（炎）
	uint8_t isMagicCorrect_byFire: 1;

	// NAME: 信仰補正するか（炎）
	uint8_t isFaithCorrect_byFire: 1;

	// NAME: 運補正するか（炎）
	uint8_t isLuckCorrect_byFire: 1;

	// NAME: 筋力補正するか（雷）
	uint8_t isStrengthCorrect_byThunder: 1;

	// NAME: 技量補正するか（雷）
	uint8_t isDexterityCorrect_byThunder: 1;

	// NAME: 理力補正するか（雷）
	uint8_t isMagicCorrect_byThunder: 1;

	// NAME: 信仰補正するか（雷）
	uint8_t isFaithCorrect_byThunder: 1;

	// NAME: 運補正するか（雷）
	uint8_t isLuckCorrect_byThunder: 1;

	// NAME: 筋力補正するか（闇）
	uint8_t isStrengthCorrect_byDark: 1;

	// NAME: 技量補正するか（闇）
	uint8_t isDexterityCorrect_byDark: 1;

	// NAME: 理力補正するか（闇）
	uint8_t isMagicCorrect_byDark: 1;

	// NAME: 信仰補正するか（闇）
	uint8_t isFaithCorrect_byDark: 1;

	// NAME: 運補正するか（闇）
	uint8_t isLuckCorrect_byDark: 1;

	// NAME: パディング
	uint8_t pad1: 7;

	// NAME: 筋力補正値上書き（物理）
	int16_t overwriteStrengthCorrectRate_byPhysics;

	// NAME: 技量補正値上書き（物理）
	int16_t overwriteDexterityCorrectRate_byPhysics;

	// NAME: 理力補正値上書き（物理）
	int16_t overwriteMagicCorrectRate_byPhysics;

	// NAME: 信仰補正値上書き（物理）
	int16_t overwriteFaithCorrectRate_byPhysics;

	// NAME: 運補正値上書き（物理）
	int16_t overwriteLuckCorrectRate_byPhysics;

	// NAME: 筋力補正値上書き（魔法）
	int16_t overwriteStrengthCorrectRate_byMagic;

	// NAME: 技量補正値上書き（魔法）
	int16_t overwriteDexterityCorrectRate_byMagic;

	// NAME: 理力補正値上書き（魔法）
	int16_t overwriteMagicCorrectRate_byMagic;

	// NAME: 信仰補正値上書き（魔法）
	int16_t overwriteFaithCorrectRate_byMagic;

	// NAME: 運補正値上書き（魔法）
	int16_t overwriteLuckCorrectRate_byMagic;

	// NAME: 筋力補正値上書き（炎）
	int16_t overwriteStrengthCorrectRate_byFire;

	// NAME: 技量補正値上書き（炎）
	int16_t overwriteDexterityCorrectRate_byFire;

	// NAME: 理力補正値上書き（炎）
	int16_t overwriteMagicCorrectRate_byFire;

	// NAME: 信仰補正値上書き（炎）
	int16_t overwriteFaithCorrectRate_byFire;

	// NAME: 運補正値上書き（炎）
	int16_t overwriteLuckCorrectRate_byFire;

	// NAME: 筋力補正値上書き（雷）
	int16_t overwriteStrengthCorrectRate_byThunder;

	// NAME: 技量補正値上書き（雷）
	int16_t overwriteDexterityCorrectRate_byThunder;

	// NAME: 理力補正値上書き（雷）
	int16_t overwriteMagicCorrectRate_byThunder;

	// NAME: 信仰補正値上書き（雷）
	int16_t overwriteFaithCorrectRate_byThunder;

	// NAME: 運補正値上書き（雷）
	int16_t overwriteLuckCorrectRate_byThunder;

	// NAME: 筋力補正値上書き（闇）
	int16_t overwriteStrengthCorrectRate_byDark;

	// NAME: 技量補正値上書き（闇）
	int16_t overwriteDexterityCorrectRate_byDark;

	// NAME: 理力補正値上書き（闇）
	int16_t overwriteMagicCorrectRate_byDark;

	// NAME: 信仰補正値上書き（闇）
	int16_t overwriteFaithCorrectRate_byDark;

	// NAME: 運補正値上書き（闇）
	int16_t overwriteLuckCorrectRate_byDark;

	// NAME: 筋力補正値影響率（物理）
	// DESC: 補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byPhysics;

	// NAME: 技量補正値影響率（物理）
	// DESC: 補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byPhysics;

	// NAME: 理力補正値影響率（物理）
	// DESC: 補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byPhysics;

	// NAME: 信仰補正値影響率（物理）
	// DESC: 補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byPhysics;

	// NAME: 運補正値影響率（物理）
	// DESC: 補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byPhysics;

	// NAME: 筋力補正値影響率（魔法）
	// DESC: 補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byMagic;

	// NAME: 技量補正値影響率（魔法）
	// DESC: 補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byMagic;

	// NAME: 理力補正値影響率（魔法）
	// DESC: 補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byMagic;

	// NAME: 信仰補正値影響率（魔法）
	// DESC: 補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byMagic;

	// NAME: 運補正値影響率（魔法）
	// DESC: 補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byMagic;

	// NAME: 筋力補正値影響率（炎）
	// DESC: 補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byFire;

	// NAME: 技量補正値影響率（炎）
	// DESC: 補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byFire;

	// NAME: 理力補正値影響率（炎）
	// DESC: 補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byFire;

	// NAME: 信仰補正値影響率（炎）
	// DESC: 補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byFire;

	// NAME: 運補正値影響率（炎）
	// DESC: 補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byFire;

	// NAME: 筋力補正値影響率（雷）
	// DESC: 補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byThunder;

	// NAME: 技量補正値影響率（雷）
	// DESC: 補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byThunder;

	// NAME: 理力補正値影響率（雷）
	// DESC: 補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byThunder;

	// NAME: 信仰補正値影響率（雷）
	// DESC: 補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byThunder;

	// NAME: 運補正値影響率（雷）
	// DESC: 補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byThunder;

	// NAME: 筋力補正値影響率（闇）
	// DESC: 補正率の影響割合。
	int16_t InfluenceStrengthCorrectRate_byDark;

	// NAME: 技量補正値影響率（闇）
	// DESC: 補正率の影響割合。
	int16_t InfluenceDexterityCorrectRate_byDark;

	// NAME: 理力補正値影響率（闇）
	// DESC: 補正率の影響割合。
	int16_t InfluenceMagicCorrectRate_byDark;

	// NAME: 信仰補正値影響率（闇）
	// DESC: 補正率の影響割合。
	int16_t InfluenceFaithCorrectRate_byDark;

	// NAME: 運補正値影響率（闇）
	// DESC: 補正率の影響割合。
	int16_t InfluenceLuckCorrectRate_byDark;

	// NAME: パディング
	uint8_t pad2[24];
} ATTACK_ELEMENT_CORRECT_PARAM_ST;

#endif
