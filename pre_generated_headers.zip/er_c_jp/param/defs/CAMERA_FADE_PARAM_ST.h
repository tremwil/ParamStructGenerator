/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CAMERA_FADE_PARAM_ST_H
#define _PARAMDEF_CAMERA_FADE_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CAMERA_FADE_PARAM_ST {

	// NAME: 透明になりきる距離(m)
	// DESC: Nearフェード最小距離(m) : α = 0になる距離
	float NearMinDist;

	// NAME: 透明になり始める距離(m)
	// DESC: Nearフェード最大距離(m) : α = MiddelAlphaとなる間の開始距離
	float NearMaxDist;

	// NAME: 半透明状態になりきる距離(m)
	// DESC: Farフェードの最小距離(m) : α = MiddleAlphaとなる間の終了距離
	float FarMinDist;

	// NAME: 半透明状態になり始める距離(m)
	// DESC: Farフェードの最大距離(m) : α = 1になる距離
	float FarMaxDist;

	// NAME: 半透明状態の濃さ(α値)
	// DESC: 中間のα値
	float MiddleAlpha;

	// NAME: ダミー
	uint8_t dummy[12];
} CAMERA_FADE_PARAM_ST;

#endif
