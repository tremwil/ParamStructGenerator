/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_BUDGET_PARAM_ST_H
#define _PARAMDEF_BUDGET_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BUDGET_PARAM_ST {

	// NAME: VRAM:ALL
	// DESC: VRAM:ALL(単位はMB)
	float vram_all;

	// NAME: VRAM:マップ/オブジェ テクスチャ
	// DESC: VRAM:マップ/オブジェ テクスチャ(単位はMB)
	float vram_mapobj_tex;

	// NAME: VRAM:マップ/オブジェ モデル
	// DESC: VRAM:マップ/オブジェ モデル(単位はMB)
	float vram_mapobj_mdl;

	// NAME: VRAM:マップ
	// DESC: VRAM:マップ(単位はMB)
	float vram_map;

	// NAME: VRAM:キャラ
	// DESC: VRAM:キャラ(単位はMB)
	float vram_chr;

	// NAME: VRAM:パーツ
	// DESC: VRAM:パーツ(単位はMB)
	float vram_parts;

	// NAME: VRAM:SFX
	// DESC: VRAM:SFX(単位はMB)
	float vram_sfx;

	// NAME: VRAM:キャラ テクスチャ
	// DESC: VRAM:キャラ テクスチャ(単位はMB)
	float vram_chr_tex;

	// NAME: VRAM:キャラ モデル
	// DESC: VRAM:キャラ モデル(単位はMB)
	float vram_chr_mdl;

	// NAME: VRAM:パーツ テクスチャ
	// DESC: VRAM:パーツ テクスチャ(単位はMB)
	float vram_parts_tex;

	// NAME: VRAM:パーツ モデル
	// DESC: VRAM:パーツ モデル(単位はMB)
	float vram_parts_mdl;

	// NAME: VRAM:SFX テクスチャ
	// DESC: VRAM:SFX テクスチャ(単位はMB)
	float vram_sfx_tex;

	// NAME: VRAM:SFX モデル
	// DESC: VRAM:SFX モデル(単位はMB)
	float vram_sfx_mdl;

	// NAME: VRAM:Gi
	// DESC: VRAM:Gi(単位はMB)
	float vram_gi;

	// NAME: VRAM:メニュー
	// DESC: VRAM:メニュー(単位はMB)
	float vram_menu_tex;

	// NAME: VRAM:DECAL_RT
	// DESC: VRAM:DECALレンダーターゲット(単位はMB)
	float vram_decal_rt;

	// NAME: VRAM:DECAL
	// DESC: VRAM:DECAL(単位はMB)
	float vram_decal;

	// NAME: 予約領域
	uint8_t reserve_0[4];

	// NAME: VRAM:その他 テクスチャ
	// DESC: VRAM:その他 モデル(単位はMB)
	float vram_other_tex;

	// NAME: VRAM:その他 モデル
	// DESC: VRAM:その他 テクスチャ(単位はMB)
	float vram_other_mdl;

	// NAME: HAVOK:アニメ
	// DESC: HAVOK:アニメ(単位はMB)
	float havok_anim;

	// NAME: HAVOK:配置
	// DESC: HAVOK:配置(単位はMB)
	float havok_ins;

	// NAME: HAVOK:ヒット
	// DESC: HAVOK:ヒット(単位はMB)
	float havok_hit;

	// NAME: VRAM:その他
	// DESC: VRAM:その他(単位はMB)
	float vram_other;

	// NAME: VRAM:合算値
	// DESC: VRAM:合算値(単位はMB)
	float vram_detail_all;

	// NAME: VRAM:キャラ&パーツ
	// DESC: VRAM:キャラとパーツ合算値(単位はMB)
	float vram_chr_and_parts;

	// NAME: HAVOK:ナビメッシュ
	// DESC: HAVOK:ナビメッシュ(単位はMB)
	float havok_navimesh;

	// NAME: 予約領域
	// DESC: 予約領域
	uint8_t reserve_1[24];
} BUDGET_PARAM_ST;

#endif
