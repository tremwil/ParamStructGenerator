/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CHARMAKEMENU_LISTITEM_PARAM_ST_H
#define _PARAMDEF_CHARMAKEMENU_LISTITEM_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CHARMAKEMENU_LISTITEM_PARAM_ST {

	// NAME: 値
	// DESC: プログラム側に扱う値。1つのグループ内で通し番号にする
	int32_t value;

	// NAME: 項目テキストID
	// DESC: 表示するテキストのID
	int32_t captionId;

	// NAME: アイコンID
	// DESC: 表示するアイコンのID
	uint8_t iconId;

	// NAME: 予約
	uint8_t reserved[7];
} CHARMAKEMENU_LISTITEM_PARAM_ST;

#endif
