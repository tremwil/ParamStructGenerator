/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_HIT_EFFECT_SFX_PARAM_ST_H
#define _PARAMDEF_HIT_EFFECT_SFX_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _HIT_EFFECT_SFX_PARAM_ST {

	// NAME: 斬撃：標準
	// DESC: 斬撃：標準
	int32_t Slash_Normal;

	// NAME: 斬撃：小
	// DESC: 斬撃：小
	int32_t Slash_S;

	// NAME: 斬撃：大
	// DESC: 斬撃：大
	int32_t Slash_L;

	// NAME: 斬撃：指定1
	// DESC: 斬撃：指定1
	int32_t Slash_Specific1;

	// NAME: 斬撃：指定2
	// DESC: 斬撃：指定2
	int32_t Slash_Specific2;

	// NAME: 打撃：標準
	// DESC: 打撃：標準
	int32_t Blow_Normal;

	// NAME: 打撃：小
	// DESC: 打撃：小
	int32_t Blow_S;

	// NAME: 打撃：大
	// DESC: 打撃：大
	int32_t Blow_L;

	// NAME: 打撃：指定1
	// DESC: 打撃：指定1
	int32_t Blow_Specific1;

	// NAME: 打撃：指定2
	// DESC: 打撃：指定2
	int32_t Blow_Specific2;

	// NAME: 刺突：標準
	// DESC: 刺突：標準
	int32_t Thrust_Normal;

	// NAME: 刺突：小
	// DESC: 刺突：小
	int32_t Thrust_S;

	// NAME: 刺突：大
	// DESC: 刺突：大
	int32_t Thrust_L;

	// NAME: 刺突：指定1
	// DESC: 刺突：指定1
	int32_t Thrust_Specific1;

	// NAME: 刺突：指定2
	// DESC: 刺突：指定2
	int32_t Thrust_Specific2;

	// NAME: 無属性：標準
	// DESC: 無属性：標準
	int32_t Neutral_Normal;

	// NAME: 無属性：小
	// DESC: 無属性：小
	int32_t Neutral_S;

	// NAME: 無属性：大
	// DESC: 無属性：大
	int32_t Neutral_L;

	// NAME: 無属性：指定1
	// DESC: 無属性：指定1
	int32_t Neutral_Specific1;

	// NAME: 無属性：指定2
	// DESC: 無属性：指定2
	int32_t Neutral_Specific2;
} HIT_EFFECT_SFX_PARAM_ST;

#endif
