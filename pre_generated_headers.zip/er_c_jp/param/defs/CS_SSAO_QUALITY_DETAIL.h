/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_SSAO_QUALITY_DETAIL_H
#define _PARAMDEF_CS_SSAO_QUALITY_DETAIL_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_SSAO_QUALITY_DETAIL {

	// NAME: SSAO有効
	// DESC: SSAO有効
	uint8_t enabled;

	// NAME: リプロジェクション有効
	// DESC: リプロジェクション強制有効の時は、PreventGhostも有効になる
	uint8_t cs_reprojEnabledType;

	// NAME: バイラテラルアップスケール有効
	// DESC: バイラテラルアップスケール有効
	uint8_t cs_upScaleEnabledType;

	// NAME: 法線使用有効
	// DESC: 法線使用有効
	uint8_t cs_useNormalEnabledType;

	// NAME: dmy
	uint8_t dmy[1];
} CS_SSAO_QUALITY_DETAIL;

#endif
