/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_GRASS_LOD_RANGE_PARAM_ST_H
#define _PARAMDEF_GRASS_LOD_RANGE_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GRASS_LOD_RANGE_PARAM_ST {

	// NAME: LOD0 - 距離
	float LOD0_range;

	// NAME: LOD0 - 遊び
	float LOD0_play;

	// NAME: LOD１ - 距離
	float LOD1_range;

	// NAME: LOD１ - 遊び
	float LOD1_play;

	// NAME: LOD２ - 距離
	float LOD2_range;

	// NAME: LOD２ - 遊び
	float LOD2_play;
} GRASS_LOD_RANGE_PARAM_ST;

#endif
