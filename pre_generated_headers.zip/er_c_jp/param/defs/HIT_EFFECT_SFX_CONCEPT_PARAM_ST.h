/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_HIT_EFFECT_SFX_CONCEPT_PARAM_ST_H
#define _PARAMDEF_HIT_EFFECT_SFX_CONCEPT_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _HIT_EFFECT_SFX_CONCEPT_PARAM_ST {

	// NAME: 鉄製：概念１
	// DESC: 鉄製：概念１
	int16_t atkIron_1;

	// NAME: 鉄製：概念２
	// DESC: 鉄製：概念２
	int16_t atkIron_2;

	// NAME: 革製：概念１
	// DESC: 革：概念１
	int16_t atkLeather_1;

	// NAME: 革製：概念２
	// DESC: 革：概念２
	int16_t atkLeather_2;

	// NAME: 木製：概念１
	// DESC: 木製：概念１
	int16_t atkWood_1;

	// NAME: 木製：概念２
	// DESC: 木製：概念２
	int16_t atkWood_2;

	// NAME: 肉：概念１
	// DESC: 肉：概念１
	int16_t atkBody_1;

	// NAME: 肉：概念２
	// DESC: 肉：概念２
	int16_t atkBody_2;

	// NAME: 石製：概念１
	// DESC: 蝕：概念１
	int16_t atkStone_1;

	// NAME: 石製：概念２
	// DESC: 蝕：概念２
	int16_t atkStone_2;

	// NAME: pad
	uint8_t pad[4];

	// NAME: なし：概念１
	// DESC: なし：概念１
	int16_t atkNone_1;

	// NAME: なし：概念２
	// DESC: なし：概念２
	int16_t atkNone_2;

	// NAME: 予約領域
	uint8_t reserve[52];
} HIT_EFFECT_SFX_CONCEPT_PARAM_ST;

#endif
