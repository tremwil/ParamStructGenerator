/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_BEHAVIOR_PARAM_ST_H
#define _PARAMDEF_BEHAVIOR_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BEHAVIOR_PARAM_ST {

	// NAME: 行動バリエーションID
	// DESC: 攻撃パラメータ用のIDを算出する際に使用します。実機上では直接使用しません。
	int32_t variationId;

	// NAME: 行動判定ID
	// DESC: 攻撃パラメータ用のIDを算出する際に使用します。このIDはTimeActEditorで入力される行動判定IDと一致させます。実機上では直接使用しません。
	int32_t behaviorJudgeId;

	// NAME: IDルール用
	// DESC: ID算出ルール用
	uint8_t ezStateBehaviorType_old;

	// NAME: 参照IDタイプ
	// DESC: 参照IDを間違わないように指定.
	uint8_t refType;

	// NAME: pad
	uint8_t pad2[2];

	// NAME: 参照ID
	// DESC: 攻撃力、飛び道具、特殊効果パラメータのID、refTypeによって使い分けられる。
	int32_t refId;

	// NAME: 消費SA
	// DESC: 行動時の消費SA量を設定.
	float consumeSA;

	// NAME: 消費スタミナ
	// DESC: 行動時の消費スタミナ量を設定.
	int32_t stamina;

	// NAME: 武器耐久度消費（飛び道具時のみ）
	// DESC: 行動時の消費武器耐久度を設定.
	int32_t consumeDurability;

	// NAME: カテゴリ
	// DESC: スキルや、魔法、アイテムなどで、パラメータが変動する効果（エンチャントウェポンなど）があるので、│定した効果が、「武器攻撃のみをパワーアップする」といった効果に対応できるように行動ごとに設定するバリスタなど、設定の必要のないものは「なし」を設定する
	uint8_t category;

	// NAME: 消費人間性
	// DESC: 行動時の消費人間性量を設定
	uint8_t heroPoint;

	// NAME: pad
	uint8_t pad1[2];
} BEHAVIOR_PARAM_ST;

#endif
