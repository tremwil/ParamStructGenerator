/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_GESTURE_PARAM_ST_H
#define _PARAMDEF_GESTURE_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GESTURE_PARAM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: 参照アイテムID
	// DESC: 参照アイテムID。各メニューでのジェスチャのテキストID、アイコンID、ソートIDを持ってくるのに使用される。装備品パラメータの道具IDを登録します
	int32_t itemId;

	// NAME: メッセージ添付用アニメID
	// DESC: メッセージ添付用アニメID。メッセージ添付時のアニメIDを指定します
	int32_t msgAnimId;

	// NAME: 騎乗中使用禁止か
	// DESC: 騎乗中使用禁止か(デフォルト:×)。○なら騎乗中に使用できない
	uint8_t cannotUseRiding: 1;

	// NAME: 予約領域
	uint8_t pad2: 7;

	// NAME: 予約領域
	uint8_t pad1[3];
} GESTURE_PARAM_ST;

#endif
