/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_ASSET_GEOMETORY_PARAM_ST_H
#define _PARAMDEF_ASSET_GEOMETORY_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ASSET_GEOMETORY_PARAM_ST {

	// NAME: サウンドのバンクID
	// DESC: サウンドのバンクID(-1:バンクなし, それ以外:指定したIDのバンク)
	int32_t soundBankId;

	// NAME: 破壊音SEID
	// DESC: 破壊音SEID(9桁) -1：assetIdから生成
	int32_t soundBreakSEId;

	// NAME: 描画パラメータ参照ID
	// DESC: 描画パラメータ参照ID。パーツ描画パラメータ.xlsmの参照IDです。
	int32_t refDrawParamId;

	// NAME: 静的アセットヒット構築設定
	// DESC: 静的アセットのヒット構築タイプを設定します。動的アセットでは無視されます。
	int8_t hitCreateType;

	// NAME: アセット挙動タイプ
	// DESC: 動的(すべてのアセット機能が使用可能)、静的(旧マップ扱いの機能制限された軽いアセット)、部分静的(部分破壊アセット)
	uint8_t behaviorType;

	// NAME: 衝突判定タイプ
	// DESC: 衝突判定タイプ。アセットが何と当たるかが設定できます。
	uint8_t collisionType;

	// NAME: 雨遮断設定
	// DESC: 雨遮断のタイプです。SFXと濡れ表現の遮断設定が行えます
	uint8_t rainBlockingType;

	// NAME: HP
	// DESC: 破壊までの耐久力(-1:破壊不可)
	int16_t hp;

	// NAME: 防御力
	// DESC: この値以下の攻撃力はダメージなし
	uint16_t defense;

	// NAME: 破壊後強制停止時間
	// DESC: 破壊されてから剛体を強制的に停止するまでの時間（0で強制停止しない）
	float breakStopTime;

	// NAME: 破壊時SFXID
	// DESC: 破壊時のSFXID(-1:デフォルト(810030))
	int32_t breakSfxId;

	// NAME: 破壊時SFXダミポリID
	// DESC: 破壊時SFXの発生位置ダミポリID(-1：配置位置）
	int32_t breakSfxCpId;

	// NAME: 破壊後着地時SFX識別子
	// DESC: 破壊された後、最初に着地した際に再生するオブジェ材質依存SFXの識別子(-1:発生しない)
	int32_t breakLandingSfxId;

	// NAME: 破壊時 弾発生 行動パラメータID
	// DESC: 破壊時[弾]の行動パラメータ(-1:発生しない)。周回によるオフセットの仕様があるので注意。(【GR】SEQ35556 )
	int32_t breakBulletBehaviorId;

	// NAME: 破壊時 弾発生 ダミポリID
	// DESC: 破壊時[弾]の発生位置ダミポリID(-1:配置位置)
	int32_t breakBulletCpId;

	// NAME: 破片非表示 待機時間(秒)
	// DESC: 破片非表示 待機時間(秒)
	float FragmentInvisibleWaitTime;

	// NAME: 破片非表示 時間(秒)
	// DESC: 破片を非表示にさせる時間(秒)
	float FragmentInvisibleTime;

	// NAME: 破壊時発生AI音ID
	// DESC: 破壊時に発生させるAI音ID
	int32_t BreakAiSoundID;

	// NAME: 破壊時_アイテム抽選種別
	// DESC: 破壊時に抽選したアイテムの入手方法を決めるタイプ
	int8_t breakItemLotType;

	// NAME: アニメ破壊ID最大値
	// DESC: アニメ破壊IDが0番から何番までか
	uint8_t animBreakIdMax;

	// NAME: 破壊時 弾発生 属性ダメージ条件
	// DESC: アセット破壊時に最後に受けたダメージがこの設定の条件を満たしていれば弾丸を生成する
	int8_t breakBulletAttributeDamageType;

	// NAME: プレイヤ衝突で壊れるか
	// DESC: プレイヤが接触したときに壊れ(0:ない, 1:る)
	uint8_t isBreakByPlayerCollide: 1;

	// NAME: 敵キャラ衝突で壊れるか
	// DESC: 敵キャラが接触したときに壊れ(0:ない, 1:る)
	uint8_t isBreakByEnemyCollide: 1;

	// NAME: キャラが乗ったら壊れるか
	// DESC: キャラが乗ったら壊れるか(0:壊れるない 1:壊れる)
	uint8_t isBreak_ByChrRide: 1;

	// NAME: 初期出現用破壊禁止
	// DESC: プレイヤの初期出現で壊れ(0:る, 1:ない)
	uint8_t isDisableBreakForFirstAppear: 1;

	// NAME: アニメ破壊か
	// DESC: アニメ破壊か(0:物理破壊, 1:アニメ破壊)
	uint8_t isAnimBreak: 1;

	// NAME: ダメージを遮蔽するか
	// DESC: ダメージを受けたときに、そのダメージを反対側に通さないかどうか　(0:通す, 1:通さない)
	uint8_t isDamageCover: 1;

	// NAME: 攻撃を弾くか
	// DESC: 攻撃を弾くか(0:弾かない, 1:弾く)
	uint8_t isAttackBacklash: 1;

	// NAME: リザーブ2
	uint8_t Reserve_2: 1;

	// NAME: ハシゴか
	// DESC: ハシゴか(0:ちがう, 1:そう)
	uint8_t isLadder: 1;

	// NAME: 移動オブジェか
	// DESC: 移動オブジェか。マルチ時の移動処理の分岐に使われるフラグです(0:ちがう, 1:そう)
	uint8_t isMoveObj: 1;

	// NAME: 天球扱いか
	// DESC: 天球扱いの処理(プレイヤー追従など)が行われます(0:ちがう, 1:そう)
	uint8_t isSkydomeFlag: 1;

	// NAME: ポリ劇中アニメを停止するか
	// DESC: ポリ劇中アニメを停止するか(0:しない, 1:する)
	uint8_t isAnimPauseOnRemoPlay: 1;

	// NAME: 燃焼するか
	// DESC: 燃焼するか(0:しない, 1:する)
	uint8_t isBurn: 1;

	// NAME: 再収集時変化があるか
	// DESC: このフラグが○なら、配置単位で再度収集するアセットでは「再収集時_***」のパラメータが使われます
	uint8_t isEnableRepick: 1;

	// NAME: 収集時破壊か
	// DESC: ×なら収集時にアニメ再生、○なら収集時に破壊（差し替えなど含めた全ての場合において破壊）
	uint8_t isBreakOnPickUp: 1;

	// NAME: 巨大敵衝突で壊れるか
	// DESC: 巨大敵が接触したときに壊れ(0:ない, 1:る)
	uint8_t isBreakByHugeenemyCollide: 1;

	// NAME: 破壊前ナビメッシュフラグ
	// DESC: 破壊前のアセットから設定されるナビメッシュフラグ
	uint8_t navimeshFlag;

	// NAME: 燃焼 弾発生間隔(フレーム)
	// DESC: 延焼用の弾を発生する間隔(フレーム)
	uint16_t burnBulletInterval;

	// NAME: クロス更新距離(m)
	// DESC: havokClothの更新を行なうカメラからの距離(0:必ず更新する)
	float clothUpdateDist;

	// NAME: ランタイム生成アセットの寿命(秒)
	// DESC: ランタイム生成アセットが生成後に消滅するまでの時間 (0:消滅しない)
	float lifeTime_forRuntimeCreate;

	// NAME: プレイヤー接触時SE ID
	// DESC: 自分が操作するローカルプレイヤーが触れた際に再生するSEのID(-1:再生しない)
	int32_t contactSeId;

	// NAME: 再収集時_アニメオフセット
	// DESC: 「再収集時変化があるか」が○のアセットは配置単位で再収集時、この値でオフセットしたアニメIDで未収集/収集済のアニメを再生
	int32_t repickAnimIdOffset;

	// NAME: 風係数(破壊前)
	// DESC: 風係数(破壊前)
	float windEffectRate_0;

	// NAME: 風係数(破壊後)
	// DESC: 風係数(破壊後)
	float windEffectRate_1;

	// NAME: 風影響タイプ(破壊前)
	// DESC: 風影響タイプ(破壊前)
	uint8_t windEffectType_0;

	// NAME: 風影響タイプ(破壊後)
	// DESC: 風影響タイプ(破壊後)
	uint8_t windEffectType_1;

	// NAME: 上書き材質ID
	// DESC: アセットの材質ID上書き設定(-1：モデルの材質IDを上書きしない 0以上：材質ID上書き)　はしご上ではこの設定でのみ材質IDが反映されます
	int16_t overrideMaterialId;

	// NAME: 自動生成時の高さオフセット(m)
	// DESC: マップに自動生成時にレイキャストが当たったところからどれぐらい浮かせるかの高さオフセット[m]
	float autoCreateOffsetHeight;

	// NAME: 燃焼時間(秒)
	// DESC: 燃焼時間(秒)(0で燃え続ける)
	float burnTime;

	// NAME: 燃焼 破壊判定進行度
	// DESC: 破壊状態に切り替わる燃焼度の閾値
	float burnBraekRate;

	// NAME: 燃焼 SFXID：0
	// DESC: 燃焼時のSFXID：0 (-1：SFXなし)
	int32_t burnSfxId;

	// NAME: 燃焼 SFXID：1
	// DESC: 燃焼時のSFXID：1 (-1：SFXなし)
	int32_t burnSfxId_1;

	// NAME: 燃焼 SFXID：2
	// DESC: 燃焼時のSFXID：2 (-1：SFXなし)
	int32_t burnSfxId_2;

	// NAME: 燃焼 SFXID：3
	// DESC: 燃焼時のSFXID：3 (-1：SFXなし)
	int32_t burnSfxId_3;

	// NAME: 燃焼 SFX発生遅延 開始時間(秒)：0
	// DESC: 燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin;

	// NAME: 燃焼 SFX発生遅延 開始時間(秒)：1
	// DESC: 燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin_1;

	// NAME: 燃焼 SFX発生遅延 開始時間(秒)：2
	// DESC: 燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin_2;

	// NAME: 燃焼 SFX発生遅延 開始時間(秒)：3
	// DESC: 燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMin_3;

	// NAME: 燃焼 SFX発生遅延 終了時間(秒)：0
	// DESC: 燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax;

	// NAME: 燃焼 SFX発生遅延 終了時間(秒)：1
	// DESC: 燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax_1;

	// NAME: 燃焼 SFX発生遅延 終了時間(秒)：2
	// DESC: 燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax_2;

	// NAME: 燃焼 SFX発生遅延 終了時間(秒)：3
	// DESC: 燃焼時のSFX発生遅延時間 開始～終了時間の間でランダムに決まる
	float burnSfxDelayTimeMax_3;

	// NAME: 燃焼 弾発生 行動パラメータ：0
	// DESC: 燃焼時の弾発生行動パラメータ：0(-1:発生しない)
	int32_t burnBulletBehaviorId;

	// NAME: 燃焼 弾発生 行動パラメータ：1
	// DESC: 燃焼時の弾発生行動パラメータ：1(-1:発生しない)
	int32_t burnBulletBehaviorId_1;

	// NAME: 燃焼 弾発生 行動パラメータ：2
	// DESC: 燃焼時の弾発生行動パラメータ：2(-1:発生しない)
	int32_t burnBulletBehaviorId_2;

	// NAME: 燃焼 弾発生 行動パラメータ：3
	// DESC: 燃焼時の弾発生行動パラメータ：3(-1:発生しない)
	int32_t burnBulletBehaviorId_3;

	// NAME: 燃焼 弾発生遅延時間(秒)
	// DESC: 延焼用の弾発生を遅らせる時間(秒)
	float burnBulletDelayTime;

	// NAME: ペイントデカールターゲットサイズ
	// DESC: ペイントデカールターゲットサイズ 0：デカール無効 (0～4096 ２のべき乗 0, 2, 4, 8, … 2048 のみ有効)
	uint16_t paintDecalTargetTextureSize;

	// NAME: 破壊後ナビメッシュフラグ
	// DESC: 破壊後のアセットから設定されるナビメッシュフラグ
	uint8_t navimeshFlag_after;

	// NAME: カメラ接近時描画
	// DESC: カメラ接近時の描画設定。【GR】SEQ07529
	int8_t camNearBehaviorType;

	// NAME: 破壊時_アイテム抽選ID_マップ用
	// DESC: 破壊時に抽選させるアイテム抽選ID_マップ用　-1：抽選しない
	int32_t breakItemLotParamId;

	// NAME: 収集時_アクションボタンID
	// DESC: 収集で出すアクションボタンID　-1：収集機能は無効
	int32_t pickUpActionButtonParamId;

	// NAME: 収集時_アイテム抽選ID_マップ用
	// DESC: 収集時に抽選させるアイテム抽選ID_マップ用　-1：収集機能は無効
	int32_t pickUpItemLotParamId;

	// NAME: 自動描画グループ_裏面チェック
	// DESC: 自動描画グループ_裏面チェック
	uint8_t autoDrawGroupBackFaceCheck;

	// NAME: 自動描画グループ_遮蔽
	// DESC: 自動描画グループ_遮蔽
	uint8_t autoDrawGroupDepthWrite;

	// NAME: 自動描画グループ_影テスト
	// DESC: 自動描画グループ_影テスト
	uint8_t autoDrawGroupShadowTest;

	// NAME: デバッグ_許容地面高さチェック
	// DESC: デバッグ_許容地面高さチェック 詳細はSEQ07876参照
	uint8_t debug_isHeightCheckEnable;

	// NAME: 床下ナビメッシュ切り抜き対象外
	// DESC: 床（地面）のヒットより低い位置に配置された場合、床下ナビメッシュ削除対象から外すかを設定すること ツールから参照
	uint8_t hitCarverCancelAreaFlag;

	// NAME: ナビメッシュ結合制御
	// DESC: 設定されたアセットが、ナビメッシュビルド時に、ヒットパーツの結合対象から除外される
	uint8_t assetNavimeshNoCombine;

	// NAME: ナビメッシュフラグ適用先
	// DESC: アセットから設定されるナビメッシュフラグの適用先
	uint8_t navimeshFlagApply;

	// NAME: 破壊後ナビメッシュフラグ適用先
	// DESC: 破壊後のアセットから設定されるナビメッシュフラグの適用先
	uint8_t navimeshFlagApply_after;

	// NAME: 自動描画グループ_合格ピクセル
	// DESC: 自動描画グループ_合格ピクセル（0.0～1.0に設定することで撮影時に拡大される）
	float autoDrawGroupPassPixelNum;

	// NAME: 収集時_差し替えフラグ条件
	// DESC: このイベントフラグがONの時は後続の差し替えのIDを使う　0：常に差し替えない
	uint32_t pickUpReplacementEventFlag;

	// NAME: 収集時_差し替えアニメオフセット
	// DESC: 「収集時_差し替えフラグ条件」がONの時、この値でオフセットしたアニメIDで未収集/収集済のアニメを再生
	int32_t pickUpReplacementAnimIdOffset;

	// NAME: 収集時_差し替えアクションボタンID
	// DESC: 「収集時_差し替えフラグ条件」がONの時、このアクションボタンIDが使われる
	int32_t pickUpReplacementActionButtonParamId;

	// NAME: 収集時_差し替えアイテム抽選ID_マップ用
	// DESC: 「収集時_差し替えフラグ条件」がONの時、このアイテム抽選ID_マップ用が使われる
	int32_t pickUpReplacementItemLotParamId;

	// NAME: 地面を這う弾丸の着弾時の挙動
	// DESC: 追従タイプ「衝突しても地面を這う」の弾丸がアセットに衝突した際、着弾地点に沿う方向に曲げるか？の挙動
	uint8_t slidingBulletHitType;

	// NAME: 茂みダメージで壊れるか
	// DESC: ◯のアセットは、 「茂みにダメージ可」◯  かつ 「オブジェ攻撃力 ＞ 防御力」の攻撃のみ、ダメージが通るようになります【GR】SEQ20617
	uint8_t isBushesForDamage;

	// NAME: 弾丸貫通タイプ
	// DESC: 弾丸がヒットして着弾するか？を決める時に、どの弾丸パラを参照するか？を決める値。
	uint8_t penetrationBulletType;

	// NAME: リザーブ3
	uint8_t Reserve_3[1];

	// NAME: リザーブ4
	uint8_t Reserve_4[4];

	// NAME: 破壊音ダミポリID
	// DESC: 破壊音を再生する場所のダミポリID (-1:配置位置)
	int32_t soundBreakSECpId;

	// NAME: デバッグ_許容地面高さ_最小[m]
	// DESC: デバッグ_許容地面高さ_最小[m] 詳細はSEQ07876参照　最大より小さい必要あり
	float debug_HeightCheckCapacityMin;

	// NAME: デバッグ_許容地面高さ_最大[m]
	// DESC: デバッグ_許容地面高さ_最大[m] 詳細はSEQ07876参照　最小より大きい必要あり
	float debug_HeightCheckCapacityMax;

	// NAME: 再収集時_アクションボタンID
	// DESC: 「再収集時変化があるか」が○のアセットは配置単位で再収集時、このアクションボタンIDが使われる
	int32_t repickActionButtonParamId;

	// NAME: 再収集時_アイテム抽選ID_マップ用
	// DESC: 「再収集時変化があるか」が○のアセットは配置単位で再収集時、このアイテム抽選ID_マップ用が使われる
	int32_t repickItemLotParamId;

	// NAME: 再収集時_差し替えアニメオフセット
	// DESC: 「再収集時変化があるか」が○のアセットは配置単位で再収集時、「収集時_差し替えアニメオフセット」の代わりにこのパラメータを使う
	int32_t repickReplacementAnimIdOffset;

	// NAME: 再収集時_差し替えアクションボタンID
	// DESC: 「再収集時変化があるか」が○のアセットは配置単位で再収集時、「収集時_差し替えアクションボタンID」の代わりにこのパラメータを使う
	int32_t repickReplacementActionButtonParamId;

	// NAME: 再収集時_差し替えアイテム抽選ID_マップ用
	// DESC: 「再収集時変化があるか」が○のアセットは配置単位で再収集時、「収集時_差し替えアイテム抽選ID_マップ用」の代わりにこのパラメータを使う
	int32_t repickReplacementItemLotParamId;

	// NAME: ナビメッシュ地形内判定無効化
	// DESC: これが設定されたAssetはCarverを作らない
	uint8_t noGenerateCarver;

	// NAME: 破壊後に巨大敵に当たらない
	// DESC: 破壊後のヒットフィルタを衝突判定タイプ巨大敵に当たらない（静○動○）相当のもので上書きする
	uint8_t noHitHugeAfterBreak;

	// NAME: 破壊を同期するか
	// DESC: これが×の場合は初期同期,マップアクティベート同期,インゲーム中のアセット破壊同期を行わないようにし、リモートPCの攻撃が当たらなくなる
	uint8_t isEnabledBreakSync: 1;

	// NAME: 再収集時_非表示
	// DESC: 配置単位で再収集時にアイテム抽選的に取れなければアセットを非表示にします
	uint8_t isHiddenOnRepick: 1;

	// NAME: マルチ中のみ有効か(動的のみ)
	// DESC: マルチ中のみ有効か。動的アセットのみ有効。(詳細：SEQ15087)
	uint8_t isCreateMultiPlayOnly: 1;

	// NAME: 弾丸の着弾SFXを発生しない
	// DESC: ○の場合、当たった弾丸が貫通しようと着弾しようと着弾SFXは発生しない
	uint8_t isDisableBulletHitSfx: 1;

	// NAME: サイン／血文字作成可能か(アセット破壊前) 
	// DESC: アセット上にいるときサイン/血文字の作成可能かを設定する(破壊前)〇：可能、×：不可能(詳細：SEQ122568)
	uint8_t isEnableSignPreBreak: 1;

	// NAME: サイン／血文字作成可能か(アセット破壊後) 
	// DESC: アセット上にいるときサイン/血文字の作成可能かを設定する(破壊後)〇：可能、×：不可能(詳細：SEQ122568)
	uint8_t isEnableSignPostBreak: 1;

	// NAME: リザーブ1
	uint8_t Reserve_1: 2;

	// NAME: 召喚禁止/侵入禁止領域生成（ダミポリ）
	// DESC: 召喚禁止/侵入禁止領域生成（ダミポリ）
	uint8_t generateMultiForbiddenRegion;

	// NAME: 常駐SEID0
	// DESC: アセットに常駐させるサウンドID0(9桁) (-1:常駐なし)
	int32_t residentSeId0;

	// NAME: 常駐SEID1
	// DESC: アセットに常駐させるサウンドID1(9桁) (-1:常駐なし)
	int32_t residentSeId1;

	// NAME: 常駐SEID2
	// DESC: アセットに常駐させるサウンドID2(9桁) (-1:常駐なし)
	int32_t residentSeId2;

	// NAME: 常駐SEID3
	// DESC: アセットに常駐させるサウンドID3(9桁) (-1:常駐なし)
	int32_t residentSeId3;

	// NAME: 常駐SEダミポリID0
	// DESC: 常駐サウンドをアタッチするダミポリID0 (-1:配置位置)
	int16_t residentSeDmypolyId0;

	// NAME: 常駐SEダミポリID1
	// DESC: 常駐サウンドをアタッチするダミポリID1 (-1:配置位置)
	int16_t residentSeDmypolyId1;

	// NAME: 常駐SEダミポリID2
	// DESC: 常駐サウンドをアタッチするダミポリID2 (-1:配置位置)
	int16_t residentSeDmypolyId2;

	// NAME: 常駐SEダミポリID3
	// DESC: 常駐サウンドをアタッチするダミポリID3 (-1:配置位置)
	int16_t residentSeDmypolyId3;

	// NAME: オープン_XB1除外割合
	// DESC: オープン_XB1除外割合【GR】SEQ25310
	uint8_t excludeActivateRatio_Xboxone_Grid;

	// NAME: レガシー_XB1除外割合
	// DESC: レガシー_XB1除外割合【GR】SEQ25310
	uint8_t excludeActivateRatio_Xboxone_Legacy;

	// NAME: オープン_PS4除外割合
	// DESC: オープン_PS4除外割合【GR】SEQ25310
	uint8_t excludeActivateRatio_PS4_Grid;

	// NAME: レガシー_PS4除外割合
	// DESC: レガシー_PS4除外割合【GR】SEQ25310
	uint8_t excludeActivateRatio_PS4_Legacy;

	// NAME: リザーブ0
	// DESC: リザーブ0
	uint8_t Reserve_0[32];
} ASSET_GEOMETORY_PARAM_ST;

#endif
