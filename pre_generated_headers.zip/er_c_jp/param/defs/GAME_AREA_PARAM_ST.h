/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_GAME_AREA_PARAM_ST_H
#define _PARAMDEF_GAME_AREA_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GAME_AREA_PARAM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: シングル時クリアボーナスソウル量
	// DESC: エリアボスを倒したときに取得できるソウル量(シングルプレイ時)
	uint32_t bonusSoul_single;

	// NAME: マルチプレイ時クリアボーナスソウル量
	// DESC: エリアボスを倒したときに取得できるソウル量(マルチプレイ時)
	uint32_t bonusSoul_multi;

	// NAME: 人間性ドロップポイントカウント先頭フラグID
	// DESC: 人間性ドロップポイントを管理する為の先頭フラグID(20Bit使用)
	uint32_t humanityPointCountFlagIdTop;

	// NAME: 人間性ドロップ必要ポイント1
	// DESC: 人間性を取得する為の閾値1
	uint16_t humanityDropPoint1;

	// NAME: 人間性ドロップ必要ポイント2
	// DESC: 人間性を取得する為の閾値2
	uint16_t humanityDropPoint2;

	// NAME: 人間性ドロップ必要ポイント3
	// DESC: 人間性を取得する為の閾値3
	uint16_t humanityDropPoint3;

	// NAME: 人間性ドロップ必要ポイント4
	// DESC: 人間性を取得する為の閾値4
	uint16_t humanityDropPoint4;

	// NAME: 人間性ドロップ必要ポイント5
	// DESC: 人間性を取得する為の閾値5
	uint16_t humanityDropPoint5;

	// NAME: 人間性ドロップ必要ポイント6
	// DESC: 人間性を取得する為の閾値6
	uint16_t humanityDropPoint6;

	// NAME: 人間性ドロップ必要ポイント7
	// DESC: 人間性を取得する為の閾値7
	uint16_t humanityDropPoint7;

	// NAME: 人間性ドロップ必要ポイント8
	// DESC: 人間性を取得する為の閾値8
	uint16_t humanityDropPoint8;

	// NAME: 人間性ドロップ必要ポイント9
	// DESC: 人間性を取得する為の閾値9
	uint16_t humanityDropPoint9;

	// NAME: 人間性ドロップ必要ポイント10
	// DESC: 人間性を取得する為の閾値10
	uint16_t humanityDropPoint10;

	// NAME: ソロ侵入ポイント加算値下限
	// DESC: エリアボスを倒したときに加算するソロ侵入ポイントの最小値。
	uint32_t soloBreakInPoint_Min;

	// NAME: ソロ侵入ポイント加算値上限
	// DESC: エリアボスを倒したときに加算するソロ侵入ポイントの最大値。
	uint32_t soloBreakInPoint_Max;

	// NAME: ボス撃破済みフラグID(ホスト化時の目的表示用)
	// DESC: このフラグがONの場合はホスト化時の目的設定のリストに表示しない。0の場合は常時表示。
	uint32_t defeatBossFlagId_forSignAimList;

	// NAME: 目的表示フラグID
	uint32_t displayAimFlagId;

	// NAME: ボス発見フラグID
	uint32_t foundBossFlagId;

	// NAME: 発見時テキストID
	int32_t foundBossTextId;

	// NAME: 未発見時テキストID
	int32_t notFindBossTextId;

	// NAME: ボス挑戦可能フラグID
	// DESC: ボス挑戦可能フラグID。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索で目的のボスを選ぶ時にこのフラグがONのボスが対象になる。0の場合は常に対象になる。
	uint32_t bossChallengeFlagId;

	// NAME: ボス撃破フラグID
	// DESC: ボス撃破フラグID。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索で目的のボスを選ぶ時にこのフラグがOFFのボスが対象になる。
	uint32_t defeatBossFlagId;

	// NAME: ボス位置_X座標
	// DESC: ボス位置_X座標（指定したマップからの相対座標）。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	float bossPosX;

	// NAME: ボス位置_Y座標
	// DESC: ボス位置_Y座標（指定したマップからの相対座標）。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	float bossPosY;

	// NAME: ボス位置_Z座標
	// DESC: ボス位置_Z座標（指定したマップからの相対座標）。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	float bossPosZ;

	// NAME: ボス位置_エリア番号(mXX_00_00_00)
	// DESC: ボス位置_エリア番号(mXX_00_00_00)。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	uint8_t bossMapAreaNo;

	// NAME: ボス位置_グリッドX番号(m00_XX_00_00)
	// DESC: ボス位置_グリッドX番号(m00_XX_00_00)。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	uint8_t bossMapBlockNo;

	// NAME: ボス位置_グリッドZ番号(m00_00_XX_00)
	// DESC: ボス位置_グリッドZ番号(m00_00_XX_00)。マルチプレイエリアパラの「侵入ポイント自動生成か」が○のときの侵入位置検索でホストとボス間の距離確認に使われる。
	uint8_t bossMapMapNo;

	// NAME: 予約領域
	// DESC: 予約領域
	uint8_t reserve[9];
} GAME_AREA_PARAM_ST;

#endif
