/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_BULLET_PARAM_ST_H
#define _PARAMDEF_BULLET_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _BULLET_PARAM_ST {

	// NAME: 攻撃ID
	// DESC: 攻撃パラメータのＩＤをそれぞれ登録する.→攻撃タイプ／攻撃材質／物理攻撃力／魔法攻撃力／スタミナ攻撃力／ノックバック距離.
	int32_t atkId_Bullet;

	// NAME: SFXID【弾】
	// DESC: 【弾】用SFX IDを入れる。-1は発生しない。
	int32_t sfxId_Bullet;

	// NAME: SFXID【着弾】
	// DESC: 【着弾】SFXIDを入れる。-1は発生しない。
	int32_t sfxId_Hit;

	// NAME: SFXID【はじき時】
	// DESC: 【はじき時】SFXIDを入れる。-1は発生しない。
	int32_t sfxId_Flick;

	// NAME: 寿命[s]
	// DESC: 飛び道具が存在し続けられる時間（-1なら無限）.
	float life;

	// NAME: 射程距離[m]
	// DESC: 減衰が開始される距離（実際の飛距離ではない）.
	float dist;

	// NAME: 発射間隔[s]
	// DESC: 飛び道具を何秒間隔で発射するかを指定.
	float shootInterval;

	// NAME: 射程距離内重力[m/s^2]
	// DESC: 射程距離内での下向きにかかる重力.
	float gravityInRange;

	// NAME: 射程距離外重力[m/s^2]
	// DESC: 減衰がはじまったときの下向きにかかる重力（ポトンと落ちる感じを表現.
	float gravityOutRange;

	// NAME: 誘導停止距離[m]
	// DESC: 誘導を停止するターゲットとの距離。誘導弾で当たり過ぎないようにするパラメータ。
	float hormingStopRange;

	// NAME: 初速[m/s]
	// DESC: ＳＦＸの初速度.
	float initVellocity;

	// NAME: 射程距離内加速度[m/s^2]
	// DESC: ＳＦＸの射程内の加速度.
	float accelInRange;

	// NAME: 射程距離外加速度[m/s^2]
	// DESC: ＳＦＸが射程距離外に出たときの加速度.
	float accelOutRange;

	// NAME: 最高速度[m/s]
	// DESC: 最高速度.
	float maxVellocity;

	// NAME: 最低速度[m/s]
	// DESC: 最低保証速度.
	float minVellocity;

	// NAME: 加速開始時間[s]
	// DESC: この時間までは、加速しない（ロケット弾みたいな魔法を撃つことができるようにしておく）.
	float accelTime;

	// NAME: 誘導開始距離[m]
	// DESC: 何ｍ進んだ地点から誘導を開始するか.
	float homingBeginDist;

	// NAME: 初期弾半径[m]
	// DESC: 当たり球の半径を設定する.
	float hitRadius;

	// NAME: 最大弾半径[m]
	// DESC: あたり球の最大半径（－1の場合、初期半径と同じにする／デフォルト）
	float hitRadiusMax;

	// NAME: 範囲拡散時間[s]
	// DESC: 範囲半径が細大にまで広がる時間.
	float spreadTime;

	// NAME: 発動遅延[s]
	// DESC: 着弾後、爆発までの時間（０の場合はすぐに爆発）.
	float expDelay;

	// NAME: 誘導ずらし量[m]
	// DESC: ０だと正確。射撃時にXYZ各成分を、この量だけずらして狙うようにする。
	float hormingOffsetRange;

	// NAME: ダメージヒット履歴の生存時間[s]
	// DESC: ダメージヒット履歴の生存時間[sec](<=0.0f：無期限)
	float dmgHitRecordLifeTime;

	// NAME: 外力[m/s^2]
	// DESC: 射撃時の方向にかかる外力.(Y軸は抜いている)
	float externalForce;

	// NAME: 射撃した人にかける特殊効果
	// DESC: 射撃した人にかける特殊効果
	int32_t spEffectIDForShooter;

	// NAME: ファンネルNPC思考ID
	// DESC: ファンネルがターゲットの検索使用するパラメータ
	int32_t autoSearchNPCThinkID;

	// NAME: 発生弾丸ID
	// DESC: 弾丸パラメータから、新しく弾丸パラメータを発生させるときにＩＤを指定する
	int32_t HitBulletID;

	// NAME: 特殊効果ID0
	// DESC: 特殊効果パラメータのＩＤをそれぞれ登録する.→特殊効果全般.
	int32_t spEffectId0;

	// NAME: 特殊効果ID1
	// DESC: 特殊効果パラメータのＩＤをそれぞれ登録する.→特殊効果全般.
	int32_t spEffectId1;

	// NAME: 特殊効果ID2
	// DESC: 特殊効果パラメータのＩＤをそれぞれ登録する.→特殊効果全般.
	int32_t spEffectId2;

	// NAME: 特殊効果ID3
	// DESC: 特殊効果パラメータのＩＤをそれぞれ登録する.→特殊効果全般.
	int32_t spEffectId3;

	// NAME: 特殊効果ID4
	// DESC: 特殊効果パラメータのＩＤをそれぞれ登録する.→特殊効果全般.
	int32_t spEffectId4;

	// NAME: 発射数
	// DESC: 一度に発射する飛び道具の数.
	uint16_t numShoot;

	// NAME: 誘導性能[deg/s]
	// DESC: 1秒間に何度まで補正するか？.
	int16_t homingAngle;

	// NAME: 発射角度[deg]
	// DESC: 飛び道具を前方何度に向かって発射するかを指定.
	int16_t shootAngle;

	// NAME: 発射角度間隔[deg]
	// DESC: 飛び道具を複数発射する場合、何度間隔で発射するかを指定.(Y軸)
	int16_t shootAngleInterval;

	// NAME: 発射仰角間隔[deg]
	// DESC: 飛び道具を複数発射する場合、何度間隔で発射するかを指定.(X軸)
	int16_t shootAngleXInterval;

	// NAME: 物理攻撃力減衰率[%/s]
	// DESC: 減衰距離以降、1秒間に減少する補正値.
	int8_t damageDamp;

	// NAME: 魔法攻撃力減衰率[%/s]
	// DESC: 減衰距離以降、1秒間に減少する補正値.
	int8_t spelDamageDamp;

	// NAME: 炎攻撃力減衰率[%/s]
	// DESC: 減衰距離以降、1秒間に減少する補正値.
	int8_t fireDamageDamp;

	// NAME: 電撃攻撃力減衰率[%/s]
	// DESC: 減衰距離以降、1秒間に減少する補正値.
	int8_t thunderDamageDamp;

	// NAME: スタミナダメージ減衰率[%/s]
	// DESC: 減衰距離以降、1秒間に減少する補正値.
	int8_t staminaDamp;

	// NAME: ノックバック減衰率[%/s]
	// DESC: 減衰距離以降、1秒間に減少する補正値.
	int8_t knockbackDamp;

	// NAME: 発射仰角[deg]
	// DESC: 水平方向からの追加仰角。
	int8_t shootAngleXZ;

	// NAME: ロック方向制限角度
	// DESC: ロック方向を向かせるときの制限角度
	uint8_t lockShootLimitAng;

	// NAME: pad
	uint8_t pad2[1];

	// NAME: 前回の移動方向加算率[%]
	// DESC: 滑る弾が壁にヒット時に前回の移動方向を今の方向へ加算する比率
	uint8_t prevVelocityDirRate;

	// NAME: 物理属性
	// DESC: 弾丸に設定する物理属性を設定
	uint8_t atkAttribute;

	// NAME: 特殊属性
	// DESC: 弾丸に設定する特殊属性を設定
	uint8_t spAttribute;

	// NAME: 攻撃属性[SFX/SE]
	// DESC: 攻撃属性が何かを指定する
	uint8_t Material_AttackType;

	// NAME: 攻撃材質[SFX/SE]
	// DESC: 攻撃時のSFX/ＳＥに使用
	uint8_t Material_AttackMaterial;

	// NAME: キャラを貫通？
	// DESC: ONであればキャラに当たったときに着弾せず貫通する
	uint8_t isPenetrateChr: 1;

	// NAME: オブジェを貫通？
	// DESC: ONであれば動的/部分破壊アセットに当たったときに着弾せず貫通する
	uint8_t isPenetrateObj: 1;

	// NAME: pad
	uint8_t pad: 6;

	// NAME: 発生条件
	// DESC: 着弾・寿命消滅時に弾を発生させるか判定する条件を指定
	uint8_t launchConditionType;

	// NAME: 追従タイプ
	// DESC: 追従タイプ。「追従しない」がデフォルト。
	uint8_t FollowType: 3;

	// NAME: 発生源タイプ
	// DESC: 発生源タイプ。ダミポリからが通常。（メテオを判定するために導入）
	uint8_t EmittePosType: 3;

	// NAME: 刺さったままになるか
	// DESC: 矢などの弾丸が、キャラクターに刺さったままになるかどうかを設定する
	uint8_t isAttackSFX: 1;

	// NAME: あたり続けるか？
	// DESC: あたり続けるか？
	uint8_t isEndlessHit: 1;

	// NAME: マップを貫通？
	// DESC: ONであればヒット/静的アセットに当たったときに着弾せず貫通する
	uint8_t isPenetrateMap: 1;

	// NAME: 敵味方共にあたる？
	// DESC: 敵味方共にあたるか？（徘徊ゴーストにはあたらない）
	uint8_t isHitBothTeam: 1;

	// NAME: ヒットリストを共有するか？
	// DESC: ヒットリストを共有するかを指定
	uint8_t isUseSharedHitList: 1;

	// NAME: 複数のダミポリを使うか？
	// DESC: 弾配置時に同一ダミポリIDを複数使うか？
	uint8_t isUseMultiDmyPolyIfPlace: 1;

	// NAME: 他弾強制消去Aに当たるか
	// DESC: 他弾強制消去Aに当たるか
	uint8_t isHitOtherBulletForceEraseA: 1;

	// NAME: 他弾強制消去Bに当たるか
	// DESC: 他弾強制消去Bに当たるか
	uint8_t isHitOtherBulletForceEraseB: 1;

	// NAME: フォース魔法に当たるか
	// DESC: フォース魔法に当たるか
	uint8_t isHitForceMagic: 1;

	// NAME: 水面衝突時のエフェクト無視するか
	// DESC: 水面に当たった場合はエフェクト無視するか
	uint8_t isIgnoreSfxIfHitWater: 1;

	// NAME: 水面衝突時の状態遷移を無視するか
	// DESC: 水に当たっても状態遷移を無視するか
	uint8_t isIgnoreMoveStateIfHitWater: 1;

	// NAME: 闇フォース魔法に当たるか
	// DESC: 闇フォース魔法に当たるか
	uint8_t isHitDarkForceMagic: 1;

	// NAME: ダメージ計算サイド
	// DESC: ダメージ計算サイド。　マルチプレイ時に、ダメージの計算を、与えた側 or 受けた側を切り替えるためのもの。
	uint8_t dmgCalcSide: 2;

	// NAME: 弾丸自動捕捉許可
	// DESC: 非ロックオン時に自動追従するか
	uint8_t isEnableAutoHoming: 1;

	// NAME: 同期弾丸の場合、ダミポリ位置での再計算を行うか
	// DESC: 同期生成された弾丸の場合、弾丸生成時にダミポリ位置による姿勢の再計算を行わず、同期時のエミッタ姿勢を使用する。
	uint8_t isSyncBulletCulcDumypolyPos: 1;

	// NAME: 弾丸の基準方向をオーナーに上書きするか？
	// DESC: 子弾丸のみ有効。ONなら基準方向をオーナーにする。
	uint8_t isOwnerOverrideInitAngle: 1;

	// NAME: 子弾にSFXを引き継ぐか
	// DESC: 親弾のSFXを引き継ぐ。子弾に設定されたSFXIDは無視する 
	uint8_t isInheritSfxToChild: 1;

	// NAME: 闇攻撃力減衰率[%/s]
	// DESC: 減衰距離以降、1秒間に減少する補正値.
	int8_t darkDamageDamp;

	// NAME: 着弾時の弾丸SFX消滅タイプ
	// DESC: 着弾or弾き時の弾丸SFX消滅タイプ
	int8_t bulletSfxDeleteType_byHit;

	// NAME: 寿命時の弾丸SFX消滅タイプ
	// DESC: 寿命時の弾丸SFX消滅タイプ
	int8_t bulletSfxDeleteType_byLifeDead;

	// NAME: 目標上下オフセット[m]
	// DESC: 着弾位置の上下オフセット。発射時とホーミング中のターゲット位置を上下にずらす。（-n～n）
	float targetYOffsetRange;

	// NAME: 発射角度乱数[deg]
	// DESC: 発射角度乱数の上限（0～360）
	float shootAngleYMaxRandom;

	// NAME: 発射仰角乱数[deg]
	// DESC: 発射仰角乱数の上限（0～360）
	float shootAngleXMaxRandom;

	// NAME: 間隔指定発生弾丸ID
	// DESC: 一定間隔で弾丸を作る時に使う、弾丸のID
	int32_t intervalCreateBulletId;

	// NAME: 発生間隔：最小時間[s]
	// DESC: 一定間隔で弾丸を作る間隔の最小（0～n）
	float intervalCreateTimeMin;

	// NAME: 発生間隔：最大時間[s]
	// DESC: 一定間隔で弾丸を作る間隔の最大（0～n 0なら機能無効）
	float intervalCreateTimeMax;

	// NAME: 予測射撃の速度観測時間[s]
	// DESC: 予測射撃機能の平均速度観測時間（0～4 0なら機能無効）
	float predictionShootObserveTime;

	// NAME: 間隔指定発生開始待ち時間[s]
	// DESC: 一定間隔で弾丸を作り始めるまでの待ち時間
	float intervalCreateWaitTime;

	// NAME: 弾丸から発生したSFXの姿勢のタイプ
	// DESC: 弾丸から作成されたSFXまたは子弾丸の初期姿勢を設定する
	uint8_t sfxPostureType;

	// NAME: 作成制限グループId
	// DESC: 0なら未使用。同一のグループIdに設定された弾丸を作成するときに上限に達していたらその弾丸を作成しない。（ネットワークで同期作成された弾は関係なく出る）
	uint8_t createLimitGroupId;

	// NAME: pad
	uint8_t pad5[1];

	// NAME: 子弾に速度を引き継ぐか
	// DESC: 子弾に差し替わるタイミングの速度を引き継ぐ。子弾に設定された速度は無視する
	uint8_t isInheritSpeedToChild: 1;

	// NAME: キャラ・OBJヒット時着弾SFXを再生しない
	// DESC: ONの時、キャラクター/オブジェクトに着弾しても弾丸パラメータの「着弾SFX」を再生しない
	uint8_t isDisableHitSfx_byChrAndObj: 1;

	// NAME: 発射位置壁めり込み判定をキャラ中心を平行に結ぶレイを飛ばして行う
	// DESC: 弾丸発射時めり込み判定に不具合があったので、それのエラーハンドリング用。SEQ23101 【自キャラ】ロックオン位置の高いキャラに密着してソウルの短矢、強いソウルの短矢を使うと弾丸の方向が反転する
	uint8_t isCheckWall_byCenterRay: 1;

	// NAME: フレア魔法に当たるか
	// DESC: フレア魔法に当たるか
	uint8_t isHitFlare: 1;

	// NAME: 原始魔法アタリを使うか？
	// DESC: 原始魔法アタリを使うか？原始魔法専用アタリに当たるフィルタに変わります。
	uint8_t isUseBulletWallFilter: 1;

	// NAME: pad
	uint8_t pad1: 1;

	// NAME: PCのファンネル数が理力で変動しない
	// DESC: PCのファンネル数が理力で変動しない。発射数になる
	uint8_t isNonDependenceMagicForFunnleNum: 1;

	// NAME: AI弾丸反応するか（攻撃力0でも）
	// DESC: AI弾丸反応するか（攻撃力0でも）
	uint8_t isAiInterruptShootNoDamageBullet: 1;

	// NAME: ランダム発生時の発生範囲(半径)[m]
	// DESC: 発生源タイプがランダムな位置に発生する設定の場合に利用される、弾丸の発生範囲。
	float randomCreateRadius;

	// NAME: ファンネル追従位置_基点高さ[m]
	// DESC: ファンネル追従位置_基点高さ[m]
	float followOffset_BaseHeight;

	// NAME: 着弾時に発生するアセット番号
	// DESC: 着弾時に発生させるアセットの番号。-1：生成しない。アセット番号はアセットの下6桁の数値です。例： AEG999_999 = 999999
	int32_t assetNo_Hit;

	// NAME: 寿命乱数[s]
	// DESC: 「寿命[s]」に対して、設定した時間の振れ幅を持つ乱数秒を加える
	float lifeRandomRange;

	// NAME: 誘導性能（X軸個別）[deg/s]
	// DESC: 誘導性能のX軸成分だけを変えます。-1で変えません
	int16_t homingAngleX;

	// NAME: 弾道計算タイプ
	// DESC: 弾道計算タイプ
	uint8_t ballisticCalcType;

	// NAME: アタッチ効果タイプ
	// DESC: アタッチする効果タイプ
	uint8_t attachEffectType;

	// NAME: SEID1【弾】
	// DESC: 【弾】用SE ID1 を入れる。-1：生成しない　9桁。サウンドタイプはs：SFX固定。
	int32_t seId_Bullet1;

	// NAME: SEID2【弾】
	// DESC: 【弾】用SE ID2 を入れる。-1：生成しない　9桁。サウンドタイプはs：SFX固定。
	int32_t seId_Bullet2;

	// NAME: SEID【着弾】
	// DESC: 【着弾】用SE ID1 を入れる。-1は発生しない。 9桁。サウンドタイプはs：SFX固定。
	int32_t seId_Hit;

	// NAME: SEID【はじき時】
	// DESC: 【はじき時】用SE ID1 を入れる。-1は発生しない。 9桁。サウンドタイプはs：SFX固定。
	int32_t seId_Flick;

	// NAME: 【曲射】発射仰角制限_下限[deg]
	// DESC: 【曲射】曲射計算の適用前の発射仰角を基準(0deg)とした下限[deg]。
	int16_t howitzerShootAngleXMin;

	// NAME: 【曲射】発射仰角制限_上限[deg]
	// DESC: 【曲射】曲射計算の適用前の発射仰角を基準(0deg)とした上限[deg]。
	int16_t howitzerShootAngleXMax;

	// NAME: 【曲射】最低制限速度[m/s]
	// DESC: 【曲射】曲射計算の最低制限速度[m/s]。
	float howitzerInitMinVelocity;

	// NAME: 【曲射】最高制限速度[m/s]
	// DESC: 【曲射】曲射計算の最高制限速度[m/s]。
	float howitzerInitMaxVelocity;

	// NAME: SFXID【強制消去時】
	// DESC: 強制消去時SFXID。-1は発生しない。
	int32_t sfxId_ForceErase;

	// NAME: 強制消去時の弾丸SFX消滅タイプ
	// DESC: 強制消去時の弾丸SFX消滅タイプ
	int8_t bulletSfxDeleteType_byForceErase;

	// NAME: パディング3
	// DESC: pad3
	uint8_t pad3[1];

	// NAME: 追従時SFX方向指定ダミポリ
	// DESC: 追従時SFX方向指定ダミポリ
	int16_t followDmypoly_forSfxPose;

	// NAME: ファンネル追従位置_半径[m]
	// DESC: ファンネル追従位置_半径[m]
	float followOffset_Radius;

	// NAME: 特殊効果飛距離補正倍率
	// DESC: 特殊効果飛距離補正倍率
	float spBulletDistUpRate;

	// NAME: 非ロック時ターゲット射程距離[m]
	// DESC: 非ロック時ターゲット射程距離（-1：「射程距離」を参照する、0：ターゲットなし）
	float nolockTargetDist;

	// NAME: pad
	uint8_t pad4[8];
} BULLET_PARAM_ST;

#endif
