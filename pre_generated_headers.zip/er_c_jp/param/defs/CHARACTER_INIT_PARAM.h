/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CHARACTER_INIT_PARAM_H
#define _PARAMDEF_CHARACTER_INIT_PARAM_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CHARACTER_INIT_PARAM {

	// NAME: ＭＰ回復速度基本値[s]
	// DESC: ＭＰが、1ポイント回復するまでの時間（小数点第一位）
	float baseRec_mp;

	// NAME: スタミナ回復速度基本値[s]
	// DESC: スタミナが、1ポイント回復するまでの時間（小数点第一位）
	float baseRec_sp;

	// NAME: 落下ダメージ軽減補正[%]
	// DESC: 他のキャラクターに上からのしかかれたときに、クッションとなりえるダメージ軽減量（％）（小数点第一位）
	float red_Falldam;

	// NAME: 初期ソウル
	// DESC: 初期に所持しているソウル量
	int32_t soul;

	// NAME: 右手武器スロット1
	// DESC: 装備品パラメータの武器ＩＤ(右手スロット１)
	int32_t equip_Wep_Right;

	// NAME: 右手武器スロット2
	// DESC: 装備品パラメータの武器ＩＤ(右手スロット２)
	int32_t equip_Subwep_Right;

	// NAME: 左手武器スロット1
	// DESC: 装備品パラメータの武器ＩＤ(左手スロット１)
	int32_t equip_Wep_Left;

	// NAME: 左手武器スロット2
	// DESC: 装備品パラメータの武器ＩＤ(左手スロット２)
	int32_t equip_Subwep_Left;

	// NAME: 頭防具
	// DESC: 装備品パラメータの防具ＩＤ(頭防具)
	int32_t equip_Helm;

	// NAME: 胴体防具
	// DESC: 装備品パラメータの防具ＩＤ(胴体防具)
	int32_t equip_Armer;

	// NAME: 腕防具
	// DESC: 装備品パラメータの防具ＩＤ(腕防具)
	int32_t equip_Gaunt;

	// NAME: 脚防具
	// DESC: 装備品パラメータの防具ＩＤ(脚防具)
	int32_t equip_Leg;

	// NAME: 矢
	// DESC: 装備品パラメータの武器ＩＤ(矢)
	int32_t equip_Arrow;

	// NAME: ボルト
	// DESC: 装備品パラメータの武器ＩＤ(ボルト)
	int32_t equip_Bolt;

	// NAME: 予備矢
	// DESC: 装備品パラメータの武器ＩＤ(矢予備)
	int32_t equip_SubArrow;

	// NAME: 予備ボルト
	// DESC: 装備品パラメータの武器ＩＤ(ボルト予備)
	int32_t equip_SubBolt;

	// NAME: 装飾品1
	// DESC: 装備品パラメータの装飾品ＩＤ01
	int32_t equip_Accessory01;

	// NAME: 装飾品2
	// DESC: 装備品パラメータの装飾品ＩＤ02
	int32_t equip_Accessory02;

	// NAME: 装飾品3
	// DESC: 装備品パラメータの装飾品ＩＤ03
	int32_t equip_Accessory03;

	// NAME: 装飾品4
	// DESC: 装備品パラメータの装飾品ＩＤ04
	int32_t equip_Accessory04;

	// NAME: pad
	// DESC: pad
	uint8_t pad8[4];

	// NAME: エリクサー用素材ID1
	// DESC: エリクサー用素材ID1
	int32_t elixir_material00;

	// NAME: エリクサー用素材ID2
	// DESC: エリクサー用素材ID2
	int32_t elixir_material01;

	// NAME: エリクサー用素材ID3
	// DESC: エリクサー用素材ID3
	int32_t elixir_material02;

	// NAME: 魔法・奇跡1
	// DESC: 初期配置の魔法・奇跡ID01
	int32_t equip_Spell_01;

	// NAME: 魔法・奇跡2
	// DESC: 初期配置の魔法・奇跡ID02
	int32_t equip_Spell_02;

	// NAME: 魔法・奇跡3
	// DESC: 初期配置の魔法・奇跡ID03
	int32_t equip_Spell_03;

	// NAME: 魔法・奇跡4
	// DESC: 初期配置の魔法・奇跡ID04
	int32_t equip_Spell_04;

	// NAME: 魔法・奇跡5
	// DESC: 初期配置の魔法・奇跡ID05
	int32_t equip_Spell_05;

	// NAME: 魔法・奇跡6
	// DESC: 初期配置の魔法・奇跡ID06
	int32_t equip_Spell_06;

	// NAME: 魔法・奇跡7
	// DESC: 初期配置の魔法・奇跡ID07
	int32_t equip_Spell_07;

	// NAME: アイテム01
	// DESC: 初期所持のアイテムID01
	int32_t item_01;

	// NAME: アイテム02
	// DESC: 初期所持のアイテムID02
	int32_t item_02;

	// NAME: アイテム03
	// DESC: 初期所持のアイテムID03
	int32_t item_03;

	// NAME: アイテム04
	// DESC: 初期所持のアイテムID04
	int32_t item_04;

	// NAME: アイテム05
	// DESC: 初期所持のアイテムID05
	int32_t item_05;

	// NAME: アイテム06
	// DESC: 初期所持のアイテムID06
	int32_t item_06;

	// NAME: アイテム07
	// DESC: 初期所持のアイテムID07
	int32_t item_07;

	// NAME: アイテム08
	// DESC: 初期所持のアイテムID08
	int32_t item_08;

	// NAME: アイテム09
	// DESC: 初期所持のアイテムID09
	int32_t item_09;

	// NAME: アイテム10
	// DESC: 初期所持のアイテムID10
	int32_t item_10;

	// NAME: フェイスジェンパラメータID
	// DESC: NPCプレイヤーで使用するフェイスジェンパラメータID。通常プレイヤーでは使用しません。
	int32_t npcPlayerFaceGenId;

	// NAME: NPCプレイヤーの思考ID
	// DESC: NPCプレイヤーで使用するNPC思考パラメータID。通常プレイヤーでは使用しません。
	int32_t npcPlayerThinkId;

	// NAME: ＨＰ基本値
	// DESC: ＨＰの基本値（実際は、計算式で補正される）
	uint16_t baseHp;

	// NAME: ＭＰ基本値
	// DESC: ＭＰの基本値（実際は、計算式で補正される）
	uint16_t baseMp;

	// NAME: スタミナ基本値
	// DESC: スタミナの基本値（実際は、計算式で補正される）
	uint16_t baseSp;

	// NAME: 矢の所持数
	// DESC: 矢の初期所持数
	uint16_t arrowNum;

	// NAME: ボルトの所持数
	// DESC: ボルトの初期所持数
	uint16_t boltNum;

	// NAME: 予備矢の所持数
	// DESC: 矢の初期所持数
	uint16_t subArrowNum;

	// NAME: 予備ボルトの所持数
	// DESC: ボルトの初期所持数
	uint16_t subBoltNum;

	// NAME: pad
	uint8_t pad4[6];

	// NAME: ソウルLv
	// DESC: 初期Lv
	int16_t soulLv;

	// NAME: 体力
	// DESC: 体力の基本値
	uint8_t baseVit;

	// NAME: 精神
	// DESC: 精神の基本値
	uint8_t baseWil;

	// NAME: 頑強
	// DESC: 頑強の基本値
	uint8_t baseEnd;

	// NAME: 筋力
	// DESC: 筋力の基本値
	uint8_t baseStr;

	// NAME: 俊敏
	// DESC: 俊敏の基本値
	uint8_t baseDex;

	// NAME: 魔力
	// DESC: 魔力の基本値
	uint8_t baseMag;

	// NAME: 信仰
	// DESC: 信仰の基本値
	uint8_t baseFai;

	// NAME: 運
	// DESC: 運の基本値
	uint8_t baseLuc;

	// NAME: 人間性
	// DESC: 人間性の基本値
	uint8_t baseHeroPoint;

	// NAME: 耐久力
	// DESC: 耐久力の基本値
	uint8_t baseDurability;

	// NAME: アイテム01の所持数
	// DESC: 初期所持のアイテム個数01
	uint8_t itemNum_01;

	// NAME: アイテム02の所持数
	// DESC: 初期所持のアイテム個数02
	uint8_t itemNum_02;

	// NAME: アイテム03の所持数
	// DESC: 初期所持のアイテム個数03
	uint8_t itemNum_03;

	// NAME: アイテム個数04
	// DESC: 初期所持のアイテム個数04
	uint8_t itemNum_04;

	// NAME: アイテム個数05
	// DESC: 初期所持のアイテム個数05
	uint8_t itemNum_05;

	// NAME: アイテム個数06
	// DESC: 初期所持のアイテム個数06
	uint8_t itemNum_06;

	// NAME: アイテム個数07
	// DESC: 初期所持のアイテム個数07
	uint8_t itemNum_07;

	// NAME: アイテム個数08
	// DESC: 初期所持のアイテム個数08
	uint8_t itemNum_08;

	// NAME: アイテム個数09
	// DESC: 初期所持のアイテム個数09
	uint8_t itemNum_09;

	// NAME: アイテム個数10
	// DESC: 初期所持のアイテム個数10
	uint8_t itemNum_10;

	// NAME: pad
	uint8_t pad5[5];

	// NAME: ジェスチャーID0
	// DESC: ジェスチャー0番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId0;

	// NAME: ジェスチャーID1
	// DESC: ジェスチャー1番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId1;

	// NAME: ジェスチャーID2
	// DESC: ジェスチャー2番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId2;

	// NAME: ジェスチャーID3
	// DESC: ジェスチャー3番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId3;

	// NAME: ジェスチャーID4
	// DESC: ジェスチャー4番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId4;

	// NAME: ジェスチャーID5
	// DESC: ジェスチャー5番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId5;

	// NAME: ジェスチャーID6
	// DESC: ジェスチャー6番目(EzStateのジェスチャー0を再生したいなら0)
	int8_t gestureId6;

	// NAME: NPCプレイヤーのNPCタイプ
	// DESC: NPCプレイヤーで使用するNPCタイプ。通常プレイヤーでは使用しません。
	uint8_t npcPlayerType;

	// NAME: NPCプレイヤーの描画タイプ
	// DESC: NPCプレイヤーで使用する描画タイプ。通常プレイヤーでは使用しません。
	int8_t npcPlayerDrawType;

	// NAME: NPCプレイヤーの性別
	// DESC: NPCプレイヤーで使用する性別です。通常プレイヤーには反映しません。
	uint8_t npcPlayerSex;

	// NAME: 誓約
	// DESC: 誓約タイプ(なし：0)
	uint8_t vowType: 4;

	// NAME: 送受信対象か
	// DESC: 送受信対象か（コピーNPC用）
	uint8_t isSyncTarget: 1;

	// NAME: pad
	uint8_t pad: 3;

	// NAME: pad
	uint8_t pad6[2];

	// NAME: 右手武器スロット1装備タイプ
	// DESC: 右手武器スロット１のパラメータ参照先
	uint8_t wepParamType_Right1;

	// NAME: 右手武器スロット2装備タイプ
	// DESC: 右手武器スロット２のパラメータ参照先
	uint8_t wepParamType_Right2;

	// NAME: 右手武器スロット3装備タイプ
	// DESC: 右手武器スロット３のパラメータ参照先
	uint8_t wepParamType_Right3;

	// NAME: 左手武器スロット1装備タイプ
	// DESC: 左手武器スロット１のパラメータ参照先
	uint8_t wepParamType_Left1;

	// NAME: 左手武器スロット2装備タイプ
	// DESC: 左手武器スロット２のパラメータ参照先
	uint8_t wepParamType_Left2;

	// NAME: 左手武器スロット3装備タイプ
	// DESC: 左手武器スロット３のパラメータ参照先
	uint8_t wepParamType_Left3;

	// NAME: pad
	uint8_t pad2[26];

	// NAME: 右手武器スロット3
	// DESC: 装備品パラメータの武器ＩＤ(右手スロット３)
	int32_t equip_Subwep_Right3;

	// NAME: 左手武器スロット3
	// DESC: 装備品パラメータの武器ＩＤ(左手スロット３)
	int32_t equip_Subwep_Left3;

	// NAME: pad
	uint8_t pad3[4];

	// NAME: 第二アイテム01
	// DESC: 第二ショートカット初期所持のアイテムID01
	int32_t secondaryItem_01;

	// NAME: 第二アイテム02
	// DESC: 第二ショートカット初期所持のアイテムID02
	int32_t secondaryItem_02;

	// NAME: 第二アイテム03
	// DESC: 第二ショートカット初期所持のアイテムID03
	int32_t secondaryItem_03;

	// NAME: 第二アイテム04
	// DESC: 第二ショートカット初期所持のアイテムID04
	int32_t secondaryItem_04;

	// NAME: 第二アイテム05
	// DESC: 第二ショートカット初期所持のアイテムID05
	int32_t secondaryItem_05;

	// NAME: 第二アイテム06
	// DESC: 第二ショートカット初期所持のアイテムID06
	int32_t secondaryItem_06;

	// NAME: 第二アイテム01の所持数
	// DESC: 第二ショートカット初期所持のアイテム個数01
	uint8_t secondaryItemNum_01;

	// NAME: 第二アイテム02の所持数
	// DESC: 第二ショートカット初期所持のアイテム個数02
	uint8_t secondaryItemNum_02;

	// NAME: 第二アイテム03の所持数
	// DESC: 第二ショートカット初期所持のアイテム個数03
	uint8_t secondaryItemNum_03;

	// NAME: 第二アイテム04の所持数
	// DESC: 第二ショートカット初期所持のアイテム個数04
	uint8_t secondaryItemNum_04;

	// NAME: 第二アイテム05の所持数
	// DESC: 第二ショートカット初期所持のアイテム個数05
	uint8_t secondaryItemNum_05;

	// NAME: 第二アイテム06の所持数
	// DESC: 第二ショートカット初期所持のアイテム個数06
	uint8_t secondaryItemNum_06;

	// NAME: HPエスト瓶 所持限界数
	// DESC: HPエスト瓶 所持限界数
	int8_t HpEstMax;

	// NAME: MPエスト瓶 所持限界数
	// DESC: MPエスト瓶 所持限界数
	int8_t MpEstMax;

	// NAME: pad
	uint8_t pad7[5];

	// NAME: 声タイプ
	// DESC: 声タイプ
	uint8_t voiceType;

	// NAME: 予約領域
	// DESC: 予約領域
	uint8_t reserve[6];
} CHARACTER_INIT_PARAM;

#endif
