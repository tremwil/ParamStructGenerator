/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_HIT_EFFECT_SE_PARAM_ST_H
#define _PARAMDEF_HIT_EFFECT_SE_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _HIT_EFFECT_SE_PARAM_ST {

	// NAME: 鉄製：斬撃：小
	// DESC: 鉄製：斬撃：小
	int32_t Iron_Slash_S;

	// NAME: 鉄製：斬撃：大
	// DESC: 鉄製：斬撃：大
	int32_t Iron_Slash_L;

	// NAME: 鉄製：斬撃：特大
	// DESC: 鉄製：斬撃：特大
	int32_t Iron_Slash_LL;

	// NAME: 鉄製：刺突：小
	// DESC: 鉄製：刺突：小
	int32_t Iron_Thrust_S;

	// NAME: 鉄製：刺突：大
	// DESC: 鉄製：刺突：大
	int32_t Iron_Thrust_L;

	// NAME: 鉄製：刺突：特大
	// DESC: 鉄製：刺突：特大
	int32_t Iron_Thrust_LL;

	// NAME: 鉄製：打撃：小
	// DESC: 鉄製：打撃：小
	int32_t Iron_Blow_S;

	// NAME: 鉄製：打撃：大
	// DESC: 鉄製：打撃：大
	int32_t Iron_Blow_L;

	// NAME: 鉄製：打撃：特大
	// DESC: 鉄製：打撃：特大
	int32_t Iron_Blow_LL;

	// NAME: 炎：斬撃：小
	// DESC: 炎：斬撃：小
	int32_t Fire_Slash_S;

	// NAME: 炎：斬撃：大
	// DESC: 炎：斬撃：大
	int32_t Fire_Slash_L;

	// NAME: 炎：斬撃：特大
	// DESC: 炎：斬撃：特大
	int32_t Fire_Slash_LL;

	// NAME: 炎：刺突：小
	// DESC: 炎：刺突：小
	int32_t Fire_Thrust_S;

	// NAME: 炎：刺突：大
	// DESC: 炎：刺突：大
	int32_t Fire_Thrust_L;

	// NAME: 炎：刺突：特大
	// DESC: 炎：刺突：特大
	int32_t Fire_Thrust_LL;

	// NAME: 炎：打撃：小
	// DESC: 炎：打撃：小
	int32_t Fire_Blow_S;

	// NAME: 炎：打撃：大
	// DESC: 炎：打撃：大
	int32_t Fire_Blow_L;

	// NAME: 炎：打撃：特大
	// DESC: 炎：打撃：特大
	int32_t Fire_Blow_LL;

	// NAME: 木製：斬撃：小
	// DESC: 木製：斬撃：小
	int32_t Wood_Slash_S;

	// NAME: 木製：斬撃：大
	// DESC: 木製：斬撃：大
	int32_t Wood_Slash_L;

	// NAME: 木製：斬撃：特大
	// DESC: 木製：斬撃：特大
	int32_t Wood_Slash_LL;

	// NAME: 木製：刺突：小
	// DESC: 木製：刺突：小
	int32_t Wood_Thrust_S;

	// NAME: 木製：刺突：大
	// DESC: 木製：刺突：大
	int32_t Wood_Thrust_L;

	// NAME: 木製：刺突：特大
	// DESC: 木製：刺突：特大
	int32_t Wood_Thrust_LL;

	// NAME: 木製：打撃：小
	// DESC: 木製：打撃：小
	int32_t Wood_Blow_S;

	// NAME: 木製：打撃：大
	// DESC: 木製：打撃：大
	int32_t Wood_Blow_L;

	// NAME: 木製：打撃：特大
	// DESC: 木製：打撃：特大
	int32_t Wood_Blow_LL;

	// NAME: 肉：斬撃：小
	// DESC: 肉：斬撃：小
	int32_t Body_Slash_S;

	// NAME: 肉：斬撃：大
	// DESC: 肉：斬撃：大
	int32_t Body_Slash_L;

	// NAME: 肉：斬撃：特大
	// DESC: 肉：斬撃：特大
	int32_t Body_Slash_LL;

	// NAME: 肉：刺突：小
	// DESC: 肉：刺突：小
	int32_t Body_Thrust_S;

	// NAME: 肉：刺突：大
	// DESC: 肉：刺突：大
	int32_t Body_Thrust_L;

	// NAME: 肉：刺突：特大
	// DESC: 肉：刺突：特大
	int32_t Body_Thrust_LL;

	// NAME: 肉：打撃：小
	// DESC: 肉：打撃：小
	int32_t Body_Blow_S;

	// NAME: 肉：打撃：大
	// DESC: 肉：打撃：大
	int32_t Body_Blow_L;

	// NAME: 肉：打撃：特大
	// DESC: 肉：打撃：特大
	int32_t Body_Blow_LL;

	// NAME: 蝕：斬撃：小
	// DESC: 蝕：斬撃：小
	int32_t Eclipse_Slash_S;

	// NAME: 蝕：斬撃：大
	// DESC: 蝕：斬撃：大
	int32_t Eclipse_Slash_L;

	// NAME: 蝕：斬撃：特大
	// DESC: 蝕：斬撃：特大
	int32_t Eclipse_Slash_LL;

	// NAME: 蝕：刺突：小
	// DESC: 蝕：刺突：小
	int32_t Eclipse_Thrust_S;

	// NAME: 蝕：刺突：大
	// DESC: 蝕：刺突：大
	int32_t Eclipse_Thrust_L;

	// NAME: 蝕：刺突：特大
	// DESC: 蝕：刺突：特大
	int32_t Eclipse_Thrust_LL;

	// NAME: 蝕：打撃：小
	// DESC: 蝕：打撃：小
	int32_t Eclipse_Blow_S;

	// NAME: 蝕：打撃：大
	// DESC: 蝕：打撃：大
	int32_t Eclipse_Blow_L;

	// NAME: 蝕：打撃：特大
	// DESC: 蝕：打撃：特大
	int32_t Eclipse_Blow_LL;

	// NAME: エネルギー：斬撃：小
	// DESC: エネルギー：斬撃：小
	int32_t Energy_Slash_S;

	// NAME: エネルギー：斬撃：大
	// DESC: エネルギー：斬撃：大
	int32_t Energy_Slash_L;

	// NAME: エネルギー：斬撃：特大
	// DESC: エネルギー：斬撃：特大
	int32_t Energy_Slash_LL;

	// NAME: エネルギー：刺突：小
	// DESC: エネルギー：刺突：小
	int32_t Energy_Thrust_S;

	// NAME: エネルギー：刺突：大
	// DESC: エネルギー：刺突：大
	int32_t Energy_Thrust_L;

	// NAME: エネルギー：刺突：特大
	// DESC: エネルギー：刺突：特大
	int32_t Energy_Thrust_LL;

	// NAME: エネルギー：打撃：小
	// DESC: エネルギー：打撃：小
	int32_t Energy_Blow_S;

	// NAME: エネルギー：打撃：大
	// DESC: エネルギー：打撃：大
	int32_t Energy_Blow_L;

	// NAME: エネルギー：打撃：特大
	// DESC: エネルギー：打撃：特大
	int32_t Energy_Blow_LL;

	// NAME: なし：斬撃：小
	// DESC: なし：斬撃：小
	int32_t None_Slash_S;

	// NAME: なし：斬撃：大
	// DESC: なし：斬撃：大
	int32_t None_Slash_L;

	// NAME: なし：斬撃：特大
	// DESC: なし：斬撃：特大
	int32_t None_Slash_LL;

	// NAME: なし：刺突：小
	// DESC: なし：刺突：小
	int32_t None_Thrust_S;

	// NAME: なし：刺突：大
	// DESC: なし：刺突：大
	int32_t None_Thrust_L;

	// NAME: なし：刺突：特大
	// DESC: なし：刺突：特大
	int32_t None_Thrust_LL;

	// NAME: なし：打撃：小
	// DESC: なし：打撃：小
	int32_t None_Blow_S;

	// NAME: なし：打撃：大
	// DESC: なし：打撃：大
	int32_t None_Blow_L;

	// NAME: なし：打撃：特大
	// DESC: なし：打撃：特大
	int32_t None_Blow_LL;

	// NAME: Dmy1：斬撃：小
	// DESC: Dmy1：斬撃：小
	int32_t Dmy1_Slash_S;

	// NAME: Dmy1：斬撃：大
	// DESC: Dmy1：斬撃：大
	int32_t Dmy1_Slash_L;

	// NAME: Dmy1：斬撃：特大
	// DESC: Dmy1：斬撃：特大
	int32_t Dmy1_Slash_LL;

	// NAME: Dmy1：刺突：小
	// DESC: Dmy1：刺突：小
	int32_t Dmy1_Thrust_S;

	// NAME: Dmy1：刺突：大
	// DESC: Dmy1：刺突：大
	int32_t Dmy1_Thrust_L;

	// NAME: Dmy1：刺突：特大
	// DESC: Dmy1：刺突：特大
	int32_t Dmy1_Thrust_LL;

	// NAME: Dmy1：打撃：小
	// DESC: Dmy1：打撃：小
	int32_t Dmy1_Blow_S;

	// NAME: Dmy1：打撃：大
	// DESC: Dmy1：打撃：大
	int32_t Dmy1_Blow_L;

	// NAME: Dmy1：打撃：特大
	// DESC: Dmy1：打撃：特大
	int32_t Dmy1_Blow_LL;

	// NAME: Dmy2：斬撃：小
	// DESC: Dmy2：斬撃：小
	int32_t Dmy2_Slash_S;

	// NAME: Dmy2：斬撃：大
	// DESC: Dmy2：斬撃：大
	int32_t Dmy2_Slash_L;

	// NAME: Dmy2：斬撃：特大
	// DESC: Dmy2：斬撃：特大
	int32_t Dmy2_Slash_LL;

	// NAME: Dmy2：刺突：小
	// DESC: Dmy2：刺突：小
	int32_t Dmy2_Thrust_S;

	// NAME: Dmy2：刺突：大
	// DESC: Dmy2：刺突：大
	int32_t Dmy2_Thrust_L;

	// NAME: Dmy2：刺突：特大
	// DESC: Dmy2：刺突：特大
	int32_t Dmy2_Thrust_LL;

	// NAME: Dmy2：打撃：小
	// DESC: Dmy2：打撃：小
	int32_t Dmy2_Blow_S;

	// NAME: Dmy2：打撃：大
	// DESC: Dmy2：打撃：大
	int32_t Dmy2_Blow_L;

	// NAME: Dmy2：打撃：特大
	// DESC: Dmy2：打撃：特大
	int32_t Dmy2_Blow_LL;

	// NAME: Dmy3：斬撃：小
	// DESC: Dmy3：斬撃：小
	int32_t Dmy3_Slash_S;

	// NAME: Dmy3：斬撃：大
	// DESC: Dmy3：斬撃：大
	int32_t Dmy3_Slash_L;

	// NAME: Dmy3：斬撃：特大
	// DESC: Dmy3：斬撃：特大
	int32_t Dmy3_Slash_LL;

	// NAME: Dmy3：刺突：小
	// DESC: Dmy3：刺突：小
	int32_t Dmy3_Thrust_S;

	// NAME: Dmy3：刺突：大
	// DESC: Dmy3：刺突：大
	int32_t Dmy3_Thrust_L;

	// NAME: Dmy3：刺突：特大
	// DESC: Dmy3：刺突：特大
	int32_t Dmy3_Thrust_LL;

	// NAME: Dmy3：打撃：小
	// DESC: Dmy3：打撃：小
	int32_t Dmy3_Blow_S;

	// NAME: Dmy3：打撃：大
	// DESC: Dmy3：打撃：大
	int32_t Dmy3_Blow_L;

	// NAME: Dmy3：打撃：特大
	// DESC: Dmy3：打撃：特大
	int32_t Dmy3_Blow_LL;

	// NAME: うじ：斬撃：小
	// DESC: うじ：斬撃：小
	int32_t Maggot_Slash_S;

	// NAME: うじ：斬撃：大
	// DESC: うじ：斬撃：大
	int32_t Maggot_Slash_L;

	// NAME: うじ：斬撃：特大
	// DESC: うじ：斬撃：特大
	int32_t Maggot_Slash_LL;

	// NAME: うじ：刺突：小
	// DESC: うじ：刺突：小
	int32_t Maggot_Thrust_S;

	// NAME: うじ：刺突：大
	// DESC: うじ：刺突：大
	int32_t Maggot_Thrust_L;

	// NAME: うじ：刺突：特大
	// DESC: うじ：刺突：特大
	int32_t Maggot_Thrust_LL;

	// NAME: うじ：打撃：小
	// DESC: うじ：打撃：小
	int32_t Maggot_Blow_S;

	// NAME: うじ：打撃：大
	// DESC: うじ：打撃：大
	int32_t Maggot_Blow_L;

	// NAME: うじ：打撃：特大
	// DESC: うじ：打撃：特大
	int32_t Maggot_Blow_LL;

	// NAME: 蝋：斬撃：小
	// DESC: 蝋：斬撃：小
	int32_t Wax_Slash_S;

	// NAME: 蝋：斬撃：大
	// DESC: 蝋：斬撃：大
	int32_t Wax_Slash_L;

	// NAME: 蝋：斬撃：特大
	// DESC: 蝋：斬撃：特大
	int32_t Wax_Slash_LL;

	// NAME: 蝋：刺突：小
	// DESC: 蝋：刺突：小
	int32_t Wax_Thrust_S;

	// NAME: 蝋：刺突：大
	// DESC: 蝋：刺突：大
	int32_t Wax_Thrust_L;

	// NAME: 蝋：刺突：特大
	// DESC: 蝋：刺突：特大
	int32_t Wax_Thrust_LL;

	// NAME: 蝋：打撃：小
	// DESC: 蝋：打撃：小
	int32_t Wax_Blow_S;

	// NAME: 蝋：打撃：大
	// DESC: 蝋：打撃：大
	int32_t Wax_Blow_L;

	// NAME: 蝋：打撃：特大
	// DESC: 蝋：打撃：特大
	int32_t Wax_Blow_LL;

	// NAME: 炎上：斬撃：小
	// DESC: 炎上：斬撃：小
	int32_t FireFlame_Slash_S;

	// NAME: 炎上：斬撃：大
	// DESC: 炎上：斬撃：大
	int32_t FireFlame_Slash_L;

	// NAME: 炎上：斬撃：特大
	// DESC: 炎上：斬撃：特大
	int32_t FireFlame_Slash_LL;

	// NAME: 炎上：刺突：小
	// DESC: 炎上：刺突：小
	int32_t FireFlame_Thrust_S;

	// NAME: 炎上：刺突：大
	// DESC: 炎上：刺突：大
	int32_t FireFlame_Thrust_L;

	// NAME: 炎上：刺突：特大
	// DESC: 炎上：刺突：特大
	int32_t FireFlame_Thrust_LL;

	// NAME: 炎上：打撃：小
	// DESC: 炎上：打撃：小
	int32_t FireFlame_Blow_S;

	// NAME: 炎上：打撃：大
	// DESC: 炎上：打撃：大
	int32_t FireFlame_Blow_L;

	// NAME: 炎上：打撃：特大
	// DESC: 炎上：打撃：特大
	int32_t FireFlame_Blow_LL;

	// NAME: 蝕：気体：斬撃：小
	// DESC: 蝕：気体：斬撃：小
	int32_t EclipseGas_Slash_S;

	// NAME: 蝕：気体：斬撃：大
	// DESC: 蝕：気体：斬撃：大
	int32_t EclipseGas_Slash_L;

	// NAME: 蝕：気体：斬撃：特大
	// DESC: 蝕：気体：斬撃：特大
	int32_t EclipseGas_Slash_LL;

	// NAME: 蝕：気体：刺突：小
	// DESC: 蝕：気体：刺突：小
	int32_t EclipseGas_Thrust_S;

	// NAME: 蝕：気体：刺突：大
	// DESC: 蝕：気体：刺突：大
	int32_t EclipseGas_Thrust_L;

	// NAME: 蝕：気体：刺突：特大
	// DESC: 蝕：気体：刺突：特大
	int32_t EclipseGas_Thrust_LL;

	// NAME: 蝕：気体：打撃：小
	// DESC: 蝕：気体：打撃：小
	int32_t EclipseGas_Blow_S;

	// NAME: 蝕：気体：打撃：大
	// DESC: 蝕：気体：打撃：大
	int32_t EclipseGas_Blow_L;

	// NAME: 蝕：気体：打撃：特大
	// DESC: 蝕：気体：打撃：特大
	int32_t EclipseGas_Blow_LL;

	// NAME: エネルギー（強）：斬撃：小
	// DESC: エネルギー（強）：斬撃：小
	int32_t EnergyStrong_Slash_S;

	// NAME: エネルギー（強）：斬撃：大
	// DESC: エネルギー（強）：斬撃：大
	int32_t EnergyStrong_Slash_L;

	// NAME: エネルギー（強）：斬撃：特大
	// DESC: エネルギー（強）：斬撃：特大
	int32_t EnergyStrong_Slash_LL;

	// NAME: エネルギー（強）：刺突：小
	// DESC: エネルギー（強）：刺突：小
	int32_t EnergyStrong_Thrust_S;

	// NAME: エネルギー（強）：刺突：大
	// DESC: エネルギー（強）：刺突：大
	int32_t EnergyStrong_Thrust_L;

	// NAME: エネルギー（強）：刺突：特大
	// DESC: エネルギー（強）：刺突：特大
	int32_t EnergyStrong_Thrust_LL;

	// NAME: エネルギー（強）：打撃：小
	// DESC: エネルギー（強）：打撃：小
	int32_t EnergyStrong_Blow_S;

	// NAME: エネルギー（強）：打撃：大
	// DESC: エネルギー（強）：打撃：大
	int32_t EnergyStrong_Blow_L;

	// NAME: エネルギー（強）：打撃：特大
	// DESC: エネルギー（強）：打撃：特大
	int32_t EnergyStrong_Blow_LL;

	// NAME: 予約領域
	// DESC: 予約領域
	uint8_t reserve[100];
} HIT_EFFECT_SE_PARAM_ST;

#endif
