/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_ENEMY_COMMON_PARAM_ST_H
#define _PARAMDEF_ENEMY_COMMON_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ENEMY_COMMON_PARAM_ST {

	// NAME: 予約
	// DESC: (dummy8)
	uint8_t reserved0[8];

	// NAME: 音ターゲットに対して接近を試みる時間
	int32_t soundTargetTryApproachTime;

	// NAME: 索敵ターゲットに対して接近を試みる時間
	int32_t searchTargetTryApproachTime;

	// NAME: 記憶ターゲットに対して接近を試みる時間
	int32_t memoryTargetTryApproachTime;

	// NAME: 予約
	// DESC: (dummy8)
	uint8_t reserved5[40];

	// NAME: 特定時間帯配置のエネミーの出現・消滅に演出に使うファントムシェーダID
	// DESC: 出現・消滅の演出でファントムシェーダをフェイドする、
	int32_t activateChrByTime_PhantomId;

	// NAME: パス終端まで行くと敵が見切れそうなことがわかったインタラプト、を発生させる距離
	// DESC: Unreachパス時、終端と対象がこの距離以内ならインタラプトを発生させる
	float findUnfavorableFailedPointDist;

	// NAME: パス終端まで行くと敵が見切れそうなことがわかったインタラプト、を発生させる高さ
	// DESC: Unreachパス時、終端と対象がこの距離以上ならインタラプトを発生させる
	float findUnfavorableFailedPointHeight;

	// NAME: 予約
	// DESC: (dummy8)
	uint8_t reserved18[184];
} ENEMY_COMMON_PARAM_ST;

#endif
