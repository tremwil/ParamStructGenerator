/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_ITEMLOT_PARAM_ST_H
#define _PARAMDEF_ITEMLOT_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 4
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ITEMLOT_PARAM_ST {

	// NAME: １：アイテムID
	// DESC: 取得できるアイテムのID
	int32_t lotItemId01;

	// NAME: ２：アイテムID
	// DESC: 取得できるアイテムのID
	int32_t lotItemId02;

	// NAME: ３：アイテムID
	// DESC: 取得できるアイテムのID
	int32_t lotItemId03;

	// NAME: ４：アイテムID
	// DESC: 取得できるアイテムのID
	int32_t lotItemId04;

	// NAME: ５：アイテムID
	// DESC: 取得できるアイテムのID
	int32_t lotItemId05;

	// NAME: ６：アイテムID
	// DESC: 取得できるアイテムのID
	int32_t lotItemId06;

	// NAME: ７：アイテムID
	// DESC: 取得できるアイテムのID
	int32_t lotItemId07;

	// NAME: ８：アイテムID
	// DESC: 取得できるアイテムのID
	int32_t lotItemId08;

	// NAME: １：アイテムカテゴリ
	// DESC: 取得できるアイテムのカテゴリ
	int32_t lotItemCategory01;

	// NAME: ２：アイテムカテゴリ
	// DESC: 取得できるアイテムのカテゴリ
	int32_t lotItemCategory02;

	// NAME: ３：アイテムカテゴリ
	// DESC: 取得できるアイテムのカテゴリ
	int32_t lotItemCategory03;

	// NAME: ４：アイテムカテゴリ
	// DESC: 取得できるアイテムのカテゴリ
	int32_t lotItemCategory04;

	// NAME: ５：アイテムカテゴリ
	// DESC: 取得できるアイテムのカテゴリ
	int32_t lotItemCategory05;

	// NAME: ６：アイテムカテゴリ
	// DESC: 取得できるアイテムのカテゴリ
	int32_t lotItemCategory06;

	// NAME: ７：アイテムカテゴリ
	// DESC: 取得できるアイテムのカテゴリ
	int32_t lotItemCategory07;

	// NAME: ８：アイテムカテゴリ
	// DESC: 取得できるアイテムのカテゴリ
	int32_t lotItemCategory08;

	// NAME: 基本出現ポイント
	// DESC: 通常時の出現ポイント
	uint16_t lotItemBasePoint01;

	// NAME: 基本出現ポイント
	// DESC: 通常時の出現ポイント
	uint16_t lotItemBasePoint02;

	// NAME: 基本出現ポイント
	// DESC: 通常時の出現ポイント
	uint16_t lotItemBasePoint03;

	// NAME: 基本出現ポイント
	// DESC: 通常時の出現ポイント
	uint16_t lotItemBasePoint04;

	// NAME: 基本出現ポイント
	// DESC: 通常時の出現ポイント
	uint16_t lotItemBasePoint05;

	// NAME: 基本出現ポイント
	// DESC: 通常時の出現ポイント
	uint16_t lotItemBasePoint06;

	// NAME: 基本出現ポイント
	// DESC: 通常時の出現ポイント
	uint16_t lotItemBasePoint07;

	// NAME: 基本出現ポイント
	// DESC: 通常時の出現ポイント
	uint16_t lotItemBasePoint08;

	// NAME: 累積後出現ポイント
	// DESC: 最大累積時の出現ポイント
	uint16_t cumulateLotPoint01;

	// NAME: 累積後出現ポイント
	// DESC: 最大累積時の出現ポイント
	uint16_t cumulateLotPoint02;

	// NAME: 累積後出現ポイント
	// DESC: 最大累積時の出現ポイント
	uint16_t cumulateLotPoint03;

	// NAME: 累積後出現ポイント
	// DESC: 最大累積時の出現ポイント
	uint16_t cumulateLotPoint04;

	// NAME: 累積後出現ポイント
	// DESC: 最大累積時の出現ポイント
	uint16_t cumulateLotPoint05;

	// NAME: 累積後出現ポイント
	// DESC: 最大累積時の出現ポイント
	uint16_t cumulateLotPoint06;

	// NAME: 累積後出現ポイント
	// DESC: 最大累積時の出現ポイント
	uint16_t cumulateLotPoint07;

	// NAME: 累積後出現ポイント
	// DESC: 最大累積時の出現ポイント
	uint16_t cumulateLotPoint08;

	// NAME: 別ザクザクフラグID
	// DESC: 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId01;

	// NAME: 別ザクザクフラグID
	// DESC: 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId02;

	// NAME: 別ザクザクフラグID
	// DESC: 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId03;

	// NAME: 別ザクザクフラグID
	// DESC: 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId04;

	// NAME: 別ザクザクフラグID
	// DESC: 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId05;

	// NAME: 別ザクザクフラグID
	// DESC: 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId06;

	// NAME: 別ザクザクフラグID
	// DESC: 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId07;

	// NAME: 別ザクザクフラグID
	// DESC: 取得済みフラグとザクザク枠兼用(0:共通使用)
	uint32_t getItemFlagId08;

	// NAME: ザクザクフラグID
	// DESC: 取得済みフラグとザクザク枠兼用(0:フラグ無効)
	uint32_t getItemFlagId;

	// NAME: 抽選累積保存フラグID
	// DESC: 抽選回数保存用(※8フラグ連番使用)
	uint32_t cumulateNumFlagId;

	// NAME: 抽選累積最大数
	// DESC: 抽選累積最大数(0:累積なし)
	uint8_t cumulateNumMax;

	// NAME: レア度上書き
	// DESC: 宝箱などに、どれくらい貴重なアイテムが入っているかを指定する。-1の時は上書きせず装備品パラのレア度を使用する
	int8_t lotItem_Rarity;

	// NAME: 個数
	// DESC: 取得できるアイテムの個数
	uint8_t lotItemNum01;

	// NAME: 個数
	// DESC: 取得できるアイテムの個数
	uint8_t lotItemNum02;

	// NAME: 個数
	// DESC: 取得できるアイテムの個数
	uint8_t lotItemNum03;

	// NAME: 個数
	// DESC: 取得できるアイテムの個数
	uint8_t lotItemNum04;

	// NAME: 個数
	// DESC: 取得できるアイテムの個数
	uint8_t lotItemNum05;

	// NAME: 個数
	// DESC: 取得できるアイテムの個数
	uint8_t lotItemNum06;

	// NAME: 個数
	// DESC: 取得できるアイテムの個数
	uint8_t lotItemNum07;

	// NAME: 個数
	// DESC: 取得できるアイテムの個数
	uint8_t lotItemNum08;

	// NAME: 運パラメータ有効
	// DESC: 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck01: 1;

	// NAME: 運パラメータ有効
	// DESC: 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck02: 1;

	// NAME: 運パラメータ有効
	// DESC: 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck03: 1;

	// NAME: 運パラメータ有効
	// DESC: 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck04: 1;

	// NAME: 運パラメータ有効
	// DESC: 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck05: 1;

	// NAME: 運パラメータ有効
	// DESC: 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck06: 1;

	// NAME: 運パラメータ有効
	// DESC: 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck07: 1;

	// NAME: 運パラメータ有効
	// DESC: 抽選の確率をプレイヤーの運を反映させるか
	uint16_t enableLuck08: 1;

	// NAME: 累積リセット
	// DESC: 累積リセットするか
	uint16_t cumulateReset01: 1;

	// NAME: 累積リセット
	// DESC: 累積リセットするか
	uint16_t cumulateReset02: 1;

	// NAME: 累積リセット
	// DESC: 累積リセットするか
	uint16_t cumulateReset03: 1;

	// NAME: 累積リセット
	// DESC: 累積リセットするか
	uint16_t cumulateReset04: 1;

	// NAME: 累積リセット
	// DESC: 累積リセットするか
	uint16_t cumulateReset05: 1;

	// NAME: 累積リセット
	// DESC: 累積リセットするか
	uint16_t cumulateReset06: 1;

	// NAME: 累積リセット
	// DESC: 累積リセットするか
	uint16_t cumulateReset07: 1;

	// NAME: 累積リセット
	// DESC: 累積リセットするか
	uint16_t cumulateReset08: 1;

	// NAME: X週目以降オフセット
	// DESC: 周回プレイ時のオフセット
	int8_t GameClearOffset;

	// NAME: 協力霊でも抽選するか
	// DESC: 自身が協力霊の時でも抽選するか
	uint8_t canExecByFriendlyGhost: 1;

	// NAME: 敵対霊でも抽選するか
	// DESC: 自身が敵対霊の時でも抽選するか
	uint8_t canExecByHostileGhost: 1;

	// NAME: PAD1
	// DESC: PAD1
	uint8_t PAD1: 6;

	// NAME: PAD2
	// DESC: PAD2
	uint16_t PAD2;
} ITEMLOT_PARAM_ST;

#endif
