/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_DOF_QUALITY_DETAIL_H
#define _PARAMDEF_CS_DOF_QUALITY_DETAIL_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_DOF_QUALITY_DETAIL {

	// NAME: DOF許可
	// DESC: DOF許可
	uint8_t enabled;

	// NAME: dmy
	uint8_t dmy[3];

	// NAME: HiResolutionBlur の設定を変更する
	// DESC: HiResolutionBlur の設定を変更する(-1:強制オフ、0:そのまま、1:強制オン)
	int32_t forceHiResoBlur;

	// NAME: 最大ブラーレベル
	// DESC: 最大ブラーレベル。2:最大、1:レベルを一段落とす、0:さらに精度を落とす
	int32_t maxBlurLevel;
} CS_DOF_QUALITY_DETAIL;

#endif
