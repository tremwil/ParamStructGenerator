/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CHR_ACTIVATE_CONDITION_PARAM_ST_H
#define _PARAMDEF_CHR_ACTIVATE_CONDITION_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CHR_ACTIVATE_CONDITION_PARAM_ST {

	// NAME: 出現条件_晴れ
	// DESC: 天候が「晴れ」のときに出現するか
	uint8_t weatherSunny: 1;

	// NAME: 出現条件_快晴
	// DESC: 天候が「快晴」のときに出現するか
	uint8_t weatherClearSky: 1;

	// NAME: 出現条件_薄曇り
	// DESC: 天候が「薄曇り」のときに出現するか
	uint8_t weatherWeakCloudy: 1;

	// NAME: 出現条件_曇り
	// DESC: 天候が「曇り」のときに出現するか
	uint8_t weatherCloudy: 1;

	// NAME: 出現条件_雨
	// DESC: 天候が「雨」のときに出現するか
	uint8_t weatherRain: 1;

	// NAME: 出現条件_豪雨
	// DESC: 天候が「豪雨」のときに出現するか
	uint8_t weatherHeavyRain: 1;

	// NAME: 出現条件_嵐
	// DESC: 天候が「嵐」のときに出現するか
	uint8_t weatherStorm: 1;

	// NAME: 出現条件_嵐（守護者の末裔との戦闘用）
	// DESC: 天候が「嵐（守護者の末裔との戦闘用）」のときに出現するか
	uint8_t weatherStormForBattle: 1;

	// NAME: 出現条件_雪
	// DESC: 天候が「雪」のときに出現するか
	uint8_t weatherSnow: 1;

	// NAME: 出現条件_大雪
	// DESC: 天候が「大雪」のときに出現するか
	uint8_t weatherHeavySnow: 1;

	// NAME: 出現条件_霧
	// DESC: 天候が「霧」のときに出現するか
	uint8_t weatherFog: 1;

	// NAME: 出現条件_濃霧
	// DESC: 天候が「濃霧」のときに出現するか
	uint8_t weatherHeavyFog: 1;

	// NAME: 出現条件_濃霧（雨）
	// DESC: 天候が「濃霧（雨）」のときに出現するか
	uint8_t weatherHeavyFogRain: 1;

	// NAME: 出現条件_砂嵐
	// DESC: 天候が「砂嵐」のときに出現するか
	uint8_t weatherSandStorm: 1;

	// NAME: pad
	uint8_t pad1: 2;

	// NAME: 出現開始インゲーム時間_時
	// DESC: 出現開始インゲーム時間_時
	uint8_t timeStartHour;

	// NAME: 出現開始インゲーム時間_分
	// DESC: 出現開始インゲーム時間_分
	uint8_t timeStartMin;

	// NAME: 出現終了インゲーム時間_時
	// DESC: 出現終了インゲーム時間_時
	uint8_t timeEndHour;

	// NAME: 出現終了インゲーム時間_分
	// DESC: 出現終了インゲーム時間_分
	uint8_t timeEndMin;

	// NAME: pad
	uint8_t pad2[2];
} CHR_ACTIVATE_CONDITION_PARAM_ST;

#endif
