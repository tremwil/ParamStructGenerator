/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_EQUIP_PARAM_GEM_ST_H
#define _PARAMDEF_EQUIP_PARAM_GEM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EQUIP_PARAM_GEM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: アイコンID
	// DESC: メニュー用アイコンID
	uint16_t iconId;

	// NAME: 魔石ランク
	// DESC: 魔石ランク
	int8_t rank;

	// NAME: ソートアイテム種別ID
	// DESC: ソートアイテム種別ID。ソート「アイテム種別順」にて、同じIDは同じグループとしてまとめて表示されます
	uint8_t sortGroupId;

	// NAME: 常駐特殊効果ID00
	// DESC: 特殊効果ID00
	int32_t spEffectId0;

	// NAME: 常駐特殊効果ID01
	// DESC: 特殊効果ID01
	int32_t spEffectId1;

	// NAME: 常駐特殊効果ID02
	// DESC: 特殊効果ID02
	int32_t spEffectId2;

	// NAME: アイテム入手チュートリアル判定フラグID
	// DESC: 初めてアイテム入手した時のチュートリアル用のイベントフラグID。アイテム入手時にフラグON。
	uint32_t itemGetTutorialFlagId;

	// NAME: 変化先アーツパラメータID
	// DESC: 変化先アーツパラメータのID
	int32_t swordArtsParamId;

	// NAME: 装着価格
	// DESC: 装着価格
	int32_t mountValue;

	// NAME: 売却価格
	// DESC: 売却価格
	int32_t sellValue;

	// NAME: 販売価格
	// DESC: 販売価格
	int32_t saleValue;

	// NAME: ソートID
	// DESC: ソートID(-1:集めない)
	int32_t sortId;

	// NAME: コンプトロフィーSEQ番号
	// DESC: コンプリート系トロフィのSEQ番号
	int16_t compTrophySedId;

	// NAME: トロフィーSEQ番号
	// DESC: トロフィーのSEQ番号
	int16_t trophySeqId;

	// NAME: 0
	// DESC: 設定可能武器属性ID0
	uint8_t configurableWepAttr00: 1;

	// NAME: 1
	// DESC: 設定可能武器属性ID1
	uint8_t configurableWepAttr01: 1;

	// NAME: 2
	// DESC: 設定可能武器属性ID2
	uint8_t configurableWepAttr02: 1;

	// NAME: 3
	// DESC: 設定可能武器属性ID3
	uint8_t configurableWepAttr03: 1;

	// NAME: 4
	// DESC: 設定可能武器属性ID4
	uint8_t configurableWepAttr04: 1;

	// NAME: 5
	// DESC: 設定可能武器属性ID5
	uint8_t configurableWepAttr05: 1;

	// NAME: 6
	// DESC: 設定可能武器属性ID6
	uint8_t configurableWepAttr06: 1;

	// NAME: 7
	// DESC: 設定可能武器属性ID7
	uint8_t configurableWepAttr07: 1;

	// NAME: 8
	// DESC: 設定可能武器属性ID8
	uint8_t configurableWepAttr08: 1;

	// NAME: 9
	// DESC: 設定可能武器属性ID9
	uint8_t configurableWepAttr09: 1;

	// NAME: 10
	// DESC: 設定可能武器属性ID10
	uint8_t configurableWepAttr10: 1;

	// NAME: 11
	// DESC: 設定可能武器属性ID11
	uint8_t configurableWepAttr11: 1;

	// NAME: 12
	// DESC: 設定可能武器属性ID12
	uint8_t configurableWepAttr12: 1;

	// NAME: 13
	// DESC: 設定可能武器属性ID13
	uint8_t configurableWepAttr13: 1;

	// NAME: 14
	// DESC: 設定可能武器属性ID14
	uint8_t configurableWepAttr14: 1;

	// NAME: 15
	// DESC: 設定可能武器属性ID15
	uint8_t configurableWepAttr15: 1;

	// NAME: レア度
	// DESC: アイテム取得ログで使うレア度
	uint8_t rarity;

	// NAME: 16
	// DESC: 設定可能武器属性ID16
	uint8_t configurableWepAttr16: 1;

	// NAME: 17
	// DESC: 設定可能武器属性ID17
	uint8_t configurableWepAttr17: 1;

	// NAME: 18
	// DESC: 設定可能武器属性ID18
	uint8_t configurableWepAttr18: 1;

	// NAME: 19
	// DESC: 設定可能武器属性ID19
	uint8_t configurableWepAttr19: 1;

	// NAME: 20
	// DESC: 設定可能武器属性ID20
	uint8_t configurableWepAttr20: 1;

	// NAME: 21
	// DESC: 設定可能武器属性ID21
	uint8_t configurableWepAttr21: 1;

	// NAME: 22
	// DESC: 設定可能武器属性ID22
	uint8_t configurableWepAttr22: 1;

	// NAME: 23
	// DESC: 設定可能武器属性ID23
	uint8_t configurableWepAttr23: 1;

	// NAME: 捨てれるか
	// DESC: アイテムを捨てれるか？TRUE=捨てれる
	uint8_t isDiscard: 1;

	// NAME: その場に置けるか
	// DESC: アイテムをその場に置けるか？TRUE=置ける
	uint8_t isDrop: 1;

	// NAME: 預けれるか
	// DESC: 倉庫に預けれるか
	uint8_t isDeposit: 1;

	// NAME: マルチドロップ共有禁止か
	// DESC: マルチドロップ共有禁止か
	uint8_t disableMultiDropShare: 1;

	// NAME: 取得ダイアログ表示条件
	// DESC: アイテム取得時にアイテム取得ダイアログに表示するか（未入力: newのみ）
	uint8_t showDialogCondType: 2;

	// NAME: 取得ログ表示条件
	// DESC: アイテム取得時にアイテム取得ログに表示するか（未入力: ○）
	uint8_t showLogCondType: 1;

	// NAME: pad
	// DESC: pad
	uint8_t pad: 1;

	// NAME: デフォルト武器属性ID
	// DESC: デフォルト武器属性ID。開放されてない武器属性でも装着可能になる
	uint8_t defaultWepAttr;

	// NAME: pad2
	// DESC: pad2
	uint8_t pad2[2];

	// NAME: 短剣
	// DESC: 「武器種別：短剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_Dagger: 1;

	// NAME: 直剣
	// DESC: 「武器種別：直剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SwordNormal: 1;

	// NAME: 大剣
	// DESC: 「武器種別：大剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SwordLarge: 1;

	// NAME: 特大剣
	// DESC: 「武器種別：特大剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SwordGigantic: 1;

	// NAME: 曲剣 
	// DESC: 「武器種別：曲剣 」に装着可能か。未入力は×になる
	uint8_t canMountWep_SaberNormal: 1;

	// NAME: 大曲剣
	// DESC: 「武器種別：大曲剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SaberLarge: 1;

	// NAME: 刀
	// DESC: 「武器種別：刀」に装着可能か。未入力は×になる
	uint8_t canMountWep_katana: 1;

	// NAME: 両刃剣
	// DESC: 「武器種別：両刃剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SwordDoubleEdge: 1;

	// NAME: 刺剣
	// DESC: 「武器種別：刺剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_SwordPierce: 1;

	// NAME: 大刺剣
	// DESC: 「武器種別：大刺剣」に装着可能か。未入力は×になる
	uint8_t canMountWep_RapierHeavy: 1;

	// NAME: 斧
	// DESC: 「武器種別：斧」に装着可能か。未入力は×になる
	uint8_t canMountWep_AxeNormal: 1;

	// NAME: 大斧
	// DESC: 「武器種別：大斧」に装着可能か。未入力は×になる
	uint8_t canMountWep_AxeLarge: 1;

	// NAME: 槌
	// DESC: 「武器種別：槌」に装着可能か。未入力は×になる
	uint8_t canMountWep_HammerNormal: 1;

	// NAME: 大槌
	// DESC: 「武器種別：大槌」に装着可能か。未入力は×になる
	uint8_t canMountWep_HammerLarge: 1;

	// NAME: フレイル
	// DESC: 「武器種別：フレイル」に装着可能か。未入力は×になる
	uint8_t canMountWep_Flail: 1;

	// NAME: 槍
	// DESC: 「武器種別：槍」に装着可能か。未入力は×になる
	uint8_t canMountWep_SpearNormal: 1;

	// NAME: 長槍
	// DESC: 「武器種別：長槍」に装着可能か。未入力は×になる
	uint8_t canMountWep_SpearLarge: 1;

	// NAME: 大槍
	// DESC: 「武器種別：大槍」に装着可能か。未入力は×になる
	uint8_t canMountWep_SpearHeavy: 1;

	// NAME: 斧槍
	// DESC: 「武器種別：斧槍」に装着可能か。未入力は×になる
	uint8_t canMountWep_SpearAxe: 1;

	// NAME: 鎌
	// DESC: 「武器種別：鎌」に装着可能か。未入力は×になる
	uint8_t canMountWep_Sickle: 1;

	// NAME: 拳
	// DESC: 「武器種別：拳」に装着可能か。未入力は×になる
	uint8_t canMountWep_Knuckle: 1;

	// NAME: 爪
	// DESC: 「武器種別：爪」に装着可能か。未入力は×になる
	uint8_t canMountWep_Claw: 1;

	// NAME: ムチ
	// DESC: 「武器種別：ムチ」に装着可能か。未入力は×になる
	uint8_t canMountWep_Whip: 1;

	// NAME: 特大斧槌
	// DESC: 「武器種別：特大斧槌」に装着可能か。未入力は×になる
	uint8_t canMountWep_AxhammerLarge: 1;

	// NAME: 小弓
	// DESC: 「武器種別：小弓」に装着可能か。未入力は×になる
	uint8_t canMountWep_BowSmall: 1;

	// NAME: 弓
	// DESC: 「武器種別：弓」に装着可能か。未入力は×になる
	uint8_t canMountWep_BowNormal: 1;

	// NAME: 大弓
	// DESC: 「武器種別：大弓」に装着可能か。未入力は×になる
	uint8_t canMountWep_BowLarge: 1;

	// NAME: クロスボウ
	// DESC: 「武器種別：クロスボウ」に装着可能か。未入力は×になる
	uint8_t canMountWep_ClossBow: 1;

	// NAME: バリスタ
	// DESC: 「武器種別：バリスタ」に装着可能か。未入力は×になる
	uint8_t canMountWep_Ballista: 1;

	// NAME: 杖
	// DESC: 「武器種別：杖」に装着可能か。未入力は×になる
	uint8_t canMountWep_Staff: 1;

	// NAME: 入れ墨
	// DESC: 「武器種別：入れ墨」に装着可能か。未入力は×になる
	uint8_t canMountWep_Sorcery: 1;

	// NAME: 聖印
	// DESC: 「武器種別：聖印」に装着可能か。未入力は×になる
	uint8_t canMountWep_Talisman: 1;

	// NAME: 小盾
	// DESC: 「武器種別：小盾」に装着可能か。未入力は×になる
	uint8_t canMountWep_ShieldSmall: 1;

	// NAME: 中盾
	// DESC: 「武器種別：中盾」に装着可能か。未入力は×になる
	uint8_t canMountWep_ShieldNormal: 1;

	// NAME: 大盾
	// DESC: 「武器種別：大盾」に装着可能か。未入力は×になる
	uint8_t canMountWep_ShieldLarge: 1;

	// NAME: 松明
	// DESC: 「武器種別：松明」に装着可能か。未入力は×になる
	uint8_t canMountWep_Torch: 1;

	// NAME: 予約領域（装着可能な武器種別か）
	// DESC: 装着可能な武器種別かの予約領域（全部で64bit分確保）
	uint8_t reserved_canMountWep: 4;

	// NAME: 予約領域（装着可能な武器種別か）
	// DESC: 装着可能な武器種別かの予約領域（全部で64bit分確保）
	uint8_t reserved2_canMountWep[3];

	// NAME: 効果テキストID00
	// DESC: 効果テキストID00(Gem_Effect)。ステータスに表示する魔石の効果テキスト
	int32_t spEffectMsgId0;

	// NAME: 効果テキストID01
	// DESC: 効果テキストID01(Gem_Effect)。ステータスに表示する魔石の効果テキスト
	int32_t spEffectMsgId1;

	// NAME: 攻撃ヒット時特殊効果ID00
	// DESC: 攻撃ヒット時用の特殊効果パラメータID
	int32_t spEffectId_forAtk0;

	// NAME: 攻撃ヒット時特殊効果ID01
	// DESC: 攻撃ヒット時用の特殊効果パラメータID
	int32_t spEffectId_forAtk1;

	// NAME: 攻撃ヒット時特殊効果ID02
	// DESC: 攻撃ヒット時用の特殊効果パラメータID
	int32_t spEffectId_forAtk2;

	// NAME: 対応武器種別上書きテキストID
	// DESC: 対応武器種別上書きテキストID(-1:上書きしない)[MenuText]
	int32_t mountWepTextId;

	// NAME: pad6
	uint8_t pad6[8];
} EQUIP_PARAM_GEM_ST;

#endif
