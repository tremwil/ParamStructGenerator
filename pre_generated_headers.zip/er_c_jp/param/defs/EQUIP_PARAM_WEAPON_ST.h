/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_EQUIP_PARAM_WEAPON_ST_H
#define _PARAMDEF_EQUIP_PARAM_WEAPON_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EQUIP_PARAM_WEAPON_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: 行動バリエーションID
	// DESC: 攻撃時に参照する行動パラメータIDを決定するときに使う
	int32_t behaviorVariationId;

	// NAME: ソートID
	// DESC: ソートID(-1:集めない)(プログラム内で強化レベルを加味するため s32 では７桁が限界)
	int32_t sortId;

	// NAME: 徘徊装備ID
	// DESC: 徘徊ゴースト用の差し替え装備ID.
	uint32_t wanderingEquipId;

	// NAME: 重量[kg]
	// DESC: 重量[kg].
	float weight;

	// NAME: 装備重量比率
	// DESC: 装備重量比率
	float weaponWeightRate;

	// NAME: 修理価格
	// DESC: 修理基本価格
	int32_t fixPrice;

	// NAME: 強化価格
	// DESC: 強化価格
	int32_t reinforcePrice;

	// NAME: 売却価格
	// DESC: 販売価格
	int32_t sellValue;

	// NAME: 筋力補正
	// DESC: キャラパラ補正値.
	float correctStrength;

	// NAME: 俊敏補正
	// DESC: キャラパラ補正値.
	float correctAgility;

	// NAME: 魔力補正
	// DESC: キャラパラ補正値.
	float correctMagic;

	// NAME: 信仰補正
	// DESC: キャラパラ補正値.
	float correctFaith;

	// NAME: ガード時物理攻撃カット率
	// DESC: ガード時のダメージカット率を各攻撃ごとに設定
	float physGuardCutRate;

	// NAME: ガード時魔法攻撃カット率
	// DESC: ガード攻撃でない場合は、0を入れる
	float magGuardCutRate;

	// NAME: ガード時炎攻撃力カット率
	// DESC: 炎攻撃をどれだけカットするか？
	float fireGuardCutRate;

	// NAME: ガード時電撃攻撃力カット率
	// DESC: 電撃攻撃をどれだけカットするか？
	float thunGuardCutRate;

	// NAME: 攻撃ヒット時特殊効果ID0
	// DESC: 武器に特殊効果を追加するときに登録する
	int32_t spEffectBehaviorId0;

	// NAME: 攻撃ヒット時特殊効果ID1
	// DESC: 武器に特殊効果を追加するときに登録する
	int32_t spEffectBehaviorId1;

	// NAME: 攻撃ヒット時特殊効果ID2
	// DESC: 武器に特殊効果を追加するときに登録する
	int32_t spEffectBehaviorId2;

	// NAME: 常駐特殊効果ID
	// DESC: 常駐特殊効果ID0
	int32_t residentSpEffectId;

	// NAME: 常駐特殊効果ID1
	// DESC: 常駐特殊効果ID1
	int32_t residentSpEffectId1;

	// NAME: 常駐特殊効果ID2
	// DESC: 常駐特殊効果ID2
	int32_t residentSpEffectId2;

	// NAME: 素材ID
	// DESC: 武器強化に必要な素材パラメータID
	int32_t materialSetId;

	// NAME: 派生元
	// DESC: この武器の強化元武器ID
	int32_t originEquipWep;

	// NAME: 派生元 強化+1
	// DESC: この武器の強化元武器ID1
	int32_t originEquipWep1;

	// NAME: 派生元 強化+2
	// DESC: この武器の強化元武器ID2
	int32_t originEquipWep2;

	// NAME: 派生元 強化+3
	// DESC: この武器の強化元武器ID3
	int32_t originEquipWep3;

	// NAME: 派生元 強化+4
	// DESC: この武器の強化元武器ID4
	int32_t originEquipWep4;

	// NAME: 派生元 強化+5
	// DESC: この武器の強化元武器ID5
	int32_t originEquipWep5;

	// NAME: 派生元 強化+6
	// DESC: この武器の強化元武器ID6
	int32_t originEquipWep6;

	// NAME: 派生元 強化+7
	// DESC: この武器の強化元武器ID7
	int32_t originEquipWep7;

	// NAME: 派生元 強化+8
	// DESC: この武器の強化元武器ID8
	int32_t originEquipWep8;

	// NAME: 派生元 強化+9
	// DESC: この武器の強化元武器ID9
	int32_t originEquipWep9;

	// NAME: 派生元 強化+10
	// DESC: この武器の強化元武器ID10
	int32_t originEquipWep10;

	// NAME: 派生元 強化+11
	// DESC: この武器の強化元武器ID11
	int32_t originEquipWep11;

	// NAME: 派生元 強化+12
	// DESC: この武器の強化元武器ID12
	int32_t originEquipWep12;

	// NAME: 派生元 強化+13
	// DESC: この武器の強化元武器ID13
	int32_t originEquipWep13;

	// NAME: 派生元 強化+14
	// DESC: この武器の強化元武器ID14
	int32_t originEquipWep14;

	// NAME: 派生元 強化+15
	// DESC: この武器の強化元武器ID15
	int32_t originEquipWep15;

	// NAME: 特攻Aダメージ倍率
	// DESC: 特攻A用のダメージ倍率
	float weakA_DamageRate;

	// NAME: 特攻Bダメージ倍率
	// DESC: 特攻B用のダメージ倍率
	float weakB_DamageRate;

	// NAME: 特攻Cダメージ倍率
	// DESC: 特攻C用のダメージ倍率
	float weakC_DamageRate;

	// NAME: 特攻Dダメージ倍率
	// DESC: 特攻D用のダメージ倍率
	float weakD_DamageRate;

	// NAME: 睡眠耐性カット率_最大補正値
	// DESC: 睡眠に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float sleepGuardResist_MaxCorrect;

	// NAME: 発狂耐性カット率_最大補正値
	// DESC: 発狂に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float madnessGuardResist_MaxCorrect;

	// NAME: SA武器攻撃力
	// DESC: スーパーアーマー基本攻撃力
	float saWeaponDamage;

	// NAME: 装備モデル番号
	// DESC: 装備モデルの番号.
	uint16_t equipModelId;

	// NAME: アイコンID
	// DESC: メニューアイコンID.
	uint16_t iconId;

	// NAME: 耐久度
	// DESC: 初期耐久度.
	uint16_t durability;

	// NAME: 耐久度最大値
	// DESC: 新品耐久度.
	uint16_t durabilityMax;

	// NAME: 投げ抜け攻撃力基本値
	// DESC: 投げ抜け攻撃力の基本値
	uint16_t attackThrowEscape;

	// NAME: パリィ発生時間[frame]
	// DESC: パリィダメージの寿命を制限する。TimeActで設定されている以上には持続しない。
	int16_t parryDamageLife;

	// NAME: 物理攻撃力基本値
	// DESC: 敵のＨＰにダメージを与える物理属性攻撃の基本値
	uint16_t attackBasePhysics;

	// NAME: 魔法攻撃力基本値
	// DESC: 敵のＨＰにダメージを与える魔法属性攻撃の基本値
	uint16_t attackBaseMagic;

	// NAME: 炎攻撃力基本値
	// DESC: 敵のＨＰにダメージを与える炎属性攻撃の基本値
	uint16_t attackBaseFire;

	// NAME: 電撃攻撃力基本値
	// DESC: 敵のＨＰにダメージを与える電撃属性攻撃の基本値
	uint16_t attackBaseThunder;

	// NAME: スタミナ攻撃力
	// DESC: 敵へのスタミナ攻撃力
	uint16_t attackBaseStamina;

	// NAME: ガード範囲[deg]
	// DESC: 武器のガード時の防御発生範囲角度
	int16_t guardAngle;

	// NAME: SA耐久値
	// DESC: 攻撃モーション中に使われる追加SA耐久値
	float saDurability;

	// NAME: ガード時スタミナ防御力
	// DESC: ガード成功時に、敵のスタミナ攻撃に対する防御力
	int16_t staminaGuardDef;

	// NAME: 強化タイプID
	// DESC: 強化タイプID
	int16_t reinforceTypeId;

	// NAME: トロフィーＳグレードID
	// DESC: トロフィーシステムに関係あるか？
	int16_t trophySGradeId;

	// NAME: トロフィーSEQ番号
	// DESC: トロフィーのSEQ番号（１３～２９）
	int16_t trophySeqId;

	// NAME: 投げ攻撃力倍率
	// DESC: 投げの攻撃力倍率
	int16_t throwAtkRate;

	// NAME: 弓飛距離補正[％]
	// DESC: 飛距離を伸ばすアップ％
	int16_t bowDistRate;

	// NAME: 装備モデル種別
	// DESC: 装備モデルの種別.
	uint8_t equipModelCategory;

	// NAME: 装備モデル性別
	// DESC: 装備モデルの性別.
	uint8_t equipModelGender;

	// NAME: 武器カテゴリ
	// DESC: 武器のカテゴリ.
	uint8_t weaponCategory;

	// NAME: 武器モーションカテゴリ
	// DESC: 武器モーションのカテゴリ.
	uint8_t wepmotionCategory;

	// NAME: ガードモーションカテゴリ
	// DESC: ガードモーションのカテゴリ
	uint8_t guardmotionCategory;

	// NAME: 攻撃材質
	// DESC: 攻撃パラから使用される攻撃材質
	uint8_t atkMaterial;

	// NAME: 防御SE材質1
	// DESC: 攻撃パラから使用される防御SE材質1
	uint16_t defSeMaterial1;

	// NAME: 補正タイプ（物理攻撃力）
	// DESC: 一次パラメータによる物理攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Physics;

	// NAME: 特殊属性
	// DESC: 武器の特殊属性値
	uint8_t spAttribute;

	// NAME: 特殊攻撃カテゴリ
	// DESC: 特殊攻撃カテゴリ（50～999まで可能)
	uint16_t spAtkcategory;

	// NAME: 武器モーション片手ID
	// DESC: 片手装備時の基本モーションID.
	uint8_t wepmotionOneHandId;

	// NAME: 武器モーション両手ID
	// DESC: 両手装備時の基本モーションID.
	uint8_t wepmotionBothHandId;

	// NAME: 装備適正筋力
	// DESC: 装備適正値.
	uint8_t properStrength;

	// NAME: 装備適正俊敏
	// DESC: 装備適正値.
	uint8_t properAgility;

	// NAME: 装備適正魔力
	// DESC: 装備適正値.
	uint8_t properMagic;

	// NAME: 装備適正信仰
	// DESC: 装備適正値.
	uint8_t properFaith;

	// NAME: 筋力オーバー開始値
	// DESC: 筋力オーバー開始値
	uint8_t overStrength;

	// NAME: パリィ攻撃基本値
	// DESC: 敵のパリィをやぶるための基本値
	uint8_t attackBaseParry;

	// NAME: パリィ防御値
	// DESC: パリィ判定時に、パリィになるかガードになるかの判定に利用
	uint8_t defenseBaseParry;

	// NAME: はじき防御力基本値
	// DESC: 敵の攻撃をガードしたときに、はじけるかどうかの判定に利用
	uint8_t guardBaseRepel;

	// NAME: はじき攻撃力基本値
	// DESC: ガード敵を攻撃した時に、はじかれるかどうかの判定に利用
	uint8_t attackBaseRepel;

	// NAME: ガードカット無効化倍率
	// DESC: 相手のガードカットを無効化させる倍率。-100で完全無効。100で相手の防御効果倍増。
	int8_t guardCutCancelRate;

	// NAME: ガードレベル
	// DESC: ガードしたとき、敵の攻撃をどのガードモーションで受けるか？を決める
	int8_t guardLevel;

	// NAME: 斬撃攻撃カット率
	// DESC: 攻撃タイプを見て、斬撃属性のダメージを何％カットするか？を指定
	int8_t slashGuardCutRate;

	// NAME: 打撃攻撃カット率
	// DESC: 攻撃タイプを見て、打撃属性のダメージを何％カットするか？を指定
	int8_t blowGuardCutRate;

	// NAME: 刺突攻撃カット率
	// DESC: 攻撃タイプを見て、刺突属性のダメージを何％カットするか？を指定
	int8_t thrustGuardCutRate;

	// NAME: 毒耐性カット率
	// DESC: 毒にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t poisonGuardResist;

	// NAME: 疫病攻撃カット率
	// DESC: 疫病にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t diseaseGuardResist;

	// NAME: 出血攻撃カット率
	// DESC: 出血にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t bloodGuardResist;

	// NAME: 呪攻撃カット率
	// DESC: 呪いにする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t curseGuardResist;

	// NAME: 物理属性1
	// DESC: 物理属性1
	uint8_t atkAttribute;

	// NAME: 右手装備
	// DESC: 右手装備可能か.
	uint8_t rightHandEquipable: 1;

	// NAME: 左手装備
	// DESC: 左手装備可能か.
	uint8_t leftHandEquipable: 1;

	// NAME: 両手装備
	// DESC: 両手装備可能か.
	uint8_t bothHandEquipable: 1;

	// NAME: 弓矢弾装備
	// DESC: 弓用矢弾装備可能か.
	uint8_t arrowSlotEquipable: 1;

	// NAME: 弩矢弾装備
	// DESC: 弩用矢弾装備可能か.
	uint8_t boltSlotEquipable: 1;

	// NAME: ガード可能
	// DESC: 左手装備時L1でガード
	uint8_t enableGuard: 1;

	// NAME: パリィ可能
	// DESC: 左手装備時L2でパリィ
	uint8_t enableParry: 1;

	// NAME: 魔法可能
	// DESC: 攻撃時に魔法発動
	uint8_t enableMagic: 1;

	// NAME: 呪術可能
	// DESC: 攻撃時に呪術発動
	uint8_t enableSorcery: 1;

	// NAME: 奇蹟可能
	// DESC: 攻撃時に奇蹟発動
	uint8_t enableMiracle: 1;

	// NAME: 誓約魔法可能
	// DESC: 攻撃時に誓約魔法発動
	uint8_t enableVowMagic: 1;

	// NAME: 通常
	// DESC: メニュー表示用攻撃タイプ。通常か
	uint8_t isNormalAttackType: 1;

	// NAME: 打撃
	// DESC: メニュー表示用攻撃タイプ。打撃か
	uint8_t isBlowAttackType: 1;

	// NAME: 斬撃
	// DESC: メニュー表示用攻撃タイプ。斬撃か
	uint8_t isSlashAttackType: 1;

	// NAME: 刺突
	// DESC: メニュー表示用攻撃タイプ。刺突か
	uint8_t isThrustAttackType: 1;

	// NAME: エンチャント可能か？
	// DESC: 松脂などで、強化可能か？
	uint8_t isEnhance: 1;

	// NAME: 人間性補正あるか
	// DESC: 人間性による攻撃力補正があるか
	uint8_t isHeroPointCorrect: 1;

	// NAME: 強化できるか？
	// DESC: 強化ショップで強化対象リストに並ぶ(仕様変更で削除するかも？)
	uint8_t isCustom: 1;

	// NAME: 転職リセット禁止か
	// DESC: 転職リセット禁止か
	uint8_t disableBaseChangeReset: 1;

	// NAME: 修理禁止か
	// DESC: 修理禁止か
	uint8_t disableRepair: 1;

	// NAME: ダークハンドか
	// DESC: ダークハンドか
	uint8_t isDarkHand: 1;

	// NAME: DLC用シンプルモデルありか
	// DESC: ＤＬＣ用シンプルモデルが存在しているか
	uint8_t simpleModelForDlc: 1;

	// NAME: ランタン武器
	// DESC: ランタン武器か
	uint8_t lanternWep: 1;

	// NAME: 対霊武器
	// DESC: NPCパラの「霊体か」が○の相手に攻撃を当たるようになります。また、攻撃パラの「霊体攻撃か」が○の攻撃をガードできるようになります。
	uint8_t isVersusGhostWep: 1;

	// NAME: 武器転職カテゴリ
	// DESC: 武器転職カテゴリ。属性アイコン表示に使用します。
	uint8_t baseChangeCategory: 6;

	// NAME: 竜狩りか
	// DESC: 竜狩り武器か
	uint8_t isDragonSlayer: 1;

	// NAME: 預けれるか
	// DESC: 倉庫に預けれるか
	uint8_t isDeposit: 1;

	// NAME: マルチドロップ共有禁止か
	// DESC: マルチドロップ共有禁止か
	uint8_t disableMultiDropShare: 1;

	// NAME: 捨てれるか
	// DESC: アイテムを捨てれるか？TRUE=捨てれる
	uint8_t isDiscard: 1;

	// NAME: その場に置けるか
	// DESC: アイテムをその場に置けるか？TRUE=置ける
	uint8_t isDrop: 1;

	// NAME: 取得ログ表示条件
	// DESC: アイテム取得時にアイテム取得ログに表示するか（未入力: ○）
	uint8_t showLogCondType: 1;

	// NAME: 投げ可能
	// DESC: 投げ可能な武器かどうか
	uint8_t enableThrow: 1;

	// NAME: 取得ダイアログ表示条件
	// DESC: アイテム取得時にアイテム取得ダイアログに表示するか（未入力: newのみ）
	uint8_t showDialogCondType: 2;

	// NAME: 魔石属性変更禁止か
	// DESC: 魔石属性変更禁止か
	uint8_t disableGemAttr: 1;

	// NAME: 防御SFX材質1
	// DESC: 攻撃パラから使用される防御SFX材質1
	uint16_t defSfxMaterial1;

	// NAME: 武器コライダブル設定
	// DESC: 武器のコライダブル設定
	uint8_t wepCollidableType0;

	// NAME: 武器1コライダブル設定
	// DESC: 武器1のコライダブル設定
	uint8_t wepCollidableType1;

	// NAME: 姿勢制御ID(右手)
	// DESC: 姿勢制御ID(右手)
	uint8_t postureControlId_Right;

	// NAME: 姿勢制御ID(左手)
	// DESC: 姿勢制御ID(左手)
	uint8_t postureControlId_Left;

	// NAME: 剣閃SfxID_０
	// DESC: 剣閃SfxID_０(-1無効)
	int32_t traceSfxId0;

	// NAME: 根元剣閃ダミポリID_０
	// DESC: 剣閃根元ダミポリID_０(-1無効)
	int32_t traceDmyIdHead0;

	// NAME: 剣先剣閃ダミポリID_０
	// DESC: 剣閃剣先ダミポリID_０
	int32_t traceDmyIdTail0;

	// NAME: 剣閃SfxID_１
	// DESC: 剣閃SfxID_１(-1無効)
	int32_t traceSfxId1;

	// NAME: 根元剣閃ダミポリID_１
	// DESC: 剣閃根元ダミポリID_１(-1無効)
	int32_t traceDmyIdHead1;

	// NAME: 剣先剣閃ダミポリID_１
	// DESC: 剣閃剣先ダミポリID_１
	int32_t traceDmyIdTail1;

	// NAME: 剣閃SfxID_２
	// DESC: 剣閃SfxID_２(-1無効)
	int32_t traceSfxId2;

	// NAME: 根元剣閃ダミポリID_２
	// DESC: 剣閃根元ダミポリID_２(-1無効)
	int32_t traceDmyIdHead2;

	// NAME: 剣先剣閃ダミポリID_２
	// DESC: 剣閃剣先ダミポリID_２
	int32_t traceDmyIdTail2;

	// NAME: 剣閃SfxID_３
	// DESC: 剣閃SfxID_３(-1無効)
	int32_t traceSfxId3;

	// NAME: 根元剣閃ダミポリID_３
	// DESC: 剣閃根元ダミポリID_３(-1無効)
	int32_t traceDmyIdHead3;

	// NAME: 剣先剣閃ダミポリID_３
	// DESC: 剣閃剣先ダミポリID_３
	int32_t traceDmyIdTail3;

	// NAME: 剣閃SfxID_４
	// DESC: 剣閃SfxID_４(-1無効)
	int32_t traceSfxId4;

	// NAME: 根元剣閃ダミポリID_４
	// DESC: 剣閃根元ダミポリID_４(-1無効)
	int32_t traceDmyIdHead4;

	// NAME: 剣先剣閃ダミポリID_４
	// DESC: 剣閃剣先ダミポリID_４
	int32_t traceDmyIdTail4;

	// NAME: 剣閃SfxID_５
	// DESC: 剣閃SfxID_５(-1無効)
	int32_t traceSfxId5;

	// NAME: 根元剣閃ダミポリID_５
	// DESC: 剣閃根元ダミポリID_５(-1無効)
	int32_t traceDmyIdHead5;

	// NAME: 剣先剣閃ダミポリID_５
	// DESC: 剣閃剣先ダミポリID_５
	int32_t traceDmyIdTail5;

	// NAME: 剣閃SfxID_６
	// DESC: 剣閃SfxID_６(-1無効)
	int32_t traceSfxId6;

	// NAME: 根元剣閃ダミポリID_６
	// DESC: 剣閃根元ダミポリID_６(-1無効)
	int32_t traceDmyIdHead6;

	// NAME: 剣先剣閃ダミポリID_６
	// DESC: 剣閃剣先ダミポリID_６
	int32_t traceDmyIdTail6;

	// NAME: 剣閃SfxID_７
	// DESC: 剣閃SfxID_７(-1無効)
	int32_t traceSfxId7;

	// NAME: 根元剣閃ダミポリID_７
	// DESC: 剣閃根元ダミポリID_７(-1無効)
	int32_t traceDmyIdHead7;

	// NAME: 剣先剣閃ダミポリID_７
	// DESC: 剣閃剣先ダミポリID_７
	int32_t traceDmyIdTail7;

	// NAME: 防御SFX材質2
	// DESC: 攻撃パラから使用される防御SFX材質2
	uint16_t defSfxMaterial2;

	// NAME: 防御SE材質2
	// DESC: 攻撃パラから使用される防御SE材質2
	uint16_t defSeMaterial2;

	// NAME: 吸着位置Id
	// DESC: 武器吸着位置パラメータのId。この値により武器が吸着する位置を決定する(-1：旧ソースコード直書きの値を参照する)
	int32_t absorpParamId;

	// NAME: 強靭度 補正倍率
	// DESC: 強靭度の基本値を補正する倍率です
	float toughnessCorrectRate;

	// NAME: 防具SAダメージ倍率が初期値でも有効か？
	// DESC: 防具SAが初期値でも強靭度計算が行われるかどうか。詳細は強靭度仕様書.xlsxを確認してください
	uint8_t isValidTough_ProtSADmg: 1;

	// NAME: 双剣か
	// DESC: この武器は双剣か。
	uint8_t isDualBlade: 1;

	// NAME: 自動装填可能か
	// DESC: 矢・ボルトのみ有効。新しくこの武器を拾っ時に対象装備スロットが空の場合に自動で装備するかどうか
	uint8_t isAutoEquip: 1;

	// NAME: 緊急回避可能か
	// DESC: 緊急回避可能な武器かどうか。ビヘイビアスクリプトに渡す。
	uint8_t isEnableEmergencyStep: 1;

	// NAME: カットシーン中非表示か
	// DESC: カットシーン中非表示か
	uint8_t invisibleOnRemo: 1;

	// NAME: pad
	uint8_t pad2: 3;

	// NAME: 補正タイプ（魔法攻撃力）
	// DESC: 一次パラメータによる魔法攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Magic;

	// NAME: 補正タイプ（炎攻撃力）
	// DESC: 一次パラメータによる炎攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Fire;

	// NAME: 補正タイプ（雷攻撃力）
	// DESC: 一次パラメータによる雷攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Thunder;

	// NAME: 特攻Eダメージ倍率
	// DESC: 特攻E用のダメージ倍率
	float weakE_DamageRate;

	// NAME: 特攻Fダメージ倍率
	// DESC: 特攻F用のダメージ倍率
	float weakF_DamageRate;

	// NAME: ガード時闇攻撃力カット率
	// DESC: 闇攻撃をどれだけカットするか？
	float darkGuardCutRate;

	// NAME: 闇攻撃力基本値
	// DESC: 敵のＨＰにダメージを与える闇属性攻撃の基本値
	uint16_t attackBaseDark;

	// NAME: 補正タイプ（闇攻撃力）
	// DESC: 一次パラメータによる闇攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Dark;

	// NAME: 補正タイプ（毒攻撃力）
	// DESC: 一次パラメータによる毒攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Poison;

	// NAME: ソートアイテム種別ID
	// DESC: ソートアイテム種別ID。ソート「アイテム種別順」にて、同じIDは同じグループとしてまとめて表示されます
	uint8_t sortGroupId;

	// NAME: 物理属性2
	// DESC: 物理属性2
	uint8_t atkAttribute2;

	// NAME: 睡眠攻撃カット率
	// DESC: 睡眠にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t sleepGuardResist;

	// NAME: 発狂攻撃カット率
	// DESC: 発狂にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t madnessGuardResist;

	// NAME: 補正タイプ（出血攻撃力）
	// DESC: 一次パラメータによる出血攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Blood;

	// NAME: 装備適正運
	// DESC: 装備適正値.
	uint8_t properLuck;

	// NAME: 冷気攻撃カット率
	// DESC: 冷気にする攻撃力（特殊効果パラメータに設定）をどれだけカットするか
	int8_t freezeGuardResist;

	// NAME: 自動補充タイプ
	// DESC: 自動補充する/しないの可否およびデフォルト設定をコントロールします
	uint8_t autoReplenishType;

	// NAME: アーツパラメータID
	// DESC: アーツパラメータのID
	int32_t swordArtsParamId;

	// NAME: 運補正
	// DESC: キャラパラ補正値.
	float correctLuck;

	// NAME: 矢筒(弾倉)表示モデル用装備ID
	// DESC: 矢筒(弾倉)表示モデルの装備品番号。弓の場合は矢筒、弩の場合は弾倉として表示する。
	uint32_t arrowBoltEquipId;

	// NAME: 還元時レベル設定
	// DESC: 武器を還元・派生させるときに強化レベルをどう設定するかの種別
	uint8_t DerivationLevelType;

	// NAME: エンチャントSfxサイズ
	// DESC: エンチャントSfxIdにオフセットする値
	uint8_t enchantSfxSize;

	// NAME: 武器種別
	// DESC: 武器種別。テキストと、魔石の紐付けに使われる（※テキスト以外にも使われるようになった）
	uint16_t wepType;

	// NAME: ガード時物理攻撃カット率_最大補正値
	// DESC: ガード時のダメージ物理カット率の補正値の最大値
	float physGuardCutRate_MaxCorrect;

	// NAME: ガード時魔法攻撃カット率_最大補正値
	// DESC: ガード時のダメージ魔法カット率の補正値の最大値
	float magGuardCutRate_MaxCorrect;

	// NAME: ガード時炎攻撃力カット率_最大補正値
	// DESC: ガード時のダメージ炎カット率の補正値の最大値
	float fireGuardCutRate_MaxCorrect;

	// NAME: ガード時電撃攻撃力カット率_最大補正値
	// DESC: ガード時のダメージ電撃カット率の補正値の最大値
	float thunGuardCutRate_MaxCorrect;

	// NAME: ガード時闇攻撃力カット率_最大補正値
	// DESC: ガード時のダメージ闇カット率の補正値の最大値
	float darkGuardCutRate_MaxCorrect;

	// NAME: 毒耐性カット率_最大補正値
	// DESC: 毒に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float poisonGuardResist_MaxCorrect;

	// NAME: 疫病耐性カット率_最大補正値
	// DESC: 疫病に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float diseaseGuardResist_MaxCorrect;

	// NAME: 出血耐性カット率_最大補正値
	// DESC: 出血に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float bloodGuardResist_MaxCorrect;

	// NAME: 呪耐性カット率_最大補正値
	// DESC: 呪いに対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float curseGuardResist_MaxCorrect;

	// NAME: 冷気耐性カット率_最大補正値
	// DESC: 冷気に対する攻撃力（特殊効果パラメータに設定）のカット率補正値の最大値
	float freezeGuardResist_MaxCorrect;

	// NAME: ガード時スタミナ防御力_最大補正値
	// DESC: ガード成功時に、敵のスタミナ攻撃に対する防御力の補正値の最大値
	float staminaGuardDef_MaxCorrect;

	// NAME: 常駐SfxId１
	// DESC: 常駐SfxId1
	int32_t residentSfxId_1;

	// NAME: 常駐SfxId２
	// DESC: 常駐SfxId2
	int32_t residentSfxId_2;

	// NAME: 常駐SfxId３
	// DESC: 常駐SfxId3
	int32_t residentSfxId_3;

	// NAME: 常駐SfxId４
	// DESC: 常駐SfxId4
	int32_t residentSfxId_4;

	// NAME: 常駐SfxダミポリId１
	// DESC: 常駐SfxダミポリId１
	int32_t residentSfx_DmyId_1;

	// NAME: 常駐SfxダミポリId２
	// DESC: 常駐SfxダミポリId２
	int32_t residentSfx_DmyId_2;

	// NAME: 常駐SfxダミポリId３
	// DESC: 常駐SfxダミポリId３
	int32_t residentSfx_DmyId_3;

	// NAME: 常駐SfxダミポリId４
	// DESC: 常駐SfxダミポリId４
	int32_t residentSfx_DmyId_4;

	// NAME: スタミナ消費量倍率
	// DESC: スタミナ消費量倍率
	float staminaConsumptionRate;

	// NAME: 対プレイヤー 物理ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Physics;

	// NAME: 対プレイヤー 魔法ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Magic;

	// NAME: 対プレイヤー 炎ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Fire;

	// NAME: 対プレイヤー 雷ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Thunder;

	// NAME: 対プレイヤー 闇ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Dark;

	// NAME: 対プレイヤー 毒ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Poison;

	// NAME: 対プレイヤー 出血ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Blood;

	// NAME: 対プレイヤー 冷気ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Freeze;

	// NAME: 武器能力解放ステータス値：筋力
	// DESC: 特定の武器を使った際、ステータスがX以上だとR2攻撃が特殊なアクションに変わるようするためのもの
	int32_t attainmentWepStatusStr;

	// NAME: 武器能力解放ステータス値：技量
	// DESC: 特定の武器を使った際、ステータスがX以上だとR2攻撃が特殊なアクションに変わるようするためのもの
	int32_t attainmentWepStatusDex;

	// NAME: 武器能力解放ステータス値：理力
	// DESC: 特定の武器を使った際、ステータスがX以上だとR2攻撃が特殊なアクションに変わるようするためのもの
	int32_t attainmentWepStatusMag;

	// NAME: 武器能力解放ステータス値：信仰
	// DESC: 特定の武器を使った際、ステータスがX以上だとR2攻撃が特殊なアクションに変わるようするためのもの
	int32_t attainmentWepStatusFai;

	// NAME: 武器能力解放ステータス値：運
	// DESC: 特定の武器を使った際、ステータスがX以上だとR2攻撃が特殊なアクションに変わるようするためのもの
	int32_t attainmentWepStatusLuc;

	// NAME: 攻撃属性補正ID
	// DESC: 攻撃属性を補正するパラメータのID
	int32_t attackElementCorrectId;

	// NAME: 販売価格
	// DESC: 販売価格
	int32_t saleValue;

	// NAME: 強化ショップカテゴリ
	// DESC: 強化ショップカテゴリ
	uint8_t reinforceShopCategory;

	// NAME: 矢の最大所持数
	// DESC: 矢の最大所持数
	uint8_t maxArrowQuantity;

	// NAME: 常駐SFX1納刀時表示するか
	// DESC: 「常駐SFX1納刀時表示するか」がtrueの場合、武器が納刀された時に「常駐SFXID1」に設定されているSFXを非表示にする
	uint8_t residentSfx_1_IsVisibleForHang: 1;

	// NAME: 常駐SFX2納刀時表示するか
	// DESC: 「常駐SFX2納刀時表示するか」がtrueの場合、武器が納刀された時に「常駐SFXID2」に設定されているSFXを非表示にする
	uint8_t residentSfx_2_IsVisibleForHang: 1;

	// NAME: 常駐SFX3納刀時表示するか
	// DESC: 「常駐SFX3納刀時表示するか」がtrueの場合、武器が納刀された時に「常駐SFXID3」に設定されているSFXを非表示にする
	uint8_t residentSfx_3_IsVisibleForHang: 1;

	// NAME: 常駐SFX4納刀時表示するか
	// DESC: 「常駐SFX4納刀時表示するか」がtrueの場合、武器が納刀された時に「常駐SFXID4」に設定されているSFXを非表示にする
	uint8_t residentSfx_4_IsVisibleForHang: 1;

	// NAME: モデル_0 ソウルパラムID差し替え可能か
	// DESC: vfxパラメータの「武器エンチャント用ソウルパラムID」と「武器エンチャント用インビジブルウェポンか」設定が適応されるか
	uint8_t isSoulParamIdChange_model0: 1;

	// NAME: モデル_1 ソウルパラムID差し替え可能か
	// DESC: vfxパラメータの「武器エンチャント用ソウルパラムID」と「武器エンチャント用インビジブルウェポンか」設定が適応されるか
	uint8_t isSoulParamIdChange_model1: 1;

	// NAME: モデル_2 ソウルパラムID差し替え可能か
	// DESC: vfxパラメータの「武器エンチャント用ソウルパラムID」と「武器エンチャント用インビジブルウェポンか」設定が適応されるか
	uint8_t isSoulParamIdChange_model2: 1;

	// NAME: モデル_3 ソウルパラムID差し替え可能か
	// DESC: vfxパラメータの「武器エンチャント用ソウルパラムID」と「武器エンチャント用インビジブルウェポンか」設定が適応されるか
	uint8_t isSoulParamIdChange_model3: 1;

	// NAME: 武器SEIDオフセット値
	// DESC: SEIDのオフセット値 
	int8_t wepSeIdOffset;

	// NAME: 進化価格
	// DESC: 進化価格
	int32_t baseChangePrice;

	// NAME: レベルシンク補正ID
	// DESC: レベルシンク補正ID
	int16_t levelSyncCorrectId;

	// NAME: 補正タイプ（睡眠攻撃力）
	// DESC: 一次パラメータによる睡眠攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Sleep;

	// NAME: 補正タイプ（発狂攻撃力）
	// DESC: 一次パラメータによる発狂攻撃力の補正グラフのタイプを決める
	uint8_t correctType_Madness;

	// NAME: レア度
	// DESC: アイテム取得ログで使うレア度
	uint8_t rarity;

	// NAME: 魔石装着可能か
	// DESC: 魔石装着可能か
	uint8_t gemMountType;

	// NAME: 武器リゲイン量
	// DESC: 武器リゲイン量
	uint16_t wepRegainHp;

	// NAME: 効果テキストID00
	// DESC: 効果テキストID00(Weapon_Effect)。ステータスに表示する武器固有効果のテキスト
	int32_t spEffectMsgId0;

	// NAME: 効果テキストID01
	// DESC: 効果テキストID01(Weapon_Effect)。ステータスに表示する武器固有効果のテキスト
	int32_t spEffectMsgId1;

	// NAME: 効果テキストID02
	// DESC: 効果テキストID02(Weapon_Effect)。ステータスに表示する武器固有効果のテキスト
	int32_t spEffectMsgId2;

	// NAME: 派生元 強化+16
	// DESC: この武器の強化元武器ID16
	int32_t originEquipWep16;

	// NAME: 派生元 強化+17
	// DESC: この武器の強化元武器ID17
	int32_t originEquipWep17;

	// NAME: 派生元 強化+18
	// DESC: この武器の強化元武器ID18
	int32_t originEquipWep18;

	// NAME: 派生元 強化+19
	// DESC: この武器の強化元武器ID19
	int32_t originEquipWep19;

	// NAME: 派生元 強化+20
	// DESC: この武器の強化元武器ID20
	int32_t originEquipWep20;

	// NAME: 派生元 強化+21
	// DESC: この武器の強化元武器ID21
	int32_t originEquipWep21;

	// NAME: 派生元 強化+22
	// DESC: この武器の強化元武器ID22
	int32_t originEquipWep22;

	// NAME: 派生元 強化+23
	// DESC: この武器の強化元武器ID23
	int32_t originEquipWep23;

	// NAME: 派生元 強化+24
	// DESC: この武器の強化元武器ID24
	int32_t originEquipWep24;

	// NAME: 派生元 強化+25
	// DESC: この武器の強化元武器ID25
	int32_t originEquipWep25;

	// NAME: 対プレイヤー 睡眠ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Sleep;

	// NAME: 対プレイヤー 発狂ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Madness;

	// NAME: ガード時SA攻撃カット率
	// DESC: ガード成功時のSAダメージのカット率
	float saGuardCutRate;

	// NAME: 防御材質バリエーション値
	// DESC: ガード時に使用される防御材質と組み合わせてダメージSFX,SEのバリエーション分けに使用する値です。SEQ16473
	uint8_t defMaterialVariationValue;

	// NAME: 特殊属性バリエーション値
	// DESC: 武器の特殊属性と組み合わせて状態異常SFX,SEなどにバリエーションを持たせるために使用する値です。SEQ16473
	uint8_t spAttributeVariationValue;

	// NAME: ステルス攻撃力倍率
	// DESC: ステルス攻撃力倍率
	int16_t stealthAtkRate;

	// NAME: 対プレイヤー 疫病ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Disease;

	// NAME: 対プレイヤー 呪ダメージ補正倍率
	// DESC: プレイヤーに対する攻撃のみ、与えるダメージを補正する。
	float vsPlayerDmgCorrectRate_Curse;

	// NAME: pad
	// DESC: pad
	uint8_t pad[8];
} EQUIP_PARAM_WEAPON_ST;

#endif
