/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CHARMAKEMENUTOP_PARAM_ST_H
#define _PARAMDEF_CHARMAKEMENUTOP_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CHARMAKEMENUTOP_PARAM_ST {

	// NAME: コマンドタイプ
	// DESC: コマンドの種別
	int32_t commandType;

	// NAME: 項目テキストID
	// DESC: 表示するテキストのID
	int32_t captionId;

	// NAME: 顔パラムID
	// DESC: 顔パラムID
	int32_t faceParamId;

	// NAME: テーブルID（男性）
	// DESC: 選択するアイテム一覧の先頭ID（男）。コマンドタイプが[スライダー：最小値ラベル(n)と最大値ラベル(n+1)のテキストID、カラー：カラーテーブルのID、グリッド or テキスト：キャラメイクリストアイテムの先頭ID、それ以外：無視]
	int32_t tableId;

	// NAME: 表示条件
	// DESC: このコマンドを表示する条件
	int32_t viewCondition;

	// NAME: プレビューモード
	// DESC: プレビュー表示しているキャラクターモデルの表示モード
	int8_t previewMode;

	// NAME: 予約
	uint8_t reserved2[3];

	// NAME: テーブルID（女性）
	// DESC: テーブルIDの女用。-1なら男用を参照する
	int32_t tableId2;

	// NAME: 参照先の顔パラムID
	// DESC: 「○○に合わせる」用の合わせ先の顔パラムID
	int32_t refFaceParamId;

	// NAME: 参照先テキストID
	// DESC: 「○○に合わせる」用の表示テキストID
	int32_t refTextId;

	// NAME: 1行ヘルプテキストID（上書き）
	// DESC: 1行ヘルプのテキストID(-1: 項目テキストIDで1行ヘルプを取得する)。基本的に項目テキストID＝1行ヘルプテキストIDになっているが、一部上書きしたいときにこのパラメータで指定する
	int32_t helpTextId;

	// NAME: イベントフラグID
	// DESC: この項目をアンロックするイベントフラグ(0:無効値)。無効値なら常にアンロックされる
	uint32_t unlockEventFlagId;

	// NAME: 予約
	uint8_t reserved[4];
} CHARMAKEMENUTOP_PARAM_ST;

#endif
