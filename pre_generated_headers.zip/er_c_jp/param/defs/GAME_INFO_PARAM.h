/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_GAME_INFO_PARAM_H
#define _PARAMDEF_GAME_INFO_PARAM_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GAME_INFO_PARAM {

	// NAME: タイトルのMsgID
	// DESC: タイトル名
	int32_t titleMsgId;

	// NAME: 内容のMsgID
	// DESC: 内容
	int32_t contentMsgId;

	// NAME: 価格
	// DESC: 価格
	int32_t value;

	// NAME: ソートID
	// DESC: ソートID
	int32_t sortId;

	// NAME: アクションID
	// DESC: 販売状況を判断するアクションIDです。
	int32_t eventId;

	// NAME: パディング
	// DESC: パディング
	uint8_t Pad[12];
} GAME_INFO_PARAM;

#endif
