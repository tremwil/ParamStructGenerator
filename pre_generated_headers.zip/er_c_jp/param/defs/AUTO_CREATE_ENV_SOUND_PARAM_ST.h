/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_AUTO_CREATE_ENV_SOUND_PARAM_ST_H
#define _PARAMDEF_AUTO_CREATE_ENV_SOUND_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 0
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AUTO_CREATE_ENV_SOUND_PARAM_ST {

	// NAME: 出現距離Min[m]
	// DESC: 出現距離Min[m]
	float RangeMin;

	// NAME: 出現距離Max[m]
	// DESC: 出現距離Max[
	float RangeMax;

	// NAME: 寿命Min[秒]
	// DESC: 寿命Min[秒]
	float LifeTimeMin;

	// NAME: 寿命Max[秒]
	// DESC: 寿命Max[秒]
	float LifeTimeMax;

	// NAME: 削除距離[m]
	// DESC: 削除距離[m]
	float DeleteDist;

	// NAME: 近傍判定距離[m]
	// DESC: 近傍判定距離[m]
	float NearDist;

	// NAME: 生成角度制限Min[度]
	// DESC: 角度制限Min[度](カメラの前方のY軸角度+-の指定。180なら全方位) 
	float LimiteRotateMin;

	// NAME: 生成角度制限Max[度]
	// DESC: 角度制限Max[度](カメラの前方のY軸角度+-の指定。180なら全方位) 
	float LimiteRotateMax;
} AUTO_CREATE_ENV_SOUND_PARAM_ST;

#endif
