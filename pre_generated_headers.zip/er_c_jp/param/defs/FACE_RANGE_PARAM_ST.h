/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_FACE_RANGE_PARAM_ST_H
#define _PARAMDEF_FACE_RANGE_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 3
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _FACE_RANGE_PARAM_ST {

	// NAME: 顔パーツID
	// DESC: 顔パーツID
	float face_partsId;

	// NAME: 肌の色(Ｒ)
	// DESC: 肌の色(Ｒ)
	float skin_color_R;

	// NAME: 肌の色(Ｇ)
	// DESC: 肌の色(Ｇ)
	float skin_color_G;

	// NAME: 肌の色(Ｂ)
	// DESC: 肌の色(Ｂ)
	float skin_color_B;

	// NAME: 肌のつや
	// DESC: 肌のつや
	float skin_gloss;

	// NAME: 毛穴
	// DESC: 毛穴
	float skin_pores;

	// NAME: 青ひげ
	// DESC: 青ひげ
	float face_beard;

	// NAME: くま
	// DESC: くま
	float face_aroundEye;

	// NAME: くまの色(R)
	// DESC: くまの色(R)
	float face_aroundEyeColor_R;

	// NAME: くまの色(G)
	// DESC: くまの色(G)
	float face_aroundEyeColor_G;

	// NAME: くまの色(B)
	// DESC: くまの色(B)
	float face_aroundEyeColor_B;

	// NAME: チーク
	// DESC: チーク
	float face_cheek;

	// NAME: チークの色(R)
	// DESC: チークの色(R)
	float face_cheekColor_R;

	// NAME: チークの色(G)
	// DESC: チークの色(G)
	float face_cheekColor_G;

	// NAME: チークの色(B)
	// DESC: チークの色(B)
	float face_cheekColor_B;

	// NAME: アイライン
	// DESC: アイライン
	float face_eyeLine;

	// NAME: アイラインの色(R)
	// DESC: アイラインの色(R)
	float face_eyeLineColor_R;

	// NAME: アイラインの色(G)
	// DESC: アイラインの色(G)
	float face_eyeLineColor_G;

	// NAME: アイラインの色(B)
	// DESC: アイラインの色(B)
	float face_eyeLineColor_B;

	// NAME: アイシャドウ(下)
	// DESC: アイシャドウ(下)
	float face_eyeShadowDown;

	// NAME: アイシャドウ(下)の色(R)
	// DESC: アイシャドウ(下)の色(R)
	float face_eyeShadowDownColor_R;

	// NAME: アイシャドウ(下)の色(G)
	// DESC: アイシャドウ(下)の色(G)
	float face_eyeShadowDownColor_G;

	// NAME: アイシャドウ(下)の色(B)
	// DESC: アイシャドウ(下)の色(B)
	float face_eyeShadowDownColor_B;

	// NAME: アイシャドウ(上)
	// DESC: アイシャドウ(上)
	float face_eyeShadowUp;

	// NAME: アイシャドウ(上)の色(R)
	// DESC: アイシャドウ(上)の色(R)
	float face_eyeShadowUpColor_R;

	// NAME: アイシャドウ(上)の色(G)
	// DESC: アイシャドウ(上)の色(G)
	float face_eyeShadowUpColor_G;

	// NAME: アイシャドウ(上)の色(B)
	// DESC: アイシャドウ(上)の色(B)
	float face_eyeShadowUpColor_B;

	// NAME: 口紅
	// DESC: 口紅
	float face_lip;

	// NAME: 口紅の色(R)
	// DESC: 口紅の色(R)
	float face_lipColor_R;

	// NAME: 口紅の色(G)
	// DESC: 口紅の色(G)
	float face_lipColor_G;

	// NAME: 口紅の色(B)
	// DESC: 口紅の色(B)
	float face_lipColor_B;

	// NAME: 体毛の濃さ
	// DESC: 体毛の濃さ
	float body_hair;

	// NAME: 体毛の色(R)
	// DESC: 体毛の色(R)
	float body_hairColor_R;

	// NAME: 体毛の色(G)
	// DESC: 体毛の色(G)
	float body_hairColor_G;

	// NAME: 体毛の色(B)
	// DESC: 体毛の色(B)
	float body_hairColor_B;

	// NAME: 眼球パーツID
	// DESC: 眼球パーツID
	float eye_partsId;

	// NAME: 虹彩の色(Ｒ)
	// DESC: 右目の虹彩の色(Ｒ)
	float eyeR_irisColor_R;

	// NAME: 虹彩の色(Ｇ)
	// DESC: 右目の虹彩の色(Ｇ)
	float eyeR_irisColor_G;

	// NAME: 虹彩の色(Ｂ)
	// DESC: 右目の虹彩の色(Ｂ)
	float eyeR_irisColor_B;

	// NAME: 虹彩の大きさ
	// DESC: 右目の虹彩の大きさ
	float eyeR_irisScale;

	// NAME: 水晶体の濁り
	// DESC: 右目の水晶体の濁り
	float eyeR_cataract;

	// NAME: 水晶体の濁りの色(Ｒ)
	// DESC: 右目の水晶体の濁りの色(Ｒ)
	float eyeR_cataractColor_R;

	// NAME: 水晶体の濁りの色(Ｇ)
	// DESC: 右目の水晶体の濁りの色(Ｇ)
	float eyeR_cataractColor_G;

	// NAME: 水晶体の濁りの色(Ｂ)
	// DESC: 右目の水晶体の濁りの色(Ｂ)
	float eyeR_cataractColor_B;

	// NAME: 白目の色(Ｒ)
	// DESC: 右目の白目の色(Ｒ)
	float eyeR_scleraColor_R;

	// NAME: 白目の色(G)
	// DESC: 右目の白目の色(G)
	float eyeR_scleraColor_G;

	// NAME: 白目の色(B)
	// DESC: 右目の白目の色(B)
	float eyeR_scleraColor_B;

	// NAME: 虹彩の位置
	// DESC: 右目の虹彩の位置
	float eyeR_irisDistance;

	// NAME: 虹彩の色(Ｒ)
	// DESC: 左目の虹彩の色(Ｒ)
	float eyeL_irisColor_R;

	// NAME: 虹彩の色(Ｇ)
	// DESC: 左目の虹彩の色(Ｇ)
	float eyeL_irisColor_G;

	// NAME: 虹彩の色(Ｂ)
	// DESC: 左目の虹彩の色(Ｂ)
	float eyeL_irisColor_B;

	// NAME: 虹彩の大きさ
	// DESC: 左目の虹彩の大きさ
	float eyeL_irisScale;

	// NAME: 水晶体の濁り
	// DESC: 左目の水晶体の濁り
	float eyeL_cataract;

	// NAME: 水晶体の濁りの色(Ｒ)
	// DESC: 左目の水晶体の濁りの色(Ｒ)
	float eyeL_cataractColor_R;

	// NAME: 水晶体の濁りの色(Ｇ)
	// DESC: 左目の水晶体の濁りの色(Ｇ)
	float eyeL_cataractColor_G;

	// NAME: 水晶体の濁りの色(Ｂ)
	// DESC: 左目の水晶体の濁りの色(Ｂ)
	float eyeL_cataractColor_B;

	// NAME: 白目の色(Ｒ)
	// DESC: 左目の白目の色(Ｒ)
	float eyeL_scleraColor_R;

	// NAME: 白目の色(G)
	// DESC: 左目の白目の色(G)
	float eyeL_scleraColor_G;

	// NAME: 白目の色(B)
	// DESC: 左目の白目の色(B)
	float eyeL_scleraColor_B;

	// NAME: 虹彩の位置
	// DESC: 左目の虹彩の位置
	float eyeL_irisDistance;

	// NAME: 髪パーツID
	// DESC: 髪パーツID
	float hair_partsId;

	// NAME: 髪の色(Ｒ)
	// DESC: 髪の色(Ｒ)
	float hair_color_R;

	// NAME: 髪の色(Ｇ)
	// DESC: 髪の色(Ｇ)
	float hair_color_G;

	// NAME: 髪の色(Ｂ)
	// DESC: 髪の色(Ｂ)
	float hair_color_B;

	// NAME: 光沢
	// DESC: 髪の光沢
	float hair_shininess;

	// NAME: 根元の黒さ
	// DESC: 髪の根元の黒さ
	float hair_rootBlack;

	// NAME: 白髪の量
	// DESC: 髪の白髪の量
	float hair_whiteDensity;

	// NAME: 髭パーツID
	// DESC: 髭パーツID
	float beard_partsId;

	// NAME: 髭の色(Ｒ)
	// DESC: 髭の色(Ｒ)
	float beard_color_R;

	// NAME: 髭の色(Ｇ)
	// DESC: 髭の色(Ｇ)
	float beard_color_G;

	// NAME: 髭の色(Ｂ)
	// DESC: 髭の色(Ｂ)
	float beard_color_B;

	// NAME: 光沢
	// DESC: 髭の光沢
	float beard_shininess;

	// NAME: 根元の黒さ
	// DESC: 髭の根元の黒さ
	float beard_rootBlack;

	// NAME: 白髪の量
	// DESC: 髭の白髪の量
	float beard_whiteDensity;

	// NAME: 眉パーツID
	// DESC: 眉パーツID
	float eyebrow_partsId;

	// NAME: 眉の色(Ｒ)
	// DESC: 眉の色(Ｒ)
	float eyebrow_color_R;

	// NAME: 眉の色(Ｇ)
	// DESC: 眉の色(Ｇ)
	float eyebrow_color_G;

	// NAME: 眉の色(Ｂ)
	// DESC: 眉の色(Ｂ)
	float eyebrow_color_B;

	// NAME: 光沢
	// DESC: 眉の光沢
	float eyebrow_shininess;

	// NAME: 根元の黒さ
	// DESC: 眉の根元の黒さ
	float eyebrow_rootBlack;

	// NAME: 白髪の量
	// DESC: 眉の白髪の量
	float eyebrow_whiteDensity;

	// NAME: まつげパーツID
	// DESC: まつげパーツID
	float eyelash_partsId;

	// NAME: まつげの色(Ｒ)
	// DESC: まつげの色(Ｒ)
	float eyelash_color_R;

	// NAME: まつげの色(Ｇ)
	// DESC: まつげの色(Ｇ)
	float eyelash_color_G;

	// NAME: まつげの色(Ｂ)
	// DESC: まつげの色(Ｂ)
	float eyelash_color_B;

	// NAME: 装飾パーツID
	// DESC: 装飾パーツID
	float accessories_partsId;

	// NAME: 装飾の色(Ｒ)
	// DESC: 装飾の色(Ｒ)
	float accessories_color_R;

	// NAME: 装飾の色(Ｇ)
	// DESC: 装飾の色(Ｇ)
	float accessories_color_G;

	// NAME: 装飾の色(Ｂ)
	// DESC: 装飾の色(Ｂ)
	float accessories_color_B;

	// NAME: デカールパーツID
	// DESC: デカールパーツID
	float decal_partsId;

	// NAME: デカール位置(x)
	// DESC: デカール位置(x)
	float decal_posX;

	// NAME: デカール位置(y)
	// DESC: デカール位置(y)
	float decal_posY;

	// NAME: デカール角度
	// DESC: デカール角度
	float decal_angle;

	// NAME: デカールスケール
	// DESC: デカールスケール
	float decal_scale;

	// NAME: デカールの色(Ｒ)
	// DESC: デカールの色(Ｒ)
	float decal_color_R;

	// NAME: デカールの色(Ｇ)
	// DESC: デカールの色(Ｇ)
	float decal_color_G;

	// NAME: デカールの色(Ｂ)
	// DESC: デカールの色(Ｂ)
	float decal_color_B;

	// NAME: デカールのつや
	// DESC: デカールのつや
	float decal_gloss;

	// NAME: デカールの反転
	// DESC: デカールの反転
	float decal_mirror;

	// NAME: キャラ体型頭部スケール
	// DESC: キャラ体型頭部スケール
	float chrBodyScaleHead;

	// NAME: キャラ体型胸部スケール
	// DESC: キャラ体型胸部スケール
	float chrBodyScaleBreast;

	// NAME: キャラ体型腹部スケール
	// DESC: キャラ体型腹部スケール
	float chrBodyScaleAbdomen;

	// NAME: キャラ体型腕部スケール
	// DESC: キャラ体型腕部スケール
	float chrBodyScaleArm;

	// NAME: キャラ体型脚部スケール
	// DESC: キャラ体型脚部スケール
	float chrBodyScaleLeg;

	// NAME: 年齢
	// DESC: 年齢
	float age;

	// NAME: 性別
	// DESC: 性別
	float gender;

	// NAME: 誇張（モデル）
	// DESC: 誇張（モデル）
	float caricatureGeometry;

	// NAME: 誇張（テクスチャ）
	// DESC: 誇張（テクスチャ）
	float caricatureTexture;

	// NAME: 顔作成ジオメトリデータ00
	// DESC: 顔作成ジオメトリデータ00
	float faceGeoData00;

	// NAME: 顔作成ジオメトリデータ01
	// DESC: 顔作成ジオメトリデータ01
	float faceGeoData01;

	// NAME: 顔作成ジオメトリデータ02
	// DESC: 顔作成ジオメトリデータ02
	float faceGeoData02;

	// NAME: 顔作成ジオメトリデータ03
	// DESC: 顔作成ジオメトリデータ03
	float faceGeoData03;

	// NAME: 顔作成ジオメトリデータ04
	// DESC: 顔作成ジオメトリデータ04
	float faceGeoData04;

	// NAME: 顔作成ジオメトリデータ05
	// DESC: 顔作成ジオメトリデータ05
	float faceGeoData05;

	// NAME: 顔作成ジオメトリデータ06
	// DESC: 顔作成ジオメトリデータ06
	float faceGeoData06;

	// NAME: 顔作成ジオメトリデータ07
	// DESC: 顔作成ジオメトリデータ07
	float faceGeoData07;

	// NAME: 顔作成ジオメトリデータ08
	// DESC: 顔作成ジオメトリデータ08
	float faceGeoData08;

	// NAME: 顔作成ジオメトリデータ09
	// DESC: 顔作成ジオメトリデータ09
	float faceGeoData09;

	// NAME: 顔作成ジオメトリデータ10
	// DESC: 顔作成ジオメトリデータ10
	float faceGeoData10;

	// NAME: 顔作成ジオメトリデータ11
	// DESC: 顔作成ジオメトリデータ11
	float faceGeoData11;

	// NAME: 顔作成ジオメトリデータ12
	// DESC: 顔作成ジオメトリデータ12
	float faceGeoData12;

	// NAME: 顔作成ジオメトリデータ13
	// DESC: 顔作成ジオメトリデータ13
	float faceGeoData13;

	// NAME: 顔作成ジオメトリデータ14
	// DESC: 顔作成ジオメトリデータ14
	float faceGeoData14;

	// NAME: 顔作成ジオメトリデータ15
	// DESC: 顔作成ジオメトリデータ15
	float faceGeoData15;

	// NAME: 顔作成ジオメトリデータ16
	// DESC: 顔作成ジオメトリデータ16
	float faceGeoData16;

	// NAME: 顔作成ジオメトリデータ17
	// DESC: 顔作成ジオメトリデータ17
	float faceGeoData17;

	// NAME: 顔作成ジオメトリデータ18
	// DESC: 顔作成ジオメトリデータ18
	float faceGeoData18;

	// NAME: 顔作成ジオメトリデータ19
	// DESC: 顔作成ジオメトリデータ19
	float faceGeoData19;

	// NAME: 顔作成ジオメトリデータ20
	// DESC: 顔作成ジオメトリデータ20
	float faceGeoData20;

	// NAME: 顔作成ジオメトリデータ21
	// DESC: 顔作成ジオメトリデータ21
	float faceGeoData21;

	// NAME: 顔作成ジオメトリデータ22
	// DESC: 顔作成ジオメトリデータ22
	float faceGeoData22;

	// NAME: 顔作成ジオメトリデータ23
	// DESC: 顔作成ジオメトリデータ23
	float faceGeoData23;

	// NAME: 顔作成ジオメトリデータ24
	// DESC: 顔作成ジオメトリデータ24
	float faceGeoData24;

	// NAME: 顔作成ジオメトリデータ25
	// DESC: 顔作成ジオメトリデータ25
	float faceGeoData25;

	// NAME: 顔作成ジオメトリデータ26
	// DESC: 顔作成ジオメトリデータ26
	float faceGeoData26;

	// NAME: 顔作成ジオメトリデータ27
	// DESC: 顔作成ジオメトリデータ27
	float faceGeoData27;

	// NAME: 顔作成ジオメトリデータ28
	// DESC: 顔作成ジオメトリデータ28
	float faceGeoData28;

	// NAME: 顔作成ジオメトリデータ29
	// DESC: 顔作成ジオメトリデータ29
	float faceGeoData29;

	// NAME: 顔作成ジオメトリデータ30
	// DESC: 顔作成ジオメトリデータ30
	float faceGeoData30;

	// NAME: 顔作成ジオメトリデータ31
	// DESC: 顔作成ジオメトリデータ31
	float faceGeoData31;

	// NAME: 顔作成ジオメトリデータ32
	// DESC: 顔作成ジオメトリデータ32
	float faceGeoData32;

	// NAME: 顔作成ジオメトリデータ33
	// DESC: 顔作成ジオメトリデータ33
	float faceGeoData33;

	// NAME: 顔作成ジオメトリデータ34
	// DESC: 顔作成ジオメトリデータ34
	float faceGeoData34;

	// NAME: 顔作成ジオメトリデータ35
	// DESC: 顔作成ジオメトリデータ35
	float faceGeoData35;

	// NAME: 顔作成ジオメトリデータ36
	// DESC: 顔作成ジオメトリデータ36
	float faceGeoData36;

	// NAME: 顔作成ジオメトリデータ37
	// DESC: 顔作成ジオメトリデータ37
	float faceGeoData37;

	// NAME: 顔作成ジオメトリデータ38
	// DESC: 顔作成ジオメトリデータ38
	float faceGeoData38;

	// NAME: 顔作成ジオメトリデータ39
	// DESC: 顔作成ジオメトリデータ39
	float faceGeoData39;

	// NAME: 顔作成ジオメトリデータ40
	// DESC: 顔作成ジオメトリデータ40
	float faceGeoData40;

	// NAME: 顔作成ジオメトリデータ41
	// DESC: 顔作成ジオメトリデータ41
	float faceGeoData41;

	// NAME: 顔作成ジオメトリデータ42
	// DESC: 顔作成ジオメトリデータ42
	float faceGeoData42;

	// NAME: 顔作成ジオメトリデータ43
	// DESC: 顔作成ジオメトリデータ43
	float faceGeoData43;

	// NAME: 顔作成ジオメトリデータ44
	// DESC: 顔作成ジオメトリデータ44
	float faceGeoData44;

	// NAME: 顔作成ジオメトリデータ45
	// DESC: 顔作成ジオメトリデータ45
	float faceGeoData45;

	// NAME: 顔作成ジオメトリデータ46
	// DESC: 顔作成ジオメトリデータ46
	float faceGeoData46;

	// NAME: 顔作成ジオメトリデータ47
	// DESC: 顔作成ジオメトリデータ47
	float faceGeoData47;

	// NAME: 顔作成ジオメトリデータ48
	// DESC: 顔作成ジオメトリデータ48
	float faceGeoData48;

	// NAME: 顔作成ジオメトリデータ49
	// DESC: 顔作成ジオメトリデータ49
	float faceGeoData49;

	// NAME: 顔作成ジオメトリデータ50
	// DESC: 顔作成ジオメトリデータ50
	float faceGeoData50;

	// NAME: 顔作成ジオメトリデータ51
	// DESC: 顔作成ジオメトリデータ51
	float faceGeoData51;

	// NAME: 顔作成ジオメトリデータ52
	// DESC: 顔作成ジオメトリデータ52
	float faceGeoData52;

	// NAME: 顔作成ジオメトリデータ53
	// DESC: 顔作成ジオメトリデータ53
	float faceGeoData53;

	// NAME: 顔作成ジオメトリデータ54
	// DESC: 顔作成ジオメトリデータ54
	float faceGeoData54;

	// NAME: 顔作成ジオメトリデータ55
	// DESC: 顔作成ジオメトリデータ55
	float faceGeoData55;

	// NAME: 顔作成ジオメトリデータ56
	// DESC: 顔作成ジオメトリデータ56
	float faceGeoData56;

	// NAME: 顔作成ジオメトリデータ57
	// DESC: 顔作成ジオメトリデータ57
	float faceGeoData57;

	// NAME: 顔作成ジオメトリデータ58
	// DESC: 顔作成ジオメトリデータ58
	float faceGeoData58;

	// NAME: 顔作成ジオメトリデータ59
	// DESC: 顔作成ジオメトリデータ59
	float faceGeoData59;

	// NAME: 顔作成ジオメトリデータ60
	// DESC: 顔作成ジオメトリデータ60
	float faceGeoData60;

	// NAME: 顔作成テクスチャデータ00
	// DESC: 顔作成テクスチャデータ00
	float faceTexData00;

	// NAME: 顔作成テクスチャデータ01
	// DESC: 顔作成テクスチャデータ01
	float faceTexData01;

	// NAME: 顔作成テクスチャデータ02
	// DESC: 顔作成テクスチャデータ02
	float faceTexData02;

	// NAME: 顔作成テクスチャデータ03
	// DESC: 顔作成テクスチャデータ03
	float faceTexData03;

	// NAME: 顔作成テクスチャデータ04
	// DESC: 顔作成テクスチャデータ04
	float faceTexData04;

	// NAME: 顔作成テクスチャデータ05
	// DESC: 顔作成テクスチャデータ05
	float faceTexData05;

	// NAME: 顔作成テクスチャデータ06
	// DESC: 顔作成テクスチャデータ06
	float faceTexData06;

	// NAME: 顔作成テクスチャデータ07
	// DESC: 顔作成テクスチャデータ07
	float faceTexData07;

	// NAME: 顔作成テクスチャデータ08
	// DESC: 顔作成テクスチャデータ08
	float faceTexData08;

	// NAME: 顔作成テクスチャデータ09
	// DESC: 顔作成テクスチャデータ09
	float faceTexData09;

	// NAME: 顔作成テクスチャデータ10
	// DESC: 顔作成テクスチャデータ10
	float faceTexData10;

	// NAME: 顔作成テクスチャデータ11
	// DESC: 顔作成テクスチャデータ11
	float faceTexData11;

	// NAME: 顔作成テクスチャデータ12
	// DESC: 顔作成テクスチャデータ12
	float faceTexData12;

	// NAME: 顔作成テクスチャデータ13
	// DESC: 顔作成テクスチャデータ13
	float faceTexData13;

	// NAME: 顔作成テクスチャデータ14
	// DESC: 顔作成テクスチャデータ14
	float faceTexData14;

	// NAME: 顔作成テクスチャデータ15
	// DESC: 顔作成テクスチャデータ15
	float faceTexData15;

	// NAME: 顔作成テクスチャデータ16
	// DESC: 顔作成テクスチャデータ16
	float faceTexData16;

	// NAME: 顔作成テクスチャデータ17
	// DESC: 顔作成テクスチャデータ17
	float faceTexData17;

	// NAME: 顔作成テクスチャデータ18
	// DESC: 顔作成テクスチャデータ18
	float faceTexData18;

	// NAME: 顔作成テクスチャデータ19
	// DESC: 顔作成テクスチャデータ19
	float faceTexData19;

	// NAME: 顔作成テクスチャデータ20
	// DESC: 顔作成テクスチャデータ20
	float faceTexData20;

	// NAME: 顔作成テクスチャデータ21
	// DESC: 顔作成テクスチャデータ21
	float faceTexData21;

	// NAME: 顔作成テクスチャデータ22
	// DESC: 顔作成テクスチャデータ22
	float faceTexData22;

	// NAME: 顔作成テクスチャデータ23
	// DESC: 顔作成テクスチャデータ23
	float faceTexData23;

	// NAME: 顔作成テクスチャデータ24
	// DESC: 顔作成テクスチャデータ24
	float faceTexData24;

	// NAME: 顔作成テクスチャデータ25
	// DESC: 顔作成テクスチャデータ25
	float faceTexData25;

	// NAME: 顔作成テクスチャデータ26
	// DESC: 顔作成テクスチャデータ26
	float faceTexData26;

	// NAME: 顔作成テクスチャデータ27
	// DESC: 顔作成テクスチャデータ27
	float faceTexData27;

	// NAME: 顔作成テクスチャデータ28
	// DESC: 顔作成テクスチャデータ28
	float faceTexData28;

	// NAME: 顔作成テクスチャデータ29
	// DESC: 顔作成テクスチャデータ29
	float faceTexData29;

	// NAME: 顔作成テクスチャデータ30
	// DESC: 顔作成テクスチャデータ30
	float faceTexData30;

	// NAME: 顔作成テクスチャデータ31
	// DESC: 顔作成テクスチャデータ31
	float faceTexData31;

	// NAME: 顔作成テクスチャデータ32
	// DESC: 顔作成テクスチャデータ32
	float faceTexData32;

	// NAME: 顔作成テクスチャデータ33
	// DESC: 顔作成テクスチャデータ33
	float faceTexData33;

	// NAME: 顔作成テクスチャデータ34
	// DESC: 顔作成テクスチャデータ34
	float faceTexData34;

	// NAME: 顔作成テクスチャデータ35
	// DESC: 顔作成テクスチャデータ35
	float faceTexData35;

	// NAME: 火傷跡
	// DESC: 火傷跡
	float burn_scar;
} FACE_RANGE_PARAM_ST;

#endif
