/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_AI_ATTACK_PARAM_ST_H
#define _PARAMDEF_AI_ATTACK_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AI_ATTACK_PARAM_ST {

	// NAME: 参照ID
	// DESC: NPC思考パラメータで指定するID
	int32_t attackTableId;

	// NAME: 攻撃ID
	// DESC: 攻撃の番号
	int32_t attackId;

	// NAME: 成功判定距離
	// DESC: Common_Attack系のサブゴールの引数用
	float successDistance;

	// NAME: 攻撃前旋回時間
	// DESC: Common_Attack系のサブゴールの引数用
	float turnTimeBeforeAttack;

	// NAME: 正面判定角度
	// DESC: Common_Attack系のサブゴールの引数用
	int16_t frontAngleRange;

	// NAME: 上方実行閾値
	// DESC: Common_Attack系のサブゴールの引数用
	int16_t upAngleThreshold;

	// NAME: 下方実行閾値
	// DESC: Common_Attack系のサブゴールの引数用
	int16_t downAngleThershold;

	// NAME: 始動技か
	// DESC: コンボの2段目以降の攻撃は×
	uint8_t isFirstAttack;

	// NAME: 適正距離外で選択するか
	// DESC: 適正距離外の時に選択対象にするかどうか
	uint8_t doesSelectOnOutRange;

	// NAME: 最小適正距離
	// DESC: 攻撃の適正距離の最小値
	float minOptimalDistance;

	// NAME: 最大適正距離
	// DESC: 攻撃の適性距離の最大値
	float maxOptimalDistance;

	// NAME: 適正角度基準方向1
	// DESC: 攻撃の適正角度の基準となる方向（XZ平面）
	int16_t baseDirectionForOptimalAngle1;

	// NAME: 適正角度基準範囲1
	// DESC: 攻撃の適性角度の範囲
	int16_t optimalAttackAngleRange1;

	// NAME: 適正角度基準方向2
	// DESC: 攻撃の適性確度の基準となる方向（XZ平面）
	int16_t baseDirectionForOptimalAngle2;

	// NAME: 適正角度基準範囲2
	// DESC: 攻撃の適性角度の範囲
	int16_t optimalAttackAngleRange2;

	// NAME: 実行可能インターバル
	// DESC: 一度攻撃を行ってから再度使うために必要な時間
	float intervalForExec;

	// NAME: 選択レート
	// DESC: 選択されやすさを倍率で指定する
	float selectionTendency;

	// NAME: 近距離選択レート
	// DESC: 近距離での選択レート
	float shortRangeTendency;

	// NAME: 中距離選択レート
	// DESC: 中距離での選択レート
	float middleRangeTendency;

	// NAME: 遠距離選択レート
	// DESC: 遠距離での選択レート
	float farRangeTendency;

	// NAME: 範囲外レート
	// DESC: 範囲外での選択レート
	float outRangeTendency;

	// NAME: 派生攻撃1
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId1;

	// NAME: 派生攻撃2
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId2;

	// NAME: 派生攻撃3
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId3;

	// NAME: 派生攻撃4
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId4;

	// NAME: 派生攻撃5
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId5;

	// NAME: 派生攻撃6
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId6;

	// NAME: 派生攻撃7
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId7;

	// NAME: 派生攻撃8
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId8;

	// NAME: 派生攻撃9
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId9;

	// NAME: 派生攻撃10
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId10;

	// NAME: 派生攻撃11
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId11;

	// NAME: 派生攻撃12
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId12;

	// NAME: 派生攻撃13
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId13;

	// NAME: 派生攻撃14
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId14;

	// NAME: 派生攻撃15
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId15;

	// NAME: 派生攻撃16
	// DESC: 派生可能な攻撃の番号
	int32_t deriveAttackId16;

	// NAME: ゴールの最小寿命
	// DESC: ゴールの最小寿命
	float goalLifeMin;

	// NAME: ゴールの最大寿命
	// DESC: ゴールの最大寿命
	float goalLifeMax;

	// NAME: 適正距離内で選択するか
	// DESC: 適正距離内の時に選択対象にするかどうか
	uint8_t doesSelectOnInnerRange;

	// NAME: 初撃として使用するか
	// DESC: 初撃として使用するか
	uint8_t enableAttackOnBattleStart;

	// NAME: ターゲットダウン時選択するか
	// DESC: ターゲットダウン時選択するか
	uint8_t doesSelectOnTargetDown;

	// NAME: pad
	uint8_t pad1[1];

	// NAME: 最小到達判定距離
	// DESC: 最小到達判定距離
	float minArriveDistance;

	// NAME: 最大到達判定距離
	// DESC: 最大到達判定距離
	float maxArriveDistance;

	// NAME: 連続攻撃実行距離
	// DESC: 二段目以降の攻撃の実行判定に使用する距離
	float comboExecDistance;

	// NAME: 連続攻撃実行角度
	// DESC: 二段目以降の攻撃の実行判定に使用する距離
	float comboExecRange;
} AI_ATTACK_PARAM_ST;

#endif
