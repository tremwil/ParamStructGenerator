/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_VOLUMETRIC_EFFECT_QUALITY_DETAIL_H
#define _PARAMDEF_CS_VOLUMETRIC_EFFECT_QUALITY_DETAIL_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_VOLUMETRIC_EFFECT_QUALITY_DETAIL {

	// NAME: フォグ有効
	// DESC: フォグ有効
	uint8_t fogEnabled;

	// NAME: フォグシャドウ許可
	// DESC: フォグシャドウ許可
	uint8_t fogShadowEnabled;

	// NAME: dmy
	// DESC: dmy
	uint8_t dmy[2];

	// NAME: シャドウのサンプルカウントオフセット。
	// DESC: シャドウのサンプルカウントオフセット。
	int32_t fogShadowSampleCountBias;

	// NAME: ローカルライト計算距離スケール (0にするとローカルライト計算をしない)
	// DESC: ローカルライト計算距離スケール (0にするとローカルライト計算をしない)
	float fogLocalLightDistScale;

	// NAME: フォグボリュームサイズスケーラ
	// DESC: フォグボリュームサイズスケーラ
	uint32_t fogVolueSizeScaler;

	// NAME: フォグボリュームサイズ除算
	// DESC: フォグボリュームサイズ除算
	uint32_t fogVolueSizeDivider;

	// NAME: フォグボリューム奥行きスライススケーラ
	// DESC: フォグボリューム奥行きスライススケーラ
	uint32_t fogVolumeDepthScaler;

	// NAME: フォグボリューム奥行きスライス除算
	// DESC: フォグボリューム奥行きスライス除算
	uint32_t fogVolumeDepthDivider;

	// NAME: 配置式フォグボリューム有効
	// DESC: 配置式フォグボリューム有効
	uint8_t fogVolumeEnabled;

	// NAME: アップスケール種別
	// DESC: アップスケール時の手法種別
	uint8_t fogVolumeUpScaleType;

	// NAME: バイラテラル時のみ行われるエッジ補正レベル
	// DESC: バイラテラル時のみ行われるエッジ補正レベル(0:無効,1:1/2x1/2解像度でのエッジ再描画許可,2:1/2x1/2+1x1解像度でパラメータ削減ありのエッジ再描画許可,3:1/2x1/2+1x1解像度でのエッジ再描画許可)
	uint8_t fogVolumeEdgeCorrectionLevel;

	// NAME: レイマーチング時のサンプリング数のオフセット
	// DESC: レイマーチング時のサンプリング数のオフセット
	int8_t fogVolumeRayMarcingSampleCountOffset;

	// NAME: シャドウ許可
	// DESC: シャドウ許可(領域に影が落ちる、領域内の密度変化による陰影処理を指す)
	uint8_t fogVolumeShadowEnabled;

	// NAME: シャドウ許可時に設定にかかわらず領域に強制的に影を落とす
	// DESC: シャドウ許可時に設定にかかわらず領域に強制的に影を落とす(陰影処理は影響をうけない)
	uint8_t fogVolumeForceShadowing;

	// NAME: フォグボリュームのアップスケール処理解像度
	uint8_t fogVolumeResolution;

	// NAME: pad
	uint8_t pad2[1];
} CS_VOLUMETRIC_EFFECT_QUALITY_DETAIL;

#endif
