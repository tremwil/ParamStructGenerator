/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_EQUIP_MTRL_SET_PARAM_ST_H
#define _PARAMDEF_EQUIP_MTRL_SET_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EQUIP_MTRL_SET_PARAM_ST {

	// NAME: 必要素材アイテムID01
	// DESC: 武具強化に必要な素材アイテムIDです。
	int32_t materialId01;

	// NAME: 必要素材アイテムID02
	// DESC: 武具強化に必要な素材アイテムIDです。
	int32_t materialId02;

	// NAME: 必要素材アイテムID03
	// DESC: 武具強化に必要な素材アイテムIDです。
	int32_t materialId03;

	// NAME: 必要素材アイテムID04
	// DESC: 武具強化に必要な素材アイテムIDです。
	int32_t materialId04;

	// NAME: 必要素材アイテムID05
	// DESC: 武具強化に必要な素材アイテムIDです。
	int32_t materialId05;

	// NAME: 必要素材アイテムID06
	// DESC: 武具強化に必要な素材アイテムIDです。
	int32_t materialId06;

	// NAME: パディング
	// DESC: パディング。素材アイテムIDが増えたとき用
	uint8_t pad_id[8];

	// NAME: 必要個数01
	// DESC: 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum01;

	// NAME: 必要個数02
	// DESC: 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum02;

	// NAME: 必要個数03
	// DESC: 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum03;

	// NAME: 必要個数04
	// DESC: 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum04;

	// NAME: 必要個数05
	// DESC: 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum05;

	// NAME: 必要個数06
	// DESC: 武具強化に必要な素材アイテムの個数です。
	int8_t itemNum06;

	// NAME: パディング
	// DESC: パディング。アイテムの個数が増えたとき用
	uint8_t pad_num[2];

	// NAME: 必要素材アイテムカテゴリ01
	// DESC: 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate01;

	// NAME: 必要素材アイテムカテゴリ02
	// DESC: 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate02;

	// NAME: 必要素材アイテムカテゴリ03
	// DESC: 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate03;

	// NAME: 必要素材アイテムカテゴリ04
	// DESC: 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate04;

	// NAME: 必要素材アイテムカテゴリ05
	// DESC: 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate05;

	// NAME: 必要素材アイテムカテゴリ06
	// DESC: 武具強化に必要な素材アイテムのカテゴリです。
	uint8_t materialCate06;

	// NAME: パディング
	// DESC: パディング。カテゴリが増えたとき用
	uint8_t pad_cate[2];

	// NAME: 個数表示を無効化01
	// DESC: 個数表示を無効化するか(強化ショップ用)
	uint8_t isDisableDispNum01: 1;

	// NAME: 個数表示を無効化02
	// DESC: 個数表示を無効化するか
	uint8_t isDisableDispNum02: 1;

	// NAME: 個数表示を無効化03
	// DESC: 個数表示を無効化するか
	uint8_t isDisableDispNum03: 1;

	// NAME: 個数表示を無効化04
	// DESC: 個数表示を無効化するか
	uint8_t isDisableDispNum04: 1;

	// NAME: 個数表示を無効化05
	// DESC: 個数表示を無効化するか
	uint8_t isDisableDispNum05: 1;

	// NAME: 個数表示を無効化06
	// DESC: 個数表示を無効化するか
	uint8_t isDisableDispNum06: 1;

	// NAME: パディング
	// DESC: パディングです。
	uint8_t pad[3];
} EQUIP_MTRL_SET_PARAM_ST;

#endif
