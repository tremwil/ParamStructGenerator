/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_COOL_TIME_PARAM_ST_H
#define _PARAMDEF_COOL_TIME_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _COOL_TIME_PARAM_ST {

	// NAME: 制限時間（協力霊数0）
	// DESC: 制限時間[sec]（協力霊数0）
	float limitationTime_0;

	// NAME: 監視時間（協力霊数0）
	// DESC: 監視時間[sec]（協力霊数0）
	float observeTime_0;

	// NAME: 制限時間（協力霊数1）
	// DESC: 制限時間[sec]（協力霊数1）
	float limitationTime_1;

	// NAME: 監視時間（協力霊数1）
	// DESC: 監視時間[sec]（協力霊数1）
	float observeTime_1;

	// NAME: 制限時間（協力霊数2）
	// DESC: 制限時間[sec]（協力霊数2）
	float limitationTime_2;

	// NAME: 監視時間（協力霊数2）
	// DESC: 監視時間[sec]（協力霊数2）
	float observeTime_2;

	// NAME: 制限時間（協力霊数3）
	// DESC: 制限時間[sec]（協力霊数3）
	float limitationTime_3;

	// NAME: 監視時間（協力霊数3）
	// DESC: 監視時間[sec]（協力霊数3）
	float observeTime_3;
} COOL_TIME_PARAM_ST;

#endif
