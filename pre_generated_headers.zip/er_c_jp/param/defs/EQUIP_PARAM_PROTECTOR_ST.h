/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_EQUIP_PARAM_PROTECTOR_ST_H
#define _PARAMDEF_EQUIP_PARAM_PROTECTOR_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 6
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _EQUIP_PARAM_PROTECTOR_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 7;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: ソートID
	// DESC: ソートID(プログラム内で強化レベルを加味しているので s32 では７桁が限界)
	int32_t sortId;

	// NAME: 徘徊装備ID
	// DESC: 徘徊ゴースト用の差し替え装備ID.
	uint32_t wanderingEquipId;

	// NAME: 睡眠耐性
	// DESC: 睡眠状態異常へのかかりにくさ
	uint16_t resistSleep;

	// NAME: 発狂耐性
	// DESC: 発狂状態異常へのかかりにくさ
	uint16_t resistMadness;

	// NAME: SA耐久値
	// DESC: スーパーアーマー耐久力
	float saDurability;

	// NAME: 強靭度 補正倍率
	// DESC: 強靭度の基本値を補正する倍率です
	float toughnessCorrectRate;

	// NAME: 修理価格
	// DESC: 修理基本価格
	int32_t fixPrice;

	// NAME: 基本価格
	// DESC: 基本価格
	int32_t basicPrice;

	// NAME: 売却価格
	// DESC: 販売価格
	int32_t sellValue;

	// NAME: 重量[kg]
	// DESC: 重量[kg].
	float weight;

	// NAME: 常駐特殊効果ID1
	// DESC: 常駐特殊効果ID1
	int32_t residentSpEffectId;

	// NAME: 常駐特殊効果ID2
	// DESC: 常駐特殊効果ID2
	int32_t residentSpEffectId2;

	// NAME: 常駐特殊効果ID3
	// DESC: 常駐特殊効果ID3
	int32_t residentSpEffectId3;

	// NAME: 素材ID
	// DESC: 武器強化に必要な素材パラメータID
	int32_t materialSetId;

	// NAME: 部位ダメージ率
	// DESC: 部位ダメージ率
	float partsDamageRate;

	// NAME: SA回復時間補正値
	// DESC: スーパーアーマー回復時間の補正値
	float corectSARecover;

	// NAME: 派生元
	// DESC: この防具の強化元防具ID
	int32_t originEquipPro;

	// NAME: 派生元 強化+1
	// DESC: この防具の強化元防具ID1
	int32_t originEquipPro1;

	// NAME: 派生元 強化+2
	// DESC: この防具の強化元防具ID2
	int32_t originEquipPro2;

	// NAME: 派生元 強化+3
	// DESC: この防具の強化元防具ID3
	int32_t originEquipPro3;

	// NAME: 派生元 強化+4
	// DESC: この防具の強化元防具ID4
	int32_t originEquipPro4;

	// NAME: 派生元 強化+5
	// DESC: この防具の強化元防具ID5
	int32_t originEquipPro5;

	// NAME: 派生元 強化+6
	// DESC: この防具の強化元防具ID6
	int32_t originEquipPro6;

	// NAME: 派生元 強化+7
	// DESC: この防具の強化元防具ID7
	int32_t originEquipPro7;

	// NAME: 派生元 強化+8
	// DESC: この防具の強化元防具ID8
	int32_t originEquipPro8;

	// NAME: 派生元 強化+9
	// DESC: この防具の強化元防具ID9
	int32_t originEquipPro9;

	// NAME: 派生元 強化+10
	// DESC: この防具の強化元防具ID10
	int32_t originEquipPro10;

	// NAME: 派生元 強化+11
	// DESC: この防具の強化元防具ID11
	int32_t originEquipPro11;

	// NAME: 派生元 強化+12
	// DESC: この防具の強化元防具ID12
	int32_t originEquipPro12;

	// NAME: 派生元 強化+13
	// DESC: この防具の強化元防具ID13
	int32_t originEquipPro13;

	// NAME: 派生元 強化+14
	// DESC: この防具の強化元防具ID14
	int32_t originEquipPro14;

	// NAME: 派生元 強化+15
	// DESC: この防具の強化元防具ID15
	int32_t originEquipPro15;

	// NAME: 男横顔拡大スケール
	float faceScaleM_ScaleX;

	// NAME: 男前顔拡大スケール
	float faceScaleM_ScaleZ;

	// NAME: 男横顔拡大最大倍率
	float faceScaleM_MaxX;

	// NAME: 男前顔拡大最大倍率
	float faceScaleM_MaxZ;

	// NAME: 女横顔拡大スケール
	float faceScaleF_ScaleX;

	// NAME: 女前顔拡大スケール
	float faceScaleF_ScaleZ;

	// NAME: 女横顔拡大最大倍率
	float faceScaleF_MaxX;

	// NAME: 女前顔拡大最大倍率
	float faceScaleF_MaxZ;

	// NAME: QWCID
	// DESC: QWCのパラメタID
	int32_t qwcId;

	// NAME: 装備モデル番号
	// DESC: 装備モデルの番号.
	uint16_t equipModelId;

	// NAME: 男用アイコンID
	// DESC: 男用メニューアイコンID.
	uint16_t iconIdM;

	// NAME: 女用アイコンID
	// DESC: 女用メニューアイコンID.
	uint16_t iconIdF;

	// NAME: ノックバックカット率
	// DESC: ノックバックの減少値.
	uint16_t knockBack;

	// NAME: ノックバック反発率
	// DESC: ノックバックの反発率.
	uint16_t knockbackBounceRate;

	// NAME: 耐久度
	// DESC: 初期耐久度.
	uint16_t durability;

	// NAME: 耐久度最大値
	// DESC: 新品耐久度.
	uint16_t durabilityMax;

	// NAME: pad
	uint8_t pad03[2];

	// NAME: はじき防御力
	// DESC: 敵の攻撃のはじき返し判定に利用.
	uint16_t defFlickPower;

	// NAME: 物理防御力
	// DESC: 物理攻撃のダメージ防御.
	uint16_t defensePhysics;

	// NAME: 魔法防御力
	// DESC: 魔法攻撃のダメージ防御.
	uint16_t defenseMagic;

	// NAME: 炎防御力
	// DESC: 炎攻撃のダメージ防御.
	uint16_t defenseFire;

	// NAME: 電撃防御力
	// DESC: 電撃攻撃のダメージ防御.
	uint16_t defenseThunder;

	// NAME: 斬撃防御力
	// DESC: 攻撃タイプを見て、斬撃属性のときは、防御力を減少させる
	int16_t defenseSlash;

	// NAME: 打撃防御力
	// DESC: 攻撃属性を見て、打撃属性のときは、防御力を減少させる.
	int16_t defenseBlow;

	// NAME: 刺突防御力
	// DESC: 攻撃属性を見て、打撃属性のときは、防御力を減少させる.
	int16_t defenseThrust;

	// NAME: 毒耐性
	// DESC: 毒状態異常へのかかりにくさ
	uint16_t resistPoison;

	// NAME: 疫病耐性
	// DESC: 疫病状態異常へのかかりにくさ
	uint16_t resistDisease;

	// NAME: 出血耐性
	// DESC: 出血状態異常へのかかりにくさ
	uint16_t resistBlood;

	// NAME: 呪耐性
	// DESC: 呪い状態異常へのかかりにくさ
	uint16_t resistCurse;

	// NAME: 強化タイプID
	// DESC: 強化タイプID
	int16_t reinforceTypeId;

	// NAME: トロフィー
	// DESC: トロフィーシステムに関係あるか？
	int16_t trophySGradeId;

	// NAME: ショップレベル
	// DESC: お店で販売できるレベル
	int16_t shopLv;

	// NAME: ノックバックパラメータID
	// DESC: ノックバックで使用するパラメータのID
	uint8_t knockbackParamId;

	// NAME: はじき時ダメージ減衰率[%]
	// DESC: はじき時のダメージ減衰率に使用
	uint8_t flickDamageCutRate;

	// NAME: 装備モデル種別
	// DESC: 装備モデルの種別.
	uint8_t equipModelCategory;

	// NAME: 装備モデル性別
	// DESC: 装備モデルの性別.
	uint8_t equipModelGender;

	// NAME: 防具カテゴリ
	// DESC: 防具のカテゴリ.
	uint8_t protectorCategory;

	// NAME: レア度
	// DESC: アイテム取得ログで使うレア度
	uint8_t rarity;

	// NAME: ソートアイテム種別ID
	// DESC: ソートアイテム種別ID。ソート「アイテム種別順」にて、同じIDは同じグループとしてまとめて表示されます
	uint8_t sortGroupId;

	// NAME: 部位ダメージ適用攻撃
	// DESC: 部位ダメージ判定を行う攻撃タイプを設定
	uint8_t partsDmgType;

	// NAME: パディング
	uint8_t pad04[2];

	// NAME: 預けれるか
	// DESC: 倉庫に預けれるか
	uint8_t isDeposit: 1;

	// NAME: 頭装備
	// DESC: 頭装備か.
	uint8_t headEquip: 1;

	// NAME: 胴装備
	// DESC: 胴装備か.
	uint8_t bodyEquip: 1;

	// NAME: 腕装備
	// DESC: 腕装備か.
	uint8_t armEquip: 1;

	// NAME: 脚装備
	// DESC: 脚装備か.
	uint8_t legEquip: 1;

	// NAME: 顔スケールを使用するか
	// DESC: 顔スケールを使用するか
	uint8_t useFaceScale: 1;

	// NAME: 弱点アニメをスキップするか
	// DESC: 弱点ダメージアニメ再生をスキップするかどうか。アニメを再生しないだけで「部位ダメージ率」「防御材質」は弱点として扱われます。
	uint8_t isSkipWeakDamageAnim: 1;

	// NAME: パディング
	uint8_t pad06: 1;

	// NAME: 弱点防御材質バリエーション値
	// DESC: 弱点防御材質と組み合わせて状態異常、ダメージSFX,SEのバリエーション分けに使用する値です。SEQ16473
	uint8_t defenseMaterialVariationValue_Weak;

	// NAME: フットデカール識別子2
	// DESC: 自動フットエフェクトのデカールID。床材質も考慮される。防具カテゴリ」が「脚」のときのみ利用される。
	int16_t autoFootEffectDecalBaseId2;

	// NAME: フットデカール識別子3
	// DESC: 自動フットエフェクトのデカールID。床材質も考慮される。防具カテゴリ」が「脚」のときのみ利用される。
	int16_t autoFootEffectDecalBaseId3;

	// NAME: 防御材質バリエーション値
	// DESC: 防御材質と組み合わせて状態異常、ダメージSFX,SEのバリエーション分けに使用する値です。SEQ16473
	uint8_t defenseMaterialVariationValue;

	// NAME: 捨てれるか
	// DESC: アイテムを捨てれるか？TRUE=捨てれる
	uint8_t isDiscard: 1;

	// NAME: その場に置けるか
	// DESC: アイテムをその場に置けるか？TRUE=置ける
	uint8_t isDrop: 1;

	// NAME: マルチドロップ共有禁止か
	// DESC: マルチドロップ共有禁止か
	uint8_t disableMultiDropShare: 1;

	// NAME: DLC用シンプルモデルありか
	// DESC: ＤＬＣ用シンプルモデルが存在しているか
	uint8_t simpleModelForDlc: 1;

	// NAME: 取得ログ表示条件
	// DESC: アイテム取得時にアイテム取得ログに表示するか（未入力: ○）
	uint8_t showLogCondType: 1;

	// NAME: 取得ダイアログ表示条件
	// DESC: アイテム取得時にアイテム取得ダイアログに表示するか（未入力: newのみ）
	uint8_t showDialogCondType: 2;

	// NAME: パディング
	uint8_t pad: 1;

	// NAME: 無属性ダメージ倍率
	// DESC: 無属性ダメージ倍率
	float neutralDamageCutRate;

	// NAME: 斬撃ダメージ倍率
	// DESC: 斬撃ダメージ倍率
	float slashDamageCutRate;

	// NAME: 打撃ダメージ倍率
	// DESC: 打撃ダメージ倍率
	float blowDamageCutRate;

	// NAME: 刺突ダメージ倍率
	// DESC: 刺突ダメージ倍率
	float thrustDamageCutRate;

	// NAME: 魔法ダメージ倍率
	// DESC: 魔法ダメージ倍率
	float magicDamageCutRate;

	// NAME: 火炎ダメージ倍率
	// DESC: 火炎ダメージ倍率
	float fireDamageCutRate;

	// NAME: 電撃ダメージ倍率
	// DESC: 電撃ダメージ倍率
	float thunderDamageCutRate;

	// NAME: 防御材質1【SFX】
	// DESC: 移動/防御時のSFX用.1
	uint16_t defenseMaterialSfx1;

	// NAME: 弱点防御材質1【SFX】
	// DESC: 弱点部位ダメージ時のSFX用1
	uint16_t defenseMaterialSfx_Weak1;

	// NAME: 防御材質1【SE】
	// DESC: 移動/防御時のSE用.1
	uint16_t defenseMaterial1;

	// NAME: 弱点防御材質1【SE】
	// DESC: 弱点部位ダメージ時のSE用1
	uint16_t defenseMaterial_Weak1;

	// NAME: 防御材質2【SFX】
	// DESC: 移動/防御時のSFX用.2
	uint16_t defenseMaterialSfx2;

	// NAME: 弱点防御材質2【SFX】
	// DESC: 弱点部位ダメージ時のSFX用2
	uint16_t defenseMaterialSfx_Weak2;

	// NAME: 足装備材質【SE】
	// DESC: 足装備SE用材質。足装備のみ参照される。(【GR】SEQ10061) 「139:なし」の場合は防御材質1【SE】が参照される
	uint16_t footMaterialSe;

	// NAME: 弱点防御材質2【SE】
	// DESC: 弱点部位ダメージ時のSE用2
	uint16_t defenseMaterial_Weak2;

	// NAME: フットデカール識別子1
	// DESC: 自動フットエフェクトのデカールID。床材質も考慮される。防具カテゴリ」が「脚」のときのみ利用される。
	int32_t autoFootEffectDecalBaseId1;

	// NAME: 強靭度 被ダメージ倍率
	// DESC: 強靭度版カット率
	float toughnessDamageCutRate;

	// NAME: 強靭度 回復時間補正値
	// DESC: 強靭度の回復時間用の補正値
	float toughnessRecoverCorrection;

	// NAME: 闇ダメージ倍率
	// DESC: 闇ダメージ倍率
	float darkDamageCutRate;

	// NAME: 闇防御力
	// DESC: 闇攻撃のダメージ防御.
	uint16_t defenseDark;

	// NAME: PAD_元_#48#非表示
	// DESC: 元_#48#非表示
	uint8_t invisibleFlag48: 1;

	// NAME: PAD_元_#49#非表示
	// DESC: 元_#49#非表示
	uint8_t invisibleFlag49: 1;

	// NAME: PAD_元_#50#非表示
	// DESC: 元_#50#非表示
	uint8_t invisibleFlag50: 1;

	// NAME: PAD_元_#51#非表示
	// DESC: 元_#51#非表示
	uint8_t invisibleFlag51: 1;

	// NAME: PAD_元_#52#非表示
	// DESC: 元_#52#非表示
	uint8_t invisibleFlag52: 1;

	// NAME: PAD_元_#53#非表示
	// DESC: 元_#53#非表示
	uint8_t invisibleFlag53: 1;

	// NAME: PAD_元_#54#非表示
	// DESC: 元_#54#非表示
	uint8_t invisibleFlag54: 1;

	// NAME: PAD_元_#55#非表示
	// DESC: 元_#55#非表示
	uint8_t invisibleFlag55: 1;

	// NAME: PAD_元_#56#非表示
	// DESC: 元_#56#非表示
	uint8_t invisibleFlag56: 1;

	// NAME: PAD_元_#57#非表示
	// DESC: 元_#57#非表示
	uint8_t invisibleFlag57: 1;

	// NAME: PAD_元_#58#非表示
	// DESC: 元_#58#非表示
	uint8_t invisibleFlag58: 1;

	// NAME: PAD_元_#59#非表示
	// DESC: 元_#59#非表示
	uint8_t invisibleFlag59: 1;

	// NAME: PAD_元_#60#非表示
	// DESC: 元_#60#非表示
	uint8_t invisibleFlag60: 1;

	// NAME: PAD_元_#61#非表示
	// DESC: 元_#61#非表示
	uint8_t invisibleFlag61: 1;

	// NAME: PAD_元_#62#非表示
	// DESC: 元_#62#非表示
	uint8_t invisibleFlag62: 1;

	// NAME: PAD_元_#63#非表示
	// DESC: 元_#63#非表示
	uint8_t invisibleFlag63: 1;

	// NAME: PAD_元_#64#非表示
	// DESC: 元_#64#非表示
	uint8_t invisibleFlag64: 1;

	// NAME: PAD_元_#65#非表示
	// DESC: 元_#65#非表示
	uint8_t invisibleFlag65: 1;

	// NAME: PAD_元_#66#非表示
	// DESC: 元_#66#非表示
	uint8_t invisibleFlag66: 1;

	// NAME: PAD_元_#67#非表示
	// DESC: 元_#67#非表示
	uint8_t invisibleFlag67: 1;

	// NAME: PAD_元_#68#非表示
	// DESC: 元_#68#非表示
	uint8_t invisibleFlag68: 1;

	// NAME: PAD_元_#69#非表示
	// DESC: 元_#69#非表示
	uint8_t invisibleFlag69: 1;

	// NAME: PAD_元_#70#非表示
	// DESC: 元_#70#非表示
	uint8_t invisibleFlag70: 1;

	// NAME: PAD_元_#71#非表示
	// DESC: 元_#71#非表示
	uint8_t invisibleFlag71: 1;

	// NAME: PAD_元_#72#非表示
	// DESC: 元_#72#非表示
	uint8_t invisibleFlag72: 1;

	// NAME: PAD_元_#73#非表示
	// DESC: 元_#73#非表示
	uint8_t invisibleFlag73: 1;

	// NAME: PAD_元_#74#非表示
	// DESC: 元_#74#非表示
	uint8_t invisibleFlag74: 1;

	// NAME: PAD_元_#75#非表示
	// DESC: 元_#75#非表示
	uint8_t invisibleFlag75: 1;

	// NAME: PAD_元_#76#非表示
	// DESC: 元_#76#非表示
	uint8_t invisibleFlag76: 1;

	// NAME: PAD_元_#77#非表示
	// DESC: 元_#77#非表示
	uint8_t invisibleFlag77: 1;

	// NAME: PAD_元_#78#非表示
	// DESC: 元_#78#非表示
	uint8_t invisibleFlag78: 1;

	// NAME: PAD_元_#79#非表示
	// DESC: 元_#79#非表示
	uint8_t invisibleFlag79: 1;

	// NAME: PAD_元_#80#非表示
	// DESC: 元_#80#非表示
	uint8_t invisibleFlag80: 1;

	// NAME: パディング
	uint8_t padbit: 7;

	// NAME: 姿勢制御ID(胴)
	// DESC: 姿勢制御ID(胴)
	uint8_t postureControlId;

	// NAME: pad
	uint8_t pad2[4];

	// NAME: 販売価格
	// DESC: 販売価格
	int32_t saleValue;

	// NAME: 冷気耐性
	// DESC: 冷気状態異常へのかかりにくさ
	uint16_t resistFreeze;

	// NAME: #00#非表示(男女指定)
	// DESC: 前髪の先
	uint8_t invisibleFlag_SexVer00;

	// NAME: #01#非表示(男女指定)
	// DESC: 前髪の根元
	uint8_t invisibleFlag_SexVer01;

	// NAME: #02#非表示(男女指定)
	// DESC: もみあげ
	uint8_t invisibleFlag_SexVer02;

	// NAME: #03#非表示(男女指定)
	// DESC: 頭頂部
	uint8_t invisibleFlag_SexVer03;

	// NAME: #04#非表示(男女指定)
	// DESC: 頭頂部
	uint8_t invisibleFlag_SexVer04;

	// NAME: #05#非表示(男女指定)
	// DESC: 後ろ髪
	uint8_t invisibleFlag_SexVer05;

	// NAME: #06#非表示(男女指定)
	// DESC: 後ろ髪の先
	uint8_t invisibleFlag_SexVer06;

	// NAME: #07#非表示(男女指定)
	uint8_t invisibleFlag_SexVer07;

	// NAME: #08#非表示(男女指定)
	uint8_t invisibleFlag_SexVer08;

	// NAME: #09#非表示(男女指定)
	uint8_t invisibleFlag_SexVer09;

	// NAME: #10#非表示(男女指定)
	// DESC: 襟
	uint8_t invisibleFlag_SexVer10;

	// NAME: #11#非表示(男女指定)
	// DESC: 襟回り
	uint8_t invisibleFlag_SexVer11;

	// NAME: #12#非表示(男女指定)
	uint8_t invisibleFlag_SexVer12;

	// NAME: #13#非表示(男女指定)
	uint8_t invisibleFlag_SexVer13;

	// NAME: #14#非表示(男女指定)
	uint8_t invisibleFlag_SexVer14;

	// NAME: #15#非表示(男女指定)
	// DESC: 頭巾の裾
	uint8_t invisibleFlag_SexVer15;

	// NAME: #16#非表示(男女指定)
	uint8_t invisibleFlag_SexVer16;

	// NAME: #17#非表示(男女指定)
	uint8_t invisibleFlag_SexVer17;

	// NAME: #18#非表示(男女指定)
	uint8_t invisibleFlag_SexVer18;

	// NAME: #19#非表示(男女指定)
	uint8_t invisibleFlag_SexVer19;

	// NAME: #20#非表示(男女指定)
	// DESC: 袖A
	uint8_t invisibleFlag_SexVer20;

	// NAME: #21#非表示(男女指定)
	// DESC: 袖B
	uint8_t invisibleFlag_SexVer21;

	// NAME: #22#非表示(男女指定)
	uint8_t invisibleFlag_SexVer22;

	// NAME: #23#非表示(男女指定)
	uint8_t invisibleFlag_SexVer23;

	// NAME: #24#非表示(男女指定)
	uint8_t invisibleFlag_SexVer24;

	// NAME: #25#非表示(男女指定)
	// DESC: 腕
	uint8_t invisibleFlag_SexVer25;

	// NAME: #26#非表示(男女指定)
	uint8_t invisibleFlag_SexVer26;

	// NAME: #27#非表示(男女指定)
	uint8_t invisibleFlag_SexVer27;

	// NAME: #28#非表示(男女指定)
	uint8_t invisibleFlag_SexVer28;

	// NAME: #29#非表示(男女指定)
	uint8_t invisibleFlag_SexVer29;

	// NAME: #30#非表示(男女指定)
	// DESC: ベルト
	uint8_t invisibleFlag_SexVer30;

	// NAME: #31#非表示(男女指定)
	uint8_t invisibleFlag_SexVer31;

	// NAME: #32#非表示(男女指定)
	uint8_t invisibleFlag_SexVer32;

	// NAME: #33#非表示(男女指定)
	uint8_t invisibleFlag_SexVer33;

	// NAME: #34#非表示(男女指定)
	uint8_t invisibleFlag_SexVer34;

	// NAME: #35#非表示(男女指定)
	uint8_t invisibleFlag_SexVer35;

	// NAME: #36#非表示(男女指定)
	uint8_t invisibleFlag_SexVer36;

	// NAME: #37#非表示(男女指定)
	uint8_t invisibleFlag_SexVer37;

	// NAME: #38#非表示(男女指定)
	uint8_t invisibleFlag_SexVer38;

	// NAME: #39#非表示(男女指定)
	uint8_t invisibleFlag_SexVer39;

	// NAME: #40#非表示(男女指定)
	uint8_t invisibleFlag_SexVer40;

	// NAME: #41#非表示(男女指定)
	uint8_t invisibleFlag_SexVer41;

	// NAME: #42#非表示(男女指定)
	uint8_t invisibleFlag_SexVer42;

	// NAME: #43#非表示(男女指定)
	uint8_t invisibleFlag_SexVer43;

	// NAME: #44#非表示(男女指定)
	uint8_t invisibleFlag_SexVer44;

	// NAME: #45#非表示(男女指定)
	uint8_t invisibleFlag_SexVer45;

	// NAME: #46#非表示(男女指定)
	uint8_t invisibleFlag_SexVer46;

	// NAME: #47#非表示(男女指定)
	uint8_t invisibleFlag_SexVer47;

	// NAME: #48#非表示(男女指定)
	uint8_t invisibleFlag_SexVer48;

	// NAME: #49#非表示(男女指定)
	uint8_t invisibleFlag_SexVer49;

	// NAME: #50#非表示(男女指定)
	uint8_t invisibleFlag_SexVer50;

	// NAME: #51#非表示(男女指定)
	uint8_t invisibleFlag_SexVer51;

	// NAME: #52#非表示(男女指定)
	uint8_t invisibleFlag_SexVer52;

	// NAME: #53#非表示(男女指定)
	uint8_t invisibleFlag_SexVer53;

	// NAME: #54#非表示(男女指定)
	uint8_t invisibleFlag_SexVer54;

	// NAME: #55#非表示(男女指定)
	uint8_t invisibleFlag_SexVer55;

	// NAME: #56#非表示(男女指定)
	uint8_t invisibleFlag_SexVer56;

	// NAME: #57#非表示(男女指定)
	uint8_t invisibleFlag_SexVer57;

	// NAME: #58#非表示(男女指定)
	uint8_t invisibleFlag_SexVer58;

	// NAME: #59#非表示(男女指定)
	uint8_t invisibleFlag_SexVer59;

	// NAME: #60#非表示(男女指定)
	uint8_t invisibleFlag_SexVer60;

	// NAME: #61#非表示(男女指定)
	uint8_t invisibleFlag_SexVer61;

	// NAME: #62#非表示(男女指定)
	uint8_t invisibleFlag_SexVer62;

	// NAME: #63#非表示(男女指定)
	uint8_t invisibleFlag_SexVer63;

	// NAME: #64#非表示(男女指定)
	uint8_t invisibleFlag_SexVer64;

	// NAME: #65#非表示(男女指定)
	uint8_t invisibleFlag_SexVer65;

	// NAME: #66#非表示(男女指定)
	uint8_t invisibleFlag_SexVer66;

	// NAME: #67#非表示(男女指定)
	uint8_t invisibleFlag_SexVer67;

	// NAME: #68#非表示(男女指定)
	uint8_t invisibleFlag_SexVer68;

	// NAME: #69#非表示(男女指定)
	uint8_t invisibleFlag_SexVer69;

	// NAME: #70#非表示(男女指定)
	uint8_t invisibleFlag_SexVer70;

	// NAME: #71#非表示(男女指定)
	uint8_t invisibleFlag_SexVer71;

	// NAME: #72#非表示(男女指定)
	uint8_t invisibleFlag_SexVer72;

	// NAME: #73#非表示(男女指定)
	uint8_t invisibleFlag_SexVer73;

	// NAME: #74#非表示(男女指定)
	uint8_t invisibleFlag_SexVer74;

	// NAME: #75#非表示(男女指定)
	uint8_t invisibleFlag_SexVer75;

	// NAME: #76#非表示(男女指定)
	uint8_t invisibleFlag_SexVer76;

	// NAME: #77#非表示(男女指定)
	uint8_t invisibleFlag_SexVer77;

	// NAME: #78#非表示(男女指定)
	uint8_t invisibleFlag_SexVer78;

	// NAME: #79#非表示(男女指定)
	uint8_t invisibleFlag_SexVer79;

	// NAME: #80#非表示(男女指定)
	uint8_t invisibleFlag_SexVer80;

	// NAME: #81#非表示(男女指定)
	uint8_t invisibleFlag_SexVer81;

	// NAME: #82#非表示(男女指定)
	uint8_t invisibleFlag_SexVer82;

	// NAME: #83#非表示(男女指定)
	uint8_t invisibleFlag_SexVer83;

	// NAME: #84#非表示(男女指定)
	uint8_t invisibleFlag_SexVer84;

	// NAME: #85#非表示(男女指定)
	uint8_t invisibleFlag_SexVer85;

	// NAME: #86#非表示(男女指定)
	uint8_t invisibleFlag_SexVer86;

	// NAME: #87#非表示(男女指定)
	uint8_t invisibleFlag_SexVer87;

	// NAME: #88#非表示(男女指定)
	uint8_t invisibleFlag_SexVer88;

	// NAME: #89#非表示(男女指定)
	uint8_t invisibleFlag_SexVer89;

	// NAME: #90#非表示(男女指定)
	uint8_t invisibleFlag_SexVer90;

	// NAME: #91#非表示(男女指定)
	uint8_t invisibleFlag_SexVer91;

	// NAME: #92#非表示(男女指定)
	uint8_t invisibleFlag_SexVer92;

	// NAME: #93#非表示(男女指定)
	uint8_t invisibleFlag_SexVer93;

	// NAME: #94#非表示(男女指定)
	uint8_t invisibleFlag_SexVer94;

	// NAME: #95#非表示(男女指定)
	uint8_t invisibleFlag_SexVer95;

	// NAME: パディング
	// DESC: パディング
	uint8_t pad404[14];
} EQUIP_PARAM_PROTECTOR_ST;

#endif
