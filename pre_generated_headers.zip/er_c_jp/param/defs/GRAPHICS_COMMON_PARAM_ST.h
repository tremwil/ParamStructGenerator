/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_GRAPHICS_COMMON_PARAM_ST_H
#define _PARAMDEF_GRAPHICS_COMMON_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _GRAPHICS_COMMON_PARAM_ST {

	// NAME: HIT INSに弾丸が当たった時のデカール発生位置オフセット
	// DESC: HIT INSに当たった時に発生するデカールの発生位置を法線方向にこの値だけオフセットする
	float hitBulletDecalOffset_HitIns;

	// NAME: 予約
	// DESC: (dummy8)
	uint8_t reserved02[8];

	// NAME: キャラが濡れた時のデカールフェード範囲[m]
	// DESC: キャラが濡れた時にデカールを消すフェード範囲[m]
	float charaWetDecalFadeRange;

	// NAME: 予約
	// DESC: (dummy8)
	uint8_t reserved04[240];
} GRAPHICS_COMMON_PARAM_ST;

#endif
