/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CUTSCENE_MAP_ID_PARAM_ST_H
#define _PARAMDEF_CUTSCENE_MAP_ID_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CUTSCENE_MAP_ID_PARAM_ST {

	// NAME: NT版出力から外すか
	// DESC: ○をつけたパラメータをNT版パッケージでは除外します
	uint8_t disableParam_NT: 1;

	// NAME: デバッグパラメータか
	// DESC: ○をつけたパラメータは全パッケージから除外します（デバッグ用なので）
	uint8_t disableParam_Debug: 1;

	// NAME: パッケージ出力用リザーブ1
	// DESC: パッケージ出力用リザーブ1
	uint8_t disableParamReserve1: 6;

	// NAME: パッケージ出力用リザーブ2
	// DESC: パッケージ出力用リザーブ2
	uint8_t disableParamReserve2[3];

	// NAME: 再生を行なうマップ番号
	// DESC: 再生を行なうマップ番号を8桁の数字で入力して下さい。カットシーンで基準としているマップの番号になります。正しいマップ番号を指定しないと再生位置がずれます。
	uint32_t PlayMapId;

	// NAME: 表示に必要なマップ番号１
	// DESC: 表示に必要なマップ番号を8桁の数字で入力して下さい。このパラメータは、ゲスト側がカットシーンを再生可能か判断するためのリストとして利用します。必要ない場合は、0もしくは未記入で良いです。
	uint32_t RequireMapId0;

	// NAME: 表示に必要なマップ番号２
	// DESC: 表示に必要なマップ番号を8桁の数字で入力して下さい。このパラメータは、ゲスト側がカットシーンを再生可能か判断するためのリストとして利用します。必要ない場合は、0もしくは未記入で良いです。
	uint32_t RequireMapId1;

	// NAME: 表示に必要なマップ番号３
	// DESC: 表示に必要なマップ番号を8桁の数字で入力して下さい。このパラメータは、ゲスト側がカットシーンを再生可能か判断するためのリストとして利用します。必要ない場合は、0もしくは未記入で良いです。
	uint32_t RequireMapId2;

	// NAME: 読み込み中カメラ位置算出用ヒットパーツID
	// DESC: 読み込み中カメラ位置算出用ヒットパーツID
	int32_t RefCamPosHitPartsID;

	// NAME: 予備
	uint8_t reserved_2[12];

	// NAME: 表示不可能時待機時間[秒]
	// DESC: マルチにおいてゲスト側が再生できない状態の時に表示されるロード画面プログレスバーの進捗表示に使われる秒数です。【GR】SEQ22843 【カットシーン】カットシーン再生時に表示に必要なマップ番号を読み込んでいないプレイヤーは画面暗転する対応
	uint16_t ClientDisableViewTimeForProgress;

	// NAME: reserved
	// DESC: reserved
	uint8_t reserved[2];

	// NAME: 読み込み待ちヒットパーツ0
	// DESC: 読み込み待ちヒットパーツ0
	int32_t HitParts_0;

	// NAME: 読み込み待ちヒットパーツ1
	// DESC: 読み込み待ちヒットパーツ1
	int32_t HitParts_1;
} CUTSCENE_MAP_ID_PARAM_ST;

#endif
