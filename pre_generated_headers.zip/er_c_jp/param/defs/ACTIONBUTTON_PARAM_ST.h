/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_ACTIONBUTTON_PARAM_ST_H
#define _PARAMDEF_ACTIONBUTTON_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 2
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _ACTIONBUTTON_PARAM_ST {

	// NAME: 範囲タイプ
	// DESC: 範囲形状(円柱、角柱、カプセル)
	uint8_t regionType;

	// NAME: カテゴリ
	// DESC: カテゴリ。名前の左側の数字は複数のアクションボタンが重なっていた場合の優先度(0に近い程優先表示)。
	uint8_t category;

	// NAME: パディング1
	uint8_t padding1[2];

	// NAME: ダミポリ1
	// DESC: 範囲の底面の中心となるダミポリIDを指定する　ダミポリがない場合 or -1が入力されている場合は、中心座標が基準になる
	int32_t dummyPoly1;

	// NAME: ダミポリ2
	// DESC: 範囲タイプがカプセルの場合のみ使用　ダミポリ2つで線分を作る追加ダミポリ(カプセル)
	int32_t dummyPoly2;

	// NAME: 半径
	// DESC: 半径(円柱・カプセル)
	float radius;

	// NAME: 角度
	// DESC: 角度(円柱)
	int32_t angle;

	// NAME: 奥行き
	// DESC: 奥行き(角柱)
	float depth;

	// NAME: 幅
	// DESC: 幅(角柱)
	float width;

	// NAME: 高さ
	// DESC: 高さ(円柱・角柱)
	float height;

	// NAME: 底面高さオフセット
	// DESC: 底面のY座標をどれだけ上下させるか(円柱・角柱)
	float baseHeightOffset;

	// NAME: 角度差判定タイプ
	// DESC: 角度差判定タイプ(円柱・角柱)
	uint8_t angleCheckType;

	// NAME: パディング2
	uint8_t padding2[3];

	// NAME: 許容角度差
	// DESC: 許容角度差(円柱・角柱)
	int32_t allowAngle;

	// NAME: アクションスポットダミポリ
	// DESC: アクションスポットの位置となるダミポリIDを指定する ダミポリがない場合 or -1が入力されている場合は、中心座標が基準となる
	int32_t spotDummyPoly;

	// NAME: テキストボックスタイプ
	// DESC: テキストボックスタイプ
	uint8_t textBoxType;

	// NAME: パディング3
	uint8_t padding3[2];

	// NAME: パディング5
	uint8_t padding5: 1;

	// NAME: 騎乗時無効か
	// DESC: この項目がYESだと騎乗時にアクションボタンが出なくなり、判定も行われない
	uint8_t isInvalidForRide: 1;

	// NAME: 騎乗時グレーアウトか
	// DESC: この項目がYESだと騎乗時にアクションボタンがグレーアウトし、判定も行われない
	uint8_t isGrayoutForRide: 1;

	// NAME: しゃがみ時無効か
	// DESC: この項目がYESだとしゃがみ時にアクションボタンが出なくなり、判定も行われない
	uint8_t isInvalidForCrouching: 1;

	// NAME: しゃがみ時グレーアウトか
	// DESC: この項目がYESだとしゃがみ時にアクションボタンがグレーアウトし、判定も行われない
	uint8_t isGrayoutForCrouching: 1;

	// NAME: パディング4
	uint8_t padding4: 3;

	// NAME: テキストID
	// DESC: 表示するテキストID
	int32_t textId;

	// NAME: 無効フラグ
	// DESC: このフラグがONだとアクションボタンが出ず、判定も行われない
	uint32_t invalidFlag;

	// NAME: グレーアウトフラグ
	// DESC: このフラグがONだとアクションボタンがグレーアウトし、判定も行われない
	uint32_t grayoutFlag;

	// NAME: 騎乗時差し替えアクションボタンID
	// DESC: 騎乗中はこのアクションボタンIDのパラメータに差し替える（-1：差し替え無し）
	int32_t overrideActionButtonIdForRide;

	// NAME: 実行後無効時間
	// DESC: 実行後無効時間(-値で無限)
	float execInvalidTime;

	// NAME: パディング6
	uint8_t padding6[28];
} ACTIONBUTTON_PARAM_ST;

#endif
