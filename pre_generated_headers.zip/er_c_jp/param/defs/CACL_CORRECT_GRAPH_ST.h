/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CACL_CORRECT_GRAPH_ST_H
#define _PARAMDEF_CACL_CORRECT_GRAPH_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CACL_CORRECT_GRAPH_ST {

	// NAME: 閾値ポイント0
	// DESC: 仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal0;

	// NAME: 閾値ポイント1
	// DESC: 仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal1;

	// NAME: 閾値ポイント2
	// DESC: 仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal2;

	// NAME: 閾値ポイント3
	// DESC: 仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal3;

	// NAME: 閾値ポイント4
	// DESC: 仕様書に「n次閾値[point]」と書いてあるもの
	float stageMaxVal4;

	// NAME: 閾値係数0
	// DESC: 仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal0;

	// NAME: 閾値係数1
	// DESC: 仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal1;

	// NAME: 閾値係数2
	// DESC: 仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal2;

	// NAME: 閾値係数3
	// DESC: 仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal3;

	// NAME: 閾値係数4
	// DESC: 仕様書に「n次閾値[係数]」と書いてあるもの
	float stageMaxGrowVal4;

	// NAME: 調整係数0
	// DESC: 調整係数
	float adjPt_maxGrowVal0;

	// NAME: 調整係数1
	// DESC: 調整係数
	float adjPt_maxGrowVal1;

	// NAME: 調整係数2
	// DESC: 調整係数
	float adjPt_maxGrowVal2;

	// NAME: 調整係数3
	// DESC: 調整係数
	float adjPt_maxGrowVal3;

	// NAME: 調整係数4
	// DESC: 調整係数
	float adjPt_maxGrowVal4;

	// NAME: 成長ソウル 初期のグラフの傾きα1
	// DESC: 成長ソウル 初期のグラフの傾きα1
	float init_inclination_soul;

	// NAME: 成長ソウル 初期のsoul調整α2
	// DESC: 成長ソウル 初期のsoul調整α2
	float adjustment_value;

	// NAME: 成長ソウル 閾値後のグラフの傾きに影響α3
	// DESC: 成長ソウル 閾値後のグラフの傾きに影響α3
	float boundry_inclination_soul;

	// NAME: 成長ソウル 閾値 t
	// DESC: 成長ソウル 閾値 t
	float boundry_value;

	// NAME: パディング
	uint8_t pad[4];
} CACL_CORRECT_GRAPH_ST;

#endif
