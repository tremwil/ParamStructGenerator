/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_AI_SOUND_PARAM_ST_H
#define _PARAMDEF_AI_SOUND_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AI_SOUND_PARAM_ST {

	// NAME: 音半径[m]
	// DESC: AI音の半径
	float radius;

	// NAME: 消滅時間[秒]
	// DESC: AI音が残る時間
	float lifeFrame;

	// NAME: 特殊効果からの影響を受けるか
	// DESC: 特殊効果の”音半径倍率”の影響を受けるかどうか
	uint8_t bSpEffectEnable;

	// NAME: 種別
	// DESC: AI音の種別
	uint8_t type;

	// NAME: 対象：●敵対
	// DESC: 対象：●敵対
	uint8_t opposeTarget: 1;

	// NAME: 対象：○味方
	// DESC: 対象：○味方
	uint8_t friendlyTarget: 1;

	// NAME: 対象：自分
	// DESC: 対象：自分
	uint8_t selfTarget: 1;

	// NAME: PC自軍をターゲット中は聞けない
	// DESC: PC自軍をターゲット中は聞けない
	uint8_t disableOnTargetPCompany: 1;

	// NAME: キャラの振る舞い
	// DESC: キャラの振る舞い(旧：音タイプ
	uint8_t rank;

	// NAME: 音ターゲット忘れる時間（上書き）[sec]
	// DESC: 音ターゲット忘れる時間（上書き）[sec]
	float forgetTime;

	// NAME: AI音優先度
	// DESC: AI音優先度
	int32_t priority;

	// NAME: 振る舞いID
	// DESC: 振る舞いID
	int32_t soundBehaviorId;

	// NAME: AI音レベル
	// DESC: どれくらい聞き取りづらい音なのか
	uint8_t aiSoundLevel;

	// NAME: リプランニングするAI状態
	// DESC: AI音を聞いた際にリプランニングを走らせるAI状態の設定
	uint8_t replaningState;

	// NAME: パッド
	// DESC: pad
	uint8_t pad1[6];
} AI_SOUND_PARAM_ST;

#endif
