/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_LIGHTING_QUALITY_DETAIL_H
#define _PARAMDEF_CS_LIGHTING_QUALITY_DETAIL_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_LIGHTING_QUALITY_DETAIL {

	// NAME: ローカルライト有効距離係数
	// DESC: ローカルライト有効距離係数(小さくすると、近い距離で消える)
	float localLightDistFactor;

	// NAME: ローカルライトシャドウ有効
	// DESC: ローカルライトシャドウ有効
	uint8_t localLightShadowEnabled;

	// NAME: フォワードパスライティング有効
	// DESC: フォワードパスライティング有効
	uint8_t forwardPassLightingEnabled;

	// NAME: ローカルライトシャドウスペックレベル
	// DESC: ローカルライトシャドウスペックレベル。大きいほど、より多くの光源にシャドウが設定される
	uint8_t localLightShadowSpecLevelMax;

	// NAME: dmy
	uint8_t dmy[1];
} CS_LIGHTING_QUALITY_DETAIL;

#endif
