/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_AI_ANIM_TBL_PARAM_H
#define _PARAMDEF_AI_ANIM_TBL_PARAM_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _AI_ANIM_TBL_PARAM {

	// NAME: 攻撃1のEzStateアニメ番号
	// DESC: 攻撃1のEzStateアニメ番号
	uint16_t atk0_EzStateId;

	// NAME: 攻撃2のEzStateアニメ番号
	// DESC: 攻撃2のEzStateアニメ番号
	uint16_t atk1_EzStateId;

	// NAME: 攻撃3のEzStateアニメ番号
	// DESC: 攻撃3のEzStateアニメ番号
	uint16_t atk2_EzStateId;

	// NAME: 攻撃4のEzStateアニメ番号
	// DESC: 攻撃4のEzStateアニメ番号
	uint16_t atk3_EzStateId;

	// NAME: 攻撃5のEzStateアニメ番号
	// DESC: 攻撃5のEzStateアニメ番号
	uint16_t atk4_EzStateId;

	// NAME: 攻撃6のEzStateアニメ番号
	// DESC: 攻撃6のEzStateアニメ番号
	uint16_t atk5_EzStateId;

	// NAME: 攻撃7のEzStateアニメ番号
	// DESC: 攻撃7のEzStateアニメ番号
	uint16_t atk6_EzStateId;

	// NAME: 攻撃8のEzStateアニメ番号
	// DESC: 攻撃8のEzStateアニメ番号
	uint16_t atk7_EzStateId;

	// NAME: 攻撃9のEzStateアニメ番号
	// DESC: 攻撃9のEzStateアニメ番号
	uint16_t atk8_EzStateId;

	// NAME: 攻撃10のEzStateアニメ番号
	// DESC: 攻撃10のEzStateアニメ番号
	uint16_t atk9_EzStateId;

	// NAME: 攻撃11のEzStateアニメ番号
	// DESC: 攻撃11のEzStateアニメ番号
	uint16_t atk10_EzStateId;

	// NAME: 攻撃12のEzStateアニメ番号
	// DESC: 攻撃12のEzStateアニメ番号
	uint16_t atk11_EzStateId;

	// NAME: 攻撃13のEzStateアニメ番号
	// DESC: 攻撃13のEzStateアニメ番号
	uint16_t atk12_EzStateId;

	// NAME: 攻撃14のEzStateアニメ番号
	// DESC: 攻撃14のEzStateアニメ番号
	uint16_t atk13_EzStateId;

	// NAME: 攻撃15のEzStateアニメ番号
	// DESC: 攻撃15のEzStateアニメ番号
	uint16_t atk14_EzStateId;

	// NAME: 攻撃16のEzStateアニメ番号
	// DESC: 攻撃16のEzStateアニメ番号
	uint16_t atk15_EzStateId;

	// NAME: 攻撃17のEzStateアニメ番号
	// DESC: 攻撃17のEzStateアニメ番号
	uint16_t atk16_EzStateId;

	// NAME: 攻撃18のEzStateアニメ番号
	// DESC: 攻撃18のEzStateアニメ番号
	uint16_t atk17_EzStateId;

	// NAME: 攻撃19のEzStateアニメ番号
	// DESC: 攻撃19のEzStateアニメ番号
	uint16_t atk18_EzStateId;

	// NAME: 攻撃20のEzStateアニメ番号
	// DESC: 攻撃20のEzStateアニメ番号
	uint16_t atk19_EzStateId;

	// NAME: 攻撃21のEzStateアニメ番号
	// DESC: 攻撃21のEzStateアニメ番号
	uint16_t atk20_EzStateId;

	// NAME: 攻撃22のEzStateアニメ番号
	// DESC: 攻撃22のEzStateアニメ番号
	uint16_t atk21_EzStateId;

	// NAME: 攻撃23のEzStateアニメ番号
	// DESC: 攻撃23のEzStateアニメ番号
	uint16_t atk22_EzStateId;

	// NAME: 攻撃24のEzStateアニメ番号
	// DESC: 攻撃24のEzStateアニメ番号
	uint16_t atk23_EzStateId;

	// NAME: 攻撃25のEzStateアニメ番号
	// DESC: 攻撃25のEzStateアニメ番号
	uint16_t atk24_EzStateId;

	// NAME: 攻撃26のEzStateアニメ番号
	// DESC: 攻撃26のEzStateアニメ番号
	uint16_t atk25_EzStateId;

	// NAME: 攻撃27のEzStateアニメ番号
	// DESC: 攻撃27のEzStateアニメ番号
	uint16_t atk26_EzStateId;

	// NAME: 攻撃28のEzStateアニメ番号
	// DESC: 攻撃28のEzStateアニメ番号
	uint16_t atk27_EzStateId;

	// NAME: 攻撃29のEzStateアニメ番号
	// DESC: 攻撃29のEzStateアニメ番号
	uint16_t atk28_EzStateId;

	// NAME: 攻撃30のEzStateアニメ番号
	// DESC: 攻撃30のEzStateアニメ番号
	uint16_t atk29_EzStateId;

	// NAME: 攻撃1の最小間合距離[cm]
	// DESC: 攻撃1の最小間合距離[cm]
	uint16_t atk0_MinDist;

	// NAME: 攻撃2の最小間合距離[cm]
	// DESC: 攻撃2の最小間合距離[cm]
	uint16_t atk1_MinDist;

	// NAME: 攻撃3の最小間合距離[cm]
	// DESC: 攻撃3の最小間合距離[cm]
	uint16_t atk2_MinDist;

	// NAME: 攻撃4の最小間合距離[cm]
	// DESC: 攻撃4の最小間合距離[cm]
	uint16_t atk3_MinDist;

	// NAME: 攻撃5の最小間合距離[cm]
	// DESC: 攻撃5の最小間合距離[cm]
	uint16_t atk4_MinDist;

	// NAME: 攻撃6の最小間合距離[cm]
	// DESC: 攻撃6の最小間合距離[cm]
	uint16_t atk5_MinDist;

	// NAME: 攻撃7の最小間合距離[cm]
	// DESC: 攻撃7の最小間合距離[cm]
	uint16_t atk6_MinDist;

	// NAME: 攻撃8の最小間合距離[cm]
	// DESC: 攻撃8の最小間合距離[cm]
	uint16_t atk7_MinDist;

	// NAME: 攻撃9の最小間合距離[cm]
	// DESC: 攻撃9の最小間合距離[cm]
	uint16_t atk8_MinDist;

	// NAME: 攻撃10の最小間合距離[cm]
	// DESC: 攻撃10の最小間合距離[cm]
	uint16_t atk9_MinDist;

	// NAME: 攻撃11の最小間合距離[cm]
	// DESC: 攻撃11の最小間合距離[cm]
	uint16_t atk10_MinDist;

	// NAME: 攻撃12の最小間合距離[cm]
	// DESC: 攻撃12の最小間合距離[cm]
	uint16_t atk11_MinDist;

	// NAME: 攻撃13の最小間合距離[cm]
	// DESC: 攻撃13の最小間合距離[cm]
	uint16_t atk12_MinDist;

	// NAME: 攻撃14の最小間合距離[cm]
	// DESC: 攻撃14の最小間合距離[cm]
	uint16_t atk13_MinDist;

	// NAME: 攻撃15の最小間合距離[cm]
	// DESC: 攻撃15の最小間合距離[cm]
	uint16_t atk14_MinDist;

	// NAME: 攻撃16の最小間合距離[cm]
	// DESC: 攻撃16の最小間合距離[cm]
	uint16_t atk15_MinDist;

	// NAME: 攻撃17の最小間合距離[cm]
	// DESC: 攻撃17の最小間合距離[cm]
	uint16_t atk16_MinDist;

	// NAME: 攻撃18の最小間合距離[cm]
	// DESC: 攻撃18の最小間合距離[cm]
	uint16_t atk17_MinDist;

	// NAME: 攻撃19の最小間合距離[cm]
	// DESC: 攻撃19の最小間合距離[cm]
	uint16_t atk18_MinDist;

	// NAME: 攻撃20の最小間合距離[cm]
	// DESC: 攻撃20の最小間合距離[cm]
	uint16_t atk19_MinDist;

	// NAME: 攻撃21の最小間合距離[cm]
	// DESC: 攻撃21の最小間合距離[cm]
	uint16_t atk20_MinDist;

	// NAME: 攻撃22の最小間合距離[cm]
	// DESC: 攻撃22の最小間合距離[cm]
	uint16_t atk21_MinDist;

	// NAME: 攻撃23の最小間合距離[cm]
	// DESC: 攻撃23の最小間合距離[cm]
	uint16_t atk22_MinDist;

	// NAME: 攻撃24の最小間合距離[cm]
	// DESC: 攻撃24の最小間合距離[cm]
	uint16_t atk23_MinDist;

	// NAME: 攻撃25の最小間合距離[cm]
	// DESC: 攻撃25の最小間合距離[cm]
	uint16_t atk24_MinDist;

	// NAME: 攻撃26の最小間合距離[cm]
	// DESC: 攻撃26の最小間合距離[cm]
	uint16_t atk25_MinDist;

	// NAME: 攻撃27の最小間合距離[cm]
	// DESC: 攻撃27の最小間合距離[cm]
	uint16_t atk26_MinDist;

	// NAME: 攻撃28の最小間合距離[cm]
	// DESC: 攻撃28の最小間合距離[cm]
	uint16_t atk27_MinDist;

	// NAME: 攻撃29の最小間合距離[cm]
	// DESC: 攻撃29の最小間合距離[cm]
	uint16_t atk28_MinDist;

	// NAME: 攻撃30の最小間合距離[cm]
	// DESC: 攻撃30の最小間合距離[cm]
	uint16_t atk29_MinDist;

	// NAME: 攻撃1の最大間合い距離[cm]
	// DESC: 攻撃1の最大間合い距離[cm]
	uint16_t atk0_MaxDist;

	// NAME: 攻撃2の最大間合距離[cm]
	// DESC: 攻撃2の最大間合距離[cm]
	uint16_t atk1_MaxDist;

	// NAME: 攻撃3の最大間合距離[cm]
	// DESC: 攻撃3の最大間合距離[cm]
	uint16_t atk2_MaxDist;

	// NAME: 攻撃4の最大間合距離[cm]
	// DESC: 攻撃4の最大間合距離[cm]
	uint16_t atk3_MaxDist;

	// NAME: 攻撃5の最大間合距離[cm]
	// DESC: 攻撃5の最大間合距離[cm]
	uint16_t atk4_MaxDist;

	// NAME: 攻撃6の最大間合距離[cm]
	// DESC: 攻撃6の最大間合距離[cm]
	uint16_t atk5_MaxDist;

	// NAME: 攻撃7の最大間合距離[cm]
	// DESC: 攻撃7の最大間合距離[cm]
	uint16_t atk6_MaxDist;

	// NAME: 攻撃8の最大間合距離[cm]
	// DESC: 攻撃8の最大間合距離[cm]
	uint16_t atk7_MaxDist;

	// NAME: 攻撃9の最大間合距離[cm]
	// DESC: 攻撃9の最大間合距離[cm]
	uint16_t atk8_MaxDist;

	// NAME: 攻撃10の最大間合距離[cm]
	// DESC: 攻撃10の最大間合距離[cm]
	uint16_t atk9_MaxDist;

	// NAME: 攻撃11の最大間合距離[cm]
	// DESC: 攻撃11の最大間合距離[cm]
	uint16_t atk10_MaxDist;

	// NAME: 攻撃12の最大間合距離[cm]
	// DESC: 攻撃12の最大間合距離[cm]
	uint16_t atk11_MaxDist;

	// NAME: 攻撃13の最大間合距離[cm]
	// DESC: 攻撃13の最大間合距離[cm]
	uint16_t atk12_MaxDist;

	// NAME: 攻撃14の最大間合距離[cm]
	// DESC: 攻撃14の最大間合距離[cm]
	uint16_t atk13_MaxDist;

	// NAME: 攻撃15の最大間合距離[cm]
	// DESC: 攻撃15の最大間合距離[cm]
	uint16_t atk14_MaxDist;

	// NAME: 攻撃16の最大間合距離[cm]
	// DESC: 攻撃16の最大間合距離[cm]
	uint16_t atk15_MaxDist;

	// NAME: 攻撃17の最大間合距離[cm]
	// DESC: 攻撃17の最大間合距離[cm]
	uint16_t atk16_MaxDist;

	// NAME: 攻撃18の最大間合距離[cm]
	// DESC: 攻撃18の最大間合距離[cm]
	uint16_t atk17_MaxDist;

	// NAME: 攻撃19の最大間合距離[cm]
	// DESC: 攻撃19の最大間合距離[cm]
	uint16_t atk18_MaxDist;

	// NAME: 攻撃20の最大間合距離[cm]
	// DESC: 攻撃20の最大間合距離[cm]
	uint16_t atk19_MaxDist;

	// NAME: 攻撃21の最大間合距離[cm]
	// DESC: 攻撃21の最大間合距離[cm]
	uint16_t atk20_MaxDist;

	// NAME: 攻撃22の最大間合距離[cm]
	// DESC: 攻撃22の最大間合距離[cm]
	uint16_t atk21_MaxDist;

	// NAME: 攻撃23の最大間合距離[cm]
	// DESC: 攻撃23の最大間合距離[cm]
	uint16_t atk22_MaxDist;

	// NAME: 攻撃24の最大間合距離[cm]
	// DESC: 攻撃24の最大間合距離[cm]
	uint16_t atk23_MaxDist;

	// NAME: 攻撃25の最大間合距離[cm]
	// DESC: 攻撃25の最大間合距離[cm]
	uint16_t atk24_MaxDist;

	// NAME: 攻撃26の最大間合距離[cm]
	// DESC: 攻撃26の最大間合距離[cm]
	uint16_t atk25_MaxDist;

	// NAME: 攻撃27の最大間合距離[cm]
	// DESC: 攻撃27の最大間合距離[cm]
	uint16_t atk26_MaxDist;

	// NAME: 攻撃28の最大間合距離[cm]
	// DESC: 攻撃28の最大間合距離[cm]
	uint16_t atk27_MaxDist;

	// NAME: 攻撃29の最大間合距離[cm]
	// DESC: 攻撃29の最大間合距離[cm]
	uint16_t atk28_MaxDist;

	// NAME: 攻撃30の最大間合距離[cm]
	// DESC: 攻撃30の最大間合距離[cm]
	uint16_t atk29_MaxDist;

	// NAME: 攻撃1の攻撃成功距離タイプ
	// DESC: 攻撃1の攻撃成功距離タイプ
	uint8_t atk0_AtkDistType: 4;

	// NAME: 攻撃2の攻撃成功距離タイプ
	// DESC: 攻撃2の攻撃成功距離タイプ
	uint8_t atk1_AtkDistType: 4;

	// NAME: 攻撃3の攻撃成功距離タイプ
	// DESC: 攻撃3の攻撃成功距離タイプ
	uint8_t atk2_AtkDistType: 4;

	// NAME: 攻撃4の攻撃成功距離タイプ
	// DESC: 攻撃4の攻撃成功距離タイプ
	uint8_t atk3_AtkDistType: 4;

	// NAME: 攻撃5の攻撃成功距離タイプ
	// DESC: 攻撃5の攻撃成功距離タイプ
	uint8_t atk4_AtkDistType: 4;

	// NAME: 攻撃6の攻撃成功距離タイプ
	// DESC: 攻撃6の攻撃成功距離タイプ
	uint8_t atk5_AtkDistType: 4;

	// NAME: 攻撃7の攻撃成功距離タイプ
	// DESC: 攻撃7の攻撃成功距離タイプ
	uint8_t atk6_AtkDistType: 4;

	// NAME: 攻撃8の攻撃成功距離タイプ
	// DESC: 攻撃8の攻撃成功距離タイプ
	uint8_t atk7_AtkDistType: 4;

	// NAME: 攻撃9の攻撃成功距離タイプ
	// DESC: 攻撃9の攻撃成功距離タイプ
	uint8_t atk8_AtkDistType: 4;

	// NAME: 攻撃10の攻撃成功距離タイプ
	// DESC: 攻撃10の攻撃成功距離タイプ
	uint8_t atk9_AtkDistType: 4;

	// NAME: 攻撃11の攻撃成功距離タイプ
	// DESC: 攻撃11の攻撃成功距離タイプ
	uint8_t atk10_AtkDistType: 4;

	// NAME: 攻撃12の攻撃成功距離タイプ
	// DESC: 攻撃12の攻撃成功距離タイプ
	uint8_t atk11_AtkDistType: 4;

	// NAME: 攻撃13の攻撃成功距離タイプ
	// DESC: 攻撃13の攻撃成功距離タイプ
	uint8_t atk12_AtkDistType: 4;

	// NAME: 攻撃14の攻撃成功距離タイプ
	// DESC: 攻撃14の攻撃成功距離タイプ
	uint8_t atk13_AtkDistType: 4;

	// NAME: 攻撃15の攻撃成功距離タイプ
	// DESC: 攻撃15の攻撃成功距離タイプ
	uint8_t atk14_AtkDistType: 4;

	// NAME: 攻撃16の攻撃成功距離タイプ
	// DESC: 攻撃16の攻撃成功距離タイプ
	uint8_t atk15_AtkDistType: 4;

	// NAME: 攻撃17の攻撃成功距離タイプ
	// DESC: 攻撃17の攻撃成功距離タイプ
	uint8_t atk16_AtkDistType: 4;

	// NAME: 攻撃18の攻撃成功距離タイプ
	// DESC: 攻撃18の攻撃成功距離タイプ
	uint8_t atk17_AtkDistType: 4;

	// NAME: 攻撃19の攻撃成功距離タイプ
	// DESC: 攻撃19の攻撃成功距離タイプ
	uint8_t atk18_AtkDistType: 4;

	// NAME: 攻撃20の攻撃成功距離タイプ
	// DESC: 攻撃20の攻撃成功距離タイプ
	uint8_t atk19_AtkDistType: 4;

	// NAME: 攻撃21の攻撃成功距離タイプ
	// DESC: 攻撃21の攻撃成功距離タイプ
	uint8_t atk20_AtkDistType: 4;

	// NAME: 攻撃22の攻撃成功距離タイプ
	// DESC: 攻撃22の攻撃成功距離タイプ
	uint8_t atk21_AtkDistType: 4;

	// NAME: 攻撃23の攻撃成功距離タイプ
	// DESC: 攻撃23の攻撃成功距離タイプ
	uint8_t atk22_AtkDistType: 4;

	// NAME: 攻撃24の攻撃成功距離タイプ
	// DESC: 攻撃24の攻撃成功距離タイプ
	uint8_t atk23_AtkDistType: 4;

	// NAME: 攻撃25の攻撃成功距離タイプ
	// DESC: 攻撃25の攻撃成功距離タイプ
	uint8_t atk24_AtkDistType: 4;

	// NAME: 攻撃26の攻撃成功距離タイプ
	// DESC: 攻撃26の攻撃成功距離タイプ
	uint8_t atk25_AtkDistType: 4;

	// NAME: 攻撃27の攻撃成功距離タイプ
	// DESC: 攻撃27の攻撃成功距離タイプ
	uint8_t atk26_AtkDistType: 4;

	// NAME: 攻撃28の攻撃成功距離タイプ
	// DESC: 攻撃28の攻撃成功距離タイプ
	uint8_t atk27_AtkDistType: 4;

	// NAME: 攻撃29の攻撃成功距離タイプ
	// DESC: 攻撃29の攻撃成功距離タイプ
	uint8_t atk28_AtkDistType: 4;

	// NAME: 攻撃30の攻撃成功距離タイプ
	// DESC: 攻撃30の攻撃成功距離タイプ
	uint8_t atk29_AtkDistType: 4;

	// NAME: pad
	// DESC: pad
	uint8_t pad0[13];
} AI_ANIM_TBL_PARAM;

#endif
