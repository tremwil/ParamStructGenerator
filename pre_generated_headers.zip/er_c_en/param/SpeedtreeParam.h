/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SpeedtreeParam_H
#define _PARAM_SpeedtreeParam_H
#pragma once
#include "defs/SPEEDTREE_MODEL_PARAM_ST.h"

// Type: SPEEDTREE_MODEL_PARAM_ST
typedef struct _SpeedtreeParam {
    struct _SPEEDTREE_MODEL_PARAM_ST data;
} SpeedtreeParam;

#endif
