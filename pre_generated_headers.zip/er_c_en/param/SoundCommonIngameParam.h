/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SoundCommonIngameParam_H
#define _PARAM_SoundCommonIngameParam_H
#pragma once
#include "defs/SOUND_COMMON_INGAME_PARAM_ST.h"

// Type: SOUND_COMMON_INGAME_PARAM_ST
typedef struct _SoundCommonIngameParam {
    struct _SOUND_COMMON_INGAME_PARAM_ST data;
} SoundCommonIngameParam;

#endif
