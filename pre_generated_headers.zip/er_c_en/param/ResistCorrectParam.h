/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ResistCorrectParam_H
#define _PARAM_ResistCorrectParam_H
#pragma once
#include "defs/RESIST_CORRECT_PARAM_ST.h"

// Type: RESIST_CORRECT_PARAM_ST
typedef struct _ResistCorrectParam {
    struct _RESIST_CORRECT_PARAM_ST data;
} ResistCorrectParam;

#endif
