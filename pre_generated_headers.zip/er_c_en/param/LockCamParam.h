/* This file was automatically generated from regulation data. */
#ifndef _PARAM_LockCamParam_H
#define _PARAM_LockCamParam_H
#pragma once
#include "defs/LOCK_CAM_PARAM_ST.h"

// Type: LOCK_CAM_PARAM_ST
typedef struct _LockCamParam {
    struct _LOCK_CAM_PARAM_ST data;
} LockCamParam;

#endif
