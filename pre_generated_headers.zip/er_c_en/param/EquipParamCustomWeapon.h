/* This file was automatically generated from regulation data. */
#ifndef _PARAM_EquipParamCustomWeapon_H
#define _PARAM_EquipParamCustomWeapon_H
#pragma once
#include "defs/EQUIP_PARAM_CUSTOM_WEAPON_ST.h"

// Type: EQUIP_PARAM_CUSTOM_WEAPON_ST
typedef struct _EquipParamCustomWeapon {
    struct _EQUIP_PARAM_CUSTOM_WEAPON_ST data;
} EquipParamCustomWeapon;

#endif
