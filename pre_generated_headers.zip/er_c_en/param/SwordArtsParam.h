/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SwordArtsParam_H
#define _PARAM_SwordArtsParam_H
#pragma once
#include "defs/SWORD_ARTS_PARAM_ST.h"

// Type: SWORD_ARTS_PARAM_ST
typedef struct _SwordArtsParam {
    struct _SWORD_ARTS_PARAM_ST data;
} SwordArtsParam;

#endif
