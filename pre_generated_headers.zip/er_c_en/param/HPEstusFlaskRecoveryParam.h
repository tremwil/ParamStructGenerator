/* This file was automatically generated from regulation data. */
#ifndef _PARAM_HPEstusFlaskRecoveryParam_H
#define _PARAM_HPEstusFlaskRecoveryParam_H
#pragma once
#include "defs/ESTUS_FLASK_RECOVERY_PARAM_ST.h"

// Type: ESTUS_FLASK_RECOVERY_PARAM_ST
typedef struct _HPEstusFlaskRecoveryParam {
    struct _ESTUS_FLASK_RECOVERY_PARAM_ST data;
} HPEstusFlaskRecoveryParam;

#endif
