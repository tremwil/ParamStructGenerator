/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MapMimicryEstablishmentParam_H
#define _PARAM_MapMimicryEstablishmentParam_H
#pragma once
#include "defs/MAP_MIMICRY_ESTABLISHMENT_PARAM_ST.h"

// Type: MAP_MIMICRY_ESTABLISHMENT_PARAM_ST
typedef struct _MapMimicryEstablishmentParam {
    struct _MAP_MIMICRY_ESTABLISHMENT_PARAM_ST data;
} MapMimicryEstablishmentParam;

#endif
