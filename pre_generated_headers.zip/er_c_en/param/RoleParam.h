/* This file was automatically generated from regulation data. */
#ifndef _PARAM_RoleParam_H
#define _PARAM_RoleParam_H
#pragma once
#include "defs/ROLE_PARAM_ST.h"

// Type: ROLE_PARAM_ST
typedef struct _RoleParam {
    struct _ROLE_PARAM_ST data;
} RoleParam;

#endif
