/* This file was automatically generated from regulation data. */
#ifndef _PARAM_GrassLodRangeParam_H
#define _PARAM_GrassLodRangeParam_H
#pragma once
#include "defs/GRASS_LOD_RANGE_PARAM_ST.h"

// Type: GRASS_LOD_RANGE_PARAM_ST
typedef struct _GrassLodRangeParam {
    struct _GRASS_LOD_RANGE_PARAM_ST data;
} GrassLodRangeParam;

#endif
