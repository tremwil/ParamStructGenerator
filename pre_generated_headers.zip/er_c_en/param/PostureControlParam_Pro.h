/* This file was automatically generated from regulation data. */
#ifndef _PARAM_PostureControlParam_Pro_H
#define _PARAM_PostureControlParam_Pro_H
#pragma once
#include "defs/POSTURE_CONTROL_PARAM_PRO_ST.h"

// Type: POSTURE_CONTROL_PARAM_PRO_ST
typedef struct _PostureControlParam_Pro {
    struct _POSTURE_CONTROL_PARAM_PRO_ST data;
} PostureControlParam_Pro;

#endif
