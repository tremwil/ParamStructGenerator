/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WorldMapPlaceNameParam_H
#define _PARAM_WorldMapPlaceNameParam_H
#pragma once
#include "defs/WORLD_MAP_PLACE_NAME_PARAM_ST.h"

// Type: WORLD_MAP_PLACE_NAME_PARAM_ST
typedef struct _WorldMapPlaceNameParam {
    struct _WORLD_MAP_PLACE_NAME_PARAM_ST data;
} WorldMapPlaceNameParam;

#endif
