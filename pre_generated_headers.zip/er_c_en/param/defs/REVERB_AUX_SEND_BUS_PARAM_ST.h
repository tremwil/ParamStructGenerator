/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_REVERB_AUX_SEND_BUS_PARAM_ST_H
#define _PARAMDEF_REVERB_AUX_SEND_BUS_PARAM_ST_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 202
typedef struct _REVERB_AUX_SEND_BUS_PARAM_ST {

	// NAME: ReverbAuxSendBus name - ReverbAuxSendBus名
	// DESC: ReverbAuxSendBus name - ReverbAuxSendBus名
	char ReverbAuxSendBusName[32];
} REVERB_AUX_SEND_BUS_PARAM_ST;

#endif
