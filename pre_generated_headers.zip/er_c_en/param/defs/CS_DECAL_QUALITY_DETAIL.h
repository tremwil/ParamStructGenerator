/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_DECAL_QUALITY_DETAIL_H
#define _PARAMDEF_CS_DECAL_QUALITY_DETAIL_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_DECAL_QUALITY_DETAIL {

	// NAME: Decal valid - デカール有効
	// DESC: Decal valid - デカール有効
	uint8_t enabled;

	// NAME: dmy - dmy
	uint8_t dmy[3];
} CS_DECAL_QUALITY_DETAIL;

#endif
