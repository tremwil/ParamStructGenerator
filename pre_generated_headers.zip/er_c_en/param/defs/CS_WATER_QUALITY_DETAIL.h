/* This file was automatically generated from XML paramdefs. */
#ifndef _PARAMDEF_CS_WATER_QUALITY_DETAIL_H
#define _PARAMDEF_CS_WATER_QUALITY_DETAIL_H
#pragma once
#include <inttypes.h>

// Data Version: 1
// Is Big Endian: False
// Is Unicode: True
// Format Version: 203
typedef struct _CS_WATER_QUALITY_DETAIL {

	// NAME: Interaction enabled - インタラクション有効
	// DESC: Interaction enabled - インタラクション有効
	uint8_t interactionEnabled;

	// NAME: dmy - dmy
	uint8_t dmy[3];
} CS_WATER_QUALITY_DETAIL;

#endif
