/* This file was automatically generated from regulation data. */
#ifndef _PARAM_GparamRefSettings_H
#define _PARAM_GparamRefSettings_H
#pragma once
#include "defs/GPARAM_REF_SETTINGS_PARAM_ST.h"

// Type: GPARAM_REF_SETTINGS_PARAM_ST
typedef struct _GparamRefSettings {
    struct _GPARAM_REF_SETTINGS_PARAM_ST data;
} GparamRefSettings;

#endif
