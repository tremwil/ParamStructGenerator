/* This file was automatically generated from regulation data. */
#ifndef _PARAM_GrassTypeParam_Lv2_H
#define _PARAM_GrassTypeParam_Lv2_H
#pragma once
#include "defs/GRASS_TYPE_PARAM_ST.h"

// Type: GRASS_TYPE_PARAM_ST
typedef struct _GrassTypeParam_Lv2 {
    struct _GRASS_TYPE_PARAM_ST data;
} GrassTypeParam_Lv2;

#endif
