/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ReinforceParamWeapon_H
#define _PARAM_ReinforceParamWeapon_H
#pragma once
#include "defs/REINFORCE_PARAM_WEAPON_ST.h"

// Type: REINFORCE_PARAM_WEAPON_ST
typedef struct _ReinforceParamWeapon {
    struct _REINFORCE_PARAM_WEAPON_ST data;
} ReinforceParamWeapon;

#endif
