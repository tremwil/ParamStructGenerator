/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WeatherAssetReplaceParam_H
#define _PARAM_WeatherAssetReplaceParam_H
#pragma once
#include "defs/WEATHER_ASSET_REPLACE_PARAM_ST.h"

// Type: WEATHER_ASSET_REPLACE_PARAM_ST
typedef struct _WeatherAssetReplaceParam {
    struct _WEATHER_ASSET_REPLACE_PARAM_ST data;
} WeatherAssetReplaceParam;

#endif
