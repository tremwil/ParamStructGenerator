/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ToughnessParam_H
#define _PARAM_ToughnessParam_H
#pragma once
#include "defs/TOUGHNESS_PARAM_ST.h"

// Type: TOUGHNESS_PARAM_ST
typedef struct _ToughnessParam {
    struct _TOUGHNESS_PARAM_ST data;
} ToughnessParam;

#endif
