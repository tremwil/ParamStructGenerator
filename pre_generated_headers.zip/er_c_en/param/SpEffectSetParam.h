/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SpEffectSetParam_H
#define _PARAM_SpEffectSetParam_H
#pragma once
#include "defs/SP_EFFECT_SET_PARAM_ST.h"

// Type: SP_EFFECT_SET_PARAM_ST
typedef struct _SpEffectSetParam {
    struct _SP_EFFECT_SET_PARAM_ST data;
} SpEffectSetParam;

#endif
