/* This file was automatically generated from regulation data. */
#ifndef _PARAM_CharMakeMenuListItemParam_H
#define _PARAM_CharMakeMenuListItemParam_H
#pragma once
#include "defs/CHARMAKEMENU_LISTITEM_PARAM_ST.h"

// Type: CHARMAKEMENU_LISTITEM_PARAM_ST
typedef struct _CharMakeMenuListItemParam {
    struct _CHARMAKEMENU_LISTITEM_PARAM_ST data;
} CharMakeMenuListItemParam;

#endif
