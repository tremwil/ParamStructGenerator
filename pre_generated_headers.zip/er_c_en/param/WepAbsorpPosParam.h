/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WepAbsorpPosParam_H
#define _PARAM_WepAbsorpPosParam_H
#pragma once
#include "defs/WEP_ABSORP_POS_PARAM_ST.h"

// Type: WEP_ABSORP_POS_PARAM_ST
typedef struct _WepAbsorpPosParam {
    struct _WEP_ABSORP_POS_PARAM_ST data;
} WepAbsorpPosParam;

#endif
