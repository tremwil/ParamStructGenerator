/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ShopLineupParam_H
#define _PARAM_ShopLineupParam_H
#pragma once
#include "defs/SHOP_LINEUP_PARAM.h"

// Type: SHOP_LINEUP_PARAM
typedef struct _ShopLineupParam {
    struct _SHOP_LINEUP_PARAM data;
} ShopLineupParam;

#endif
