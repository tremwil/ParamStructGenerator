/* This file was automatically generated from regulation data. */
#ifndef _PARAM_PostureControlParam_Gender_H
#define _PARAM_PostureControlParam_Gender_H
#pragma once
#include "defs/POSTURE_CONTROL_PARAM_GENDER_ST.h"

// Type: POSTURE_CONTROL_PARAM_GENDER_ST
typedef struct _PostureControlParam_Gender {
    struct _POSTURE_CONTROL_PARAM_GENDER_ST data;
} PostureControlParam_Gender;

#endif
