/* This file was automatically generated from regulation data. */
#ifndef _PARAM_NetworkAreaParam_H
#define _PARAM_NetworkAreaParam_H
#pragma once
#include "defs/NETWORK_AREA_PARAM_ST.h"

// Type: NETWORK_AREA_PARAM_ST
typedef struct _NetworkAreaParam {
    struct _NETWORK_AREA_PARAM_ST data;
} NetworkAreaParam;

#endif
