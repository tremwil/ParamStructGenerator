/* This file was automatically generated from regulation data. */
#ifndef _PARAM_AtkParam_Npc_H
#define _PARAM_AtkParam_Npc_H
#pragma once
#include "defs/ATK_PARAM_ST.h"

// Type: ATK_PARAM_ST
typedef struct _AtkParam_Npc {
    struct _ATK_PARAM_ST data;
} AtkParam_Npc;

#endif
