/* This file was automatically generated from regulation data. */
#ifndef _PARAM_CalcCorrectGraph_H
#define _PARAM_CalcCorrectGraph_H
#pragma once
#include "defs/CACL_CORRECT_GRAPH_ST.h"

// Type: CACL_CORRECT_GRAPH_ST
typedef struct _CalcCorrectGraph {
    struct _CACL_CORRECT_GRAPH_ST data;
} CalcCorrectGraph;

#endif
