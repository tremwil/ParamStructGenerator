/* This file was automatically generated from regulation data. */
#ifndef _PARAM_Magic_H
#define _PARAM_Magic_H
#pragma once
#include "defs/MAGIC_PARAM_ST.h"

// Type: MAGIC_PARAM_ST
typedef struct _Magic {
    struct _MAGIC_PARAM_ST data;
} Magic;

#endif
