/* This file was automatically generated from regulation data. */
#ifndef _PARAM_KeyAssignParam_TypeB_H
#define _PARAM_KeyAssignParam_TypeB_H
#pragma once
#include "defs/KEY_ASSIGN_PARAM_ST.h"

// Type: KEY_ASSIGN_PARAM_ST
typedef struct _KeyAssignParam_TypeB {
    struct _KEY_ASSIGN_PARAM_ST data;
} KeyAssignParam_TypeB;

#endif
