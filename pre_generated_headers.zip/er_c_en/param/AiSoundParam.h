/* This file was automatically generated from regulation data. */
#ifndef _PARAM_AiSoundParam_H
#define _PARAM_AiSoundParam_H
#pragma once
#include "defs/AI_SOUND_PARAM_ST.h"

// Type: AI_SOUND_PARAM_ST
typedef struct _AiSoundParam {
    struct _AI_SOUND_PARAM_ST data;
} AiSoundParam;

#endif
