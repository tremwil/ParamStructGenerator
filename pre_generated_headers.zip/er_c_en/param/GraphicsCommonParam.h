/* This file was automatically generated from regulation data. */
#ifndef _PARAM_GraphicsCommonParam_H
#define _PARAM_GraphicsCommonParam_H
#pragma once
#include "defs/GRAPHICS_COMMON_PARAM_ST.h"

// Type: GRAPHICS_COMMON_PARAM_ST
typedef struct _GraphicsCommonParam {
    struct _GRAPHICS_COMMON_PARAM_ST data;
} GraphicsCommonParam;

#endif
