/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SpEffectParam_H
#define _PARAM_SpEffectParam_H
#pragma once
#include "defs/SP_EFFECT_PARAM_ST.h"

// Type: SP_EFFECT_PARAM_ST
typedef struct _SpEffectParam {
    struct _SP_EFFECT_PARAM_ST data;
} SpEffectParam;

#endif
