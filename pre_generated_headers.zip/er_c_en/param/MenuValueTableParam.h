/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MenuValueTableParam_H
#define _PARAM_MenuValueTableParam_H
#pragma once
#include "defs/MENU_VALUE_TABLE_SPEC.h"

// Type: MENU_VALUE_TABLE_SPEC
typedef struct _MenuValueTableParam {
    struct _MENU_VALUE_TABLE_SPEC data;
} MenuValueTableParam;

#endif
