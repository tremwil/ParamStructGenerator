/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WwiseValueToStrParam_Switch_DeffensiveMaterial_H
#define _PARAM_WwiseValueToStrParam_Switch_DeffensiveMaterial_H
#pragma once
#include "defs/WWISE_VALUE_TO_STR_CONVERT_PARAM_ST.h"

// Type: WWISE_VALUE_TO_STR_CONVERT_PARAM_ST
typedef struct _WwiseValueToStrParam_Switch_DeffensiveMaterial {
    struct _WWISE_VALUE_TO_STR_CONVERT_PARAM_ST data;
} WwiseValueToStrParam_Switch_DeffensiveMaterial;

#endif
