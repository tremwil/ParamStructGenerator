/* This file was automatically generated from regulation data. */
#ifndef _PARAM_BonfireWarpSubCategoryParam_H
#define _PARAM_BonfireWarpSubCategoryParam_H
#pragma once
#include "defs/BONFIRE_WARP_SUB_CATEGORY_PARAM_ST.h"

// Type: BONFIRE_WARP_SUB_CATEGORY_PARAM_ST
typedef struct _BonfireWarpSubCategoryParam {
    struct _BONFIRE_WARP_SUB_CATEGORY_PARAM_ST data;
} BonfireWarpSubCategoryParam;

#endif
