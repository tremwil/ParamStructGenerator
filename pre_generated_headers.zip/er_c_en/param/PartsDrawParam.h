/* This file was automatically generated from regulation data. */
#ifndef _PARAM_PartsDrawParam_H
#define _PARAM_PartsDrawParam_H
#pragma once
#include "defs/PARTS_DRAW_PARAM_ST.h"

// Type: PARTS_DRAW_PARAM_ST
typedef struct _PartsDrawParam {
    struct _PARTS_DRAW_PARAM_ST data;
} PartsDrawParam;

#endif
