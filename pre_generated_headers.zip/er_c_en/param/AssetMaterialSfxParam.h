/* This file was automatically generated from regulation data. */
#ifndef _PARAM_AssetMaterialSfxParam_H
#define _PARAM_AssetMaterialSfxParam_H
#pragma once
#include "defs/ASSET_MATERIAL_SFX_PARAM_ST.h"

// Type: ASSET_MATERIAL_SFX_PARAM_ST
typedef struct _AssetMaterialSfxParam {
    struct _ASSET_MATERIAL_SFX_PARAM_ST data;
} AssetMaterialSfxParam;

#endif
