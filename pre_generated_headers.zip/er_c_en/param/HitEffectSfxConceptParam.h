/* This file was automatically generated from regulation data. */
#ifndef _PARAM_HitEffectSfxConceptParam_H
#define _PARAM_HitEffectSfxConceptParam_H
#pragma once
#include "defs/HIT_EFFECT_SFX_CONCEPT_PARAM_ST.h"

// Type: HIT_EFFECT_SFX_CONCEPT_PARAM_ST
typedef struct _HitEffectSfxConceptParam {
    struct _HIT_EFFECT_SFX_CONCEPT_PARAM_ST data;
} HitEffectSfxConceptParam;

#endif
