/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WeatherLotParam_H
#define _PARAM_WeatherLotParam_H
#pragma once
#include "defs/WEATHER_LOT_PARAM_ST.h"

// Type: WEATHER_LOT_PARAM_ST
typedef struct _WeatherLotParam {
    struct _WEATHER_LOT_PARAM_ST data;
} WeatherLotParam;

#endif
