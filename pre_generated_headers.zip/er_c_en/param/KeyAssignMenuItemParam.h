/* This file was automatically generated from regulation data. */
#ifndef _PARAM_KeyAssignMenuItemParam_H
#define _PARAM_KeyAssignMenuItemParam_H
#pragma once
#include "defs/CS_KEY_ASSIGN_MENUITEM_PARAM.h"

// Type: CS_KEY_ASSIGN_MENUITEM_PARAM
typedef struct _KeyAssignMenuItemParam {
    struct _CS_KEY_ASSIGN_MENUITEM_PARAM data;
} KeyAssignMenuItemParam;

#endif
