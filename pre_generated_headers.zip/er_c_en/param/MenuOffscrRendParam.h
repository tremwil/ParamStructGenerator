/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MenuOffscrRendParam_H
#define _PARAM_MenuOffscrRendParam_H
#pragma once
#include "defs/MENU_OFFSCR_REND_PARAM_ST.h"

// Type: MENU_OFFSCR_REND_PARAM_ST
typedef struct _MenuOffscrRendParam {
    struct _MENU_OFFSCR_REND_PARAM_ST data;
} MenuOffscrRendParam;

#endif
