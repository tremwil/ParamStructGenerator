/* This file was automatically generated from regulation data. */
#ifndef _PARAM_DirectionCameraParam_H
#define _PARAM_DirectionCameraParam_H
#pragma once
#include "defs/DIRECTION_CAMERA_PARAM_ST.h"

// Type: DIRECTION_CAMERA_PARAM_ST
typedef struct _DirectionCameraParam {
    struct _DIRECTION_CAMERA_PARAM_ST data;
} DirectionCameraParam;

#endif
