/* This file was automatically generated from regulation data. */
#ifndef _PARAM_NpcAiActionParam_H
#define _PARAM_NpcAiActionParam_H
#pragma once
#include "defs/NPC_AI_ACTION_PARAM_ST.h"

// Type: NPC_AI_ACTION_PARAM_ST
typedef struct _NpcAiActionParam {
    struct _NPC_AI_ACTION_PARAM_ST data;
} NpcAiActionParam;

#endif
