/* This file was automatically generated from regulation data. */
#ifndef _PARAM_LoadBalancerNewDrawDistScaleParam_ps5_H
#define _PARAM_LoadBalancerNewDrawDistScaleParam_ps5_H
#pragma once
#include "defs/LOAD_BALANCER_NEW_DRAW_DIST_SCALE_PARAM_ST.h"

// Type: LOAD_BALANCER_NEW_DRAW_DIST_SCALE_PARAM_ST
typedef struct _LoadBalancerNewDrawDistScaleParam_ps5 {
    struct _LOAD_BALANCER_NEW_DRAW_DIST_SCALE_PARAM_ST data;
} LoadBalancerNewDrawDistScaleParam_ps5;

#endif
