/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SfxBlockResShareParam_H
#define _PARAM_SfxBlockResShareParam_H
#pragma once
#include "defs/SFX_BLOCK_RES_SHARE_PARAM.h"

// Type: SFX_BLOCK_RES_SHARE_PARAM
typedef struct _SfxBlockResShareParam {
    struct _SFX_BLOCK_RES_SHARE_PARAM data;
} SfxBlockResShareParam;

#endif
