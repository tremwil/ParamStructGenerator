/* This file was automatically generated from regulation data. */
#ifndef _PARAM_CutSceneTextureLoadParam_H
#define _PARAM_CutSceneTextureLoadParam_H
#pragma once
#include "defs/CUTSCENE_TEXTURE_LOAD_PARAM_ST.h"

// Type: CUTSCENE_TEXTURE_LOAD_PARAM_ST
typedef struct _CutSceneTextureLoadParam {
    struct _CUTSCENE_TEXTURE_LOAD_PARAM_ST data;
} CutSceneTextureLoadParam;

#endif
