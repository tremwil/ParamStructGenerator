/* This file was automatically generated from regulation data. */
#ifndef _PARAM_CharaInitParam_H
#define _PARAM_CharaInitParam_H
#pragma once
#include "defs/CHARACTER_INIT_PARAM.h"

// Type: CHARACTER_INIT_PARAM
typedef struct _CharaInitParam {
    struct _CHARACTER_INIT_PARAM data;
} CharaInitParam;

#endif
