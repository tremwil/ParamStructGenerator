/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SoundAssetSoundObjEnableDistParam_H
#define _PARAM_SoundAssetSoundObjEnableDistParam_H
#pragma once
#include "defs/SOUND_ASSET_SOUND_OBJ_ENABLE_DIST_PARAM_ST.h"

// Type: SOUND_ASSET_SOUND_OBJ_ENABLE_DIST_PARAM_ST
typedef struct _SoundAssetSoundObjEnableDistParam {
    struct _SOUND_ASSET_SOUND_OBJ_ENABLE_DIST_PARAM_ST data;
} SoundAssetSoundObjEnableDistParam;

#endif
