/* This file was automatically generated from regulation data. */
#ifndef _PARAM_NpcAiBehaviorProbability_H
#define _PARAM_NpcAiBehaviorProbability_H
#pragma once
#include "defs/NPC_AI_BEHAVIOR_PROBABILITY_PARAM_ST.h"

// Type: NPC_AI_BEHAVIOR_PROBABILITY_PARAM_ST
typedef struct _NpcAiBehaviorProbability {
    struct _NPC_AI_BEHAVIOR_PROBABILITY_PARAM_ST data;
} NpcAiBehaviorProbability;

#endif
