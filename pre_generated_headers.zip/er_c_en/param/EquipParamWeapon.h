/* This file was automatically generated from regulation data. */
#ifndef _PARAM_EquipParamWeapon_H
#define _PARAM_EquipParamWeapon_H
#pragma once
#include "defs/EQUIP_PARAM_WEAPON_ST.h"

// Type: EQUIP_PARAM_WEAPON_ST
typedef struct _EquipParamWeapon {
    struct _EQUIP_PARAM_WEAPON_ST data;
} EquipParamWeapon;

#endif
