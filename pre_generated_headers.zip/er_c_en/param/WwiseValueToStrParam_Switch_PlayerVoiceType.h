/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WwiseValueToStrParam_Switch_PlayerVoiceType_H
#define _PARAM_WwiseValueToStrParam_Switch_PlayerVoiceType_H
#pragma once
#include "defs/WWISE_VALUE_TO_STR_CONVERT_PARAM_ST.h"

// Type: WWISE_VALUE_TO_STR_CONVERT_PARAM_ST
typedef struct _WwiseValueToStrParam_Switch_PlayerVoiceType {
    struct _WWISE_VALUE_TO_STR_CONVERT_PARAM_ST data;
} WwiseValueToStrParam_Switch_PlayerVoiceType;

#endif
