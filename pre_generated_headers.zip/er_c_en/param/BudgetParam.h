/* This file was automatically generated from regulation data. */
#ifndef _PARAM_BudgetParam_H
#define _PARAM_BudgetParam_H
#pragma once
#include "defs/BUDGET_PARAM_ST.h"

// Type: BUDGET_PARAM_ST
typedef struct _BudgetParam {
    struct _BUDGET_PARAM_ST data;
} BudgetParam;

#endif
