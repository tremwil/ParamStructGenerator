/* This file was automatically generated from regulation data. */
#ifndef _PARAM_BaseChrSelectMenuParam_H
#define _PARAM_BaseChrSelectMenuParam_H
#pragma once
#include "defs/BASECHR_SELECT_MENU_PARAM_ST.h"

// Type: BASECHR_SELECT_MENU_PARAM_ST
typedef struct _BaseChrSelectMenuParam {
    struct _BASECHR_SELECT_MENU_PARAM_ST data;
} BaseChrSelectMenuParam;

#endif
