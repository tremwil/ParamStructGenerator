/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ChrModelParam_H
#define _PARAM_ChrModelParam_H
#pragma once
#include "defs/CHR_MODEL_PARAM_ST.h"

// Type: CHR_MODEL_PARAM_ST
typedef struct _ChrModelParam {
    struct _CHR_MODEL_PARAM_ST data;
} ChrModelParam;

#endif
