/* This file was automatically generated from regulation data. */
#ifndef _PARAM_LoadBalancerDrawDistScaleParam_ps4_H
#define _PARAM_LoadBalancerDrawDistScaleParam_ps4_H
#pragma once
#include "defs/LOAD_BALANCER_DRAW_DIST_SCALE_PARAM_ST.h"

// Type: LOAD_BALANCER_DRAW_DIST_SCALE_PARAM_ST
typedef struct _LoadBalancerDrawDistScaleParam_ps4 {
    struct _LOAD_BALANCER_DRAW_DIST_SCALE_PARAM_ST data;
} LoadBalancerDrawDistScaleParam_ps4;

#endif
