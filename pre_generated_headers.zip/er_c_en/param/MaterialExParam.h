/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MaterialExParam_H
#define _PARAM_MaterialExParam_H
#pragma once
#include "defs/MATERIAL_EX_PARAM_ST.h"

// Type: MATERIAL_EX_PARAM_ST
typedef struct _MaterialExParam {
    struct _MATERIAL_EX_PARAM_ST data;
} MaterialExParam;

#endif
