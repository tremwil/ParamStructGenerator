/* This file was automatically generated from regulation data. */
#ifndef _PARAM_NetworkMsgParam_H
#define _PARAM_NetworkMsgParam_H
#pragma once
#include "defs/NETWORK_MSG_PARAM_ST.h"

// Type: NETWORK_MSG_PARAM_ST
typedef struct _NetworkMsgParam {
    struct _NETWORK_MSG_PARAM_ST data;
} NetworkMsgParam;

#endif
