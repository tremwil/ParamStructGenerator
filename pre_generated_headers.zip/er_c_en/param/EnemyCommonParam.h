/* This file was automatically generated from regulation data. */
#ifndef _PARAM_EnemyCommonParam_H
#define _PARAM_EnemyCommonParam_H
#pragma once
#include "defs/ENEMY_COMMON_PARAM_ST.h"

// Type: ENEMY_COMMON_PARAM_ST
typedef struct _EnemyCommonParam {
    struct _ENEMY_COMMON_PARAM_ST data;
} EnemyCommonParam;

#endif
