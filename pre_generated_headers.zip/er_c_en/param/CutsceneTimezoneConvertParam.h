/* This file was automatically generated from regulation data. */
#ifndef _PARAM_CutsceneTimezoneConvertParam_H
#define _PARAM_CutsceneTimezoneConvertParam_H
#pragma once
#include "defs/CUTSCENE_TIMEZONE_CONVERT_PARAM_ST.h"

// Type: CUTSCENE_TIMEZONE_CONVERT_PARAM_ST
typedef struct _CutsceneTimezoneConvertParam {
    struct _CUTSCENE_TIMEZONE_CONVERT_PARAM_ST data;
} CutsceneTimezoneConvertParam;

#endif
