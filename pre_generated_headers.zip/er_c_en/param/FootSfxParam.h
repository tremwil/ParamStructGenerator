/* This file was automatically generated from regulation data. */
#ifndef _PARAM_FootSfxParam_H
#define _PARAM_FootSfxParam_H
#pragma once
#include "defs/FOOT_SFX_PARAM_ST.h"

// Type: FOOT_SFX_PARAM_ST
typedef struct _FootSfxParam {
    struct _FOOT_SFX_PARAM_ST data;
} FootSfxParam;

#endif
