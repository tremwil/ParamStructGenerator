/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MultiSoulBonusRateParam_H
#define _PARAM_MultiSoulBonusRateParam_H
#pragma once
#include "defs/MULTI_SOUL_BONUS_RATE_PARAM_ST.h"

// Type: MULTI_SOUL_BONUS_RATE_PARAM_ST
typedef struct _MultiSoulBonusRateParam {
    struct _MULTI_SOUL_BONUS_RATE_PARAM_ST data;
} MultiSoulBonusRateParam;

#endif
