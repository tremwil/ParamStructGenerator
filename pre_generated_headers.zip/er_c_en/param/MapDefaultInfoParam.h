/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MapDefaultInfoParam_H
#define _PARAM_MapDefaultInfoParam_H
#pragma once
#include "defs/MAP_DEFAULT_INFO_PARAM_ST.h"

// Type: MAP_DEFAULT_INFO_PARAM_ST
typedef struct _MapDefaultInfoParam {
    struct _MAP_DEFAULT_INFO_PARAM_ST data;
} MapDefaultInfoParam;

#endif
