/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WaypointParam_H
#define _PARAM_WaypointParam_H
#pragma once
#include "defs/WAYPOINT_PARAM_ST.h"

// Type: WAYPOINT_PARAM_ST
typedef struct _WaypointParam {
    struct _WAYPOINT_PARAM_ST data;
} WaypointParam;

#endif
