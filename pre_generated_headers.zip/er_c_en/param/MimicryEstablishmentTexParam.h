/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MimicryEstablishmentTexParam_H
#define _PARAM_MimicryEstablishmentTexParam_H
#pragma once
#include "defs/MIMICRY_ESTABLISHMENT_TEX_PARAM_ST.h"

// Type: MIMICRY_ESTABLISHMENT_TEX_PARAM_ST
typedef struct _MimicryEstablishmentTexParam {
    struct _MIMICRY_ESTABLISHMENT_TEX_PARAM_ST data;
} MimicryEstablishmentTexParam;

#endif
