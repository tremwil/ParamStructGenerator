/* This file was automatically generated from regulation data. */
#ifndef _PARAM_Bullet_H
#define _PARAM_Bullet_H
#pragma once
#include "defs/BULLET_PARAM_ST.h"

// Type: BULLET_PARAM_ST
typedef struct _Bullet {
    struct _BULLET_PARAM_ST data;
} Bullet;

#endif
