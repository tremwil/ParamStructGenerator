/* This file was automatically generated from regulation data. */
#ifndef _PARAM_HitEffectSfxParam_H
#define _PARAM_HitEffectSfxParam_H
#pragma once
#include "defs/HIT_EFFECT_SFX_PARAM_ST.h"

// Type: HIT_EFFECT_SFX_PARAM_ST
typedef struct _HitEffectSfxParam {
    struct _HIT_EFFECT_SFX_PARAM_ST data;
} HitEffectSfxParam;

#endif
