/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WeatherAssetCreateParam_H
#define _PARAM_WeatherAssetCreateParam_H
#pragma once
#include "defs/WEATHER_ASSET_CREATE_PARAM_ST.h"

// Type: WEATHER_ASSET_CREATE_PARAM_ST
typedef struct _WeatherAssetCreateParam {
    struct _WEATHER_ASSET_CREATE_PARAM_ST data;
} WeatherAssetCreateParam;

#endif
