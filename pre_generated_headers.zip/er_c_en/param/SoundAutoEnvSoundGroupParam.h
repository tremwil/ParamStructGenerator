/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SoundAutoEnvSoundGroupParam_H
#define _PARAM_SoundAutoEnvSoundGroupParam_H
#pragma once
#include "defs/SOUND_AUTO_ENV_SOUND_GROUP_PARAM_ST.h"

// Type: SOUND_AUTO_ENV_SOUND_GROUP_PARAM_ST
typedef struct _SoundAutoEnvSoundGroupParam {
    struct _SOUND_AUTO_ENV_SOUND_GROUP_PARAM_ST data;
} SoundAutoEnvSoundGroupParam;

#endif
