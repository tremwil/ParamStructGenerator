/* This file was automatically generated from regulation data. */
#ifndef _PARAM_FeTextEffectParam_H
#define _PARAM_FeTextEffectParam_H
#pragma once
#include "defs/FE_TEXT_EFFECT_PARAM_ST.h"

// Type: FE_TEXT_EFFECT_PARAM_ST
typedef struct _FeTextEffectParam {
    struct _FE_TEXT_EFFECT_PARAM_ST data;
} FeTextEffectParam;

#endif
