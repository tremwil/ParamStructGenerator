/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SignPuddleParam_H
#define _PARAM_SignPuddleParam_H
#pragma once
#include "defs/SIGN_PUDDLE_PARAM_ST.h"

// Type: SIGN_PUDDLE_PARAM_ST
typedef struct _SignPuddleParam {
    struct _SIGN_PUDDLE_PARAM_ST data;
} SignPuddleParam;

#endif
