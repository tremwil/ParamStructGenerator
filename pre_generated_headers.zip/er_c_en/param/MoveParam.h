/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MoveParam_H
#define _PARAM_MoveParam_H
#pragma once
#include "defs/MOVE_PARAM_ST.h"

// Type: MOVE_PARAM_ST
typedef struct _MoveParam {
    struct _MOVE_PARAM_ST data;
} MoveParam;

#endif
