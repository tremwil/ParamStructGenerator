/* This file was automatically generated from regulation data. */
#ifndef _PARAM_CutsceneWeatherOverrideGparamConvertParam_H
#define _PARAM_CutsceneWeatherOverrideGparamConvertParam_H
#pragma once
#include "defs/CUTSCENE_WEATHER_OVERRIDE_GPARAM_ID_CONVERT_PARAM_ST.h"

// Type: CUTSCENE_WEATHER_OVERRIDE_GPARAM_ID_CONVERT_PARAM_ST
typedef struct _CutsceneWeatherOverrideGparamConvertParam {
    struct _CUTSCENE_WEATHER_OVERRIDE_GPARAM_ID_CONVERT_PARAM_ST data;
} CutsceneWeatherOverrideGparamConvertParam;

#endif
