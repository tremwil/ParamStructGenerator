/* This file was automatically generated from regulation data. */
#ifndef _PARAM_CoolTimeParam_H
#define _PARAM_CoolTimeParam_H
#pragma once
#include "defs/COOL_TIME_PARAM_ST.h"

// Type: COOL_TIME_PARAM_ST
typedef struct _CoolTimeParam {
    struct _COOL_TIME_PARAM_ST data;
} CoolTimeParam;

#endif
