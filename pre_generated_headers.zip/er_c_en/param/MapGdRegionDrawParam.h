/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MapGdRegionDrawParam_H
#define _PARAM_MapGdRegionDrawParam_H
#pragma once
#include "defs/MAP_GD_REGION_DRAW_PARAM.h"

// Type: MAP_GD_REGION_DRAW_PARAM
typedef struct _MapGdRegionDrawParam {
    struct _MAP_GD_REGION_DRAW_PARAM data;
} MapGdRegionDrawParam;

#endif
