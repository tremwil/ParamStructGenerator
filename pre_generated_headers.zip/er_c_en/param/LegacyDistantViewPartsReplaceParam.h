/* This file was automatically generated from regulation data. */
#ifndef _PARAM_LegacyDistantViewPartsReplaceParam_H
#define _PARAM_LegacyDistantViewPartsReplaceParam_H
#pragma once
#include "defs/LEGACY_DISTANT_VIEW_PARTS_REPLACE_PARAM.h"

// Type: LEGACY_DISTANT_VIEW_PARTS_REPLACE_PARAM
typedef struct _LegacyDistantViewPartsReplaceParam {
    struct _LEGACY_DISTANT_VIEW_PARTS_REPLACE_PARAM data;
} LegacyDistantViewPartsReplaceParam;

#endif
