/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WeatherParam_H
#define _PARAM_WeatherParam_H
#pragma once
#include "defs/WEATHER_PARAM_ST.h"

// Type: WEATHER_PARAM_ST
typedef struct _WeatherParam {
    struct _WEATHER_PARAM_ST data;
} WeatherParam;

#endif
