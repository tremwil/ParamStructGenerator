/* This file was automatically generated from regulation data. */
#ifndef _PARAM_NpcParam_H
#define _PARAM_NpcParam_H
#pragma once
#include "defs/NPC_PARAM_ST.h"

// Type: NPC_PARAM_ST
typedef struct _NpcParam {
    struct _NPC_PARAM_ST data;
} NpcParam;

#endif
