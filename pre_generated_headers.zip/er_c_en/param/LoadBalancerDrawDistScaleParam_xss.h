/* This file was automatically generated from regulation data. */
#ifndef _PARAM_LoadBalancerDrawDistScaleParam_xss_H
#define _PARAM_LoadBalancerDrawDistScaleParam_xss_H
#pragma once
#include "defs/LOAD_BALANCER_DRAW_DIST_SCALE_PARAM_ST.h"

// Type: LOAD_BALANCER_DRAW_DIST_SCALE_PARAM_ST
typedef struct _LoadBalancerDrawDistScaleParam_xss {
    struct _LOAD_BALANCER_DRAW_DIST_SCALE_PARAM_ST data;
} LoadBalancerDrawDistScaleParam_xss;

#endif
