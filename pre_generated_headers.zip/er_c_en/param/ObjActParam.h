/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ObjActParam_H
#define _PARAM_ObjActParam_H
#pragma once
#include "defs/OBJ_ACT_PARAM_ST.h"

// Type: OBJ_ACT_PARAM_ST
typedef struct _ObjActParam {
    struct _OBJ_ACT_PARAM_ST data;
} ObjActParam;

#endif
