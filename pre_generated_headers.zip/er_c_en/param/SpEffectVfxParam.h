/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SpEffectVfxParam_H
#define _PARAM_SpEffectVfxParam_H
#pragma once
#include "defs/SP_EFFECT_VFX_PARAM_ST.h"

// Type: SP_EFFECT_VFX_PARAM_ST
typedef struct _SpEffectVfxParam {
    struct _SP_EFFECT_VFX_PARAM_ST data;
} SpEffectVfxParam;

#endif
