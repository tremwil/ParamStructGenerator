/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WorldMapPointParam_H
#define _PARAM_WorldMapPointParam_H
#pragma once
#include "defs/WORLD_MAP_POINT_PARAM_ST.h"

// Type: WORLD_MAP_POINT_PARAM_ST
typedef struct _WorldMapPointParam {
    struct _WORLD_MAP_POINT_PARAM_ST data;
} WorldMapPointParam;

#endif
