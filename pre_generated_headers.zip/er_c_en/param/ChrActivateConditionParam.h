/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ChrActivateConditionParam_H
#define _PARAM_ChrActivateConditionParam_H
#pragma once
#include "defs/CHR_ACTIVATE_CONDITION_PARAM_ST.h"

// Type: CHR_ACTIVATE_CONDITION_PARAM_ST
typedef struct _ChrActivateConditionParam {
    struct _CHR_ACTIVATE_CONDITION_PARAM_ST data;
} ChrActivateConditionParam;

#endif
