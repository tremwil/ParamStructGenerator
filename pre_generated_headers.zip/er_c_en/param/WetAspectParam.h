/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WetAspectParam_H
#define _PARAM_WetAspectParam_H
#pragma once
#include "defs/WET_ASPECT_PARAM_ST.h"

// Type: WET_ASPECT_PARAM_ST
typedef struct _WetAspectParam {
    struct _WET_ASPECT_PARAM_ST data;
} WetAspectParam;

#endif
