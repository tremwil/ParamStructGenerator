/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MultiHPEstusFlaskBonusParam_H
#define _PARAM_MultiHPEstusFlaskBonusParam_H
#pragma once
#include "defs/MULTI_ESTUS_FLASK_BONUS_PARAM_ST.h"

// Type: MULTI_ESTUS_FLASK_BONUS_PARAM_ST
typedef struct _MultiHPEstusFlaskBonusParam {
    struct _MULTI_ESTUS_FLASK_BONUS_PARAM_ST data;
} MultiHPEstusFlaskBonusParam;

#endif
