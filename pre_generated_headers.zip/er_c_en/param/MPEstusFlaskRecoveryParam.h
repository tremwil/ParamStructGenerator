/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MPEstusFlaskRecoveryParam_H
#define _PARAM_MPEstusFlaskRecoveryParam_H
#pragma once
#include "defs/ESTUS_FLASK_RECOVERY_PARAM_ST.h"

// Type: ESTUS_FLASK_RECOVERY_PARAM_ST
typedef struct _MPEstusFlaskRecoveryParam {
    struct _ESTUS_FLASK_RECOVERY_PARAM_ST data;
} MPEstusFlaskRecoveryParam;

#endif
