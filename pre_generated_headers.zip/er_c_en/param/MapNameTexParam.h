/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MapNameTexParam_H
#define _PARAM_MapNameTexParam_H
#pragma once
#include "defs/MAP_NAME_TEX_PARAM_ST.h"

// Type: MAP_NAME_TEX_PARAM_ST
typedef struct _MapNameTexParam {
    struct _MAP_NAME_TEX_PARAM_ST data;
} MapNameTexParam;

#endif
