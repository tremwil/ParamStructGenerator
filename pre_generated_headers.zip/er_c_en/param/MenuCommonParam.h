/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MenuCommonParam_H
#define _PARAM_MenuCommonParam_H
#pragma once
#include "defs/MENU_COMMON_PARAM_ST.h"

// Type: MENU_COMMON_PARAM_ST
typedef struct _MenuCommonParam {
    struct _MENU_COMMON_PARAM_ST data;
} MenuCommonParam;

#endif
