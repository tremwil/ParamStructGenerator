/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WeatherLotTexParam_H
#define _PARAM_WeatherLotTexParam_H
#pragma once
#include "defs/WEATHER_LOT_TEX_PARAM_ST.h"

// Type: WEATHER_LOT_TEX_PARAM_ST
typedef struct _WeatherLotTexParam {
    struct _WEATHER_LOT_TEX_PARAM_ST data;
} WeatherLotTexParam;

#endif
