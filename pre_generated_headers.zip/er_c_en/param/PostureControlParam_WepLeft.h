/* This file was automatically generated from regulation data. */
#ifndef _PARAM_PostureControlParam_WepLeft_H
#define _PARAM_PostureControlParam_WepLeft_H
#pragma once
#include "defs/POSTURE_CONTROL_PARAM_WEP_LEFT_ST.h"

// Type: POSTURE_CONTROL_PARAM_WEP_LEFT_ST
typedef struct _PostureControlParam_WepLeft {
    struct _POSTURE_CONTROL_PARAM_WEP_LEFT_ST data;
} PostureControlParam_WepLeft;

#endif
