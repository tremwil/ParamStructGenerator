/* This file was automatically generated from regulation data. */
#ifndef _PARAM_RideParam_H
#define _PARAM_RideParam_H
#pragma once
#include "defs/RIDE_PARAM_ST.h"

// Type: RIDE_PARAM_ST
typedef struct _RideParam {
    struct _RIDE_PARAM_ST data;
} RideParam;

#endif
