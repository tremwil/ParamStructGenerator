/* This file was automatically generated from regulation data. */
#ifndef _PARAM_BulletCreateLimitParam_H
#define _PARAM_BulletCreateLimitParam_H
#pragma once
#include "defs/BULLET_CREATE_LIMIT_PARAM_ST.h"

// Type: BULLET_CREATE_LIMIT_PARAM_ST
typedef struct _BulletCreateLimitParam {
    struct _BULLET_CREATE_LIMIT_PARAM_ST data;
} BulletCreateLimitParam;

#endif
