/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SoundCutsceneParam_H
#define _PARAM_SoundCutsceneParam_H
#pragma once
#include "defs/SOUND_CUTSCENE_PARAM_ST.h"

// Type: SOUND_CUTSCENE_PARAM_ST
typedef struct _SoundCutsceneParam {
    struct _SOUND_CUTSCENE_PARAM_ST data;
} SoundCutsceneParam;

#endif
