/* This file was automatically generated from regulation data. */
#ifndef _PARAM_CutsceneMapIdParam_H
#define _PARAM_CutsceneMapIdParam_H
#pragma once
#include "defs/CUTSCENE_MAP_ID_PARAM_ST.h"

// Type: CUTSCENE_MAP_ID_PARAM_ST
typedef struct _CutsceneMapIdParam {
    struct _CUTSCENE_MAP_ID_PARAM_ST data;
} CutsceneMapIdParam;

#endif
