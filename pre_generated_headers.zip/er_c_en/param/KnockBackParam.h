/* This file was automatically generated from regulation data. */
#ifndef _PARAM_KnockBackParam_H
#define _PARAM_KnockBackParam_H
#pragma once
#include "defs/KNOCKBACK_PARAM_ST.h"

// Type: KNOCKBACK_PARAM_ST
typedef struct _KnockBackParam {
    struct _KNOCKBACK_PARAM_ST data;
} KnockBackParam;

#endif
