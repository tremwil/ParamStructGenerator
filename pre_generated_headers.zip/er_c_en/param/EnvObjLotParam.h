/* This file was automatically generated from regulation data. */
#ifndef _PARAM_EnvObjLotParam_H
#define _PARAM_EnvObjLotParam_H
#pragma once
#include "defs/ENV_OBJ_LOT_PARAM_ST.h"

// Type: ENV_OBJ_LOT_PARAM_ST
typedef struct _EnvObjLotParam {
    struct _ENV_OBJ_LOT_PARAM_ST data;
} EnvObjLotParam;

#endif
