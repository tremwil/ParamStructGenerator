/* This file was automatically generated from regulation data. */
#ifndef _PARAM_LoadBalancerParam_H
#define _PARAM_LoadBalancerParam_H
#pragma once
#include "defs/LOAD_BALANCER_PARAM_ST.h"

// Type: LOAD_BALANCER_PARAM_ST
typedef struct _LoadBalancerParam {
    struct _LOAD_BALANCER_PARAM_ST data;
} LoadBalancerParam;

#endif
