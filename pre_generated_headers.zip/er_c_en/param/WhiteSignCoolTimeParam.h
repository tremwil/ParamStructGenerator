/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WhiteSignCoolTimeParam_H
#define _PARAM_WhiteSignCoolTimeParam_H
#pragma once
#include "defs/WHITE_SIGN_COOL_TIME_PARAM_ST.h"

// Type: WHITE_SIGN_COOL_TIME_PARAM_ST
typedef struct _WhiteSignCoolTimeParam {
    struct _WHITE_SIGN_COOL_TIME_PARAM_ST data;
} WhiteSignCoolTimeParam;

#endif
