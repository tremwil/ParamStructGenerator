/* This file was automatically generated from regulation data. */
#ifndef _PARAM_HitEffectSeParam_H
#define _PARAM_HitEffectSeParam_H
#pragma once
#include "defs/HIT_EFFECT_SE_PARAM_ST.h"

// Type: HIT_EFFECT_SE_PARAM_ST
typedef struct _HitEffectSeParam {
    struct _HIT_EFFECT_SE_PARAM_ST data;
} HitEffectSeParam;

#endif
