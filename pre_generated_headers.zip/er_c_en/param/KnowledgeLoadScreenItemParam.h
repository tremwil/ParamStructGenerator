/* This file was automatically generated from regulation data. */
#ifndef _PARAM_KnowledgeLoadScreenItemParam_H
#define _PARAM_KnowledgeLoadScreenItemParam_H
#pragma once
#include "defs/KNOWLEDGE_LOADSCREEN_ITEM_PARAM_ST.h"

// Type: KNOWLEDGE_LOADSCREEN_ITEM_PARAM_ST
typedef struct _KnowledgeLoadScreenItemParam {
    struct _KNOWLEDGE_LOADSCREEN_ITEM_PARAM_ST data;
} KnowledgeLoadScreenItemParam;

#endif
