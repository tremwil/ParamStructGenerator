/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ItemLotParam_enemy_H
#define _PARAM_ItemLotParam_enemy_H
#pragma once
#include "defs/ITEMLOT_PARAM_ST.h"

// Type: ITEMLOT_PARAM_ST
typedef struct _ItemLotParam_enemy {
    struct _ITEMLOT_PARAM_ST data;
} ItemLotParam_enemy;

#endif
