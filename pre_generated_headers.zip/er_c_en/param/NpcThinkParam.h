/* This file was automatically generated from regulation data. */
#ifndef _PARAM_NpcThinkParam_H
#define _PARAM_NpcThinkParam_H
#pragma once
#include "defs/NPC_THINK_PARAM_ST.h"

// Type: NPC_THINK_PARAM_ST
typedef struct _NpcThinkParam {
    struct _NPC_THINK_PARAM_ST data;
} NpcThinkParam;

#endif
