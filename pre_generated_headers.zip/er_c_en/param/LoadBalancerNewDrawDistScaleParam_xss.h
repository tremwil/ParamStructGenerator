/* This file was automatically generated from regulation data. */
#ifndef _PARAM_LoadBalancerNewDrawDistScaleParam_xss_H
#define _PARAM_LoadBalancerNewDrawDistScaleParam_xss_H
#pragma once
#include "defs/LOAD_BALANCER_NEW_DRAW_DIST_SCALE_PARAM_ST.h"

// Type: LOAD_BALANCER_NEW_DRAW_DIST_SCALE_PARAM_ST
typedef struct _LoadBalancerNewDrawDistScaleParam_xss {
    struct _LOAD_BALANCER_NEW_DRAW_DIST_SCALE_PARAM_ST data;
} LoadBalancerNewDrawDistScaleParam_xss;

#endif
