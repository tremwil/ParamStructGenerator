/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SoundChrPhysicsSeParam_H
#define _PARAM_SoundChrPhysicsSeParam_H
#pragma once
#include "defs/SOUND_CHR_PHYSICS_SE_PARAM_ST.h"

// Type: SOUND_CHR_PHYSICS_SE_PARAM_ST
typedef struct _SoundChrPhysicsSeParam {
    struct _SOUND_CHR_PHYSICS_SE_PARAM_ST data;
} SoundChrPhysicsSeParam;

#endif
