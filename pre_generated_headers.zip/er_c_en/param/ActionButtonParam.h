/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ActionButtonParam_H
#define _PARAM_ActionButtonParam_H
#pragma once
#include "defs/ACTIONBUTTON_PARAM_ST.h"

// Type: ACTIONBUTTON_PARAM_ST
typedef struct _ActionButtonParam {
    struct _ACTIONBUTTON_PARAM_ST data;
} ActionButtonParam;

#endif
