/* This file was automatically generated from regulation data. */
#ifndef _PARAM_FaceRangeParam_H
#define _PARAM_FaceRangeParam_H
#pragma once
#include "defs/FACE_RANGE_PARAM_ST.h"

// Type: FACE_RANGE_PARAM_ST
typedef struct _FaceRangeParam {
    struct _FACE_RANGE_PARAM_ST data;
} FaceRangeParam;

#endif
