/* This file was automatically generated from regulation data. */
#ifndef _PARAM_KeyAssignParam_TypeA_H
#define _PARAM_KeyAssignParam_TypeA_H
#pragma once
#include "defs/KEY_ASSIGN_PARAM_ST.h"

// Type: KEY_ASSIGN_PARAM_ST
typedef struct _KeyAssignParam_TypeA {
    struct _KEY_ASSIGN_PARAM_ST data;
} KeyAssignParam_TypeA;

#endif
