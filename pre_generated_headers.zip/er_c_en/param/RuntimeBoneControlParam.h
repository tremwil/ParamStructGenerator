/* This file was automatically generated from regulation data. */
#ifndef _PARAM_RuntimeBoneControlParam_H
#define _PARAM_RuntimeBoneControlParam_H
#pragma once
#include "defs/RUNTIME_BONE_CONTROL_PARAM_ST.h"

// Type: RUNTIME_BONE_CONTROL_PARAM_ST
typedef struct _RuntimeBoneControlParam {
    struct _RUNTIME_BONE_CONTROL_PARAM_ST data;
} RuntimeBoneControlParam;

#endif
