/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MultiPlayCorrectionParam_H
#define _PARAM_MultiPlayCorrectionParam_H
#pragma once
#include "defs/MULTI_PLAY_CORRECTION_PARAM_ST.h"

// Type: MULTI_PLAY_CORRECTION_PARAM_ST
typedef struct _MultiPlayCorrectionParam {
    struct _MULTI_PLAY_CORRECTION_PARAM_ST data;
} MultiPlayCorrectionParam;

#endif
