/* This file was automatically generated from regulation data. */
#ifndef _PARAM_BuddyParam_H
#define _PARAM_BuddyParam_H
#pragma once
#include "defs/BUDDY_PARAM_ST.h"

// Type: BUDDY_PARAM_ST
typedef struct _BuddyParam {
    struct _BUDDY_PARAM_ST data;
} BuddyParam;

#endif
