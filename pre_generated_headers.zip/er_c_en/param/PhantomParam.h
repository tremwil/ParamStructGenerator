/* This file was automatically generated from regulation data. */
#ifndef _PARAM_PhantomParam_H
#define _PARAM_PhantomParam_H
#pragma once
#include "defs/PHANTOM_PARAM_ST.h"

// Type: PHANTOM_PARAM_ST
typedef struct _PhantomParam {
    struct _PHANTOM_PARAM_ST data;
} PhantomParam;

#endif
