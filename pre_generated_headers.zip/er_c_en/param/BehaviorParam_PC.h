/* This file was automatically generated from regulation data. */
#ifndef _PARAM_BehaviorParam_PC_H
#define _PARAM_BehaviorParam_PC_H
#pragma once
#include "defs/BEHAVIOR_PARAM_ST.h"

// Type: BEHAVIOR_PARAM_ST
typedef struct _BehaviorParam_PC {
    struct _BEHAVIOR_PARAM_ST data;
} BehaviorParam_PC;

#endif
