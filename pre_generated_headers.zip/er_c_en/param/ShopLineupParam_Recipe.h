/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ShopLineupParam_Recipe_H
#define _PARAM_ShopLineupParam_Recipe_H
#pragma once
#include "defs/SHOP_LINEUP_PARAM.h"

// Type: SHOP_LINEUP_PARAM
typedef struct _ShopLineupParam_Recipe {
    struct _SHOP_LINEUP_PARAM data;
} ShopLineupParam_Recipe;

#endif
