/* This file was automatically generated from regulation data. */
#ifndef _PARAM_BonfireWarpParam_H
#define _PARAM_BonfireWarpParam_H
#pragma once
#include "defs/BONFIRE_WARP_PARAM_ST.h"

// Type: BONFIRE_WARP_PARAM_ST
typedef struct _BonfireWarpParam {
    struct _BONFIRE_WARP_PARAM_ST data;
} BonfireWarpParam;

#endif
