/* This file was automatically generated from regulation data. */
#ifndef _PARAM_AutoCreateEnvSoundParam_H
#define _PARAM_AutoCreateEnvSoundParam_H
#pragma once
#include "defs/AUTO_CREATE_ENV_SOUND_PARAM_ST.h"

// Type: AUTO_CREATE_ENV_SOUND_PARAM_ST
typedef struct _AutoCreateEnvSoundParam {
    struct _AUTO_CREATE_ENV_SOUND_PARAM_ST data;
} AutoCreateEnvSoundParam;

#endif
