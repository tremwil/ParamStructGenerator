/* This file was automatically generated from regulation data. */
#ifndef _PARAM_BonfireWarpTabParam_H
#define _PARAM_BonfireWarpTabParam_H
#pragma once
#include "defs/BONFIRE_WARP_TAB_PARAM_ST.h"

// Type: BONFIRE_WARP_TAB_PARAM_ST
typedef struct _BonfireWarpTabParam {
    struct _BONFIRE_WARP_TAB_PARAM_ST data;
} BonfireWarpTabParam;

#endif
