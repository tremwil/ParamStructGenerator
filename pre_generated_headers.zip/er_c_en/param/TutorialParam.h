/* This file was automatically generated from regulation data. */
#ifndef _PARAM_TutorialParam_H
#define _PARAM_TutorialParam_H
#pragma once
#include "defs/TUTORIAL_PARAM_ST.h"

// Type: TUTORIAL_PARAM_ST
typedef struct _TutorialParam {
    struct _TUTORIAL_PARAM_ST data;
} TutorialParam;

#endif
