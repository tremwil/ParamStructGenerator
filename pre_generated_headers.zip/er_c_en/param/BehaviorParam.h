/* This file was automatically generated from regulation data. */
#ifndef _PARAM_BehaviorParam_H
#define _PARAM_BehaviorParam_H
#pragma once
#include "defs/BEHAVIOR_PARAM_ST.h"

// Type: BEHAVIOR_PARAM_ST
typedef struct _BehaviorParam {
    struct _BEHAVIOR_PARAM_ST data;
} BehaviorParam;

#endif
