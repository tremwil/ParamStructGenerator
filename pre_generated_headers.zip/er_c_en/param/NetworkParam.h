/* This file was automatically generated from regulation data. */
#ifndef _PARAM_NetworkParam_H
#define _PARAM_NetworkParam_H
#pragma once
#include "defs/NETWORK_PARAM_ST.h"

// Type: NETWORK_PARAM_ST
typedef struct _NetworkParam {
    struct _NETWORK_PARAM_ST data;
} NetworkParam;

#endif
