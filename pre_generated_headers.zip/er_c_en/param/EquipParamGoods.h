/* This file was automatically generated from regulation data. */
#ifndef _PARAM_EquipParamGoods_H
#define _PARAM_EquipParamGoods_H
#pragma once
#include "defs/EQUIP_PARAM_GOODS_ST.h"

// Type: EQUIP_PARAM_GOODS_ST
typedef struct _EquipParamGoods {
    struct _EQUIP_PARAM_GOODS_ST data;
} EquipParamGoods;

#endif
