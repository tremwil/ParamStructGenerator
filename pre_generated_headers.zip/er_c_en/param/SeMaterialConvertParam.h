/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SeMaterialConvertParam_H
#define _PARAM_SeMaterialConvertParam_H
#pragma once
#include "defs/SE_MATERIAL_CONVERT_PARAM_ST.h"

// Type: SE_MATERIAL_CONVERT_PARAM_ST
typedef struct _SeMaterialConvertParam {
    struct _SE_MATERIAL_CONVERT_PARAM_ST data;
} SeMaterialConvertParam;

#endif
