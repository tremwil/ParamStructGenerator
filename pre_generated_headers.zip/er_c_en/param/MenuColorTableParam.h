/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MenuColorTableParam_H
#define _PARAM_MenuColorTableParam_H
#pragma once
#include "defs/MENU_PARAM_COLOR_TABLE_ST.h"

// Type: MENU_PARAM_COLOR_TABLE_ST
typedef struct _MenuColorTableParam {
    struct _MENU_PARAM_COLOR_TABLE_ST data;
} MenuColorTableParam;

#endif
