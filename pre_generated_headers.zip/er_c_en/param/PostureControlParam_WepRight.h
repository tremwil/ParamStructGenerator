/* This file was automatically generated from regulation data. */
#ifndef _PARAM_PostureControlParam_WepRight_H
#define _PARAM_PostureControlParam_WepRight_H
#pragma once
#include "defs/POSTURE_CONTROL_PARAM_WEP_RIGHT_ST.h"

// Type: POSTURE_CONTROL_PARAM_WEP_RIGHT_ST
typedef struct _PostureControlParam_WepRight {
    struct _POSTURE_CONTROL_PARAM_WEP_RIGHT_ST data;
} PostureControlParam_WepRight;

#endif
