/* This file was automatically generated from regulation data. */
#ifndef _PARAM_EquipParamGem_H
#define _PARAM_EquipParamGem_H
#pragma once
#include "defs/EQUIP_PARAM_GEM_ST.h"

// Type: EQUIP_PARAM_GEM_ST
typedef struct _EquipParamGem {
    struct _EQUIP_PARAM_GEM_ST data;
} EquipParamGem;

#endif
