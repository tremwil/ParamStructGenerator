/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WorldMapLegacyConvParam_H
#define _PARAM_WorldMapLegacyConvParam_H
#pragma once
#include "defs/WORLD_MAP_LEGACY_CONV_PARAM_ST.h"

// Type: WORLD_MAP_LEGACY_CONV_PARAM_ST
typedef struct _WorldMapLegacyConvParam {
    struct _WORLD_MAP_LEGACY_CONV_PARAM_ST data;
} WorldMapLegacyConvParam;

#endif
