/* This file was automatically generated from regulation data. */
#ifndef _PARAM_LoadBalancerDrawDistScaleParam_xb1_H
#define _PARAM_LoadBalancerDrawDistScaleParam_xb1_H
#pragma once
#include "defs/LOAD_BALANCER_DRAW_DIST_SCALE_PARAM_ST.h"

// Type: LOAD_BALANCER_DRAW_DIST_SCALE_PARAM_ST
typedef struct _LoadBalancerDrawDistScaleParam_xb1 {
    struct _LOAD_BALANCER_DRAW_DIST_SCALE_PARAM_ST data;
} LoadBalancerDrawDistScaleParam_xb1;

#endif
