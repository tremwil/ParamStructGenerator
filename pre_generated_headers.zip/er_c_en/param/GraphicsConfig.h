/* This file was automatically generated from regulation data. */
#ifndef _PARAM_GraphicsConfig_H
#define _PARAM_GraphicsConfig_H
#pragma once
#include "defs/CS_GRAPHICS_CONFIG_PARAM_ST.h"

// Type: CS_GRAPHICS_CONFIG_PARAM_ST
typedef struct _GraphicsConfig {
    struct _CS_GRAPHICS_CONFIG_PARAM_ST data;
} GraphicsConfig;

#endif
