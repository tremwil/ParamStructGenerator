/* This file was automatically generated from regulation data. */
#ifndef _PARAM_AssetModelSfxParam_H
#define _PARAM_AssetModelSfxParam_H
#pragma once
#include "defs/ASSET_MODEL_SFX_PARAM_ST.h"

// Type: ASSET_MODEL_SFX_PARAM_ST
typedef struct _AssetModelSfxParam {
    struct _ASSET_MODEL_SFX_PARAM_ST data;
} AssetModelSfxParam;

#endif
