/* This file was automatically generated from regulation data. */
#ifndef _PARAM_GestureParam_H
#define _PARAM_GestureParam_H
#pragma once
#include "defs/GESTURE_PARAM_ST.h"

// Type: GESTURE_PARAM_ST
typedef struct _GestureParam {
    struct _GESTURE_PARAM_ST data;
} GestureParam;

#endif
