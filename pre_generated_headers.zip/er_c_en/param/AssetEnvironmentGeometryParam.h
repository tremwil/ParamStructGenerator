/* This file was automatically generated from regulation data. */
#ifndef _PARAM_AssetEnvironmentGeometryParam_H
#define _PARAM_AssetEnvironmentGeometryParam_H
#pragma once
#include "defs/ASSET_GEOMETORY_PARAM_ST.h"

// Type: ASSET_GEOMETORY_PARAM_ST
typedef struct _AssetEnvironmentGeometryParam {
    struct _ASSET_GEOMETORY_PARAM_ST data;
} AssetEnvironmentGeometryParam;

#endif
