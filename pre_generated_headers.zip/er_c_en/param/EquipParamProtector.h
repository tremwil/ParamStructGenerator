/* This file was automatically generated from regulation data. */
#ifndef _PARAM_EquipParamProtector_H
#define _PARAM_EquipParamProtector_H
#pragma once
#include "defs/EQUIP_PARAM_PROTECTOR_ST.h"

// Type: EQUIP_PARAM_PROTECTOR_ST
typedef struct _EquipParamProtector {
    struct _EQUIP_PARAM_PROTECTOR_ST data;
} EquipParamProtector;

#endif
