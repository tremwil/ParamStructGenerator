/* This file was automatically generated from regulation data. */
#ifndef _PARAM_WorldMapPieceParam_H
#define _PARAM_WorldMapPieceParam_H
#pragma once
#include "defs/WORLD_MAP_PIECE_PARAM_ST.h"

// Type: WORLD_MAP_PIECE_PARAM_ST
typedef struct _WorldMapPieceParam {
    struct _WORLD_MAP_PIECE_PARAM_ST data;
} WorldMapPieceParam;

#endif
