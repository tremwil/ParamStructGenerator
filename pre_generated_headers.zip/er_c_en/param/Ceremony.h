/* This file was automatically generated from regulation data. */
#ifndef _PARAM_Ceremony_H
#define _PARAM_Ceremony_H
#pragma once
#include "defs/CEREMONY_PARAM_ST.h"

// Type: CEREMONY_PARAM_ST
typedef struct _Ceremony {
    struct _CEREMONY_PARAM_ST data;
} Ceremony;

#endif
