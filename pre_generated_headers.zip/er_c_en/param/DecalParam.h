/* This file was automatically generated from regulation data. */
#ifndef _PARAM_DecalParam_H
#define _PARAM_DecalParam_H
#pragma once
#include "defs/DECAL_PARAM_ST.h"

// Type: DECAL_PARAM_ST
typedef struct _DecalParam {
    struct _DECAL_PARAM_ST data;
} DecalParam;

#endif
