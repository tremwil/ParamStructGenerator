/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SoundAutoReverbEvaluationDistParam_H
#define _PARAM_SoundAutoReverbEvaluationDistParam_H
#pragma once
#include "defs/SOUND_AUTO_REVERB_EVALUATION_DIST_PARAM_ST.h"

// Type: SOUND_AUTO_REVERB_EVALUATION_DIST_PARAM_ST
typedef struct _SoundAutoReverbEvaluationDistParam {
    struct _SOUND_AUTO_REVERB_EVALUATION_DIST_PARAM_ST data;
} SoundAutoReverbEvaluationDistParam;

#endif
