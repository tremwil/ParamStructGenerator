/* This file was automatically generated from regulation data. */
#ifndef _PARAM_AtkParam_Pc_H
#define _PARAM_AtkParam_Pc_H
#pragma once
#include "defs/ATK_PARAM_ST.h"

// Type: ATK_PARAM_ST
typedef struct _AtkParam_Pc {
    struct _ATK_PARAM_ST data;
} AtkParam_Pc;

#endif
