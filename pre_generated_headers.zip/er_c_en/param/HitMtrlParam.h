/* This file was automatically generated from regulation data. */
#ifndef _PARAM_HitMtrlParam_H
#define _PARAM_HitMtrlParam_H
#pragma once
#include "defs/HIT_MTRL_PARAM_ST.h"

// Type: HIT_MTRL_PARAM_ST
typedef struct _HitMtrlParam {
    struct _HIT_MTRL_PARAM_ST data;
} HitMtrlParam;

#endif
