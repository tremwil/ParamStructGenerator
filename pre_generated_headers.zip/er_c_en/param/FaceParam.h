/* This file was automatically generated from regulation data. */
#ifndef _PARAM_FaceParam_H
#define _PARAM_FaceParam_H
#pragma once
#include "defs/FACE_PARAM_ST.h"

// Type: FACE_PARAM_ST
typedef struct _FaceParam {
    struct _FACE_PARAM_ST data;
} FaceParam;

#endif
