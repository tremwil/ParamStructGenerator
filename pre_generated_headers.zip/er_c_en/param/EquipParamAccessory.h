/* This file was automatically generated from regulation data. */
#ifndef _PARAM_EquipParamAccessory_H
#define _PARAM_EquipParamAccessory_H
#pragma once
#include "defs/EQUIP_PARAM_ACCESSORY_ST.h"

// Type: EQUIP_PARAM_ACCESSORY_ST
typedef struct _EquipParamAccessory {
    struct _EQUIP_PARAM_ACCESSORY_ST data;
} EquipParamAccessory;

#endif
