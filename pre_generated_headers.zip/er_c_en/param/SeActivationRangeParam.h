/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SeActivationRangeParam_H
#define _PARAM_SeActivationRangeParam_H
#pragma once
#include "defs/SE_ACTIVATION_RANGE_PARAM_ST.h"

// Type: SE_ACTIVATION_RANGE_PARAM_ST
typedef struct _SeActivationRangeParam {
    struct _SE_ACTIVATION_RANGE_PARAM_ST data;
} SeActivationRangeParam;

#endif
