/* This file was automatically generated from regulation data. */
#ifndef _PARAM_TalkParam_H
#define _PARAM_TalkParam_H
#pragma once
#include "defs/TALK_PARAM_ST.h"

// Type: TALK_PARAM_ST
typedef struct _TalkParam {
    struct _TALK_PARAM_ST data;
} TalkParam;

#endif
