/* This file was automatically generated from regulation data. */
#ifndef _PARAM_CutsceneGparamWeatherParam_H
#define _PARAM_CutsceneGparamWeatherParam_H
#pragma once
#include "defs/CUTSCENE_GPARAM_WEATHER_PARAM_ST.h"

// Type: CUTSCENE_GPARAM_WEATHER_PARAM_ST
typedef struct _CutsceneGparamWeatherParam {
    struct _CUTSCENE_GPARAM_WEATHER_PARAM_ST data;
} CutsceneGparamWeatherParam;

#endif
