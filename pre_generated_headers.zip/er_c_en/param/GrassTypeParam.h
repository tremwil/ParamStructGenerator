/* This file was automatically generated from regulation data. */
#ifndef _PARAM_GrassTypeParam_H
#define _PARAM_GrassTypeParam_H
#pragma once
#include "defs/GRASS_TYPE_PARAM_ST.h"

// Type: GRASS_TYPE_PARAM_ST
typedef struct _GrassTypeParam {
    struct _GRASS_TYPE_PARAM_ST data;
} GrassTypeParam;

#endif
