/* This file was automatically generated from regulation data. */
#ifndef _PARAM_GameAreaParam_H
#define _PARAM_GameAreaParam_H
#pragma once
#include "defs/GAME_AREA_PARAM_ST.h"

// Type: GAME_AREA_PARAM_ST
typedef struct _GameAreaParam {
    struct _GAME_AREA_PARAM_ST data;
} GameAreaParam;

#endif
