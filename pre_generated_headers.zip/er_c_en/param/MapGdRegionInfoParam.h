/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MapGdRegionInfoParam_H
#define _PARAM_MapGdRegionInfoParam_H
#pragma once
#include "defs/MAP_GD_REGION_ID_PARAM_ST.h"

// Type: MAP_GD_REGION_ID_PARAM_ST
typedef struct _MapGdRegionInfoParam {
    struct _MAP_GD_REGION_ID_PARAM_ST data;
} MapGdRegionInfoParam;

#endif
