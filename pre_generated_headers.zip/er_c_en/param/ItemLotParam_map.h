/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ItemLotParam_map_H
#define _PARAM_ItemLotParam_map_H
#pragma once
#include "defs/ITEMLOT_PARAM_ST.h"

// Type: ITEMLOT_PARAM_ST
typedef struct _ItemLotParam_map {
    struct _ITEMLOT_PARAM_ST data;
} ItemLotParam_map;

#endif
