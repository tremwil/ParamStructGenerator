/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ClearCountCorrectParam_H
#define _PARAM_ClearCountCorrectParam_H
#pragma once
#include "defs/CLEAR_COUNT_CORRECT_PARAM_ST.h"

// Type: CLEAR_COUNT_CORRECT_PARAM_ST
typedef struct _ClearCountCorrectParam {
    struct _CLEAR_COUNT_CORRECT_PARAM_ST data;
} ClearCountCorrectParam;

#endif
