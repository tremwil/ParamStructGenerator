/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ThrowDirectionSfxParam_H
#define _PARAM_ThrowDirectionSfxParam_H
#pragma once
#include "defs/THROW_DIRECTION_SFX_PARAM_ST.h"

// Type: THROW_DIRECTION_SFX_PARAM_ST
typedef struct _ThrowDirectionSfxParam {
    struct _THROW_DIRECTION_SFX_PARAM_ST data;
} ThrowDirectionSfxParam;

#endif
