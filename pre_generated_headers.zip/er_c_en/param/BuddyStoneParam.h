/* This file was automatically generated from regulation data. */
#ifndef _PARAM_BuddyStoneParam_H
#define _PARAM_BuddyStoneParam_H
#pragma once
#include "defs/BUDDY_STONE_PARAM_ST.h"

// Type: BUDDY_STONE_PARAM_ST
typedef struct _BuddyStoneParam {
    struct _BUDDY_STONE_PARAM_ST data;
} BuddyStoneParam;

#endif
