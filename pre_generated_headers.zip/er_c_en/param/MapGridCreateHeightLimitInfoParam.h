/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MapGridCreateHeightLimitInfoParam_H
#define _PARAM_MapGridCreateHeightLimitInfoParam_H
#pragma once
#include "defs/MAP_GRID_CREATE_HEIGHT_LIMIT_INFO_PARAM_ST.h"

// Type: MAP_GRID_CREATE_HEIGHT_LIMIT_INFO_PARAM_ST
typedef struct _MapGridCreateHeightLimitInfoParam {
    struct _MAP_GRID_CREATE_HEIGHT_LIMIT_INFO_PARAM_ST data;
} MapGridCreateHeightLimitInfoParam;

#endif
