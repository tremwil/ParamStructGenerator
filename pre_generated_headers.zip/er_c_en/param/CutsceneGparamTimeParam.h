/* This file was automatically generated from regulation data. */
#ifndef _PARAM_CutsceneGparamTimeParam_H
#define _PARAM_CutsceneGparamTimeParam_H
#pragma once
#include "defs/CUTSCENE_GPARAM_TIME_PARAM_ST.h"

// Type: CUTSCENE_GPARAM_TIME_PARAM_ST
typedef struct _CutsceneGparamTimeParam {
    struct _CUTSCENE_GPARAM_TIME_PARAM_ST data;
} CutsceneGparamTimeParam;

#endif
