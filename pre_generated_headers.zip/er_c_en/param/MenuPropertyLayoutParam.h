/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MenuPropertyLayoutParam_H
#define _PARAM_MenuPropertyLayoutParam_H
#pragma once
#include "defs/MENUPROPERTY_LAYOUT.h"

// Type: MENUPROPERTY_LAYOUT
typedef struct _MenuPropertyLayoutParam {
    struct _MENUPROPERTY_LAYOUT data;
} MenuPropertyLayoutParam;

#endif
