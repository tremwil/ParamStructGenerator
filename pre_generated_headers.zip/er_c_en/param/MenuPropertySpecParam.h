/* This file was automatically generated from regulation data. */
#ifndef _PARAM_MenuPropertySpecParam_H
#define _PARAM_MenuPropertySpecParam_H
#pragma once
#include "defs/MENUPROPERTY_SPEC.h"

// Type: MENUPROPERTY_SPEC
typedef struct _MenuPropertySpecParam {
    struct _MENUPROPERTY_SPEC data;
} MenuPropertySpecParam;

#endif
