/* This file was automatically generated from regulation data. */
#ifndef _PARAM_AttackElementCorrectParam_H
#define _PARAM_AttackElementCorrectParam_H
#pragma once
#include "defs/ATTACK_ELEMENT_CORRECT_PARAM_ST.h"

// Type: ATTACK_ELEMENT_CORRECT_PARAM_ST
typedef struct _AttackElementCorrectParam {
    struct _ATTACK_ELEMENT_CORRECT_PARAM_ST data;
} AttackElementCorrectParam;

#endif
