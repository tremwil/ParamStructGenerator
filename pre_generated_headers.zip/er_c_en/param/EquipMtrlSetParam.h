/* This file was automatically generated from regulation data. */
#ifndef _PARAM_EquipMtrlSetParam_H
#define _PARAM_EquipMtrlSetParam_H
#pragma once
#include "defs/EQUIP_MTRL_SET_PARAM_ST.h"

// Type: EQUIP_MTRL_SET_PARAM_ST
typedef struct _EquipMtrlSetParam {
    struct _EQUIP_MTRL_SET_PARAM_ST data;
} EquipMtrlSetParam;

#endif
