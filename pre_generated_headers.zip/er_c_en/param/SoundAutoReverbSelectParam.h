/* This file was automatically generated from regulation data. */
#ifndef _PARAM_SoundAutoReverbSelectParam_H
#define _PARAM_SoundAutoReverbSelectParam_H
#pragma once
#include "defs/SOUND_AUTO_REVERB_SELECT_PARAM_ST.h"

// Type: SOUND_AUTO_REVERB_SELECT_PARAM_ST
typedef struct _SoundAutoReverbSelectParam {
    struct _SOUND_AUTO_REVERB_SELECT_PARAM_ST data;
} SoundAutoReverbSelectParam;

#endif
