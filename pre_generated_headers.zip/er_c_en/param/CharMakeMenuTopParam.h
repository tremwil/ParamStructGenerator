/* This file was automatically generated from regulation data. */
#ifndef _PARAM_CharMakeMenuTopParam_H
#define _PARAM_CharMakeMenuTopParam_H
#pragma once
#include "defs/CHARMAKEMENUTOP_PARAM_ST.h"

// Type: CHARMAKEMENUTOP_PARAM_ST
typedef struct _CharMakeMenuTopParam {
    struct _CHARMAKEMENUTOP_PARAM_ST data;
} CharMakeMenuTopParam;

#endif
