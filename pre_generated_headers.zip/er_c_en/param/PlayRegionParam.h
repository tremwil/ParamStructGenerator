/* This file was automatically generated from regulation data. */
#ifndef _PARAM_PlayRegionParam_H
#define _PARAM_PlayRegionParam_H
#pragma once
#include "defs/PLAY_REGION_PARAM_ST.h"

// Type: PLAY_REGION_PARAM_ST
typedef struct _PlayRegionParam {
    struct _PLAY_REGION_PARAM_ST data;
} PlayRegionParam;

#endif
