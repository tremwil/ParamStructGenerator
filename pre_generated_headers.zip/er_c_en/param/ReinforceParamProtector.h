/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ReinforceParamProtector_H
#define _PARAM_ReinforceParamProtector_H
#pragma once
#include "defs/REINFORCE_PARAM_PROTECTOR_ST.h"

// Type: REINFORCE_PARAM_PROTECTOR_ST
typedef struct _ReinforceParamProtector {
    struct _REINFORCE_PARAM_PROTECTOR_ST data;
} ReinforceParamProtector;

#endif
