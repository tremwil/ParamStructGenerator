/* This file was automatically generated from regulation data. */
#ifndef _PARAM_RandomAppearParam_H
#define _PARAM_RandomAppearParam_H
#pragma once
#include "defs/RANDOM_APPEAR_PARAM_ST.h"

// Type: RANDOM_APPEAR_PARAM_ST
typedef struct _RandomAppearParam {
    struct _RANDOM_APPEAR_PARAM_ST data;
} RandomAppearParam;

#endif
