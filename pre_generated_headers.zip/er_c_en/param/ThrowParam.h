/* This file was automatically generated from regulation data. */
#ifndef _PARAM_ThrowParam_H
#define _PARAM_ThrowParam_H
#pragma once
#include "defs/THROW_PARAM_ST.h"

// Type: THROW_PARAM_ST
typedef struct _ThrowParam {
    struct _THROW_PARAM_ST data;
} ThrowParam;

#endif
